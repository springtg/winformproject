using System;
using System.Security.Cryptography;
using System.Text;
using System.IO;
using System.Threading;
using System.Globalization;
using System.Diagnostics;
using PallaControls.Utilities.CoreHelpers;

namespace PallaControls.Utilities.Security
{
	public class SymmetricEncryption
	{
		#region PallaControlsSymmetricSecretKey

		public const string PallaControlsSymmetricSecretKey = "kjhfd9876435365&%$^#%@$#@)_(),kxa;l fddfgdf12[]}{}{)(*XCJHG^%%";

		#endregion 
		
		private string m_sPassPhrase;
		private byte[] mbytKey;
		private byte[] mbytIV;
		private bool mbKeyIsSet = false;
		private string mksKeyNotSetException = "Chave para criptografia n�o configurada.";
		private string mksPassphraseTooSmall = "Chave para criptografia deve ter ao menos {0} caracteres.";
		
		#region Constructors
		
		public SymmetricEncryption()
		{
		}

		public SymmetricEncryption(string cryptoPassPhrase)
		{
			PassPhrase = cryptoPassPhrase;
		}

		#endregion

		#region Properties

		public string PassPhrase
		{
			get
			{
				return this.m_sPassPhrase;
			}
			set
			{
				const int iMinLength = -1;
				m_sPassPhrase = value.Trim();

				if (value.Length > iMinLength || iMinLength == -1) 
				{
					SHA256Managed sha2 = new SHA256Managed();
					mbytKey = sha2.ComputeHash(CommonHelpers.BytesFromString(m_sPassPhrase));
					string sKey = Convert.ToBase64String(mbytKey);
					mbytIV = Encoding.ASCII.GetBytes(sKey.Remove(0, sKey.Length - 16));
					mbKeyIsSet = true;
					sha2 = null;
				}
				else
				{
					mbKeyIsSet = false;
					throw new Exception(String.Format(mksPassphraseTooSmall, (iMinLength + 1).ToString()));
				}
			}
		}

		#endregion

		#region Methods

		public bool DecryptFile(string targetFile)
		{
			if (mbKeyIsSet)
				return decryptFile(targetFile, targetFile);
			else
			{ 
				throw new Exception(mksKeyNotSetException);
			}
		}

		public bool DecryptFile(string encryptedFile, string plainFile)
		{
			if (mbKeyIsSet)
				return decryptFile(encryptedFile, plainFile);
			else
				throw new Exception(mksKeyNotSetException);
		}

		public MemoryStream DecryptStream(MemoryStream encryptedStream)
		{
			if (mbKeyIsSet)
			{
				try
				{
					RijndaelManaged oCSP = new RijndaelManaged();
					oCSP.Key = mbytKey;
					oCSP.IV = mbytIV;
					ICryptoTransform ct = oCSP.CreateDecryptor();
					CryptoStream cs = new CryptoStream(encryptedStream, ct, CryptoStreamMode.Read);
					byte[] byteArray = new byte[encryptedStream.Length];
					int iBytesIn = cs.Read(byteArray, 0, (int)encryptedStream.Length);
					cs.Close();
					MemoryStream plainStream = new MemoryStream();
					plainStream.Write(byteArray, 0, iBytesIn);
					return plainStream;
				}
				catch (Exception ex)
				{
					Debug.WriteLine(ex.ToString());
					return null;
				}
			}
			else
			{
				throw new Exception(mksKeyNotSetException);
			}
		}

		public string DecryptString(string encryptedString)
		{
			if (mbKeyIsSet)
				return decryptString(encryptedString, true);
			else
				throw new Exception(mksKeyNotSetException);
		}

		public string DecryptString(string encryptedString, bool base64)
		{
			if (mbKeyIsSet)
				return decryptString(encryptedString, base64);
			else
				throw new Exception(mksKeyNotSetException);
		}

		public string EncryptString(string plainString)
		{
			if (mbKeyIsSet)
				return encryptString(plainString, true);
			else
				throw new Exception(mksKeyNotSetException);
		}

		public string EncryptString(string plainString, bool base64)
		{
			if (mbKeyIsSet)
				return encryptString(plainString, base64);
			else
				throw new Exception(mksKeyNotSetException);
		}

		public bool EncryptFile(string targetFile)
		{
			if (mbKeyIsSet)
				return encryptFile(targetFile, targetFile);
			else
			{
				throw new Exception(mksKeyNotSetException);
			}
		}
																													  
		public bool EncryptFile(string plainFile, string targetFile)
		{
			if (mbKeyIsSet)
				return encryptFile(plainFile, targetFile);
			else
			{
				throw new Exception(mksKeyNotSetException);
			}
		}

		public MemoryStream EncryptStream(MemoryStream plainStream)
		{
			if (mbKeyIsSet)
			{
				try
				{
					MemoryStream encStream = new MemoryStream();
					RijndaelManaged oCSP = new RijndaelManaged();
					oCSP.Key = mbytKey;
					oCSP.IV = mbytIV;
					ICryptoTransform ct = oCSP.CreateEncryptor();
					CryptoStream cs = new CryptoStream(encStream, ct, CryptoStreamMode.Write);
					byte[] byteArray = plainStream.ToArray();
					cs.Write(byteArray, 0, (int)plainStream.Length);
					cs.FlushFinalBlock();
					cs.Close();
					return encStream;
				}
				catch (Exception ex)
				{
					Debug.WriteLine(ex.ToString());
					return null;
				}
			}
			else
			{
				throw new Exception(mksKeyNotSetException);
			}
		}
		
		public string GetHashString(string inputValue)
		{
			try
			{
				byte[] inputBytes = CommonHelpers.BytesFromString(inputValue);
				byte[] hashValue = new SHA1Managed().ComputeHash(inputBytes);
				return CommonHelpers.BytesToHexString(hashValue);
			}
			catch (Exception ex)
			{
				Debug.WriteLine(ex.ToString());
				return String.Empty;
			}
		}
		
		public bool ValidPassword(string passphrase, string hashValue)
		{
			return (GetHashString(passphrase) == hashValue);
		}

		#endregion

		#region Internal helpers

		private string encryptString(string plainText, bool base64)
		{
			try
			{
				byte[] byteArray = CommonHelpers.BytesFromString(plainText);
				MemoryStream msPlain = new MemoryStream(byteArray);
				MemoryStream msEnc = EncryptStream(msPlain);

				if (base64)
				{
					return Convert.ToBase64String(msEnc.ToArray());
				}
				else
				{
					return CommonHelpers.BytesToString(msEnc.ToArray());
				}
			}
			catch (Exception ex)
			{
				Debug.WriteLine(ex.ToString());
				return String.Empty;
			}
		}

		private string decryptString(string encryptedString, bool base64)
		{
			try
			{
				byte[] byteArray;
				if (base64)
				{
					byteArray = Convert.FromBase64String(encryptedString);
				}
				else
				{
					byteArray = CommonHelpers.BytesFromString(encryptedString);
				}

				MemoryStream msEnc = new MemoryStream(byteArray);
				MemoryStream msPlain = DecryptStream(msEnc);
				return CommonHelpers.BytesToString(msPlain.GetBuffer());
			}
			catch (Exception ex)
			{
				Debug.WriteLine(ex.ToString());
				return String.Empty;
			}
		}

		private bool encryptFile(string plainFile, string encryptedFile)
		{
			try
			{
 				bool bReplaceFile = (encryptedFile.ToLower(CultureInfo.CurrentCulture).Trim() == plainFile.ToLower(CultureInfo.CurrentCulture).Trim());
				FileStream fsIn = File.OpenRead(plainFile);
				string sEncryptedFile;

				if (bReplaceFile)
				{
					sEncryptedFile = Path.GetTempFileName();
				}
				else
				{
					sEncryptedFile = encryptedFile;
				}

				FileStream fsOut = File.OpenWrite(sEncryptedFile);
				RijndaelManaged oCSP = new RijndaelManaged();
				oCSP.Key = mbytKey;
				oCSP.IV = mbytIV;
				ICryptoTransform ct = oCSP.CreateEncryptor();
				CryptoStream cs = new CryptoStream(fsOut, ct, CryptoStreamMode.Write);
				byte[] bytesPlain = new byte[fsIn.Length];

				fsIn.Read(bytesPlain, 0, (int)fsIn.Length);
				cs.Write(bytesPlain, 0, (int)fsIn.Length);
				cs.FlushFinalBlock();
				cs.Close();
				fsIn.Close();
				fsOut.Close();
				if (bReplaceFile)
					return IoHelpers.ReplaceFile(sEncryptedFile, plainFile, true);
				else
					return true;
			}
			catch (Exception ex)
			{
				Debug.WriteLine(ex.ToString());
				return false;
			}
		}

		private bool decryptFile(string encryptedFile, string plainFile)
		{
			try
			{
				bool bReplaceFile = (encryptedFile.ToLower(CultureInfo.CurrentCulture).Trim() == plainFile.ToLower(CultureInfo.CurrentCulture).Trim());
				FileStream fsIn = File.OpenRead(encryptedFile);

				RijndaelManaged oCSP = new RijndaelManaged();
				oCSP.Key = mbytKey;
				oCSP.IV = mbytIV;
				ICryptoTransform ct = oCSP.CreateDecryptor();
				CryptoStream cs = new CryptoStream(fsIn, ct, CryptoStreamMode.Read);
				byte[] bytesPlain = new byte[fsIn.Length];
				int iBytesIn = cs.Read(bytesPlain, 0, (int)fsIn.Length);
				cs.Close();
				fsIn.Close();
				string sPlainFile;

				if (bReplaceFile)
				{
					sPlainFile = Path.GetTempFileName();
				}
				else
				{
					sPlainFile = plainFile;
				}

				FileStream fsOut = File.OpenWrite(sPlainFile);
				fsOut.Write(bytesPlain, 0, iBytesIn);
				fsOut.Close();

				if (bReplaceFile)
					return IoHelpers.ReplaceFile(sPlainFile, encryptedFile, true);
				else
					return true;
			}
			catch (Exception ex)
			{
				Debug.WriteLine(ex.ToString());
				return false;
			}
		}
			
		#endregion
	}
}
