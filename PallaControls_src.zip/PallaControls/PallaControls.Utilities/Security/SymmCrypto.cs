using System;
using System.Security.Cryptography;
using System.IO;
using System.Text;

namespace ControlWare.Utilities.Security
{
	/// <summary>
	/// SymmCrypto � uma modifica��o de System.Security.Cryptography.SymmetricAlgorithm.
	/// Esta "vers�o" � mais direta e atende mais diretamente �s necessidades das aplica��es
	/// da ControlWare.
	/// </summary>
	public class SymmCrypto
	{
		private SymmetricAlgorithm mobjCryptoService;

		#region Nested types
		
		/// <remarks>
		/// Indica o tipo de criptografia a ser utilizado.
		/// </remarks>
		public enum SymmProv : int
		{
			/// <summary>
			/// DES
			/// </summary>
			Des,
			/// <summary>
			/// RC2
			/// </summary>
			Rc2,
			/// <summary>
			/// Rijndael
			/// </summary>
			Rijndael
		}

		#endregion

		#region Constructors
		
		/// <summary>
		/// Inicializa o padr�o de criptografia
		/// </summary>
		/// <param name="netSelected">Padr�o de criptografia utilizado</param>
		public SymmCrypto(SymmProv netSelected)
		{
			switch (netSelected)
			{
				case SymmProv.Des:
					mobjCryptoService = new DESCryptoServiceProvider();
					break;
				case SymmProv.Rc2:
					mobjCryptoService = new RC2CryptoServiceProvider();
					break;
				case SymmProv.Rijndael:
					mobjCryptoService = new RijndaelManaged();
					break;
			}
		}

		/// <summary>
		/// Permite a customiza��o da criptografia
		/// </summary>
		/// <param name="serviceProvider">Tipo de servi�o de criptografia</param>
		public SymmCrypto(SymmetricAlgorithm serviceProvider)
		{
			mobjCryptoService = serviceProvider;
		}

		#endregion

		#region Internal helpers

		private byte[] GetLegalKey(string key)
		{
			string sTemp;
			if (mobjCryptoService.LegalKeySizes.Length > 0)
			{
				int lessSize = 0, moreSize = mobjCryptoService.LegalKeySizes[0].MinSize;
				while (key.Length * 8 > moreSize)
				{
					lessSize = moreSize;
					moreSize += mobjCryptoService.LegalKeySizes[0].SkipSize;
				}
				sTemp = key.PadRight(moreSize / 8, ' ');
			}
			else
				sTemp = key;

			return ASCIIEncoding.ASCII.GetBytes(sTemp);
		}

		#endregion

		#region Methods
		
		/// <summary>
		/// Criptografa uma string
		/// </summary>
		/// <param name="source">String a ser criptografada</param>
		/// <param name="key">Chave para criptografia</param>
		/// <returns>String criptografada</returns>
		public string Encrypting(string source, string key)
		{
			byte[] bytIn = System.Text.ASCIIEncoding.ASCII.GetBytes(source);
			System.IO.MemoryStream ms = new System.IO.MemoryStream();

			byte[] bytKey = GetLegalKey(key);

			mobjCryptoService.Key = bytKey;
			mobjCryptoService.IV = bytKey;

			ICryptoTransform encrypto = mobjCryptoService.CreateEncryptor();

			CryptoStream cs = new CryptoStream(ms, encrypto, CryptoStreamMode.Write);

			cs.Write(bytIn, 0, bytIn.Length);
			cs.FlushFinalBlock();

			byte[] bytOut = ms.GetBuffer();
			int i = 0;
			for (i = 0; i < bytOut.Length; i++)
				if (bytOut[i] == 0)
					break;

			return System.Convert.ToBase64String(bytOut, 0, i);
		}

		/// <summary>
		/// Criptografa uma string
		/// </summary>
		/// <param name="source">String a ser criptografada</param>
		/// <returns>String criptografada</returns>
		public string Encrypting(string source)
		{
			string key = "0@#kL?:|";
			
			byte[] bytIn = System.Text.ASCIIEncoding.ASCII.GetBytes(source);
			System.IO.MemoryStream ms = new System.IO.MemoryStream();

			byte[] bytKey = GetLegalKey(key);

			mobjCryptoService.Key = bytKey;
			mobjCryptoService.IV = bytKey;

			ICryptoTransform encrypto = mobjCryptoService.CreateEncryptor();

			CryptoStream cs = new CryptoStream(ms, encrypto, CryptoStreamMode.Write);

			cs.Write(bytIn, 0, bytIn.Length);
			cs.FlushFinalBlock();

			byte[] bytOut = ms.GetBuffer();
			int i = 0;
			for (i = 0; i < bytOut.Length; i++)
				if (bytOut[i] == 0)
					break;

			return System.Convert.ToBase64String(bytOut, 0, i);
		}
		
		/// <summary>
		/// Descriptografa uma string
		/// </summary>
		/// <param name="source">String a ser descriptografada</param>
		/// <param name="key">Chave para descriptografia</param>
		/// <returns>String descriptografada</returns>
		public string Decrypting(string source, string key)
		{
			byte[] bytIn = System.Convert.FromBase64String(source);
			System.IO.MemoryStream ms = new System.IO.MemoryStream(bytIn, 0, bytIn.Length);

			byte[] bytKey = GetLegalKey(key);

			mobjCryptoService.Key = bytKey;
			mobjCryptoService.IV = bytKey;

			ICryptoTransform encrypto = mobjCryptoService.CreateDecryptor();

			CryptoStream cs = new CryptoStream(ms, encrypto, CryptoStreamMode.Read);
			
			System.IO.StreamReader sr = new System.IO.StreamReader( cs );
			return sr.ReadToEnd();
		}

		/// <summary>
		/// Descriptografa uma string
		/// </summary>
		/// <param name="source">String a ser descriptografada</param>
		/// <returns>String descriptografada</returns>
		public string Decrypting(string source)
		{
			string key = "0@#kL?:|";
			
			byte[] bytIn = System.Convert.FromBase64String(source);
			System.IO.MemoryStream ms = new System.IO.MemoryStream(bytIn, 0, bytIn.Length);

			byte[] bytKey = GetLegalKey(key);

			mobjCryptoService.Key = bytKey;
			mobjCryptoService.IV = bytKey;

			ICryptoTransform encrypto = mobjCryptoService.CreateDecryptor();

			CryptoStream cs = new CryptoStream(ms, encrypto, CryptoStreamMode.Read);
			
			System.IO.StreamReader sr = new System.IO.StreamReader( cs );
			return sr.ReadToEnd();
		}
		
		#endregion
	}
}
