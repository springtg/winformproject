using System;

namespace PallaControls.Utilities
{
	#region HandledExceptionHappenedEventArgs

	public class HandledExceptionHappenedEventArgs : EventArgs
	{
		Exception exception = null;
			
		#region Constructors

		public HandledExceptionHappenedEventArgs(Exception exception)
		{
			this.exception = exception;
		}

		#endregion

		#region Properties

		public Exception Except
		{
			get{return this.exception;}
		}

		#endregion
	}

	#endregion

	public delegate void HandledExceptionHappenedEventHandler(object sender, HandledExceptionHappenedEventArgs e);
}
