using System;

namespace PallaControls.Utilities.Plugins
{
	#region IPlugin
	
	public interface IPlugin
	{
		string Name{get;}

		void OnLoad(object sender, EventArgs e);

		void OnUnLoad(object sender, EventArgs e);

		void ReceiveMessage(IPluginMessage message);

		void About();
	}

	#endregion

	#region IPluginMessage

	public interface IPluginMessage
	{
		string Message {get;}
	}

	#endregion
}
