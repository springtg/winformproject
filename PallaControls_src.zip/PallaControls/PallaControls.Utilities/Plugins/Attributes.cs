using System;
using System.Collections.Specialized;

namespace PallaControls.Utilities.Plugins
{
	#region PluginClassificationAttribute
	
	[AttributeUsage(AttributeTargets.Assembly)]
	public sealed class PluginClassificationAttribute : Attribute
	{
		private string companyName = String.Empty;
		private string businessName = String.Empty;
		private string contractName = String.Empty;
		private string pluginDate;
		private string pluginPurpose = String.Empty;
		private string pluginRemarks = String.Empty;

		private string pluginTypeName = String.Empty;
				
		#region Constructors

		public PluginClassificationAttribute()
		{
		}

		public PluginClassificationAttribute(string companyName, string businessName,
			                                 string contractName, string pluginDate,
											 string pluginPurpose, string pluginRemarks,
			                                 string pluginTypeName)
		{
			this.companyName = companyName;
			this.businessName = businessName;
			this.contractName = contractName;
			this.pluginDate = pluginDate;
			this.pluginPurpose = pluginPurpose;
			this.pluginRemarks = pluginRemarks;
			this.pluginTypeName = pluginTypeName;
		}
		
		#endregion

		#region Properties
		
		public string PluginTypeName
		{
			get{return this.pluginTypeName;}
			set{this.pluginTypeName = value;}
		}

		public string CompanyName
		{
			get{return this.companyName;}
			set{this.companyName = value;}
		}

		public string BusinessName
		{
			get{return this.businessName;}
			set{this.businessName = value;}
		}

		public string ContractName
		{
			get{return this.contractName;}
			set{this.contractName = value;}
		}

		public string PluginDate
		{
			get{return this.pluginDate;}
			set{this.pluginDate = value;}
		}

		public string PluginPurpose
		{
			get{return this.pluginPurpose;}
			set{this.pluginPurpose = value;}
		}

		public string PluginRemarks
		{
			get{return this.pluginRemarks;}
			set{this.pluginRemarks = value;}
		}

		#endregion
	}

	#endregion
}