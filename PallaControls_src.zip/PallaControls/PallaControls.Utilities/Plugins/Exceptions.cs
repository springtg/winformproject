using System;
using System.Runtime.Serialization;

namespace PallaControls.Utilities.Plugins
{
	#region PluginClassificationNotFoundException

	[Serializable]
	public class PluginClassificationNotFoundException : ApplicationException
	{
		#region Constructors

		public PluginClassificationNotFoundException():base()
		{
		}

		public PluginClassificationNotFoundException(string message, Exception innerException) : base(message, innerException)
		{
		}
		public PluginClassificationNotFoundException(string message) : base(message)
		{
		}

		protected PluginClassificationNotFoundException(SerializationInfo info, StreamingContext context) : base(info,context)
		{
		}

		#endregion
	}

	#endregion
}

