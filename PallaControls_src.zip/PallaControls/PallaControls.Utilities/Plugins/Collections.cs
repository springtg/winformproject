using System;
using System.Collections;

namespace PallaControls.Utilities.Plugins
{
	#region PluginCollection

	public class PluginCollection: CollectionBase
	{
		#region Constructors

		public PluginCollection() 
		{
		}
		
		public PluginCollection(PluginCollection value)	
		{
			this.AddRange(value);
		}
		
		public PluginCollection(IPlugin[] value)
		{
			this.AddRange(value);
		}

		#endregion
		
		#region Methods
		
		public int Add(IPlugin value) 
		{
			return this.List.Add(value);
		}
		
		public void AddRange(IPlugin[] value) 
		{
			for (int i = 0;	(i < value.Length); i = (i + 1)) 
			{
				this.Add(value[i]);
			}
		}
		
		public void AddRange(PluginCollection value) 
		{
			for (int i = 0;	(i < value.Count); i = (i +	1))	
			{
				this.Add((IPlugin)value.List[i]);
			}
		}
		
		public bool Contains(IPlugin value) 
		{
			return this.List.Contains(value);
		}
		
		public void CopyTo(IPlugin[] array, int index) 
		{
			this.List.CopyTo(array, index);
		}
		
		public IPlugin[] ToArray()
		{
			IPlugin[] array = new IPlugin[this.Count];
			this.CopyTo(array, 0);
			
			return array;
		}
		
		public int IndexOf(IPlugin value) 
		{
			return this.List.IndexOf(value);
		}
		
		public void Insert(int index, IPlugin value)	
		{
			List.Insert(index, value);
		}
		
		public void Remove(IPlugin value) 
		{
			List.Remove(value);
		}
		
		public new PluginCollectionEnumerator GetEnumerator()	
		{
			return new PluginCollectionEnumerator(this);
		}

		#endregion

		#region Properties

		public IPlugin this[int index] 
		{
			get	{return ((IPlugin)(this.List[index]));}
		}

		#endregion
		
		#region PluginCollectionEnumerator

		public class PluginCollectionEnumerator : IEnumerator	
		{
			private	IEnumerator _enumerator;
			private	IEnumerable _temp;
			
			public PluginCollectionEnumerator(PluginCollection mappings)
			{
				_temp =	((IEnumerable)(mappings));
				_enumerator = _temp.GetEnumerator();
			}
			
			public IPlugin Current
			{
				get {return ((IPlugin)(_enumerator.Current));}
			}
			
			object IEnumerator.Current
			{
				get {return _enumerator.Current;}
			}
			
			public bool MoveNext()
			{
				return _enumerator.MoveNext();
			}
			
			bool IEnumerator.MoveNext()
			{
				return _enumerator.MoveNext();
			}
			
			public void Reset()
			{
				_enumerator.Reset();
			}
			
			void IEnumerator.Reset() 
			{
				_enumerator.Reset();
			}
		}

		#endregion
	}

	#endregion
}
