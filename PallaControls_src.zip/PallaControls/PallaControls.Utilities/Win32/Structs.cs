using System;
using System.Runtime.InteropServices;

namespace ControlWare.Utilities.Win32
{
	#region LogBrush

	/// <summary>
	/// LogBrush
	/// </summary>
	[StructLayout(LayoutKind.Sequential)]
	public struct LogBrush
	{
		/// <summary>
		/// lbStyle
		/// </summary>
		public int lbStyle; 
		/// <summary>
		/// lbColor
		/// </summary>
		public int lbColor; 
		/// <summary>
		/// lbHatch
		/// </summary>
		public int lbHatch; 
	}

	#endregion

	#region Rect

	/// <summary>
	/// Rect
	/// </summary>
	[StructLayout(LayoutKind.Sequential)]
	public struct Rect
	{
		/// <summary>
		/// Left
		/// </summary>
		public int Left;
		/// <summary>
		/// Top
		/// </summary>
		public int Top;
		/// <summary>
		/// Right
		/// </summary>
		public int Right;
		/// <summary>
		/// Bottom
		/// </summary>
		public int Bottom;
	}

	#endregion
}
