using System;
using System.Runtime.InteropServices;

namespace ControlWare.Utilities.Win32
{
	/// <summary>
	/// Classe que cont�m fun��es de API do windows utilizadas por outros componentes.
	/// </summary>
	/// <remarks>O USO DESTA CLASSE DIMINUE A PORTABILIDADE DO C�DIGO, PORTANTO
	/// N�O USE ESTA CLASSE A N�O SER QUE TENHA CERTEZA ABSOLUTA DO QUE EST�
	/// FAZENDO!!</remarks>
	public class Gdi32
	{
		#region Constructors

		/// <summary>
		/// Constructor padr�o
		/// </summary>
		private Gdi32()
		{
		}

		#endregion

		#region Methods

		/// <summary>
		/// CombineRgn
		/// </summary>
		[DllImport("gdi32.dll", CharSet=CharSet.Auto)]
		public static extern int CombineRgn(IntPtr dest, IntPtr src1, IntPtr src2, int flags);

		/// <summary>
		/// CreateRectRgnIndirect
		/// </summary>
		[DllImport("gdi32.dll", CharSet=CharSet.Auto)]
		public static extern IntPtr CreateRectRgnIndirect(ref Rect rect); 

		/// <summary>
		/// GetClipBox
		/// </summary>
		[DllImport("gdi32.dll", CharSet=CharSet.Auto)]
		public static extern int GetClipBox(IntPtr hDC, ref Rect rectBox); 

		/// <summary>
		/// SelectClipRgn
		/// </summary>
		[DllImport("gdi32.dll", CharSet=CharSet.Auto)]
		public static extern int SelectClipRgn(IntPtr hDC, IntPtr hRgn); 

		/// <summary>
		/// CreateBrushIndirect
		/// </summary>
		[DllImport("gdi32.dll", CharSet=CharSet.Auto)]
		public static extern IntPtr CreateBrushIndirect(ref LogBrush brush); 

		/// <summary>
		/// PatBlt
		/// </summary>
		[DllImport("gdi32.dll", CharSet=CharSet.Auto)]
		public static extern bool PatBlt(IntPtr hDC, int x, int y, int width, int height, int flags); 

		/// <summary>
		/// DeleteObject
		/// </summary>
		[DllImport("gdi32.dll", CharSet=CharSet.Auto)]
		public static extern IntPtr DeleteObject(IntPtr hObject);

		/// <summary>
		/// DeleteDC
		/// </summary>
		[DllImport("gdi32.dll", CharSet=CharSet.Auto)]
		public static extern bool DeleteDC(IntPtr hDC);

		/// <summary>
		/// SelectObject
		/// </summary>
		[DllImport("gdi32.dll", CharSet=CharSet.Auto)]
		public static extern IntPtr SelectObject(IntPtr hDC, IntPtr hObject);

		/// <summary>
		/// CreateCompatibleDC
		/// </summary>
		[DllImport("gdi32.dll", CharSet=CharSet.Auto)]
		public static extern IntPtr CreateCompatibleDC(IntPtr hDC);

		#endregion
	}
}
