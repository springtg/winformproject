using System;
using System.Runtime.InteropServices;

namespace ControlWare.Utilities.Win32
{
	#region ScrollBarTypes

	/// <summary>
	/// ScrollBarTypes
	/// </summary>
	public enum ScrollBarTypes
	{
		/// <summary>
		/// Sb_Horz
		/// </summary>
		SbHorz = 0,
			
		/// <summary>
		/// Sb_Vert
		/// </summary>
		SbVert = 1,

		/// <summary>
		/// Sb_Ctl
		/// </summary>
		SbCtl = 2,
			
		/// <summary>
		/// Sb_Both
		/// </summary>
		SbBoth = 3
	}

	#endregion

	#region MouseActivateFlags	
	
	/// <summary>
	/// MouseActivateFlags
	/// </summary>
	public enum MouseActivateFlags
	{
		/// <summary>
		/// Mactivate
		/// </summary>
		Mactivate = 1,
		/// <summary>
		/// MactivateAndeat
		/// </summary>
		MactivateAndeat = 2,
		/// <summary>
		/// MaNoActivate
		/// </summary>
		MaNoActivate = 3,
		/// <summary>
		/// MaNoActivateAndeat
		/// </summary>
		MaNoActivateAndeat = 4
	}

	#endregion

	#region Msg
	
	/// <summary>
	/// Msg
	/// </summary>
	public enum Msg
	{
		/// <summary>
		/// WmMouseActivate
		/// </summary>
		WmMouseActivate = 0x0021,
			
		/// <summary>
		/// WmUser
		/// </summary>
		WmUser = 0x0400,
			
		/// <summary>
		/// WmMouseWhell
		/// </summary>
		WmMouseWhell = 0x020A,
			
		/// <summary>
		/// WmKeyDown
		/// </summary>
		WmKeyDown = 0x0100,
			
		/// <summary>
		/// WmKeyUp
		/// </summary>
		WmKeyUp = 0x0101,
			
		/// <summary>
		/// WmChar
		/// </summary>
		WmChar = 0x0102,
			
		/// <summary>
		///	WmlButtonUp	
		/// </summary>
		WmlButtonUp = 0x0202,

		/// <summary>
		/// WmlButtonDown
		/// </summary>
		WmlButtonDown = 0x0201,
			
		/// <summary>
		/// WmmButtonDown
		/// </summary>
		WmmButtonDown = 0x0207,
			
		/// <summary>
		/// WmmButtonUp
		/// </summary>
		WmmButtonUp = 0x0208,

		/// <summary>
		/// WmlButtonDblClk
		/// </summary>
		WmlButtonDblClk = 0x0203,
			
		/// <summary>
		/// WmReflect
		/// </summary>
		WmReflect = WmUser + 0x1c00
	}

	#endregion

	#region WindowExStyles
	
	/// <summary>
	/// WindowExStyles
	/// </summary>
	public enum WindowExStyles
	{
		/// <summary>
		/// WsExTopMost
		/// </summary>
		WsExTopMost = 0x00000008,
	}

	#endregion

	#region CombineFlags
	
	/// <summary>
	/// CombineFlags
	/// </summary>
	public enum CombineFlags
	{
		/// <summary>
		/// RgnAnd
		/// </summary>
		RgnAnd		= 1,
		/// <summary>
		/// RgnOr
		/// </summary>
		RgnOr		= 2,
		/// <summary>
		/// RgnXor
		/// </summary>
		RgnXor		= 3,
		/// <summary>
		/// RgnDiff
		/// </summary>
		RgnDiff 	= 4,
		/// <summary>
		/// RgnCopy
		/// </summary>
		RgnCopy 	= 5
	}

	#endregion

	#region RasterOperations

	/// <summary>
	/// RasterOperations
	/// </summary>
	public enum RasterOperations : int
	{
		/// <summary>
		/// SrcCopy
		/// </summary>
		SrcCopy		= 0x00CC0020,
		/// <summary>
		/// SrcPaint
		/// </summary>
		SrcPaint	= 0x00EE0086,
		/// <summary>
		/// SrcAnd
		/// </summary>
		SrcAnd		= 0x008800C6,
		/// <summary>
		/// SrcInvert
		/// </summary>
		SrcInvert	= 0x00660046,
		/// <summary>
		/// SrcErase
		/// </summary>
		SrcErase	= 0x00440328,
		/// <summary>
		/// NotSrcNot
		/// </summary>
		NotSrcNot	= 0x00330008,
		/// <summary>
		/// NotSrcErase
		/// </summary>
		NotSrcErase = 0x001100A6,
		/// <summary>
		/// MergeCopy
		/// </summary>
		MergeCopy	= 0x00C000CA,
		/// <summary>
		/// MergePaint
		/// </summary>
		MergePaint	= 0x00BB0226,
		/// <summary>
		/// PatCopy
		/// </summary>
		PatCopy		= 0x00F00021,
		/// <summary>
		/// PatPaint
		/// </summary>
		PatPaint	= 0x00FB0A09,
		/// <summary>
		/// PatInvert
		/// </summary>
		PatInvert	= 0x005A0049,
		/// <summary>
		/// DstInvert
		/// </summary>
		DstInvert	= 0x00550009,
		/// <summary>
		/// BlaskNess
		/// </summary>
		BlaskNess	= 0x00000042,
		/// <summary>
		/// WhiteNess
		/// </summary>
		WhiteNess	= 0x00FF0062
	}

	#endregion

	#region BrushStyles
	
	/// <summary>
	/// BrushStyles
	/// </summary>
	public enum BrushStyles
	{
		/// <summary>
		/// BsSolid
		/// </summary>
		BsSolid			= 0,
		/// <summary>
		/// BsNull
		/// </summary>
		BsNull             = 1,
		/// <summary>
		/// BsHollow
		/// </summary>
		BsHollow           = 1,
		/// <summary>
		/// BsHatched
		/// </summary>
		BsHatched          = 2,
		/// <summary>
		/// BsPattern
		/// </summary>
		BsPattern          = 3,
		/// <summary>
		/// BsIndexed
		/// </summary>
		BsIndexed          = 4,
		/// <summary>
		/// BsDipPattern
		/// </summary>
		BsDibPattern       = 5,
		/// <summary>
		/// BsDibPatternPt
		/// </summary>
		BsDibPatternPt     = 6,
		/// <summary>
		/// BsPattern8x8
		/// </summary>
		BsPattern8x8       = 7,
		/// <summary>
		/// BsDibPattern8x8
		/// </summary>
		BsDibPattern8x8    = 8,
		/// <summary>
		/// BsMonoPattern
		/// </summary>
		BsMonoPattern      = 9
	}

	#endregion
}
