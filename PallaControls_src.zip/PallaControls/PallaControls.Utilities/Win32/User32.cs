using System;
using System.Runtime.InteropServices;
using System.Text;

namespace ControlWare.Utilities.Win32
{
	/// <summary>
	/// Classe que cont�m fun��es de API do windows utilizadas por outros componentes.
	/// </summary>
	/// <remarks>O USO DESTA CLASSE DIMINUE A PORTABILIDADE DO C�DIGO, PORTANTO
	/// N�O USE ESTA CLASSE A N�O SER QUE TENHA CERTEZA ABSOLUTA DO QUE EST�
	/// FAZENDO!!</remarks>
	public class User32
	{
		#region Constructors

		/// <summary>
		/// Construtor padr�o, n�o precisa ser utilizado.
		/// </summary>
		private User32()
		{
		}

		#endregion

		#region Methods

		/// <summary>
		/// GetFocus
		/// </summary>
		[DllImport("User32.dll", CharSet=CharSet.Auto)]
		public static extern IntPtr GetFocus();

		/// <summary>
		/// SetFocus
		/// </summary>
		[DllImport("User32.dll", CharSet=CharSet.Auto)]
		public static extern IntPtr SetFocus(IntPtr hWnd);

		/// <summary>
		/// MoveWindow
		/// </summary>
		[DllImport("User32.dll", CharSet=CharSet.Auto)]
		public static extern bool MoveWindow(IntPtr hWnd, int x, int y, int width, int height, bool repaint);

		/// <summary>
		/// ShowScrollBar
		/// </summary>
		[DllImport("user32.dll", CharSet=CharSet.Auto)]
		static public extern int ShowScrollBar(IntPtr hWnd, int bar,  int show);

		/// <summary>
		/// GetPixel
		/// </summary>
		[DllImport("gdi32.dll")]
		static public extern int GetPixel(IntPtr hDC, int XPos, int YPos);

		/// <summary>
		/// ShowWindow
		/// </summary>
		[DllImport("user32.dll", CharSet=CharSet.Auto)]
		static public extern bool ShowWindow(IntPtr hWnd, short State);

		/// <summary>
		/// GetDC
		/// </summary>
		[DllImport("User32.dll", CharSet=CharSet.Auto)]
		public static extern IntPtr GetDC(IntPtr hWnd);

		/// <summary>
		/// ReleaseDC
		/// </summary>
		[DllImport("User32.dll", CharSet=CharSet.Auto)]
		public static extern int ReleaseDC(IntPtr hWnd, IntPtr hDC);

		#endregion
	}
}
