using System;
using System.Collections.Specialized;

namespace PallaControls.Utilities
{
	#region UseApiElementsAttribute
	
	[AttributeUsage(AttributeTargets.Property|AttributeTargets.Method|
		 AttributeTargets.Constructor)]
	public sealed class UseApiElementsAttribute : Attribute
	{
		StringCollection elementsNames = new StringCollection();
		
		public UseApiElementsAttribute(string elementNames) 
		{
			this.elementsNames.Add(elementNames);
		}

		public StringCollection ElementsNames
		{
			get {return elementsNames;}
		}	
	}

	#endregion
}

namespace PallaControls.Utilities.Settings
{
	#region ConfigureManuallyAttribute
	
	[AttributeUsage(AttributeTargets.Property)]
	public sealed class ConfigureManuallyAttribute : Attribute
	{
		private bool allow = true;
		
		public ConfigureManuallyAttribute() 
		{
		}

		public ConfigureManuallyAttribute(bool allow) 
		{
			this.allow = allow;
		}

		public bool Allow
		{
			get {return this.allow;}
			set {this.allow = value;}
		}	
	}

	#endregion
}

namespace PallaControls.Utilities.Update
{
	#region UpdateDbScriptsAttribute
	
	[AttributeUsage(AttributeTargets.Assembly, AllowMultiple=true)]
	public sealed class UpdateDbScriptsAttribute : Attribute
	{
		private string version = String.Empty;
		private string scriptsInSql = String.Empty;
		private string scriptsOutSql = String.Empty;
				
		#region Constructors
		
		public UpdateDbScriptsAttribute(string version, string scriptsInSql, string scriptsOutSql)
		{
			this.version = version;
			this.scriptsInSql = scriptsInSql;
			this.scriptsOutSql = scriptsOutSql;
		}

		public UpdateDbScriptsAttribute()
		{
		}

		#endregion

		#region Properties
		
		public string Version
		{
			get{return this.version;}
			set{this.version = value;}
		}

		
		public string ScriptsInSql
		{
			get{return this.scriptsInSql;}
			set{this.scriptsInSql = value;}
		}

		public string ScriptsOutSql
		{
			get{return this.scriptsOutSql;}
			set{this.scriptsOutSql = value;}
		}

		#endregion
	}

	#endregion

	#region UpdateDocumentationAttribute
	
	[AttributeUsage(AttributeTargets.Assembly, AllowMultiple=true)]
	public sealed class UpdateDocumentationAttribute : Attribute
	{
		private string version = String.Empty;
		private string changesSummary = String.Empty;
		private string changesSummaryForInstallLog = String.Empty;
		private string changesSummaryForInstallProcess = String.Empty;
		private UpdatePriority priority = UpdatePriority.High;
		private string dateChange = String.Empty;
				
		#region Constructors
		
		public UpdateDocumentationAttribute(string version, string changesSumary, UpdatePriority priority)
		{
			InternalConstructor(version, changesSumary, String.Empty, String.Empty, priority, String.Empty);
		}

		public UpdateDocumentationAttribute(string version, string changesSumary, string changesSumaryForInstallLog, UpdatePriority priority)
		{
			InternalConstructor(version, changesSumary, changesSumaryForInstallLog, String.Empty, priority, String.Empty);
		}

		public UpdateDocumentationAttribute(string version, string changesSumary, string changesSumaryForInstallLog, string changesSumaryForInstallProcess, UpdatePriority priority, string dateChange)
		{
			InternalConstructor(version, changesSumary, changesSumaryForInstallLog, changesSumaryForInstallProcess, priority, dateChange);
		}

		public UpdateDocumentationAttribute()
		{
		}

		private void InternalConstructor(string version, string changesSumary, string changesSumaryForInstallLog, string changesSumaryForInstallProcess, UpdatePriority priority, string dateChange)
		{
			this.Version = version;
			this.changesSummary = changesSumary;
			this.changesSummaryForInstallLog = changesSumaryForInstallLog;
			this.changesSummaryForInstallProcess = changesSumaryForInstallProcess;
			this.priority = priority;
			this.dateChange = dateChange;
		}

		#endregion

		#region Properties
		
		public string Version
		{
			get{return this.version;}
			set{this.version = value;}
		}
		
		public UpdatePriority Priority
		{
			get{return this.priority;}
			set{this.priority = value;}
		}

		public string ChangesSummary
		{
			get{return this.changesSummary;}
			set{this.changesSummary = value;}
		}

		public string ChangesSummaryForInstallLog
		{
			get{return this.changesSummaryForInstallLog;}
			set{this.changesSummaryForInstallLog = value;}
		}

		public string ChangesSummaryForInstallProcess
		{
			get{return this.changesSummaryForInstallProcess;}
			set{this.changesSummaryForInstallProcess = value;}
		}

		public string DateChange
		{
			get{return this.dateChange;}
			set{this.dateChange = value;}
		}

		#endregion
	}

	#endregion

	#region UpdateAssemblyTypeAttribute
	
	[AttributeUsage(AttributeTargets.Assembly)]
	public sealed class UpdateAssemblyTypeAttribute : Attribute
	{
		private UpdateAssemblyTypes assemblyType;
				
		#region Constructors
		
		public UpdateAssemblyTypeAttribute(UpdateAssemblyTypes assemblyType)
		{
			this.assemblyType = assemblyType;
		}

		public UpdateAssemblyTypeAttribute()
		{
		}

		#endregion

		#region Properties
		
		public UpdateAssemblyTypes AssemblyType
		{
			get{return this.assemblyType;}
			set{this.assemblyType = value;}
		}

		#endregion
	}

	#endregion
}