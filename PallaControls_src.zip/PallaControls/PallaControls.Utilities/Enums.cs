using System;

namespace PallaControls.Utilities
{
	#region DateTimeFormats
	
	public enum DateTimeFormats
	{
		ShortDatePattern,
		LongDatePattern,
		FullDateAndShortTimePattern,
		FullDateAndLongTimePattern,
		GeneralShortTime,
		GeneralLongTime,
		MonthDayPattern,
		RFC1123Pattern,
		SortableDateTimePattern,
		ShortTimePattern,
		LongTimePattern,
		UniversalSortableDateTimePattern,
		FullLongDateAndLongTime,
		YearMonthPattern
	}

	#endregion
}

namespace PallaControls.Utilities.Update
{
	#region UpdatePriority

	public enum UpdatePriority
	{
		High = 1,
		Medium = 2,
		Low = 3
	}

	#endregion
	
	#region UpdateAssemblyTypes
	
	[Flags()]
	public enum UpdateAssemblyTypes
	{
		Shared = 1,
		Local = 2,
		Plugin = 3,
		SimplePackage,
		ServicePackPackage
	}

	#endregion
}