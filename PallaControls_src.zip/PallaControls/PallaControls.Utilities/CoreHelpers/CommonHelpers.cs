using System;
using System.Collections;
using System.ComponentModel;
using System.Text;
using System.Data;
using System.Globalization;
using PallaControls.Utilities.Update;

namespace PallaControls.Utilities.CoreHelpers
{
	public class CommonHelpers
	{
		#region Constructors

		private CommonHelpers()
		{
		}

		#endregion

		#region Methods

		public static string GetOnlyDigits(string sourceValue)
		{
			StringBuilder sb = new StringBuilder();
			foreach (char localChar in sourceValue)
			{
				if (Char.IsDigit(localChar)) sb.Append(localChar);
			}
			return sb.ToString();
		}

		public static int GetNextDozen(int value)
		{
			int mod = 0, auxVal = value;
			do
			{
				mod = auxVal%10;
				if (mod != 0) auxVal++;
			}
			while(mod != 0);

			return auxVal;
		}

		public static bool IsDateOk(string dateVal)
		{
			try
			{
				DateTime dummy = Convert.ToDateTime(dateVal, CultureInfo.CurrentCulture);
				return true;
			}
			catch
			{
				return false;
			}
		}

		public static bool IsNumberOk(string number)
		{
			try
			{
				double dummy = Convert.ToDouble(number, CultureInfo.CurrentCulture);
				return true;
			}
			catch
			{
				return false;
			}
		}

		public static double StringToDouble(string value)
		{
			double retVal = 0;

			try
			{
				retVal = Convert.ToDouble(value, CultureInfo.CurrentCulture);
			}
			catch
			{
				retVal = 0;
			}

			return retVal;
		}

		public static string DateToString(DateTime value)
		{
			string sep = System.Globalization.DateTimeFormatInfo.CurrentInfo.DateSeparator;
			string format = String.Empty;

			DateTime t = new DateTime(2000,2,1);
			string   tStr  = t.ToShortDateString();					
			if(tStr.IndexOf("1") > tStr.IndexOf("2"))
			{
				format = "MM" + sep + "dd" + sep + "yyyy";
			}
			else
			{
				format = "dd" + sep + "MM" + sep + "yyyy";
			}

			return value.ToString(format, CultureInfo.CurrentCulture);
		}

		public static byte[] BytesFromString(string stringValue)
		{
			return (new UnicodeEncoding()).GetBytes(stringValue);
		}

		public static string BytesToHexString(byte[] byteArray)
		{
			StringBuilder sb = new StringBuilder(40);
			foreach(byte bValue in byteArray)
			{
				sb.AppendFormat(CultureInfo.CurrentCulture, bValue.ToString("x2", CultureInfo.CurrentCulture).ToUpper(CultureInfo.CurrentCulture));
			}
			return sb.ToString();
		}

		public static string BytesToString(byte[] byteArray)
		{
			return (new UnicodeEncoding()).GetString(byteArray);
		}

		public static string PriorityToString(UpdatePriority updatePriority)
		{
			if (updatePriority == UpdatePriority.High)
				return "Alta";
			else if (updatePriority == UpdatePriority.Medium)
				return "M�dia";
			else if (updatePriority == UpdatePriority.Low)
				return "Baixa";

			return "Baixa";
		}

		public static string DateTimeFormatToString(DateTimeFormats dateTimeFormat)
		{
			string result = "d";

			if (dateTimeFormat == DateTimeFormats.ShortDatePattern) result = "d";
			else if	(dateTimeFormat == DateTimeFormats.LongDatePattern) result = "D";
			else if	(dateTimeFormat == DateTimeFormats.FullDateAndShortTimePattern) result = "f";
			else if	(dateTimeFormat == DateTimeFormats.FullDateAndLongTimePattern) result = "F";
			else if	(dateTimeFormat == DateTimeFormats.GeneralShortTime) result = "g";
			else if	(dateTimeFormat == DateTimeFormats.GeneralLongTime) result = "G";
			else if	(dateTimeFormat == DateTimeFormats.MonthDayPattern) result = "m";
			else if	(dateTimeFormat == DateTimeFormats.RFC1123Pattern) result = "r";
			else if	(dateTimeFormat == DateTimeFormats.SortableDateTimePattern) result = "s";
			else if	(dateTimeFormat == DateTimeFormats.ShortTimePattern) result = "t";
			else if	(dateTimeFormat == DateTimeFormats.LongTimePattern) result = "T";
			else if	(dateTimeFormat == DateTimeFormats.UniversalSortableDateTimePattern) result = "u";
			else if	(dateTimeFormat == DateTimeFormats.FullLongDateAndLongTime) result = "U";
			else if	(dateTimeFormat == DateTimeFormats.YearMonthPattern) result = "y";

			return result;
		}

		#endregion
	}
}