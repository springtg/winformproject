using System;
using System.Diagnostics;
using System.Text;
using System.Globalization;

namespace PallaControls.Utilities.CoreHelpers
{
	public class ValidationDigits
	{
		#region Constructors

		private ValidationDigits()
		{
		}

		#endregion
		
		#region Methods

		public static bool IsCpfOk(string cpf)
		{
			System.Int32 sum = 0, digit1 = 0, digit2 = 0;

			//begin test
			string localCpf = CommonHelpers.GetOnlyDigits(cpf);
			
			if (localCpf.Length == 11) 
			{
				try
				{
					//D�git 1
					sum = 0;
					for (int i=1;i<=9;i++) sum += Convert.ToInt16(localCpf.Substring(10-i,1), CultureInfo.CurrentCulture)*(i+1);
					digit1 = 11 - (sum % 11);
					if (digit1 > 9) digit1 = 0;

					//D�git 2
					sum = 0;
					for (int i=1;i<=10;i++) sum += Convert.ToInt16(localCpf.Substring(11-i,1), CultureInfo.CurrentCulture)*(i+1);
					digit2 = 11 - (sum % 11);
					if (digit2 > 9) digit2 = 0;

					//Check digits
					if (digit1 == Convert.ToInt16(localCpf.Substring(10,1), CultureInfo.CurrentCulture) ||
						digit2 == Convert.ToInt16(localCpf.Substring(11,1), CultureInfo.CurrentCulture)) 
						return true;
					else
						return false; 
				}
				catch(Exception x)
				{
					Debug.WriteLine(x.Message);
					return false;
				}
			}
			return false;
		}

		public static bool IsCnpjOk(string cnpj)
		{
			System.Int32 sum = 0, digit1 = 0, digit2 = 0;
			
			//test begin
			string localCnpj = CommonHelpers.GetOnlyDigits(cnpj);

			if (localCnpj.Length == 14) 
			{
				try
				{
					//Digit 1
					sum = 0;
					for (int i=1;i<=12;i++) 
					{
						if (i<5) sum += Convert.ToInt16(localCnpj.Substring(i,1), CultureInfo.CurrentCulture)*(6-i);
						else sum += Convert.ToInt16(localCnpj.Substring(i,1),  CultureInfo.CurrentCulture)*(14-i);
					}
					digit1 = 11 - (sum % 11);
					if (digit1 > 9) digit1 = 0;

					//D�git 2
					sum = 0;
					for (int i=1;i<=13;i++) 
					{
						if (i<6) sum += Convert.ToInt16(localCnpj.Substring(i,1), CultureInfo.CurrentCulture)*(7-i);
						else sum += Convert.ToInt16(localCnpj.Substring(i,1), CultureInfo.CurrentCulture)*(15-i);
					}
					digit2 = 11 - (sum % 11);
					if (digit2 > 9) digit2 = 0;

					//Check digits
					if (digit1 == Convert.ToInt16(localCnpj.Substring(12,1),CultureInfo.CurrentCulture ) ||
						digit2 == Convert.ToInt16(localCnpj.Substring(13,1), CultureInfo.CurrentCulture)) 
						return true;
					else
						return false; 
				}
				catch(Exception x)
				{
					Debug.WriteLine(x.Message);
					return false;
				}
			}
			return false;
		}

		public static bool IsCepOk(string cep, string state)
		{
			if (cep.Length > 0)
			{
				try
				{
					string localCep = CommonHelpers.GetOnlyDigits(cep);
				
					if (Convert.ToInt32(localCep, CultureInfo.CurrentCulture) >= 1000000.0 && localCep.ToString(CultureInfo.CurrentCulture).Length == 8)
					{
						localCep = localCep.Substring(0,3);
						//
						if (state == "SP" && Convert.ToInt32(localCep, CultureInfo.CurrentCulture) >= 10  && Convert.ToInt32(localCep, CultureInfo.CurrentCulture) <= 199)      return true; 
						else if (state == "RJ" && Convert.ToInt32(localCep, CultureInfo.CurrentCulture) >= 200 && Convert.ToInt32(localCep, CultureInfo.CurrentCulture) <= 289) return true; 
						else if (state == "ES" && Convert.ToInt32(localCep, CultureInfo.CurrentCulture) >= 290 && Convert.ToInt32(localCep, CultureInfo.CurrentCulture) <= 299) return true; 
						else if (state == "MG" && Convert.ToInt32(localCep, CultureInfo.CurrentCulture) >= 300 && Convert.ToInt32(localCep, CultureInfo.CurrentCulture) <= 399) return true; 
						else if (state == "BA" && Convert.ToInt32(localCep, CultureInfo.CurrentCulture) >= 400 && Convert.ToInt32(localCep, CultureInfo.CurrentCulture) <= 489) return true; 
						else if (state == "SE" && Convert.ToInt32(localCep, CultureInfo.CurrentCulture) >= 490 && Convert.ToInt32(localCep, CultureInfo.CurrentCulture) <= 499) return true; 
						else if (state == "PE" && Convert.ToInt32(localCep, CultureInfo.CurrentCulture) >= 500 && Convert.ToInt32(localCep, CultureInfo.CurrentCulture) <= 569) return true; 
						else if (state == "AL" && Convert.ToInt32(localCep, CultureInfo.CurrentCulture) >= 570 && Convert.ToInt32(localCep, CultureInfo.CurrentCulture) <= 579) return true; 
						else if (state == "PB" && Convert.ToInt32(localCep, CultureInfo.CurrentCulture) >= 580 && Convert.ToInt32(localCep, CultureInfo.CurrentCulture) <= 589) return true; 
						else if (state == "RN" && Convert.ToInt32(localCep, CultureInfo.CurrentCulture) >= 590 && Convert.ToInt32(localCep, CultureInfo.CurrentCulture) <= 599) return true; 
						else if (state == "CE" && Convert.ToInt32(localCep, CultureInfo.CurrentCulture) >= 600 && Convert.ToInt32(localCep, CultureInfo.CurrentCulture) <= 639) return true; 
						else if (state == "PI" && Convert.ToInt32(localCep, CultureInfo.CurrentCulture) >= 640 && Convert.ToInt32(localCep, CultureInfo.CurrentCulture) <= 649) return true; 
						else if (state == "MA" && Convert.ToInt32(localCep, CultureInfo.CurrentCulture) >= 650 && Convert.ToInt32(localCep, CultureInfo.CurrentCulture) <= 659) return true; 
						else if (state == "PA" && Convert.ToInt32(localCep, CultureInfo.CurrentCulture) >= 660 && Convert.ToInt32(localCep, CultureInfo.CurrentCulture) <= 688) return true; 
						else if ((state == "AM" && Convert.ToInt32(localCep, CultureInfo.CurrentCulture) >= 690 && Convert.ToInt32(localCep, CultureInfo.CurrentCulture) <= 692) || (Convert.ToInt32(localCep, CultureInfo.CurrentCulture) >= 694 && (Convert.ToInt32(localCep, CultureInfo.CurrentCulture) <= 698))) return true; 
						else if (state == "AP" && Convert.ToInt32(localCep, CultureInfo.CurrentCulture) == 689) return true; 
						else if (state == "RR" && Convert.ToInt32(localCep, CultureInfo.CurrentCulture) == 693) return true; 
						else if (state == "AC" && Convert.ToInt32(localCep, CultureInfo.CurrentCulture) == 699) return true; 
						else if (((state == "DF") || (state == "GO")) && Convert.ToInt32(localCep, CultureInfo.CurrentCulture) >= 700 && Convert.ToInt32(localCep, CultureInfo.CurrentCulture) <= 769) return true; 
						else if (state == "TO" && Convert.ToInt32(localCep, CultureInfo.CurrentCulture) >= 770 && Convert.ToInt32(localCep, CultureInfo.CurrentCulture) <= 779) return true; 
						else if (state == "MT" && Convert.ToInt32(localCep, CultureInfo.CurrentCulture) >= 780 && Convert.ToInt32(localCep, CultureInfo.CurrentCulture) <= 788) return true; 
						else if (state == "MS" && Convert.ToInt32(localCep, CultureInfo.CurrentCulture) >= 790 && Convert.ToInt32(localCep, CultureInfo.CurrentCulture) <= 799) return true; 
						else if (state == "RO" && Convert.ToInt32(localCep, CultureInfo.CurrentCulture) == 789)  return true; 
						else if (state == "PR" && Convert.ToInt32(localCep, CultureInfo.CurrentCulture) >= 800 && Convert.ToInt32(localCep, CultureInfo.CurrentCulture) <= 879) return true; 
						else if (state == "SC" && Convert.ToInt32(localCep, CultureInfo.CurrentCulture) >= 880 && Convert.ToInt32(localCep, CultureInfo.CurrentCulture) <= 899) return true; 
						else if (state == "RS" && Convert.ToInt32(localCep, CultureInfo.CurrentCulture) >= 900 && Convert.ToInt32(localCep, CultureInfo.CurrentCulture) <= 999) return true;
					}
				}
				catch(Exception x)
				{
					Debug.WriteLine(x.Message);
					return false;
				}
			}
			return false;
		}

		public static bool IsAcreSrOk(string sr)
		{
			System.Int32 sum = 0, digit1 = 0;

			//begin test
			string localSr = CommonHelpers.GetOnlyDigits(sr);
			
			if (localSr.Length == 9 && 
				Convert.ToInt16(localSr.Substring(2,1), CultureInfo.CurrentCulture) +
				Convert.ToInt16(localSr.Substring(3,1), CultureInfo.CurrentCulture) > 0)     
			{
				try
				{
					//D�git
					sum = 0;
					for (int i=1;i<=9;i++) sum += Convert.ToInt16(localSr.Substring(i-1,1), CultureInfo.CurrentCulture)*(10-i);
					digit1 = sum % 11;
					if (digit1 < 2) digit1 = 0;
					else digit1 = 11-digit1;
					//
					return (digit1 == Convert.ToInt16(localSr.Substring(8,1), CultureInfo.CurrentCulture));
				}
				catch(Exception x)
				{
					Debug.WriteLine(x.Message);
					return false;
				}
			}
			return false;
		}
		
		public static bool IsAlagoasSrOk(string sr)
		{
			System.Int32 sum = 0, digit1 = 0;

			//begin test
			string localSr = CommonHelpers.GetOnlyDigits(sr);
			
			if ((localSr.Length == 9 && 
				localSr.Substring(0,1) == "2" &&
				localSr.Substring(1,1) == "4") &&
				(localSr.Substring(2,1) == "0" || //normal
				localSr.Substring(2,1) == "3" || //produtor rural
				localSr.Substring(2,1) == "5" || //substituta
				localSr.Substring(2,1) == "7" || //microempresa ambulante
				localSr.Substring(2,1) == "8"))  //microempresa
			{
				try
				{
					//D�git
					sum = 0;
					for (int i=1;i<=8;i++) sum += Convert.ToInt16(localSr.Substring((localSr.Length-1)-i,1), CultureInfo.CurrentCulture)*(i+1);
					sum *= 10;
					digit1 = sum - ((Int32)(sum / 11))*11;
					//
					return (digit1 == Convert.ToInt16(localSr.Substring(8,1), CultureInfo.CurrentCulture));
				}
				catch(Exception x)
				{
					Debug.WriteLine(x.Message);
					return false;
				}
			}
			return false;
		}

		public static bool IsAmapaSrOk(string sr)
		{
			System.Int32 sum = 0, digit1 = 0;

			//begin test
			string localSr = CommonHelpers.GetOnlyDigits(sr);
			
			if (localSr.Length == 9 && 
				localSr.Substring(0,1) == "0" &&
				localSr.Substring(1,1) == "3")
			{
				try
				{
					System.Int32 p=0,d=0,n=0;
					n = Convert.ToInt32(localSr.Substring(0,8), CultureInfo.CurrentCulture);
					if (n >= 03000001 && n <= 03017000) {p=5;d=0;}
					else if (n >= 03017001 && n <= 03019022) {p=9;d=1;}
					else if (n >= 03019023) {p=0;d=0;}
					//D�git
					sum = 0;
					for (int i=1;i<=8;i++) sum += Convert.ToInt16(localSr.Substring(i-1,1), CultureInfo.CurrentCulture)*(10-i);
					sum += p;
					digit1 = 11 - (sum % 11);
					if (digit1 == 10) digit1 = 0;
					else if (digit1 == 11) digit1 = d;
					//
					return (digit1 == Convert.ToInt16(localSr.Substring(8,1), CultureInfo.CurrentCulture));
				}
				catch(Exception x)
				{
					Debug.WriteLine(x.Message);
					return false;
				}
			}
			return false;
		}

		public static bool IsAmazonasSrOk(string sr)
		{
			System.Int32 sum = 0, digit1 = 0;

			//begin test
			string localSr = CommonHelpers.GetOnlyDigits(sr);
		
			try
			{
				if (localSr.Length == 9)
				{
					//D�git
					sum = 0;
					for (int i=1;i<=8;i++) sum += Convert.ToInt16(localSr.Substring(i-1,1), CultureInfo.CurrentCulture)*(10-i);
				
					if (sum < 11) digit1 = 11-sum;
					else
					{
						digit1 = (sum % 11);
						if (digit1 <= 1) digit1 = 0;
						else digit1 = 11 - digit1;
					}
					return (digit1 == Convert.ToInt16(localSr.Substring(8,1), CultureInfo.CurrentCulture));
				}
			}
			catch(Exception x)
			{
				Debug.WriteLine(x.Message);
				return false;
			}
			return false;
		}

		public static bool IsBahiaSrOk(string sr)
		{
			System.Int32 sum = 0, digit1,digit2,firstDigit = 0;

			//begin test
			string localSr = CommonHelpers.GetOnlyDigits(sr);
			try
			{
				if (localSr.Length == 8)
				{
					firstDigit = Convert.ToInt16(localSr.Substring(0,1), CultureInfo.CurrentCulture);
					if (firstDigit == 0 || firstDigit == 1 || firstDigit == 2 ||
						firstDigit == 3 || firstDigit == 4 || firstDigit == 5 ||
						firstDigit == 8)
					{
						//D�git2
						sum = 0;
						for (int i=1;i<=6;i++) sum += Convert.ToInt16(localSr.Substring((localSr.Length-2)-i,1), CultureInfo.CurrentCulture)*(i+1);
						digit2 = (sum % 10);
						if (digit2 > 0) digit2 = 10-digit2;
						
						//Digit1
						sum = 0;
						for (int i=1;i<=6;i++) sum += Convert.ToInt16(localSr.Substring((localSr.Length-2)-i,1), CultureInfo.CurrentCulture)*(i+2);
						sum += Convert.ToInt16(localSr.Substring(7,1), CultureInfo.CurrentCulture)*2;

						digit1 = 10 - (sum % 10);

						//Check digits
						return (digit1 == Convert.ToInt16(localSr.Substring(6,1), CultureInfo.CurrentCulture) &&
							digit2 == Convert.ToInt16(localSr.Substring(7,1), CultureInfo.CurrentCulture));
					}
					else if (firstDigit == 6 || firstDigit == 7 || firstDigit == 9)
					{
						//D�git2
						sum = 0;
						for (int i=1;i<=6;i++) sum += Convert.ToInt16(localSr.Substring((localSr.Length-2)-i,1), CultureInfo.CurrentCulture)*(i+1);
						digit2 = (sum % 11);
						if (digit2 == 0 || digit2 == 1) digit2 = 0;
						else digit2 = 11-digit2;
						
						//Digit1
						sum = 0;
						for (int i=1;i<=6;i++) sum += Convert.ToInt16(localSr.Substring((localSr.Length-2)-i,1), CultureInfo.CurrentCulture)*(i+2);
						sum += Convert.ToInt16(localSr.Substring(7,1), CultureInfo.CurrentCulture)*2;

						digit1 = 11 - (sum % 11);

						//Check digits
						return (digit1 == Convert.ToInt16(localSr.Substring(6,1), CultureInfo.CurrentCulture) &&
							digit2 == Convert.ToInt16(localSr.Substring(7,1), CultureInfo.CurrentCulture));
					}
				}
			}
			catch(Exception x)
			{
				Debug.WriteLine(x.Message);
				return false;
			}
			return false;
		}

		public static bool IsCearaSrOk(string sr)
		{
			System.Int32 sum = 0, digit1 = 0;

			//begin test
			string localSr = CommonHelpers.GetOnlyDigits(sr);
			
			if (localSr.Length == 9)
			{
				try
				{
					//D�git
					sum = 0;
					for (int i=1;i<=8;i++) sum += Convert.ToInt16(localSr.Substring(i-1,1), CultureInfo.CurrentCulture)*(10-i);
					digit1 = 11-(sum % 11);
					if (digit1 == 10 || digit1 == 11) digit1 = 0;
					//
					return (digit1 == Convert.ToInt16(localSr.Substring(8,1), CultureInfo.CurrentCulture));
				}
				catch(Exception x)
				{
					Debug.WriteLine(x.Message);
					return false;
				}
			}
			return false;
		}
		
		public static bool IsDistritoFederalSrOk(string sr)
		{
			System.Int32 sum = 0, digit1,digit2 = 0;

			//begin test
			string localSr = CommonHelpers.GetOnlyDigits(sr);
			
			try
			{
				if (localSr.Length == 13)
				{
					//Digit1
					sum = 0;
					for (Int16 i=1;i<=11;i++) 
					{
						Int32 mult = i+1;
						if (mult >= 10) mult -= 8;
						else mult = i+1;
						sum += Convert.ToInt16(localSr.Substring((localSr.Length-2)-i,1), CultureInfo.CurrentCulture)*mult;
					}
					digit1 = 11-(sum % 11);
					if (digit1 == 10 || digit1 == 11) digit1 = 0;

					//Digit2
					sum = 0;
					for (Int16 i=1;i<=12;i++) 
					{
						Int32 mult = i+1;
						if (mult >= 10) mult -= 8;
						else mult = i+1;
						sum += Convert.ToInt16(localSr.Substring((localSr.Length-1)-i,1), CultureInfo.CurrentCulture)*mult;
					}
					digit2 = 11-(sum % 11);
					if (digit2 == 10 || digit2 == 11) digit2 = 0;

					//Check digits
					return (digit1 == Convert.ToInt16(localSr.Substring(11,1), CultureInfo.CurrentCulture) &&
						digit2 == Convert.ToInt16(localSr.Substring(12,1), CultureInfo.CurrentCulture));
				}
			}
			catch(Exception x)
			{
				Debug.WriteLine(x.Message);
				return false;
			}
			return false;
		}
		
		public static bool IsEspiritoSantoSrOk(string sr)
		{
			System.Int32 sum = 0, digit1 = 0;

			//begin test
			string localSr = CommonHelpers.GetOnlyDigits(sr);
			
			if (localSr.Length == 9)
			{
				try
				{
					//D�git
					sum = 0;
					for (int i=1;i<=8;i++) sum += Convert.ToInt16(localSr.Substring(i-1,1), CultureInfo.CurrentCulture)*(10-i);
					digit1 = (sum % 11);
					if (digit1 > 1) digit1 = 11-digit1;
					else if (digit1 < 2) digit1 = 0;
					//
					return (digit1 == Convert.ToInt16(localSr.Substring(8,1), CultureInfo.CurrentCulture));
				}
				catch(Exception x)
				{
					Debug.WriteLine(x.Message);
					return false;
				}
			}
			return false;
		}

		public static bool IsGoiasSrOk(string sr)
		{
			System.Int32 sum = 0, digit1 = 0;

			//begin test
			string localSr = CommonHelpers.GetOnlyDigits(sr);
			
			Int32 ab = Convert.ToInt16(localSr.Substring(0,2), CultureInfo.CurrentCulture);

			if (localSr.Length == 9 && 
				(ab == 10 || ab == 11 || ab ==15))
			{
				try
				{
					//D�git
					sum = 0;
					for (int i=1;i<=8;i++) sum += Convert.ToInt16(localSr.Substring(i-1,1), CultureInfo.CurrentCulture)*(10-i);
					digit1 = sum % 11;
					//
					if (digit1 == 0) digit1 = 0;
					else if (digit1 == 1)
					{
						if (Convert.ToInt32(localSr.Substring(0,8), CultureInfo.CurrentCulture) >= 10103105 &&
							Convert.ToInt32(localSr.Substring(0,8), CultureInfo.CurrentCulture) <= 10119997) 
							digit1 = 1;
						else 
							digit1 = 0;
					}
					else //digit1 <> 0 and 1
					{
						digit1 = 11-digit1;
					}
					//
					return (digit1 == Convert.ToInt16(localSr.Substring(8,1), CultureInfo.CurrentCulture));
				}
				catch(Exception x)
				{
					Debug.WriteLine(x.Message);
					return false;
				}
			}
			return false;
		}
		
		public static bool IsMaranhaoSrOk(string sr)
		{
			System.Int32 sum = 0, digit1 = 0;

			//begin test
			string localSr = CommonHelpers.GetOnlyDigits(sr);
			
			Int32 ab = Convert.ToInt16(localSr.Substring(0,2), CultureInfo.CurrentCulture);

			if (localSr.Length == 9 && ab == 12) 
			{
				try
				{
					//D�git
					sum = 0;
					for (int i=1;i<=8;i++) sum += Convert.ToInt16(localSr.Substring(i-1,1), CultureInfo.CurrentCulture)*(10-i);
					digit1 = 11-(sum % 11);
					//
					return (digit1 == Convert.ToInt16(localSr.Substring(8,1), CultureInfo.CurrentCulture));
				}
				catch(Exception x)
				{
					Debug.WriteLine(x.Message);
					return false;
				}
			}
			return false;
		}
		
		public static bool IsMatoGrossoSrOk(string sr)
		{
			System.Int32 sum = 0, digit1 = 0;

			//begin test
			string localSr = CommonHelpers.GetOnlyDigits(sr);
			
			try
			{
				if (localSr.Length == 11)
				{
					//Digit1
					sum = 0;
					for (Int16 i=1;i<=10;i++) 
					{
						Int32 mult = i+1;
						if (mult >= 10) mult -= 8;
						else mult = i+1;
						sum += Convert.ToInt16(localSr.Substring((localSr.Length-1)-i,1), CultureInfo.CurrentCulture)*mult;
					}
					digit1 = 11-(sum % 11);

					//Check digit
					return (digit1 == Convert.ToInt16(localSr.Substring(10,1), CultureInfo.CurrentCulture));
				}
			}
			catch(Exception x)
			{
				Debug.WriteLine(x.Message);
				return false;
			}
			return false;
		}

		public static bool IsMatoGrossoSulSrOk(string sr)
		{
			System.Int32 sum = 0, digit1 = 0;

			//begin test
			string localSr = CommonHelpers.GetOnlyDigits(sr);
			
			if (localSr.Length == 9 && localSr[1] == '8')
			{
				try
				{
					//D�git
					sum = 0;
					for (int i=1;i<=8;i++) sum += Convert.ToInt16(localSr.Substring(i-1,1), CultureInfo.CurrentCulture)*(10-i);
					digit1 = (sum % 11);
					if (digit1 == 0) digit1 = 0;
					else if (digit1 > 0)
					{
						digit1 = 11-(sum % 11);
						if (digit1 > 9) digit1=0;
					}
					//
					return (digit1 == Convert.ToInt16(localSr.Substring(8,1), CultureInfo.CurrentCulture));
				}
				catch(Exception x)
				{
					Debug.WriteLine(x.Message);
					return false;
				}
			}
			return false;
		}

		public static bool IsMinasGeraisSrOk(string sr)
		{
			System.Int32 sum = 0,mult,digit1,digit2 = 0;

			//begin test
			string localSr = CommonHelpers.GetOnlyDigits(sr);
			
			try
			{
				if (localSr.Length == 13)
				{
					//Digit1
					StringBuilder sb     = new StringBuilder();
					string digit1LocalSr = localSr.Insert(3, "0");
					mult = 1;
					for (Int16 i=1;i<=12;i++) 
					{
						sb.Append(Convert.ToString(Convert.ToInt16(digit1LocalSr.Substring(i-1,1), CultureInfo.CurrentCulture)*mult, CultureInfo.CurrentCulture));
						if (mult == 1) mult = 2;
						else mult = 1;
					}
					foreach(Char myChar in sb.ToString()) sum += Convert.ToInt16(myChar.ToString(CultureInfo.CurrentCulture), CultureInfo.CurrentCulture);
					digit1 = CommonHelpers.GetNextDozen(sum) - sum; 
					
					//Digit2
					sum = 0;
					for (Int16 i=1;i<=12;i++) 
					{
						mult = i+1;
						if (mult >= 12) mult -= 10;
						else mult = i+1;
						sum += Convert.ToInt16(localSr.Substring((localSr.Length-1)-i,1), CultureInfo.CurrentCulture)*mult;
					}
					digit2 = 11-(sum % 11);

					//Check digits
					return (digit1 == Convert.ToInt16(localSr.Substring(11,1), CultureInfo.CurrentCulture) &&
						digit2 == Convert.ToInt16(localSr.Substring(12,1), CultureInfo.CurrentCulture));
				}
			}
			catch(Exception x)
			{
				Debug.WriteLine(x.Message);
				return false;
			}
			return false;
		}

		public static bool IsParaSrOk(string sr)
		{
			System.Int32 sum = 0, digit1 = 0;

			//begin test
			string localSr = CommonHelpers.GetOnlyDigits(sr);
			
			Int32 ab = Convert.ToInt16(localSr.Substring(0,2), CultureInfo.CurrentCulture);

			if (localSr.Length == 9 && ab == 15) 
			{
				try
				{
					//D�git
					sum = 0;
					for (int i=1;i<=8;i++) sum += Convert.ToInt16(localSr.Substring(i-1,1), CultureInfo.CurrentCulture)*(10-i);
					digit1 = (sum % 11);
					if (digit1 == 0 || digit1 == 1) digit1 = 0;
					else digit1 = 11 - digit1;
					//
					return (digit1 == Convert.ToInt16(localSr.Substring(8,1), CultureInfo.CurrentCulture));
				}
				catch(Exception x)
				{
					Debug.WriteLine(x.Message);
					return false;
				}
			}
			return false;
		}

		public static bool IsParaibaSrOk(string sr)
		{
			System.Int32 sum = 0, digit1 = 0;

			//begin test
			string localSr = CommonHelpers.GetOnlyDigits(sr);
			
			if (localSr.Length == 9) 
			{
				try
				{
					//D�git
					sum = 0;
					for (int i=1;i<=8;i++) sum += Convert.ToInt16(localSr.Substring(i-1,1), CultureInfo.CurrentCulture)*(10-i);
					digit1 = (sum % 11);
					if (digit1 == 10 || digit1 == 11) digit1 = 0;
					else digit1 = 11 - digit1;
					//
					return (digit1 == Convert.ToInt16(localSr.Substring(8,1), CultureInfo.CurrentCulture));
				}
				catch(Exception x)
				{
					Debug.WriteLine(x.Message);
					return false;
				}
			}
			return false;
		}

		public static bool IsParanaSrOk(string sr)
		{
			System.Int32 mult=0,sum = 0,digit1,digit2 = 0;

			//begin test
			string localSr = CommonHelpers.GetOnlyDigits(sr);
			
			try
			{
				if (localSr.Length == 10)
				{
					//Digit1
					sum = 0;
					for (int i=1;i<=8;i++) 
					{
						mult = i+1;
						if (mult >= 8) mult -= 6;
						else mult = i+1;
						sum += Convert.ToInt16(localSr.Substring((localSr.Length-2)-i,1), CultureInfo.CurrentCulture)*mult;
					}
					digit1 = (sum % 11);
					if (digit1 == 0 || digit1 == 1) digit1 = 0;
					else digit1 = 11-digit1;

					//Digit2
					sum = 0;
					for (int i=1;i<=9;i++) 
					{
						mult = i+1;
						if (mult >= 8) mult -= 6;
						else mult = i+1;
						sum += Convert.ToInt16(localSr.Substring((localSr.Length-1)-i,1), CultureInfo.CurrentCulture)*mult;
					}
					digit2 = (sum % 11);
					if (digit2 == 0 || digit2 == 1) digit2 = 0;
					else digit2 = 11-digit2;

					//Check digits
					return (digit1 == Convert.ToInt16(localSr.Substring(8,1), CultureInfo.CurrentCulture) &&
						digit2 == Convert.ToInt16(localSr.Substring(9,1), CultureInfo.CurrentCulture));
				}
			}
			catch(Exception x)
			{
				Debug.WriteLine(x.Message);
				return false;
			}
			return false;
		}

		public static bool IsPernambucoSrOk(string sr)
		{
			System.Int32 mult=0,sum = 0,digit1 = 0;

			//begin test
			string localSr = CommonHelpers.GetOnlyDigits(sr);
			
			try
			{
				if (localSr.Length == 14)
				{
					//Digit1
					sum = 0;
					for (int i=1;i<=13;i++) 
					{
						mult = i+1;
						if (mult >= 11) mult -= 9;
						else mult = i+1;
						sum += Convert.ToInt16(localSr.Substring((localSr.Length-1)-i,1), CultureInfo.CurrentCulture)*mult;
					}
					digit1 = 11-(sum % 11);
					if (digit1 > 9) digit1 = digit1-10;

					//Check digits
					return (digit1 == Convert.ToInt16(localSr.Substring(13,1), CultureInfo.CurrentCulture));
				}
			}
			catch(Exception x)
			{
				Debug.WriteLine(x.Message);
				return false;
			}
			return false;
		}

		public static bool IsPiauiSrOk(string sr)
		{
			System.Int32 sum = 0, digit1 = 0;

			//begin test
			string localSr = CommonHelpers.GetOnlyDigits(sr);
			
			if (localSr.Length == 9)
			{
				try
				{
					//D�git
					sum = 0;
					for (int i=1;i<=8;i++) sum += Convert.ToInt16(localSr.Substring(i-1,1), CultureInfo.CurrentCulture)*(10-i);
					digit1 = 11-(sum % 11);
					if (digit1 == 10 || digit1 == 11) digit1 = 0;
					//
					return (digit1 == Convert.ToInt16(localSr.Substring(8,1), CultureInfo.CurrentCulture));
				}
				catch(Exception x)
				{
					Debug.WriteLine(x.Message);
					return false;
				}
			}
			return false;
		}

		public static bool IsRioDeJaneiroSrOk(string sr)
		{
			System.Int32 mult=0,sum = 0,digit1 = 0;

			//begin test
			string localSr = CommonHelpers.GetOnlyDigits(sr);
			
			try
			{
				if (localSr.Length == 8)
				{
					//Digit1
					sum = 0;
					for (int i=1;i<=7;i++) 
					{
						mult = i+1;
						if (mult >= 8) mult -= 6;
						else mult = i+1;
						sum += Convert.ToInt16(localSr.Substring((localSr.Length-1)-i,1), CultureInfo.CurrentCulture)*mult;
					}
					digit1 = (sum % 11);
					if (digit1 <= 1) digit1 = 0;
					else digit1 = 11 - digit1;

					//Check digits
					return (digit1 == Convert.ToInt16(localSr.Substring(7,1), CultureInfo.CurrentCulture));
				}
			}
			catch(Exception x)
			{
				Debug.WriteLine(x.Message);
				return false;
			}
			return false;
		}

		public static bool IsRioGrandeDoNorteSrOk(string sr)
		{
			System.Int32 sum = 0, digit1 = 0;

			//begin test
			string localSr = CommonHelpers.GetOnlyDigits(sr);
			
			if ((localSr.Length == 9 && 
				localSr.Substring(0,1) == "2" &&
				localSr.Substring(1,1) == "0"))
			{
				try
				{
					//D�git
					sum = 0;
					for (int i=1;i<=8;i++) sum += Convert.ToInt16(localSr.Substring((localSr.Length-1)-i,1), CultureInfo.CurrentCulture)*(i+1);
					sum *= 10;
					digit1 = (sum % 11);
					if (digit1 > 9) digit1 = 0;
					//
					return (digit1 == Convert.ToInt16(localSr.Substring(8,1), CultureInfo.CurrentCulture));
				}
				catch(Exception x)
				{
					Debug.WriteLine(x.Message);
					return false;
				}
			}
			return false;
		}

		public static bool IsRioGrandeDoSulOk(string sr)
		{
			System.Int32 mult=0,sum = 0,digit1 = 0;

			//begin test
			string localSr = CommonHelpers.GetOnlyDigits(sr);
			
			try
			{
				if (localSr.Length == 10)
				{
					//Digit1
					sum = 0;
					for (int i=1;i<=9;i++) 
					{
						mult = i+1;
						if (mult >= 10) mult -= 8;
						else mult = i+1;
						sum += Convert.ToInt16(localSr.Substring((localSr.Length-1)-i,1), CultureInfo.CurrentCulture)*mult;
					}
					digit1 = 11-(sum % 11);
					if (digit1 > 10) digit1 = 0;

					//Check digits
					return (digit1 == Convert.ToInt16(localSr.Substring(9,1), CultureInfo.CurrentCulture));
				}
			}
			catch(Exception x)
			{
				Debug.WriteLine(x.Message);
				return false;
			}
			return false;
		}

		public static bool IsRondoniaOk(string sr)
		{
			System.Int32 sum = 0,digit1 = 0;

			//begin test
			string localSr = CommonHelpers.GetOnlyDigits(sr);
			
			try
			{
				if (localSr.Length == 9)
				{
					//Digit1
					sum = 0;
					for (int i=1;i<=5;i++) 
					{
						sum += Convert.ToInt16(localSr.Substring((localSr.Length-1)-i,1), CultureInfo.CurrentCulture)*(i+1);
					}
					digit1 = 11-(sum % 11);
					if (digit1 > 10) digit1 = 0;

					//Check digits
					return (digit1 == Convert.ToInt16(localSr.Substring(8,1), CultureInfo.CurrentCulture));
				}
			}
			catch(Exception x)
			{
				Debug.WriteLine(x.Message);
				return false;
			}
			return false;
		}

		public static bool IsRoraimaOk(string sr)
		{
			System.Int32 sum = 0,digit1 = 0;

			//begin test
			string localSr = CommonHelpers.GetOnlyDigits(sr);
			
			try
			{
				if (localSr.Length == 9)
				{
					//Digit1
					sum = 0;
					for (int i=1;i<=8;i++) 
					{
						sum += Convert.ToInt16(localSr.Substring(i-1,1), CultureInfo.CurrentCulture)*i;
					}
					digit1 = (sum % 9);

					//Check digits
					return (digit1 == Convert.ToInt16(localSr.Substring(8,1), CultureInfo.CurrentCulture));
				}
			}
			catch(Exception x)
			{
				Debug.WriteLine(x.Message);
				return false;
			}
			return false;
		}

		public static bool IsSantaCatarinaSrOk(string sr)
		{
			System.Int32 sum = 0, digit1 = 0;

			//begin test
			string localSr = CommonHelpers.GetOnlyDigits(sr);
			
			if (localSr.Length == 9)
			{
				try
				{
					//D�git
					sum = 0;
					for (int i=1;i<=8;i++) sum += Convert.ToInt16(localSr.Substring((localSr.Length-1)-i,1), CultureInfo.CurrentCulture)*(i+1);
					digit1 = 11-(sum % 11);
					if (digit1 == 0 || digit1 == 1) digit1 = 0;
					//
					return (digit1 == Convert.ToInt16(localSr.Substring(8,1), CultureInfo.CurrentCulture));
				}
				catch(Exception x)
				{
					Debug.WriteLine(x.Message);
					return false;
				}
			}
			return false;
		}

		public static bool IsSergipeSrOk(string sr)
		{
			System.Int32 sum = 0, digit1 = 0;

			//begin test
			string localSr = CommonHelpers.GetOnlyDigits(sr);
			
			if (localSr.Length == 9)
			{
				try
				{
					//D�git
					sum = 0;
					for (int i=1;i<=8;i++) sum += Convert.ToInt16(localSr.Substring((localSr.Length-1)-i,1), CultureInfo.CurrentCulture)*(i+1);
					digit1 = 11-(sum % 11);
					if (digit1 > 9) digit1 = 0;
					//
					return (digit1 == Convert.ToInt16(localSr.Substring(8,1), CultureInfo.CurrentCulture));
				}
				catch(Exception x)
				{
					Debug.WriteLine(x.Message);
					return false;
				}
			}
			return false;
		}

		public static bool IsTocantinsSrOk(string sr)
		{
			System.Int32 sum = 0, digit1 = 0;

			//begin test
			string localSr = CommonHelpers.GetOnlyDigits(sr);
			
			string ab = localSr.Substring(2,2);

			if (localSr.Length == 11 && 
				(ab == "01" || ab == "02" || ab == "03" || ab == "99"))
			{
				try
				{
					//D�git
					sum = 0;
					Int16 indexAux = 1;
					for (Int16 i=1;i<=10;i++) 
					{
						if ((localSr.Length-1-i) != 2 && (localSr.Length-1-i) != 3)
						{
							sum += Convert.ToInt16(localSr.Substring((localSr.Length-1)-i,1), CultureInfo.CurrentCulture)*indexAux;
							indexAux++;
						}
						else {if (indexAux == 7) indexAux++;}
					}
					digit1 = 11-(sum % 11);

					//Check digit
					return (digit1 == Convert.ToInt16(localSr.Substring(10,1), CultureInfo.CurrentCulture));
				}
				catch(Exception x)
				{
					Debug.WriteLine(x.Message);
					return false;
				}
			}
			return false;
		}

		public static bool IsSaoPauloSrOk(string sr)
		{
			System.Int32 sum = 0,digit1 = 0,digit2 = 0;

			//begin test
			string localSr = CommonHelpers.GetOnlyDigits(sr);
			
			try
			{
				if (localSr.Length == 12)
				{
					if (sr[0] != 'P')
					{
						//Digit1
						sum = 0;
						sum += Convert.ToInt16(localSr[0].ToString(CultureInfo.CurrentCulture), CultureInfo.CurrentCulture)*1;
						sum += Convert.ToInt16(localSr[1].ToString(CultureInfo.CurrentCulture), CultureInfo.CurrentCulture)*3;
						sum += Convert.ToInt16(localSr[2].ToString(CultureInfo.CurrentCulture), CultureInfo.CurrentCulture)*4;
						sum += Convert.ToInt16(localSr[3].ToString(CultureInfo.CurrentCulture), CultureInfo.CurrentCulture)*5;
						sum += Convert.ToInt16(localSr[4].ToString(CultureInfo.CurrentCulture), CultureInfo.CurrentCulture)*6;
						sum += Convert.ToInt16(localSr[5].ToString(CultureInfo.CurrentCulture), CultureInfo.CurrentCulture)*7;
						sum += Convert.ToInt16(localSr[6].ToString(CultureInfo.CurrentCulture), CultureInfo.CurrentCulture)*8;
						sum += Convert.ToInt16(localSr[7].ToString(CultureInfo.CurrentCulture), CultureInfo.CurrentCulture)*10;
						
						digit1 = (sum % 11);
						digit1 = Convert.ToInt16(digit1.ToString(CultureInfo.CurrentCulture)[digit1.ToString(CultureInfo.CurrentCulture).Length-1].ToString(CultureInfo.CurrentCulture), CultureInfo.CurrentCulture);

						//Digit2
						sum = 0;
						sum += Convert.ToInt16(localSr[00].ToString(CultureInfo.CurrentCulture), CultureInfo.CurrentCulture)*3;
						sum += Convert.ToInt16(localSr[01].ToString(CultureInfo.CurrentCulture), CultureInfo.CurrentCulture)*2;
						sum += Convert.ToInt16(localSr[02].ToString(CultureInfo.CurrentCulture), CultureInfo.CurrentCulture)*10;
						sum += Convert.ToInt16(localSr[03].ToString(CultureInfo.CurrentCulture), CultureInfo.CurrentCulture)*9;
						sum += Convert.ToInt16(localSr[04].ToString(CultureInfo.CurrentCulture), CultureInfo.CurrentCulture)*8;
						sum += Convert.ToInt16(localSr[05].ToString(CultureInfo.CurrentCulture), CultureInfo.CurrentCulture)*7;
						sum += Convert.ToInt16(localSr[06].ToString(CultureInfo.CurrentCulture), CultureInfo.CurrentCulture)*6;
						sum += Convert.ToInt16(localSr[07].ToString(CultureInfo.CurrentCulture), CultureInfo.CurrentCulture)*5;
						sum += Convert.ToInt16(localSr[08].ToString(CultureInfo.CurrentCulture), CultureInfo.CurrentCulture)*4;
						sum += Convert.ToInt16(localSr[09].ToString(CultureInfo.CurrentCulture), CultureInfo.CurrentCulture)*3;
						sum += Convert.ToInt16(localSr[10].ToString(CultureInfo.CurrentCulture), CultureInfo.CurrentCulture)*2;
						
						digit2 = (sum % 11);
						digit2 = Convert.ToInt16(digit2.ToString(CultureInfo.CurrentCulture)[digit2.ToString(CultureInfo.CurrentCulture).Length-1].ToString(CultureInfo.CurrentCulture), CultureInfo.CurrentCulture);
					
						//Check digits
						return (digit1 == Convert.ToInt16(localSr.Substring(8,1), CultureInfo.CurrentCulture) &&
							digit2 == Convert.ToInt16(localSr.Substring(11,1), CultureInfo.CurrentCulture));
					}
					else
					{
						//Digit1
						sum = 0;
						sum += Convert.ToInt16(localSr[0].ToString(CultureInfo.CurrentCulture), CultureInfo.CurrentCulture)*1;
						sum += Convert.ToInt16(localSr[1].ToString(CultureInfo.CurrentCulture), CultureInfo.CurrentCulture)*3;
						sum += Convert.ToInt16(localSr[2].ToString(CultureInfo.CurrentCulture), CultureInfo.CurrentCulture)*4;
						sum += Convert.ToInt16(localSr[3].ToString(CultureInfo.CurrentCulture), CultureInfo.CurrentCulture)*5;
						sum += Convert.ToInt16(localSr[4].ToString(CultureInfo.CurrentCulture), CultureInfo.CurrentCulture)*6;
						sum += Convert.ToInt16(localSr[5].ToString(CultureInfo.CurrentCulture), CultureInfo.CurrentCulture)*7;
						sum += Convert.ToInt16(localSr[6].ToString(CultureInfo.CurrentCulture), CultureInfo.CurrentCulture)*8;
						sum += Convert.ToInt16(localSr[7].ToString(CultureInfo.CurrentCulture), CultureInfo.CurrentCulture)*10;
						
						digit1 = (sum % 11);
						digit1 = Convert.ToInt16(digit1.ToString(CultureInfo.CurrentCulture)[digit1.ToString(CultureInfo.CurrentCulture).Length-1].ToString(CultureInfo.CurrentCulture), CultureInfo.CurrentCulture);

						//Check digits
						return (digit1 == Convert.ToInt16(localSr.Substring(8,1), CultureInfo.CurrentCulture));
					}
				}
			}
			catch(Exception x)
			{
				Debug.WriteLine(x.Message);
				return false;
			}
			return false;
		}

		public static bool IsSrOk(string sr, string state)
		{
			if (state == "AC") return IsAcreSrOk(sr);
			else if (state == "AL") return IsAlagoasSrOk(sr);
			else if (state == "AM") return IsAmazonasSrOk(sr);
			else if (state == "AP") return IsAmapaSrOk(sr);
			else if (state == "BA") return IsBahiaSrOk(sr);
			else if (state == "CE") return IsCearaSrOk(sr);
			else if (state == "DF") return IsDistritoFederalSrOk(sr);
			else if (state == "ES") return IsEspiritoSantoSrOk(sr);
			else if (state == "GO") return IsGoiasSrOk(sr);
			else if (state == "MA") return IsMaranhaoSrOk(sr);
			else if (state == "MG") return IsMinasGeraisSrOk(sr);
			else if (state == "MS") return IsMatoGrossoSulSrOk(sr);
			else if (state == "MT") return IsMatoGrossoSrOk(sr);
			else if (state == "PA") return IsParaSrOk(sr);
			else if (state == "PB") return IsParaibaSrOk(sr);
			else if (state == "PE") return IsPernambucoSrOk(sr);
			else if (state == "PI") return IsPiauiSrOk(sr);
			else if (state == "PR") return IsParanaSrOk(sr);
			else if (state == "RJ") return IsRioDeJaneiroSrOk(sr);
			else if (state == "RN") return IsRioGrandeDoNorteSrOk(sr);
			else if (state == "RO") return IsRondoniaOk(sr);
			else if (state == "RR") return IsRoraimaOk(sr);
			else if (state == "RS") return IsRioGrandeDoSulOk(sr);
			else if (state == "SC") return IsSantaCatarinaSrOk(sr);
			else if (state == "SE") return IsSergipeSrOk(sr);
			else if (state == "SP") return IsSaoPauloSrOk(sr);
			else if (state == "TO") return IsTocantinsSrOk(sr);
			else return false;
		}

		#endregion
	}
}