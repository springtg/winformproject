using System;
using System.IO;
using System.Threading;
using System.Collections;

namespace PallaControls.Utilities.CoreHelpers
{
	public class IoHelpers
	{
		#region Constructors

		private IoHelpers()
		{
		}

		#endregion

		#region Methods

		public static void GetRecursiveFiles(string path, string searchPattern, ref ArrayList listFiles)
		{
			string[] filesMain = Directory.GetFiles(path, searchPattern);
			foreach (string file in filesMain)
			{
				if (listFiles.IndexOf(file)==-1)
					listFiles.Add(file);
			}

			foreach(string localPath in Directory.GetDirectories(path))
			{
				listFiles.AddRange(Directory.GetFiles(localPath, searchPattern));
				GetRecursiveFiles(localPath, searchPattern, ref listFiles);
			}
		}

		public static bool ReplaceFile(string tempFile, string targetFile, bool deleteTempFile)
		{
			bool bStatus = false;

			if (CheckWriteAccess(targetFile))
			{
				File.Copy(tempFile, targetFile, true);
				bStatus = true;
			}
	
			if (deleteTempFile) File.Delete(tempFile);
			return bStatus;
		}

		public static bool CheckWriteAccess(string fileName)
		{
			int iCount = 0; //N�mero de tentativas
			const int iLimit = 10; //N�mero m�ximo de tentativas que devem ser feitas
			const int iDelay = 200; //Intervalo (msec) entre um tentativa e outra

			while (iCount < iLimit)
			{
				try
				{
					FileStream fs;
					fs = new FileStream(fileName, FileMode.Append, FileAccess.Write, FileShare.None);
					fs.Close();
					return true;
				}
				catch
				{
					Thread.Sleep(iDelay);
				}
				finally
				{
					iCount += 1;
				}
			}
			return false;
		}

		#endregion
	}
}
