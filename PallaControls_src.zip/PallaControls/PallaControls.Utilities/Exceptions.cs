using System;
using System.Runtime.Serialization;

namespace PallaControls.Utilities.Update
{
	#region InvalidFileAuthorizationException

	[Serializable]
	public class InvalidFileAuthorizationException : ApplicationException
	{
		#region Constructors

		public InvalidFileAuthorizationException():base()
		{
		}

		public InvalidFileAuthorizationException(string message, Exception innerException) : base(message, innerException)
		{
		}

		public InvalidFileAuthorizationException(string message) : base(message)
		{
		}

		protected InvalidFileAuthorizationException(SerializationInfo info, StreamingContext context) : base(info,context)
		{
		}

		#endregion
	}

	#endregion

	#region UpdateNotAuthorizedException

	[Serializable]
	public class UpdateNotAuthorizedException : ApplicationException
	{
		#region Constructors

		public UpdateNotAuthorizedException():base()
		{
		}

		public UpdateNotAuthorizedException(string message, Exception innerException) : base(message, innerException)
		{
		}

		public UpdateNotAuthorizedException(string message) : base(message)
		{
		}

		protected UpdateNotAuthorizedException(SerializationInfo info, StreamingContext context) : base(info,context)
		{
		}

		#endregion
	}

	#endregion

	#region InvalidPublicKeyException

	[Serializable]
	public class InvalidPublicKeyException : ApplicationException
	{
		#region Constructors

		public InvalidPublicKeyException():base()
		{
		}

		public InvalidPublicKeyException(string message, Exception innerException) : base(message, innerException)
		{
		}

		public InvalidPublicKeyException(string message) : base(message)
		{
		}

		protected InvalidPublicKeyException(SerializationInfo info, StreamingContext context) : base(info,context)
		{
		}

		#endregion
	}

	#endregion

	#region InvalidUrlUpdateServiceException

	[Serializable]
	public class InvalidUrlUpdateServiceException : ApplicationException
	{
		#region Constructors

		public InvalidUrlUpdateServiceException():base()
		{
		}

		public InvalidUrlUpdateServiceException(string message, Exception innerException) : base(message, innerException)
		{
		}

		public InvalidUrlUpdateServiceException(string message) : base(message)
		{
		}

		protected InvalidUrlUpdateServiceException(SerializationInfo info, StreamingContext context) : base(info,context)
		{
		}

		#endregion
	}

	#endregion

	#region InvalidAssemblyException

	[Serializable]
	public class InvalidAssemblyException : ApplicationException
	{
		#region Constructors

		public InvalidAssemblyException():base()
		{
		}

		public InvalidAssemblyException(string message, Exception innerException) : base(message, innerException)
		{
		}

		public InvalidAssemblyException(string message) : base(message)
		{
		}

		protected InvalidAssemblyException(SerializationInfo info, StreamingContext context) : base(info,context)
		{
		}

		#endregion
	}

	#endregion

	#region SystemUpToDateException

	[Serializable]
	public class SystemUpToDateException : ApplicationException
	{
		#region Constructors

		public SystemUpToDateException():base()
		{
		}

		public SystemUpToDateException(string message, Exception innerException) : base(message, innerException)
		{
		}

		public SystemUpToDateException(string message) : base(message)
		{
		}

		protected SystemUpToDateException(SerializationInfo info, StreamingContext context) : base(info,context)
		{
		}

		#endregion
	}

	#endregion
}
