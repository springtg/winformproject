using System;
using System.Collections;
using PallaControls.Windows.Docking;

namespace PallaControls.Windows.Forms.Collections
{
    public class ContentCollection : CollectionBase
    {
		private int _suspendCount; 

		public event CollectionClearEventHandler Clearing;
		public event CollectionClearEventHandler Cleared;
		public event CollectionChangeEventHandler Inserting;
		public event CollectionChangeEventHandler Inserted;
		public event CollectionChangeEventHandler Removing;
		public event CollectionChangeEventHandler Removed;
		
		#region Constructors

		public ContentCollection()
		{
			_suspendCount = 0;
		}

		#endregion
		
		#region Overrides
	
		protected override void OnClear()
		{
			if (!IsSuspended)
			{
				if (Clearing != null)
					Clearing(this,new EventArgs());
			}
		}	

		protected override void OnClearComplete()
		{
			if (!IsSuspended)
			{
				if (Cleared != null)
					Cleared(this,new EventArgs());
			}
		}	

		protected override void OnInsert(int index, object value)
		{
			if (!IsSuspended)
			{
				if (Inserting != null)
					Inserting(value, new PallaControls.Windows.Forms.Collections.CollectionChangeEventArgs(index));
			}
		}

		protected override void OnInsertComplete(int index, object value)
		{
			if (!IsSuspended)
			{
				if (Inserted != null)
					Inserted(value, new PallaControls.Windows.Forms.Collections.CollectionChangeEventArgs(index));
			}
		}

		protected override void OnRemove(int index, object value)
		{
			if (!IsSuspended)
			{
				if (Removing != null)
					Removing(value, new PallaControls.Windows.Forms.Collections.CollectionChangeEventArgs(index));
			}
		}

		protected override void OnRemoveComplete(int index, object value)
		{
			if (!IsSuspended)
			{
				if (Removed != null)
					Removed(value, new PallaControls.Windows.Forms.Collections.CollectionChangeEventArgs(index));
			}
		}

		#endregion
		
		#region Methods

		public Content Add(Content value)
        {
            base.List.Add(value as object);
            return value;
        }

        public void AddRange(Content[] values)
        {
            foreach(Content page in values)
                Add(page);
        }

        public void Remove(Content value)
        {
            base.List.Remove(value as object);
        }

        public void Insert(int index, Content value)
        {
            base.List.Insert(index, value as object);
        }

        public bool Contains(Content value)
        {
            return base.List.Contains(value as object);
        }

        public bool Contains(ContentCollection values)
        {
			foreach(Content c in values)
			{
				if (Contains(c))
					return true;
			}

			return false;
        }

		public void CopyTo(ContentCollection array, System.Int32 index)
		{
			foreach (Content obj in base.List)
				array.Add(obj);
		}

		public bool Contains(String value)
		{
			foreach(Content c in base.List)
				if (c.Title.Equals(value))
					return true;
					
			return false;			
		}

		public bool Contains(StringCollection values)
		{
			foreach(String s in values)
				if (Contains(s))
					return true;

			return false;
		}

		public int IndexOf(Content value)
		{
			return base.List.IndexOf(value);
		}

		public ContentCollection Copy()
		{
			ContentCollection clone = new ContentCollection();

			foreach(Content c in base.List)
				clone.Add(c);

			return clone;
		}

		#endregion

		#region Properties

		public Content this[int index]
        {
            get { return (base.List[index] as Content); }
        }

        public Content this[string title]
        {
            get 
            {
                foreach(Content c in base.List)
                    if (c.Title == title)
                        return c;

                return null;
            }
        }

		public bool IsSuspended
		{
			get { return (_suspendCount > 0); }
		}

		#endregion
    }
}
