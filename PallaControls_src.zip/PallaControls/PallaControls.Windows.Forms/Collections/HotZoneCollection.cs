using System;
using System.Collections;
using System.Drawing;
using PallaControls.Windows.Docking;
using PallaControls.Windows.Forms.Collections;

namespace PallaControls.Windows.Forms.Collections
{
    public class HotZoneCollection : CollectionBase
    {
		private int _suspendCount; 

		public event CollectionClearEventHandler Clearing;
		public event CollectionClearEventHandler Cleared;
		public event CollectionChangeEventHandler Inserting;
		public event CollectionChangeEventHandler Inserted;
		public event CollectionChangeEventHandler Removing;
		public event CollectionChangeEventHandler Removed;
		
		#region Constructors

		public HotZoneCollection()
		{
			_suspendCount = 0;
		}

		#endregion
		
		#region Overrides
	
		protected override void OnClear()
		{
			if (!IsSuspended)
			{
				if (Clearing != null)
					Clearing(this,new EventArgs());
			}
		}	

		protected override void OnClearComplete()
		{
			if (!IsSuspended)
			{
				if (Cleared != null)
					Cleared(this,new EventArgs());
			}
		}	

		protected override void OnInsert(int index, object value)
		{
			if (!IsSuspended)
			{
				if (Inserting != null)
					Inserting(value, new PallaControls.Windows.Forms.Collections.CollectionChangeEventArgs(index));
			}
		}

		protected override void OnInsertComplete(int index, object value)
		{
			if (!IsSuspended)
			{
				if (Inserted != null)
					Inserted(value, new PallaControls.Windows.Forms.Collections.CollectionChangeEventArgs(index));
			}
		}

		protected override void OnRemove(int index, object value)
		{
			if (!IsSuspended)
			{
				if (Removing != null)
					Removing(value, new PallaControls.Windows.Forms.Collections.CollectionChangeEventArgs(index));
			}
		}

		protected override void OnRemoveComplete(int index, object value)
		{
			if (!IsSuspended)
			{
				if (Removed != null)
					Removed(value, new PallaControls.Windows.Forms.Collections.CollectionChangeEventArgs(index));
			}
		}

		#endregion
		
		#region Methods
		
		public HotZone Add(HotZone value)
        {
            base.List.Add(value as object);
            return value;
        }

        public void AddRange(HotZone[] values)
        {
            foreach(HotZone page in values)
                Add(page);
        }

        public void Remove(HotZone value)
        {
            base.List.Remove(value as object);
        }

        public void Insert(int index, HotZone value)
        {
            base.List.Insert(index, value as object);
        }

        public bool Contains(HotZone value)
        {
            return base.List.Contains(value as object);
        }

        public int IndexOf(HotZone value)
        {
            return base.List.IndexOf(value);
        }

        public HotZone Contains(Point pt)
        {
            foreach(HotZone hz in base.List)
            {
                if (hz.HotArea.Contains(pt))
                    return hz;
            }

            return null;
        }

		public void CopyTo(HotZoneCollection array, System.Int32 index)
		{
			foreach (HotZone obj in base.List)
				array.Add(obj);
		}

		#endregion

		#region Properties

		public bool IsSuspended
		{
			get { return (_suspendCount > 0); }
		}

		public HotZone this[int index]
		{
			get { return (base.List[index] as HotZone); }
		}

		#endregion
    }
}
