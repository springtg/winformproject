using System;
using System.Collections;
using System.Runtime.InteropServices;

namespace PallaControls.Windows.Forms.Collections
{
	public class WizardStepCollection : System.Collections.CollectionBase
	{
		#region Constructors

		public WizardStepCollection()
		{
		}

		#endregion

		#region Methods
	
		public void Add(BaseStep step)
		{
			this.InnerList.Add(step);
		}

		public void Remove(int index)
		{
			if((index < this.Count) && (index >= 0))
				this.InnerList.RemoveAt(index);
		}

		public void Remove(object obj)
		{
			this.InnerList.Remove(obj);
		}

		public BaseStep this[int index] 
		{
			get
			{
				if((index < this.Count) && (index >= 0))
					return (BaseStep)this.List[index];

				return null;
			} 
		}
		
		public BaseStep this[string stepName] 
		{
			get
			{
				foreach (BaseStep step in InnerList)
				{
					if (step.Name == stepName)
					{
						return step;
					}
				}
				
				return null;
			} 
		}

		public void Insert(int index, BaseStep step)
		{
			this.InnerList.Insert(index, step);
		}

		public void CopyTo(WizardStepCollection array, System.Int32 index)
		{
			foreach (BaseStep obj in base.List)
				array.Add(obj);
		}

		public bool Contains(BaseStep step)
		{
			return this.InnerList.Contains(step);
		}

		public int IndexOf(BaseStep step)
		{
			return this.InnerList.IndexOf(step);
		}

		public object Clone()
		{
			return this.InnerList.Clone();
		}

		#endregion
	}
}