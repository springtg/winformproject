using System;
using System.Xml;
using System.Collections;
using System.Globalization;
using PallaControls.Resources;
using PallaControls.Resources.Keys;
using PallaControls.Windows.Forms.Collections;

namespace PallaControls.Windows.Forms.Collections
{
    public class StringCollection : CollectionBase
    {
		private int _suspendCount; 

		public event CollectionClearEventHandler Clearing;
		public event CollectionClearEventHandler Cleared;
		public event CollectionChangeEventHandler Inserting;
		public event CollectionChangeEventHandler Inserted;
		public event CollectionChangeEventHandler Removing;
		public event CollectionChangeEventHandler Removed;
		
		#region Constructors

		public StringCollection()
		{
			_suspendCount = 0;
		}

		#endregion
		
		#region Overrides
	
		protected override void OnClear()
		{
			if (!IsSuspended)
			{
				if (Clearing != null)
					Clearing(this,new EventArgs());
			}
		}	

		protected override void OnClearComplete()
		{
			if (!IsSuspended)
			{
				if (Cleared != null)
					Cleared(this,new EventArgs());
			}
		}	

		protected override void OnInsert(int index, object value)
		{
			if (!IsSuspended)
			{
				if (Inserting != null)
					Inserting(value, new PallaControls.Windows.Forms.Collections.CollectionChangeEventArgs(index));
			}
		}

		protected override void OnInsertComplete(int index, object value)
		{
			if (!IsSuspended)
			{
				if (Inserted != null)
					Inserted(value, new PallaControls.Windows.Forms.Collections.CollectionChangeEventArgs(index));
			}
		}

		protected override void OnRemove(int index, object value)
		{
			if (!IsSuspended)
			{
				if (Removing != null)
					Removing(value, new PallaControls.Windows.Forms.Collections.CollectionChangeEventArgs(index));
			}
		}

		protected override void OnRemoveComplete(int index, object value)
		{
			if (!IsSuspended)
			{
				if (Removed != null)
					Removed(value, new PallaControls.Windows.Forms.Collections.CollectionChangeEventArgs(index));
			}
		}

		#endregion
		
		#region Methods

		public String Add(String value)
        {
            base.List.Add(value as object);
            return value;
        }

        public void AddRange(String[] values)
        {
            foreach(String item in values)
                Add(item);
        }

        public void Remove(String value)
        {
            base.List.Remove(value as object);
        }

        public void Insert(int index, String value)
        {
            base.List.Insert(index, value as object);
        }

        public bool Contains(String value)
        {
			foreach(String s in base.List)
				if (value.Equals(s))
					return true;

			return false;
        }

        public bool Contains(StringCollection values)
        {
			foreach(String c in values)
			{
				if (Contains(c))
					return true;
			}

			return false;
        }

        public int IndexOf(String value)
        {
            return base.List.IndexOf(value);
        }

		public void CopyTo(StringCollection array, System.Int32 index)
		{
			foreach (string obj in base.List)
				array.Add(obj);
		}

		public void SaveToXml(string name, XmlTextWriter xmlOut)
		{
			xmlOut.WriteStartElement(name);
			xmlOut.WriteAttributeString("Count", this.Count.ToString(CultureInfo.CurrentCulture));

			foreach(String s in base.List)
			{
				xmlOut.WriteStartElement("Item");
				xmlOut.WriteAttributeString("Name", s);
				xmlOut.WriteEndElement();
			}

			xmlOut.WriteEndElement();
		}

		public void LoadFromXml(string name, XmlTextReader xmlIn)
		{
			if (!xmlIn.Read())
				throw new ArgumentException(ResourceLibrary.GetString(WindowsControlsResourceKeys.InaccessibleNode, WindowsControlsResourceKeys.Root));

			if (xmlIn.Name != name)
				throw new ArgumentException(ResourceLibrary.GetString(WindowsControlsResourceKeys.IncorrectNodeName, WindowsControlsResourceKeys.Root));

			this.Clear();

			string attrCount = xmlIn.GetAttribute(0);

			int count = int.Parse(attrCount, CultureInfo.CurrentCulture);

			for(int index=0; index<count; index++)
			{
				if (!xmlIn.Read())
					throw new ArgumentException(ResourceLibrary.GetString(WindowsControlsResourceKeys.InaccessibleNode, WindowsControlsResourceKeys.Root));

				if (xmlIn.Name != "Item")
					throw new ArgumentException(ResourceLibrary.GetString(WindowsControlsResourceKeys.IncorrectNodeName, WindowsControlsResourceKeys.Root));

				this.Add(xmlIn.GetAttribute(0));
			}

			if (count > 0)
			{
				if (!xmlIn.Read())
					throw new ArgumentException(ResourceLibrary.GetString(WindowsControlsResourceKeys.InaccessibleNode, WindowsControlsResourceKeys.Root));

				if (xmlIn.Name != name)
					throw new ArgumentException(ResourceLibrary.GetString(WindowsControlsResourceKeys.IncorrectNodeName, WindowsControlsResourceKeys.Root));
			}
		}

		#endregion

		#region Properties

		public bool IsSuspended
		{
			get { return (_suspendCount > 0); }
		}

		public String this[int index]
		{
			get { return (base.List[index] as String); }
		}

		#endregion
    }
}
