using System;
using System.Collections;
using ControlWare.Windows.Controls.Helpers;

namespace ControlWare.Windows.Controls.Collections
{
	public class ColInfoCollection : CollectionBase
	{
		public int Add(ColInfo p)
		{
			return InnerList.Add(p);
		}
		public int Add(int paramIndex, ColInfo p)
		{
			InnerList.Insert(paramIndex,p);
			return paramIndex;
		}
		public ColInfo this[int p]
		{
			get{return (ColInfo)InnerList[p];}
		}
	}
}
