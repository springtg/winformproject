using System;
using System.Collections;
using PallaControls.Windows.Forms;
using PallaControls.Resources.Keys; 

namespace PallaControls.Windows.Forms.Collections
{
	public class TaskPanelCollection : System.Collections.CollectionBase
	{
		private int _suspendCount; 

		public event CollectionClearEventHandler Clearing;
		public event CollectionClearEventHandler Cleared;
		public event CollectionChangeEventHandler Inserting;
		public event CollectionChangeEventHandler Inserted;
		public event CollectionChangeEventHandler Removing;
		public event CollectionChangeEventHandler Removed;
		
		#region Constructors	

		public TaskPanelCollection()
		{
			_suspendCount = 0;
		}

		#endregion
		
		#region Overrides
	
		protected override void OnClear()
		{
			if (!IsSuspended)
			{
				if (Clearing != null)
					Clearing(this,new EventArgs());
			}
		}	

		protected override void OnClearComplete()
		{
			if (!IsSuspended)
			{
				if (Cleared != null)
					Cleared(this,new EventArgs());
			}
		}	

		protected override void OnInsert(int index, object value)
		{
			if (!IsSuspended)
			{
				if (Inserting != null)
					Inserting(value, new PallaControls.Windows.Forms.Collections.CollectionChangeEventArgs(index));
			}
		}

		protected override void OnInsertComplete(int index, object value)
		{
			if (!IsSuspended)
			{
				if (Inserted != null)
					Inserted(value, new PallaControls.Windows.Forms.Collections.CollectionChangeEventArgs(index));
			}
		}

		protected override void OnRemove(int index, object value)
		{
			if (!IsSuspended)
			{
				if (Removing != null)
					Removing(value, new PallaControls.Windows.Forms.Collections.CollectionChangeEventArgs(index));
			}
		}

		protected override void OnRemoveComplete(int index, object value)
		{
			if (!IsSuspended)
			{
				if (Removed != null)
					Removed(value, new PallaControls.Windows.Forms.Collections.CollectionChangeEventArgs(index));
			}
		}

		#endregion

		#region Methods

		public void SuspendEvents()
		{
			_suspendCount++;
		}

		public void ResumeEvents()
		{
			--_suspendCount;
		}
		
		public void AddRange(TaskPanel[] values)
		{
			foreach(TaskPanel page in values)
				Add(page);
		}

		public void Insert(int index, TaskPanel value)
		{
			base.List.Insert(index, value as object);
		}

		public TaskPanel Add(TaskPanel value)
		{
			base.List.Add(value);
			return value;
		}

		public TaskPanel Add(string title)
		{
			TaskPanel item = new TaskPanel();
			item.TitleText = title;
			return Add(item);
		}

		public TaskPanel Add(TaskPanel value, string title)
		{
			value.TitleText = title;
			base.List.Add(value);
			return value;
		}
		
		public TaskPanel Add(string title, StyleGuide style)
		{
			TaskPanel item = new TaskPanel();
			item.TitleText = title;
			item.Style = style;
			return Add(item);
		}

		public TaskPanel Add(TaskPanel value, string title, StyleGuide style)
		{
			value.TitleText = title;
			value.Style = style;
			return Add(value);
		}

		public void Remove(TaskPanel value)
		{
			base.List.Remove(value as object);
		}

		public bool Contains(TaskPanel value)
		{
			return base.List.Contains(value as object);
		}

		public int IndexOf(TaskPanel value)
		{
			return base.List.IndexOf(value);
		}

		public void CopyTo(TaskPanelCollection array, System.Int32 index)
		{
			foreach (TaskPanel obj in base.List)
				array.Add(obj);
		}

		#endregion 

		#region Properties

		public bool IsSuspended
		{
			get { return (_suspendCount > 0); }
		}

		public TaskPanel this[int index]
		{
			get { return (base.List[index] as TaskPanel); }
		}

		public TaskPanel this[string title]
		{
			get 
			{
				foreach(TaskPanel task in base.List)
					if (task.Text == title)
						return task;

				return null;
			}
		}

		#endregion
	}
}
