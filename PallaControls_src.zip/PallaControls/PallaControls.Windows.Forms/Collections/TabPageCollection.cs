using System;
using System.Collections;
using PallaControls.Windows.Forms;

namespace PallaControls.Windows.Forms.Collections
{
    public class TabPageCollection : CollectionBase
    {
		private int _suspendCount; 

		public event CollectionClearEventHandler Clearing;
		public event CollectionClearEventHandler Cleared;
		public event CollectionChangeEventHandler Inserting;
		public event CollectionChangeEventHandler Inserted;
		public event CollectionChangeEventHandler Removing;
		public event CollectionChangeEventHandler Removed;
		
		#region Constructors	

		public TabPageCollection()
		{
			_suspendCount = 0;
		}

		#endregion
		
		#region Overrides
	
		protected override void OnClear()
		{
			if (!IsSuspended)
			{
				if (Clearing != null)
					Clearing(this,new EventArgs());
			}
		}	

		protected override void OnClearComplete()
		{
			if (!IsSuspended)
			{
				if (Cleared != null)
					Cleared(this,new EventArgs());
			}
		}	

		protected override void OnInsert(int index, object value)
		{
			if (!IsSuspended)
			{
				if (Inserting != null)
					Inserting(value, new PallaControls.Windows.Forms.Collections.CollectionChangeEventArgs(index));
			}
		}

		protected override void OnInsertComplete(int index, object value)
		{
			if (!IsSuspended)
			{
				if (Inserted != null)
					Inserted(value, new PallaControls.Windows.Forms.Collections.CollectionChangeEventArgs(index));
			}
		}

		protected override void OnRemove(int index, object value)
		{
			if (!IsSuspended)
			{
				if (Removing != null)
					Removing(value, new PallaControls.Windows.Forms.Collections.CollectionChangeEventArgs(index));
			}
		}

		protected override void OnRemoveComplete(int index, object value)
		{
			if (!IsSuspended)
			{
				if (Removed != null)
					Removed(value, new PallaControls.Windows.Forms.Collections.CollectionChangeEventArgs(index));
			}
		}

		#endregion

		#region Methods

		public void SuspendEvents()
		{
			_suspendCount++;
		}

		public void ResumeEvents()
		{
			--_suspendCount;
		}
		
		public void AddRange(TabPage[] values)
		{
			foreach(TabPage page in values)
				Add(page);
		}

		public void Insert(int index, TabPage value)
		{
			base.List.Insert(index, value as object);
		}

		public TabPage Add(TabPage value)
		{
			base.List.Add(value);
			return value;
		}

		public TabPage Add(string title)
		{
			TabPage item = new TabPage(title);
			return Add(item);
		}
		
		public TabPage Add(string title, StyleGuide style)
		{
			TabPage item = new TabPage(title);
			item.Style = style;
			return Add(item);
		}

		public void Remove(TabPage value)
		{
			base.List.Remove(value as object);
		}

		public bool Contains(TabPage value)
		{
			return base.List.Contains(value as object);
		}

		public int IndexOf(TabPage value)
		{
			return base.List.IndexOf(value);
		}

		public void CopyTo(TabPageCollection array, System.Int32 index)
		{
			foreach (TabPage obj in base.List)
				array.Add(obj);
		}

		#endregion 

		#region Properties

		public bool IsSuspended
		{
			get { return (_suspendCount > 0); }
		}

		public TabPage this[int index]
		{
			get { return (base.List[index] as TabPage); }
		}

		public TabPage this[string title]
		{
			get 
			{
				foreach(TabPage page in base.List)
					if (page.Text == title)
						return page;

				return null;
			}
		}

		#endregion
	}
}
