using System;
using System.Collections;
using ControlWare.Windows.Controls.Helpers;

namespace ControlWare.Windows.Controls.Collections
{
	public class RowInfoCollection : CollectionBase
	{
		public int Add(RowInfo p)
		{
			return InnerList.Add(p);
		}
		public int Add(int paramIndex,RowInfo p)
		{
			InnerList.Insert(paramIndex,p);
			return paramIndex;
		}

		public RowInfo this[int p]
		{
			get{return (RowInfo)InnerList[p];}
		}
	}
}
