using System;
using System.Collections;
using System.Windows.Forms;

namespace ControlWare.Windows.Controls.Collections
{
	public class MenuCollection : CollectionBase
	{
		public MenuCollection()
		{
		}

		public int Add(MenuItem paramItem)
		{
			return List.Add(paramItem);
		}
		public void Remove(MenuItem paramItem)
		{
			List.Remove(paramItem);
		}
		public MenuItem this[int paramIndex]
		{
			get{return (MenuItem)List[paramIndex];}
			set{List[paramIndex] = value;}
		}
	}
}
