using System;
using PallaControls.Windows.Forms;

namespace PallaControls.Windows.Forms.Collections
{
	[Serializable()]
	public class MenuListBoxItemCollection: System.Collections.CollectionBase
	{
		private int _suspendCount; 

		public event CollectionClearEventHandler Clearing;
		public event CollectionClearEventHandler Cleared;
		public event CollectionChangeEventHandler Inserting;
		public event CollectionChangeEventHandler Inserted;
		public event CollectionChangeEventHandler Removing;
		public event CollectionChangeEventHandler Removed;
		
		#region Constructors	

		public MenuListBoxItemCollection()
		{
			_suspendCount = 0;
		}

		#endregion
		
		#region Overrides
	
		protected override void OnClear()
		{
			if (!IsSuspended)
			{
				if (Clearing != null)
					Clearing(this,new EventArgs());
			}
		}	

		protected override void OnClearComplete()
		{
			if (!IsSuspended)
			{
				if (Cleared != null)
					Cleared(this,new EventArgs());
			}
		}	

		protected override void OnInsert(int index, object value)
		{
			if (!IsSuspended)
			{
				if (Inserting != null)
					Inserting(value, new PallaControls.Windows.Forms.Collections.CollectionChangeEventArgs(index));
			}
		}

		protected override void OnInsertComplete(int index, object value)
		{
			if (!IsSuspended)
			{
				if (Inserted != null)
					Inserted(value, new PallaControls.Windows.Forms.Collections.CollectionChangeEventArgs(index));
			}
		}

		protected override void OnRemove(int index, object value)
		{
			if (!IsSuspended)
			{
				if (Removing != null)
					Removing(value, new PallaControls.Windows.Forms.Collections.CollectionChangeEventArgs(index));
			}
		}

		protected override void OnRemoveComplete(int index, object value)
		{
			if (!IsSuspended)
			{
				if (Removed != null)
					Removed(value, new PallaControls.Windows.Forms.Collections.CollectionChangeEventArgs(index));
			}
		}

		#endregion

		#region Methods

		public void SuspendEvents()
		{
			_suspendCount++;
		}

		public void ResumeEvents()
		{
			--_suspendCount;
		}
		
		public void AddRange(MenuListBoxItem[] values)
		{
			foreach(MenuListBoxItem page in values)
				Add(page);
		}

		public void Insert(int index, MenuListBoxItem value)
		{
			base.List.Insert(index, value as object);
		}

		public MenuListBoxItem Add(MenuListBoxItem value)
		{
			base.List.Add(value);
			return value;
		}

		public MenuListBoxItem Add(string title)
		{
			MenuListBoxItem item = new MenuListBoxItem();
			item.Title = title;
			return Add(item);
		}

		public MenuListBoxItem Add(MenuListBoxItem value, string title)
		{
			value.Title = title;
			base.List.Add(value);
			return value;
		}
		
		public MenuListBoxItem Add(string title, string description)
		{
			MenuListBoxItem item = new MenuListBoxItem();
			item.Title = title;
			item.Description = description;
			return Add(item);
		}

		public MenuListBoxItem Add(string title, string description, string name)
		{
			MenuListBoxItem item = new MenuListBoxItem();
			item.Title = title;
			item.Description = description;
			item.Name = name;
			return Add(item);
		}

		public MenuListBoxItem Add(MenuListBoxItem value, string title, string description, string name)
		{
			value.Title = title;
			value.Description = description;
			value.Name = name;
			return Add(value);
		}

		public void Remove(MenuListBoxItem value)
		{
			base.List.Remove(value as object);
		}

		public bool Contains(MenuListBoxItem value)
		{
			return base.List.Contains(value as object);
		}

		public int IndexOf(MenuListBoxItem value)
		{
			return base.List.IndexOf(value);
		}

		public void CopyTo(MenuListBoxItemCollection array, System.Int32 index)
		{
			foreach (MenuListBoxItem obj in base.List)
				array.Add(obj);
		}

		#endregion 

		#region Properties

		public bool IsSuspended
		{
			get { return (_suspendCount > 0); }
		}

		public MenuListBoxItem this[int index]
		{
			get { return (base.List[index] as MenuListBoxItem); }
		}

		public MenuListBoxItem this[string title]
		{
			get 
			{
				foreach(MenuListBoxItem item in base.List)
					if (item.Title == title)
						return item;

				return null;
			}
		}

		#endregion
	}
}
