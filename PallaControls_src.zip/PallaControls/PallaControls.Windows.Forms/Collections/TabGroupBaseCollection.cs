using System;
using System.Collections;
using PallaControls.Windows.Forms;
using PallaControls.Windows.Forms.Collections;

namespace PallaControls.Windows.Forms.Collections
{
    public class TabGroupBaseCollection : CollectionBase
    {
		private int _suspendCount; 

		public event CollectionClearEventHandler Clearing;
		public event CollectionClearEventHandler Cleared;
		public event CollectionChangeEventHandler Inserting;
		public event CollectionChangeEventHandler Inserted;
		public event CollectionChangeEventHandler Removing;
		public event CollectionChangeEventHandler Removed;
		
		#region Overrides
	
		protected override void OnClear()
		{
			if (!IsSuspended)
			{
				if (Clearing != null)
					Clearing(this,new EventArgs());
			}
		}	

		protected override void OnClearComplete()
		{
			if (!IsSuspended)
			{
				if (Cleared != null)
					Cleared(this,new EventArgs());
			}
		}	

		protected override void OnInsert(int index, object value)
		{
			if (!IsSuspended)
			{
				if (Inserting != null)
					Inserting(value, new PallaControls.Windows.Forms.Collections.CollectionChangeEventArgs(index));
			}
		}

		protected override void OnInsertComplete(int index, object value)
		{
			if (!IsSuspended)
			{
				if (Inserted != null)
					Inserted(value, new PallaControls.Windows.Forms.Collections.CollectionChangeEventArgs(index));
			}
		}

		protected override void OnRemove(int index, object value)
		{
			if (!IsSuspended)
			{
				if (Removing != null)
					Removing(value, new PallaControls.Windows.Forms.Collections.CollectionChangeEventArgs(index));
			}
		}

		protected override void OnRemoveComplete(int index, object value)
		{
			if (!IsSuspended)
			{
				if (Removed != null)
					Removed(value, new PallaControls.Windows.Forms.Collections.CollectionChangeEventArgs(index));
			}
		}

		#endregion

		#region Constructors

		public TabGroupBaseCollection()
		{
			_suspendCount = 0;
		}

		#endregion

		#region Methods
		
		public TabGroupBase Add(TabGroupBase value)
        {
            base.List.Add(value as object);
            return value;
        }

        public void AddRange(TabGroupBase[] values)
        {
            foreach(TabGroupBase item in values)
                Add(item);
        }

		public void CopyTo(TabGroupBaseCollection array, System.Int32 index)
		{
			foreach (TabGroupBase obj in base.List)
				array.Add(obj);
		}

        public void Remove(TabGroupBase value)
        {
            base.List.Remove(value as object);
        }

        public void Insert(int index, TabGroupBase value)
        {
            base.List.Insert(index, value as object);
        }

        public bool Contains(TabGroupBase value)
        {
			foreach(String s in base.List)
				if (value.Equals(s))
					return true;

			return false;
        }

        public bool Contains(TabGroupBaseCollection values)
        {
			foreach(TabGroupBase c in values)
			{
				if (Contains(c))
					return true;
			}

			return false;
        }

        public int IndexOf(TabGroupBase value)
        {
            return base.List.IndexOf(value);
        }

		#endregion

		#region Properties

		public bool IsSuspended
		{
			get { return (_suspendCount > 0); }
		}

		public TabGroupBase this[int index]
		{
			get { return (base.List[index] as TabGroupBase); }
			set { base.List[index] = value; }
		}

		#endregion
    }
}
