using System;
using System.Collections;
using PallaControls.Windows.Forms;

namespace PallaControls.Windows.Forms.Collections
{
    public class PanelItemCollection : CollectionBase
    {
		private int _suspendCount; 

		public event CollectionClearEventHandler Clearing;
		public event CollectionClearEventHandler Cleared;
		public event CollectionChangeEventHandler Inserting;
		public event CollectionChangeEventHandler Inserted;
		public event CollectionChangeEventHandler Removing;
		public event CollectionChangeEventHandler Removed;
		
		#region Constructors	

		public PanelItemCollection()
		{
			_suspendCount = 0;
		}

		#endregion
		
		#region Overrides
	
		protected override void OnClear()
		{
			if (!IsSuspended)
			{
				if (Clearing != null)
					Clearing(this,new EventArgs());
			}
		}	

		protected override void OnClearComplete()
		{
			if (!IsSuspended)
			{
				if (Cleared != null)
					Cleared(this,new EventArgs());
			}
		}	

		protected override void OnInsert(int index, object value)
		{
			if (!IsSuspended)
			{
				if (Inserting != null)
					Inserting(value, new PallaControls.Windows.Forms.Collections.CollectionChangeEventArgs(index));
			}
		}

		protected override void OnInsertComplete(int index, object value)
		{
			if (!IsSuspended)
			{
				if (Inserted != null)
					Inserted(value, new PallaControls.Windows.Forms.Collections.CollectionChangeEventArgs(index));
			}
		}

		protected override void OnRemove(int index, object value)
		{
			if (!IsSuspended)
			{
				if (Removing != null)
					Removing(value, new PallaControls.Windows.Forms.Collections.CollectionChangeEventArgs(index));
			}
		}

		protected override void OnRemoveComplete(int index, object value)
		{
			if (!IsSuspended)
			{
				if (Removed != null)
					Removed(value, new PallaControls.Windows.Forms.Collections.CollectionChangeEventArgs(index));
			}
		}

		#endregion

		#region Methods

		public void SuspendEvents()
		{
			_suspendCount++;
		}

		public void ResumeEvents()
		{
			--_suspendCount;
		}
		
		public void AddRange(PanelItem[] values)
		{
			foreach(PanelItem page in values)
				Add(page);
		}

		public void Insert(int index, PanelItem value)
		{
			base.List.Insert(index, value as object);
		}

		public PanelItem Add(PanelItem value)
		{
			base.List.Add(value);
			return value;
		}

		public PanelItem Add(string title)
		{
			PanelItem item = new PanelItem(title);
			return Add(item);
		}
		
		public PanelItem Add(string title, PanelItemStyle itemStyle)
		{
			PanelItem item = new PanelItem(title, itemStyle);
			return Add(item);
		}

		public PanelItem Add(string title, StyleGuide style)
		{
			PanelItem item = new PanelItem(title);
			item.Style = style;
			item.ItemStyle = PanelItemStyle.Item;
			return Add(item);
		}

		public PanelItem Add(string title, StyleGuide style, PanelItemStyle itemStyle)
		{
			PanelItem item = new PanelItem(title);
			item.Style = style;
			item.ItemStyle = itemStyle;
			return Add(item);
		}

		public void Remove(PanelItem value)
		{
			base.List.Remove(value as object);
		}

		public bool Contains(PanelItem value)
		{
			return base.List.Contains(value as object);
		}

		public int IndexOf(PanelItem value)
		{
			return base.List.IndexOf(value);
		}

		public void CopyTo(PanelItemCollection array, System.Int32 index)
		{
			foreach (PanelItem obj in base.List)
				array.Add(obj);
		}

		#endregion 

		#region Properties

		public bool IsSuspended
		{
			get { return (_suspendCount > 0); }
		}

		public PanelItem this[int index]
		{
			get { return (base.List[index] as PanelItem); }
		}

		public PanelItem this[string title]
		{
			get 
			{
				foreach(PanelItem page in base.List)
					if (page.Text == title)
						return page;

				return null;
			}
		}

		#endregion
	}
}
