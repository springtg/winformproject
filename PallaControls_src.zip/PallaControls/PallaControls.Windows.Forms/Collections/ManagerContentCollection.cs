using System;
using System.Collections;
using System.Xml;
using System.Windows.Forms;
using System.Runtime.Serialization;
using PallaControls.Windows.Docking;
using PallaControls.Windows.Forms;

namespace PallaControls.Windows.Forms.Collections
{
    public class ManagerContentCollection : CollectionBase
    {
		private int msuspendCount; 

		protected DockingManager mmanager;

		public event CollectionClearEventHandler Clearing;
		public event CollectionClearEventHandler Cleared;
		public event CollectionChangeEventHandler Inserting;
		public event CollectionChangeEventHandler Inserted;
		public event CollectionChangeEventHandler Removing;
		public event CollectionChangeEventHandler Removed;

		#region Constructors

		public ManagerContentCollection(DockingManager manager)
        {
            if (manager == null)
                throw new ArgumentNullException("DockingManager");

            mmanager = manager;
			msuspendCount = 0;
        }

		#endregion

		#region Overrides
	
		protected override void OnClear()
		{
			if (!IsSuspended)
			{
				if (Clearing != null)
					Clearing(this,new EventArgs());
			}
		}	

		protected override void OnClearComplete()
		{
			if (!IsSuspended)
			{
				if (Cleared != null)
					Cleared(this,new EventArgs());
			}
		}	

		protected override void OnInsert(int index, object value)
		{
			if (!IsSuspended)
			{
				if (Inserting != null)
					Inserting(value, new PallaControls.Windows.Forms.Collections.CollectionChangeEventArgs(index));
			}
		}

		protected override void OnInsertComplete(int index, object value)
		{
			if (!IsSuspended)
			{
				if (Inserted != null)
					Inserted(value, new PallaControls.Windows.Forms.Collections.CollectionChangeEventArgs(index));
			}
		}

		protected override void OnRemove(int index, object value)
		{
			if (!IsSuspended)
			{
				if (Removing != null)
					Removing(value, new PallaControls.Windows.Forms.Collections.CollectionChangeEventArgs(index));
			}
		}

		protected override void OnRemoveComplete(int index, object value)
		{
			if (!IsSuspended)
			{
				if (Removed != null)
					Removed(value, new PallaControls.Windows.Forms.Collections.CollectionChangeEventArgs(index));
			}
		}

		#endregion
		
		#region Methods
		
		public Content Add()
        {
            Content c = new Content(mmanager);
            base.List.Add(c as object);

            return c;
        }

		public Content Add(Content c)
        {
			c.DockingManager = mmanager;

            base.List.Add(c as object);

            return c;
        }

		public void CopyTo(ManagerContentCollection array, System.Int32 index)
		{
			foreach (Control obj in base.List)
				array.Add(obj);
		}

        public Content Add(Control control)
        {
            Content c = new Content(mmanager, control);

            base.List.Add(c as object);

            return c;
        }

        public Content Add(Control control, string title)
        {
            Content c = new Content(mmanager, control, title);

            base.List.Add(c as object);

            return c;
        }

        public Content Add(Control control, string title, ImageList imageList, int imageIndex)
        {
            Content c = new Content(mmanager, control, title, imageList, imageIndex);

            base.List.Add(c as object);

            return c;
        }

        public void Remove(Content value)
        {
            base.List.Remove(value as object);
        }

        public bool Contains(Content value)
        {
            return base.List.Contains(value as object);
        }

		public void Insert(int index, Control control)
		{
			this.List.Insert(index, control);
		}

		public int SetIndex(int newIndex, Content value)
		{
			SuspendEvents();

			base.List.Remove(value);
			base.List.Insert(newIndex, value);

			ResumeEvents();

			return newIndex;
		}

        public int IndexOf(Content value)
        {
            return base.List.IndexOf(value);
        }

		public ContentCollection Copy()
		{
			ContentCollection clone = new ContentCollection();

            foreach(Content c in base.List)
				clone.Add(c);

			return clone;
		}

		public void SuspendEvents()
		{
			msuspendCount++;
		}

		public void ResumeEvents()
		{
			--msuspendCount;
		}

		#endregion

		#region Properties

		public bool IsSuspended
		{
			get { return (msuspendCount > 0); }
		}

		public Content this[int index]
		{
			get { return (base.List[index] as Content); }
		}

		public Content this[string title]
		{
			get 
			{
				foreach(Content c in base.List)
					if (c.Title == title)
						return c;

				return null;
			}
		}

		#endregion
    }
}
