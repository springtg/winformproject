using System;
using System.Collections;

namespace ControlWare.Windows.Controls.Collections
{
	public class CellCollection : CollectionBase
	{
		public Cell this[int index]
		{
			get{return (Cell)base.InnerList[index];}
		}

		public int Add(Cell paramCell)
		{
			return base.InnerList.Add(paramCell);
		}

		public void Remove(Cell paramCell)
		{
			base.InnerList.Remove(paramCell);
		}

		public bool Contains(Cell paramCell)
		{
			foreach ( Cell c in this)
			{
				if (paramCell == c)
					return true;
			}
			return false;
		}
	}
}
