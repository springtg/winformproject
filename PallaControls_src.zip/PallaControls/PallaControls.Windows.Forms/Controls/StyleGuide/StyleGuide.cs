using System;
//2002-08-07 - GWO - Added to retrieve assembly information for the serialization/deserialization process.
using System.Reflection;
using System.IO;
using System.ComponentModel;
using System.Collections;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using PallaControls.Windows.Forms.Helpers;

namespace PallaControls.Windows.Forms
{
	[ToolboxItem(true)]
	public class StyleGuide : System.ComponentModel.Component
	{
		private System.ComponentModel.Container components = null;
		private PlansColors m_PlansOfColors = PlansColors.NeoTheOne;   
		
		//PictureBox
		private Color m_PictureBoxColor = Color.FromArgb(242, 242, 228);

		//Common
		private Color m_BorderColor = Color.FromArgb(222, 217, 207);
		private Color m_BorderHotColor = Color.FromArgb(222, 217, 207);
		
		//Buttons
		private Color m_ButtonColor = Color.FromArgb(242, 242, 228);
		private Color m_ButtonHotColor = Color.FromArgb(231, 231, 214);
		private Color m_ButtonPressedColor = Color.FromArgb(222, 217, 207);
		private Color m_ButtonBorderColor = Color.FromArgb(222, 217, 207);
		private Color m_ButtonBorderHotColor = Color.FromArgb(222, 217, 207);
		private Color m_ButtonTextColor = Color.Black;
		private Color m_ButtonFlashColor = Color.FromArgb(170, 170, 221);

		//EditButtons
		private Color m_EditButtonColor = Color.FromArgb(242, 242, 228);
		private Color m_EditButtonHotColor = Color.FromArgb(231, 231, 214);
		private Color m_EditButtonPressedColor = Color.FromArgb(222, 217, 207);

		//EditControls
		private Color m_EditColor = Color.FromArgb(242, 242, 228);
		private Color m_EditFocusedColor = Color.White;
		private Color m_EditReadOnlyColor = Color.FromArgb(238, 238, 225);
		private Color m_EditDisabledColor = Color.FromArgb(238, 238, 225);
		private Color m_FlashColor = Color.FromArgb(170, 170, 221);
		private Color m_TextColor = Color.Black;
		private Color m_NegativeNumberColor = Color.Black;
		private Color m_DisabledTextColor = Color.FromKnownColor(KnownColor.GrayText);

		//Option, CheckBox, RadioButton
		private Color m_CheckColor = Color.FromArgb(170, 170, 221);
		private Color m_CheckBoxColor = Color.FromArgb(242, 242, 228);
		private Color m_RadioButtonColor = Color.FromArgb(242, 242, 228);
		
		//Calendar
		private Color m_CalendarTitleBackColor = StyleGuide.InteliSelectionColor(PlansColors.NeoTheOne);
		private Color m_CalendarTitleForeColor = Color.White;
		private Color m_CalendarTrailingForeColor = Color.Silver;
		private Color m_CalendarBackColor = Color.White;
		private Color m_CalendarForeColor = Color.Black;
		//Label
		private Color m_LabelColor = Color.FromArgb(231, 231, 214);
		//Panels
		private Color m_LeftPanelColor = Color.FromArgb(231, 231, 214);
		private Color m_TopPanelColor = Color.FromArgb(170, 170, 221);
		private Color m_BottomPanelColor = Color.FromArgb(222, 217, 207);
		private Color m_ClientPanelColor = Color.FromArgb(242, 242, 228);
		private Color m_PanelAssLeftTitleColor = Color.FromArgb(242, 242, 228);
		private Color m_PanelAssRightTitleColor = Color.FromArgb(231, 231, 214);
		private Color m_PanelAssLeftOptionsColor = Color.FromArgb(231, 231, 214);
		private Color m_PanelAssClientAreaColor = Color.FromArgb(242, 242, 228);
		private Color m_PanelAssBottomAreaColor = Color.FromArgb(222, 217, 207);
		//CollapsiblePanel
		private Color m_CollapsiblePanelBarBackColor = Color.FromArgb(231, 231, 214);
		private Color m_CollapsiblePanelBackColor = Color.FromArgb(237, 237, 224);
		private Color m_CollapsiblePanelStartColor = Color.FromArgb(170, 170, 221);
		private Color m_CollapsiblePanelEndColor = Color.FromArgb(170, 170, 221);
		private Color m_CollapsiblePanelTitleFontColor = Color.White;
		private Color m_CollapsiblePanelLineStartColor = Color.White;
		private Color m_CollapsiblePanelLineEndColor = Color.FromArgb(237, 237, 224);
		private Color m_CollapsiblePanelLinkColor = Color.White;
		//PanelItem
		private Color m_PanelItemBackColor = Color.FromArgb(237, 237, 224); 
		private Color m_PanelItemAssBackColor = Color.FromArgb(231, 231, 214);
		private Color m_PanelItemForeColor = Color.FromArgb(170, 170, 221); 
		private Color m_PanelItemFlashColor = Color.LightSteelBlue;
		//TabControl
		private Color m_TabControlBackColor = Color.FromArgb(242, 242, 228);
		//Docking
		private Color m_DockingBackColor = Color.FromArgb(231, 231, 214);
		private Color m_DockingResizeBarColor = Color.FromArgb(231, 231, 214);
		private Color m_DockingActiveTextColor = Color.White;
		private Color m_DockingActiveColor = Color.FromArgb(206, 206, 181);
		private Color m_DockingInactiveTextColor = Color.Black;
		//DataGrid
		private Color m_DataGridAlternatingBackColor = StyleGuide.InteliSelectionColor(PlansColors.NeoTheOne);
		private Color m_DataGridBackColor = Color.White;
		private Color m_DataGridBackgroundColor = Color.FromArgb(242, 242, 228);
		private Color m_DataGridCaptionBackColor = Color.FromArgb(170, 170, 221);
		private Color m_DataGridCaptionForeColor = Color.White;
		private Color m_DataGridForeColor = Color.Black;
		private Color m_DataGridLineColor = Color.FromArgb(222, 217, 207);
		private Color m_DataGridHeaderBackColor = Color.FromArgb(222, 217, 207);
		private Color m_DataGridHeaderForeColor = Color.Black;
		private Color m_DataGridLinkColor = Color.LightSteelBlue;
		private Color m_DataGridParentRowsBackColor = Color.FromArgb(222, 217, 207);
		private Color m_DataGridParentRowsForeColor = Color.Black;
		private Color m_DataGridSelectionBackColor = Color.Navy;
		private Color m_DataGridSelectionForeColor = Color.White;

		//Infinite progress bar
		private Color m_InfiniteProgressStartColor = Color.FromArgb(170, 170, 221);
		private Color m_InfiniteProgressEndColor = Color.White;

		//TaskPanelBar
		private Color m_TaskPanelBarBackColor = Color.FromArgb(242, 242, 228);

		//TaskPanel
		private Color m_TaskPanelBackColor = Color.FromArgb(242, 242, 228);
		private Color m_TaskPanelTitleBackColor = Color.FromArgb(231, 231, 214);
		private Color m_TaskPanelTitleForeColor = Color.White;

		//MenuListBox
		private Color m_SelectionColor = StyleGuide.InteliSelectionColor(PlansColors.NeoTheOne);

		[Category("Enterprise style changes")]
		public event StyleChangedEventHandler StyleChanged = null;
		[Category("Enterprise style changes")]
		public event PlansOfColorsChangedEventHandler PlansOfColorsChanged = null; 

		#region Constructors
		public StyleGuide(System.ComponentModel.IContainer container)
		{
			container.Add(this);
			this.PlansOfColors = m_PlansOfColors;
			InitializeComponent();
		}

		public StyleGuide()
		{
			InitializeComponent();
		}
		#endregion

		#region Component Designer generated code
		private void InitializeComponent()
		{
			components = new System.ComponentModel.Container();
		}
		#endregion

		#region Virtuals

		protected void OnStyleChanged(string propertyName,object popertyValue)
		{
			StyleEventArgs oArg = new StyleEventArgs(propertyName,popertyValue);
			if(this.StyleChanged != null)
			{
				this.StyleChanged(this, oArg);
			}	
		}

		protected void OnPlansOfColorsChanged(PlansColors newPlan)
		{
			PlansOfColorsChangedEventArgs args = new PlansOfColorsChangedEventArgs(newPlan);
			if (this.PlansOfColorsChanged != null)
			{
				this.PlansOfColorsChanged(this, args);
			}
		}

		#endregion

		#region Internal helpers

		private void SetPlanColorsMorpheus()
		{
			this.m_PictureBoxColor           = Color.FromArgb(242, 242, 228);

			this.m_ButtonColor               = Color.FromArgb(242, 242, 228);
			this.m_ButtonHotColor            = Color.FromArgb(231, 231, 214);
			this.m_ButtonPressedColor        = Color.FromArgb(222, 217, 207);
			this.m_ButtonBorderColor         = Color.FromArgb(222, 217, 207);
			this.m_ButtonBorderHotColor      = Color.FromArgb(222, 217, 207);
			this.m_ButtonTextColor           = Color.Black;
			this.m_ButtonFlashColor          = Color.FromArgb(255, 204, 102);
			
			this.m_BorderColor               = Color.FromArgb(222, 217, 207);     
			this.m_BorderHotColor            = Color.FromArgb(222, 217, 207);

			this.m_CheckColor                = Color.FromArgb(255, 219, 145);
			this.m_CheckBoxColor             = Color.FromArgb(242, 242, 228);
			this.m_RadioButtonColor          = Color.FromArgb(242, 242, 228);
			
			this.m_CalendarBackColor         = Color.White;
			this.m_CalendarForeColor         = Color.Black;
			this.m_CalendarTitleBackColor    = StyleGuide.InteliSelectionColor(PlansColors.Morpheus);
			this.m_CalendarTitleForeColor    = Color.White;
			this.m_CalendarTrailingForeColor = Color.Silver;
			this.m_EditColor                 = Color.FromArgb(242, 242, 228);
			this.m_EditFocusedColor          = Color.White;
			this.m_EditReadOnlyColor         = Color.FromArgb(238, 238, 225);
			this.m_EditDisabledColor         = Color.FromArgb(238, 238, 225);
			this.m_DisabledTextColor		 = Color.FromKnownColor(KnownColor.GrayText);
			this.m_FlashColor                = Color.FromArgb(255, 204, 102);
			this.m_TextColor                 = Color.Black;
			this.m_NegativeNumberColor       = Color.FromArgb(254, 107, 130);
			this.m_LabelColor                = Color.FromArgb(231, 231, 214);
			
			this.m_LeftPanelColor            = Color.FromArgb(255, 153, 0);
			this.m_TopPanelColor             = Color.FromArgb(255, 204, 102); 
			this.m_BottomPanelColor          = Color.FromArgb(222, 217, 207);
			this.m_ClientPanelColor          = Color.FromArgb(242, 242, 228);
			
			this.m_InfiniteProgressStartColor = Color.FromArgb(255, 204, 102); 
			this.m_InfiniteProgressEndColor   = Color.White;
			
			this.m_PanelAssLeftTitleColor = Color.FromArgb(242, 242, 228);
			this.m_PanelAssRightTitleColor = Color.FromArgb(255, 153, 0);
			this.m_PanelAssLeftOptionsColor = Color.FromArgb(255, 153, 0);
			this.m_PanelAssClientAreaColor = Color.FromArgb(242, 242, 228);
			this.m_PanelAssBottomAreaColor = Color.FromArgb(222, 217, 207);

			this.m_CollapsiblePanelBarBackColor     = Color.FromArgb(255, 153, 0);
			this.m_CollapsiblePanelStartColor       = Color.FromArgb(255, 204, 102);
			this.m_CollapsiblePanelEndColor         = Color.FromArgb(255, 204, 102);
			this.m_CollapsiblePanelBackColor        = Color.FromArgb(255, 221, 149);
			this.m_CollapsiblePanelTitleFontColor   = Color.White; 
			this.m_CollapsiblePanelLineStartColor   = Color.White; 
			this.m_CollapsiblePanelLineEndColor     = Color.FromArgb(255, 221, 149);
			this.m_CollapsiblePanelLinkColor        = Color.White;

			this.m_PanelItemBackColor = Color.FromArgb(255, 221, 149);
			this.m_PanelItemAssBackColor = Color.FromArgb(255, 153, 0);
			this.m_PanelItemForeColor = Color.White;
			this.m_PanelItemFlashColor = Color.FromArgb(255, 153, 0);

			this.m_TabControlBackColor = Color.FromArgb(242, 242, 228);

			this.m_DockingBackColor = Color.FromArgb(231, 231, 214);
			this.m_DockingResizeBarColor = Color.FromArgb(231, 231, 214);
			this.m_DockingActiveTextColor = Color.White;
			this.m_DockingActiveColor = Color.FromArgb(206, 206, 181);
			this.m_DockingInactiveTextColor = Color.Black;

			this.m_DataGridAlternatingBackColor = StyleGuide.InteliSelectionColor(PlansColors.Morpheus);
			this.m_DataGridBackColor = Color.White;
			this.m_DataGridBackgroundColor = Color.FromArgb(242, 242, 228);
			this.m_DataGridCaptionBackColor = Color.FromArgb(255, 204, 102);
			this.m_DataGridCaptionForeColor = Color.White;
			this.m_DataGridForeColor = Color.Black;
			this.m_DataGridLineColor = Color.FromArgb(222, 217, 207);
			this.m_DataGridHeaderBackColor = Color.FromArgb(222, 217, 207);
			this.m_DataGridHeaderForeColor = Color.Black;
			this.m_DataGridLinkColor = Color.LightSteelBlue;
			this.m_DataGridParentRowsBackColor = Color.FromArgb(222, 217, 207);
			this.m_DataGridParentRowsForeColor = Color.Black;
			this.m_DataGridSelectionBackColor = Color.Navy;
			this.m_DataGridSelectionForeColor = Color.White;

			this.m_TaskPanelBarBackColor = this.m_ClientPanelColor;

     		this.m_TaskPanelBackColor = this.m_ClientPanelColor;
			this.m_TaskPanelTitleBackColor = this.m_LeftPanelColor;
			this.m_TaskPanelTitleForeColor = Color.White;

			this.m_SelectionColor = this.m_CalendarTitleBackColor;
		}

		private void SetPlanColorsCypher()
		{
			this.m_PictureBoxColor           = Color.FromArgb(242, 242, 228);
			
			this.m_ButtonColor               = Color.FromArgb(242, 242, 228);
			this.m_ButtonHotColor            = Color.FromArgb(231, 231, 214);
			this.m_ButtonPressedColor        = Color.FromArgb(222, 217, 207);
			this.m_ButtonBorderColor         = Color.FromArgb(222, 217, 207);
			this.m_ButtonBorderHotColor      = Color.FromArgb(222, 217, 207);
			this.m_ButtonTextColor           = Color.Black;
			this.m_ButtonFlashColor          = Color.FromArgb(204, 204, 153);
			
			this.m_CalendarBackColor         = Color.White;
			this.m_CalendarForeColor         = Color.Black;
			this.m_CalendarTitleBackColor    = StyleGuide.InteliSelectionColor(PlansColors.Cypher);
			this.m_CalendarTitleForeColor    = Color.White;
			this.m_CalendarTrailingForeColor = Color.Silver;
			
			this.m_BorderColor               = Color.FromArgb(222, 217, 207);     
			this.m_BorderHotColor            = Color.FromArgb(222, 217, 207);

			this.m_CheckColor                = Color.FromArgb(215, 215, 174);
			this.m_CheckBoxColor             = Color.FromArgb(242, 242, 228);
			this.m_RadioButtonColor          = Color.FromArgb(242, 242, 228);
			
			this.m_EditColor                 = Color.FromArgb(242, 242, 228);
			this.m_EditFocusedColor          = Color.White;
			this.m_EditReadOnlyColor         = Color.FromArgb(238, 238, 225);
			this.m_EditDisabledColor         = Color.FromArgb(238, 238, 225);
			this.m_DisabledTextColor		 = Color.FromKnownColor(KnownColor.GrayText);
			this.m_FlashColor                = Color.FromArgb(204, 204, 153);
			this.m_TextColor                 = Color.Black;
			this.m_NegativeNumberColor       = Color.FromArgb(254, 107, 130);
			
			this.m_LabelColor                = Color.FromArgb(231, 231, 214);
			this.m_LeftPanelColor            = Color.FromArgb(153, 153, 102);
			this.m_TopPanelColor             = Color.FromArgb(204, 204, 153);
			this.m_BottomPanelColor          = Color.FromArgb(206, 206, 181);
			this.m_ClientPanelColor          = Color.FromArgb(242, 242, 228);
			this.m_PanelAssLeftTitleColor = Color.FromArgb(242, 242, 228);
			this.m_PanelAssRightTitleColor = Color.FromArgb(153, 153, 102);
			this.m_PanelAssLeftOptionsColor = Color.FromArgb(153, 153, 102);
			this.m_PanelAssClientAreaColor = Color.FromArgb(242, 242, 228);
			this.m_PanelAssBottomAreaColor = Color.FromArgb(206, 206, 181);

			this.m_InfiniteProgressStartColor = Color.FromArgb(204, 204, 153);
			this.m_InfiniteProgressEndColor   = Color.White;
		
			this.m_CollapsiblePanelBarBackColor     = Color.FromArgb(153, 153, 102);
			this.m_CollapsiblePanelStartColor       = Color.FromArgb(174, 174, 134);
			this.m_CollapsiblePanelEndColor         = Color.FromArgb(174, 174, 134);
			this.m_CollapsiblePanelBackColor        = Color.FromArgb(204, 204, 153);
			this.m_CollapsiblePanelTitleFontColor   = Color.White; 
			this.m_CollapsiblePanelLineStartColor   = Color.White; 
			this.m_CollapsiblePanelLineEndColor     = Color.FromArgb(204, 204, 153);
			this.m_CollapsiblePanelLinkColor        = Color.White;

			this.m_PanelItemBackColor = Color.FromArgb(204, 204, 153);
			this.m_PanelItemAssBackColor = Color.FromArgb(153, 153, 102);
			this.m_PanelItemForeColor = Color.White;
			this.m_PanelItemFlashColor = Color.SteelBlue;

			this.m_TabControlBackColor = Color.FromArgb(242, 242, 228);

			this.m_DockingBackColor = Color.FromArgb(231, 231, 214);
			this.m_DockingResizeBarColor = Color.FromArgb(231, 231, 214);
			this.m_DockingActiveTextColor = Color.White;
			this.m_DockingActiveColor = Color.FromArgb(206, 206, 181);
			this.m_DockingInactiveTextColor = Color.Black;

			this.m_DataGridAlternatingBackColor = StyleGuide.InteliSelectionColor(PlansColors.Cypher);
			this.m_DataGridBackColor = Color.White;
			this.m_DataGridBackgroundColor = Color.FromArgb(242, 242, 228);
			this.m_DataGridCaptionBackColor = Color.FromArgb(204, 204, 153);
			this.m_DataGridCaptionForeColor = Color.White;
			this.m_DataGridForeColor = Color.Black;
			this.m_DataGridLineColor = Color.FromArgb(222, 217, 207);
			this.m_DataGridHeaderBackColor = Color.FromArgb(222, 217, 207);
			this.m_DataGridHeaderForeColor = Color.Black;
			this.m_DataGridLinkColor = Color.LightSteelBlue;
			this.m_DataGridParentRowsBackColor = Color.FromArgb(222, 217, 207);
			this.m_DataGridParentRowsForeColor = Color.Black;
			this.m_DataGridSelectionBackColor = Color.Navy;
			this.m_DataGridSelectionForeColor = Color.White;

			this.m_TaskPanelBarBackColor = this.m_ClientPanelColor;

			this.m_TaskPanelBackColor = this.m_ClientPanelColor;
			this.m_TaskPanelTitleBackColor = this.m_LeftPanelColor;
			this.m_TaskPanelTitleForeColor = Color.White;

			this.m_SelectionColor = this.m_CalendarTitleBackColor;
		}

		private void SetPlanColorsApoc()
		{
			this.m_SelectionColor            = this.m_CalendarTitleBackColor;
			this.m_PictureBoxColor           = Color.FromArgb(242, 242, 228);

			this.m_ButtonColor               = Color.FromArgb(242, 242, 228);
			this.m_ButtonHotColor            = Color.FromArgb(231, 231, 214);
			this.m_ButtonPressedColor        = Color.FromArgb(222, 217, 207);
			this.m_ButtonBorderColor         = Color.FromArgb(222, 217, 207);
			this.m_ButtonBorderHotColor      = Color.FromArgb(222, 217, 207);
			this.m_ButtonTextColor           = Color.Black;
			this.m_ButtonFlashColor          = Color.FromArgb(153, 204, 204);

			this.m_CalendarBackColor         = Color.White;
			this.m_CalendarForeColor         = Color.Black;
			this.m_CalendarTitleBackColor    = StyleGuide.InteliSelectionColor(PlansColors.Apoc);
			this.m_CalendarTitleForeColor    = Color.White;
			this.m_CalendarTrailingForeColor = Color.Silver;
			this.m_BorderColor               = Color.FromArgb(222, 217, 207);     
			this.m_BorderHotColor            = Color.FromArgb(222, 217, 207);
			this.m_CheckColor                = Color.FromArgb(153, 204, 204);
			this.m_CheckBoxColor             = Color.FromArgb(242, 242, 228);
			this.m_RadioButtonColor          = Color.FromArgb(242, 242, 228);
			this.m_EditColor                 = Color.FromArgb(242, 242, 228);
			this.m_EditFocusedColor          = Color.White;
			this.m_EditReadOnlyColor         = Color.FromArgb(238, 238, 225);
			this.m_EditDisabledColor         = Color.FromArgb(238, 238, 225);
			this.m_DisabledTextColor		 = Color.FromKnownColor(KnownColor.GrayText);
			this.m_FlashColor                = Color.FromArgb(153, 204, 204);
			this.m_TextColor                 = Color.Black;
			this.m_NegativeNumberColor       = Color.Black;
			this.m_LabelColor                = Color.FromArgb(231, 231, 214);

			this.m_LeftPanelColor            = Color.FromArgb(51, 153, 153);
			this.m_TopPanelColor             = Color.FromArgb(153, 204, 204);
			this.m_BottomPanelColor          = Color.FromArgb(222, 217, 207);
			this.m_ClientPanelColor          = Color.FromArgb(242, 242, 228);
			this.m_PanelAssLeftTitleColor = Color.FromArgb(242, 242, 228);
			this.m_PanelAssRightTitleColor = Color.FromArgb(51, 153, 153);
			this.m_PanelAssLeftOptionsColor = Color.FromArgb(51, 153, 153);
			this.m_PanelAssClientAreaColor = Color.FromArgb(242, 242, 228);
			this.m_PanelAssBottomAreaColor = Color.FromArgb(222, 217, 207);

			this.m_InfiniteProgressStartColor = Color.FromArgb(153, 204, 204);
			this.m_InfiniteProgressEndColor   = Color.White;
			
			this.m_CollapsiblePanelBarBackColor     = Color.FromArgb(51, 153, 153);
			this.m_CollapsiblePanelStartColor       = Color.FromArgb(56, 171, 171);
			this.m_CollapsiblePanelEndColor         = Color.FromArgb(56, 171, 171);
			this.m_CollapsiblePanelBackColor        = Color.FromArgb(153, 204, 204);
			this.m_CollapsiblePanelTitleFontColor   = Color.White; 
			this.m_CollapsiblePanelLineStartColor   = Color.White; 
			this.m_CollapsiblePanelLineEndColor     = Color.FromArgb(153, 204, 204);
			this.m_CollapsiblePanelLinkColor        = Color.White;

			this.m_PanelItemBackColor = Color.FromArgb(153, 204, 204);
			this.m_PanelItemAssBackColor = Color.FromArgb(51, 153, 153);
			this.m_PanelItemForeColor = Color.White;
			this.m_PanelItemFlashColor = Color.FromArgb(51, 153, 153);

			this.m_TabControlBackColor = Color.FromArgb(242, 242, 228);

			this.m_DockingBackColor = Color.FromArgb(231, 231, 214);
			this.m_DockingResizeBarColor = Color.FromArgb(231, 231, 214);
			this.m_DockingActiveTextColor = Color.White;
			this.m_DockingActiveColor = Color.FromArgb(206, 206, 181);
			this.m_DockingInactiveTextColor = Color.Black;

			this.m_DataGridAlternatingBackColor = StyleGuide.InteliSelectionColor(PlansColors.Apoc);
			this.m_DataGridBackColor = Color.White;
			this.m_DataGridBackgroundColor = Color.FromArgb(242, 242, 228);
			this.m_DataGridCaptionBackColor = Color.FromArgb(153, 204, 204);
			this.m_DataGridCaptionForeColor = Color.White;
			this.m_DataGridForeColor = Color.Black;
			this.m_DataGridLineColor = Color.FromArgb(222, 217, 207);
			this.m_DataGridHeaderBackColor = Color.FromArgb(222, 217, 207);
			this.m_DataGridHeaderForeColor = Color.Black;
			this.m_DataGridLinkColor = Color.LightSteelBlue;
			this.m_DataGridParentRowsBackColor = Color.FromArgb(222, 217, 207);
			this.m_DataGridParentRowsForeColor = Color.Black;
			this.m_DataGridSelectionBackColor = Color.Navy;
			this.m_DataGridSelectionForeColor = Color.White;

			this.m_TaskPanelBarBackColor = this.m_ClientPanelColor;

			this.m_TaskPanelBackColor = this.m_ClientPanelColor;
			this.m_TaskPanelTitleBackColor = this.m_LeftPanelColor;
			this.m_TaskPanelTitleForeColor = Color.White;
		}

		private void SetPlanColorsAgentSmith()
		{
			this.m_PictureBoxColor           = Color.FromArgb(242, 242, 228);

			this.m_ButtonColor               = Color.FromArgb(242, 242, 228);
			this.m_ButtonHotColor            = Color.FromArgb(231, 231, 214);
			this.m_ButtonPressedColor        = Color.FromArgb(222, 217, 207);
			this.m_ButtonBorderColor         = Color.FromArgb(222, 217, 207);
			this.m_ButtonBorderHotColor      = Color.FromArgb(222, 217, 207);
			this.m_ButtonTextColor           = Color.Black;
			this.m_ButtonFlashColor          = Color.FromArgb(102, 153, 204);

			this.m_CalendarBackColor         = Color.White;
			this.m_CalendarForeColor         = Color.Black;
			this.m_CalendarTitleBackColor    = StyleGuide.InteliSelectionColor(PlansColors.AgentSmith);
			this.m_CalendarTitleForeColor    = Color.White;
			this.m_CalendarTrailingForeColor = Color.Silver;
			this.m_BorderColor               = Color.FromArgb(222, 217, 207);     
			this.m_BorderHotColor            = Color.FromArgb(222, 217, 207);

			this.m_CheckColor                = Color.FromArgb(172, 200, 227);
			this.m_CheckBoxColor             = Color.FromArgb(242, 242, 228);
			this.m_RadioButtonColor          = Color.FromArgb(242, 242, 228);
			this.m_EditColor                 = Color.FromArgb(242, 242, 228);
			this.m_EditFocusedColor          = Color.White;
			this.m_EditReadOnlyColor         = Color.FromArgb(238, 238, 225);
			this.m_EditDisabledColor         = Color.FromArgb(238, 238, 225);
			this.m_DisabledTextColor		 = Color.FromKnownColor(KnownColor.GrayText);
			this.m_FlashColor                = Color.FromArgb(102, 153, 204);
			this.m_TextColor                 = Color.Black;
			this.m_NegativeNumberColor       = Color.Black;
			this.m_LabelColor                = Color.FromArgb(231, 231, 214);

			this.m_LeftPanelColor            = Color.FromArgb(51, 102, 153);
			this.m_TopPanelColor             = Color.FromArgb(102, 153, 204);
			this.m_BottomPanelColor          = Color.FromArgb(222, 217, 207);
			this.m_ClientPanelColor          = Color.FromArgb(242, 242, 228);
			this.m_PanelAssLeftTitleColor = Color.FromArgb(242, 242, 228);
			this.m_PanelAssRightTitleColor = Color.FromArgb(51, 102, 153);
			this.m_PanelAssLeftOptionsColor = Color.FromArgb(51, 102, 153);
			this.m_PanelAssClientAreaColor = Color.FromArgb(242, 242, 228);
			this.m_PanelAssBottomAreaColor = Color.FromArgb(222, 217, 207);

			this.m_InfiniteProgressStartColor = Color.FromArgb(102, 153, 204);
			this.m_InfiniteProgressEndColor   = Color.White;
			
			this.m_CollapsiblePanelBarBackColor     = Color.FromArgb(51, 102, 153);
			this.m_CollapsiblePanelStartColor       = Color.FromArgb(63, 125, 188);
			this.m_CollapsiblePanelEndColor         = Color.FromArgb(63, 125, 188);
			this.m_CollapsiblePanelBackColor        = Color.FromArgb(102, 153, 204);
			this.m_CollapsiblePanelTitleFontColor   = Color.White; 
			this.m_CollapsiblePanelLineStartColor   = Color.White; 
			this.m_CollapsiblePanelLineEndColor     = Color.FromArgb(102, 153, 204);
			this.m_CollapsiblePanelLinkColor        = Color.White;

			this.m_PanelItemBackColor = Color.FromArgb(102, 153, 204);
			this.m_PanelItemAssBackColor = Color.FromArgb(51, 102, 153);
			this.m_PanelItemForeColor = Color.White;
			this.m_PanelItemFlashColor = Color.FromArgb(242, 242, 228);

			this.m_TabControlBackColor = Color.FromArgb(242, 242, 228);

			this.m_DockingBackColor = Color.FromArgb(231, 231, 214);
			this.m_DockingResizeBarColor = Color.FromArgb(231, 231, 214);
			this.m_DockingActiveTextColor = Color.White;
			this.m_DockingActiveColor = Color.FromArgb(206, 206, 181);
			this.m_DockingInactiveTextColor = Color.Black;

			this.m_DataGridAlternatingBackColor = StyleGuide.InteliSelectionColor(PlansColors.AgentSmith);
			this.m_DataGridBackColor = Color.White;
			this.m_DataGridBackgroundColor = Color.FromArgb(242, 242, 228);
			this.m_DataGridCaptionBackColor = Color.FromArgb(102, 153, 204);
			this.m_DataGridCaptionForeColor = Color.White;
			this.m_DataGridForeColor = Color.Black;
			this.m_DataGridLineColor = Color.FromArgb(222, 217, 207);
			this.m_DataGridHeaderBackColor = Color.FromArgb(222, 217, 207);
			this.m_DataGridHeaderForeColor = Color.Black;
			this.m_DataGridLinkColor = Color.LightSteelBlue;
			this.m_DataGridParentRowsBackColor = Color.FromArgb(222, 217, 207);
			this.m_DataGridParentRowsForeColor = Color.Black;
			this.m_DataGridSelectionBackColor = Color.Navy;
			this.m_DataGridSelectionForeColor = Color.White;

			this.m_TaskPanelBarBackColor = this.m_ClientPanelColor;

			this.m_TaskPanelBackColor = this.m_ClientPanelColor;
			this.m_TaskPanelTitleBackColor = this.m_LeftPanelColor;
			this.m_TaskPanelTitleForeColor = Color.White;

			this.m_SelectionColor = this.m_CalendarTitleBackColor;
		}

		private void SetPlanColorsTrinity()
		{
			this.m_PictureBoxColor           = Color.FromArgb(242, 242, 228);

			this.m_ButtonColor               = Color.FromArgb(242, 242, 228);
			this.m_ButtonHotColor            = Color.FromArgb(231, 231, 214);
			this.m_ButtonPressedColor        = Color.FromArgb(222, 217, 207);
			this.m_ButtonBorderColor         = Color.FromArgb(222, 217, 207);
			this.m_ButtonBorderHotColor      = Color.FromArgb(222, 217, 207);
			this.m_ButtonTextColor           = Color.Black;
			this.m_ButtonFlashColor          = Color.FromArgb(204, 128, 128);

			this.m_CalendarBackColor         = Color.White;
			this.m_CalendarForeColor         = Color.Black;
			this.m_CalendarTitleBackColor    = StyleGuide.InteliSelectionColor(PlansColors.Trinity);
			this.m_CalendarTitleForeColor    = Color.White;
			this.m_CalendarTrailingForeColor = Color.Silver;
			this.m_BorderColor				 = Color.FromArgb(222, 217, 207);     
			this.m_BorderHotColor			 = Color.FromArgb(222, 217, 207);
			this.m_CheckColor				 = Color.FromArgb(204, 128, 128);
			this.m_CheckBoxColor             = Color.FromArgb(242, 242, 228);
			this.m_RadioButtonColor          = Color.FromArgb(242, 242, 228);
			this.m_EditColor                 = Color.FromArgb(242, 242, 228);
			this.m_EditFocusedColor          = Color.White;
			this.m_EditReadOnlyColor         = Color.FromArgb(238, 238, 225);
			this.m_EditDisabledColor         = Color.FromArgb(238, 238, 225);
			this.m_DisabledTextColor		 = Color.FromKnownColor(KnownColor.GrayText);
			this.m_FlashColor                = Color.FromArgb(204, 128, 128);
			this.m_TextColor                 = Color.Black;
			this.m_NegativeNumberColor       = Color.Black;
			this.m_LabelColor                = Color.FromArgb(231, 231, 214);
			
			this.m_LeftPanelColor            = Color.FromArgb(153, 51, 51);
			this.m_TopPanelColor             = Color.FromArgb(204, 128, 128);
			this.m_BottomPanelColor          = Color.FromArgb(222, 217, 207);
			this.m_ClientPanelColor          = Color.FromArgb(242, 242, 228);
			this.m_PanelAssLeftTitleColor = Color.FromArgb(242, 242, 228);
			this.m_PanelAssRightTitleColor = Color.FromArgb(153, 51, 51);
			this.m_PanelAssLeftOptionsColor = Color.FromArgb(153, 51, 51);
			this.m_PanelAssClientAreaColor = Color.FromArgb(242, 242, 228);
			this.m_PanelAssBottomAreaColor = Color.FromArgb(222, 217, 207);

			this.m_InfiniteProgressStartColor = Color.FromArgb(204, 128, 128);
			this.m_InfiniteProgressEndColor   = Color.White;

			this.m_CollapsiblePanelBarBackColor     = Color.FromArgb(153, 51, 51);
			this.m_CollapsiblePanelStartColor       = Color.FromArgb(187, 62, 62);
			this.m_CollapsiblePanelEndColor         = Color.FromArgb(187, 62, 62);
			this.m_CollapsiblePanelBackColor        = Color.FromArgb(204, 128, 128);
			this.m_CollapsiblePanelTitleFontColor   = Color.White; 
			this.m_CollapsiblePanelLineStartColor   = Color.White; 
			this.m_CollapsiblePanelLineEndColor     = Color.FromArgb(204, 128, 128);
			this.m_CollapsiblePanelLinkColor        = Color.White;

			this.m_PanelItemBackColor = Color.FromArgb(204, 128, 128);
			this.m_PanelItemAssBackColor = Color.FromArgb(153, 51, 51);
			this.m_PanelItemForeColor = Color.White;
			this.m_PanelItemFlashColor = Color.FromArgb(242, 242, 228);

			this.m_TabControlBackColor = Color.FromArgb(242, 242, 228);

			this.m_DockingBackColor = Color.FromArgb(231, 231, 214);
			this.m_DockingResizeBarColor = Color.FromArgb(231, 231, 214);
			this.m_DockingActiveTextColor = Color.White;
			this.m_DockingActiveColor = Color.FromArgb(206, 206, 181);
			this.m_DockingInactiveTextColor = Color.Black;

			this.m_DataGridAlternatingBackColor = StyleGuide.InteliSelectionColor(PlansColors.Trinity);
			this.m_DataGridBackColor = Color.White;
			this.m_DataGridBackgroundColor = Color.FromArgb(242, 242, 228);
			this.m_DataGridCaptionBackColor = Color.FromArgb(204, 128, 128);
			this.m_DataGridCaptionForeColor = Color.White;
			this.m_DataGridForeColor = Color.Black;
			this.m_DataGridLineColor = Color.FromArgb(222, 217, 207);
			this.m_DataGridHeaderBackColor = Color.FromArgb(222, 217, 207);
			this.m_DataGridHeaderForeColor = Color.Black;
			this.m_DataGridLinkColor = Color.LightSteelBlue;
			this.m_DataGridParentRowsBackColor = Color.FromArgb(222, 217, 207);
			this.m_DataGridParentRowsForeColor = Color.Black;
			this.m_DataGridSelectionBackColor = Color.Navy;
			this.m_DataGridSelectionForeColor = Color.White;

			this.m_TaskPanelBarBackColor = this.m_ClientPanelColor;

			this.m_TaskPanelBackColor = this.m_ClientPanelColor;
			this.m_TaskPanelTitleBackColor = this.m_LeftPanelColor;
			this.m_TaskPanelTitleForeColor = Color.White;

			this.m_SelectionColor = this.m_CalendarTitleBackColor;
		}

		private void SetPlanColorsMouse()
		{
			this.m_PictureBoxColor           = Color.FromArgb(242, 242, 228);
			
			this.m_ButtonColor               = Color.FromArgb(242, 242, 228);
			this.m_ButtonHotColor            = Color.FromArgb(231, 231, 214);
			this.m_ButtonPressedColor        = Color.FromArgb(222, 217, 207);
			this.m_ButtonBorderColor         = Color.FromArgb(222, 217, 207);
			this.m_ButtonBorderHotColor      = Color.FromArgb(222, 217, 207);
			this.m_ButtonTextColor           = Color.Black;
			this.m_ButtonFlashColor          = Color.FromArgb(204, 153, 102);

			this.m_CalendarBackColor         = Color.White;
			this.m_CalendarForeColor         = Color.Black;
			this.m_CalendarTitleBackColor    = StyleGuide.InteliSelectionColor(PlansColors.Mouse);
			this.m_CalendarTitleForeColor    = Color.White;
			this.m_CalendarTrailingForeColor = Color.Silver;
			this.m_BorderColor               = Color.FromArgb(222, 217, 207);     
			this.m_BorderHotColor            = Color.FromArgb(222, 217, 207);
			this.m_CheckColor                = Color.FromArgb(215, 175, 136);
			this.m_CheckBoxColor             = Color.FromArgb(242, 242, 228);
			this.m_RadioButtonColor          = Color.FromArgb(242, 242, 228);
			this.m_EditColor                 = Color.FromArgb(242, 242, 228);
			this.m_EditFocusedColor          = Color.White;
			this.m_EditReadOnlyColor         = Color.FromArgb(238, 238, 225);
			this.m_EditDisabledColor         = Color.FromArgb(238, 238, 225);
			this.m_DisabledTextColor		 = Color.FromKnownColor(KnownColor.GrayText);
			this.m_FlashColor                = Color.FromArgb(204, 153, 102);
			this.m_TextColor                 = Color.Black;
			this.m_NegativeNumberColor       = Color.Black;
			this.m_LabelColor                = Color.FromArgb(231, 231, 214);

			this.m_LeftPanelColor            = Color.FromArgb(153, 102, 51);
			this.m_TopPanelColor             = Color.FromArgb(204, 153, 102);
			this.m_BottomPanelColor          = Color.FromArgb(222, 217, 207);
			this.m_ClientPanelColor          = Color.FromArgb(242, 242, 228);

			this.m_InfiniteProgressStartColor = Color.FromArgb(204, 153, 102);
			this.m_InfiniteProgressEndColor   = Color.White;
			
			this.m_PanelAssLeftTitleColor = Color.FromArgb(242, 242, 228);
			this.m_PanelAssRightTitleColor = Color.FromArgb(153, 102, 51);
			this.m_PanelAssLeftOptionsColor = Color.FromArgb(153, 102, 51);
			this.m_PanelAssClientAreaColor = Color.FromArgb(242, 242, 228);
			this.m_PanelAssBottomAreaColor = Color.FromArgb(222, 217, 207);

			this.m_CollapsiblePanelBarBackColor     = Color.FromArgb(153, 102, 51);
			this.m_CollapsiblePanelStartColor       = Color.FromArgb(182, 121, 61);
			this.m_CollapsiblePanelEndColor         = Color.FromArgb(182, 121, 61);
			this.m_CollapsiblePanelBackColor        = Color.FromArgb(204, 153, 102);
			this.m_CollapsiblePanelTitleFontColor   = Color.White; 
			this.m_CollapsiblePanelLineStartColor   = Color.White; 
			this.m_CollapsiblePanelLineEndColor     = Color.FromArgb(204, 153, 102);
			this.m_CollapsiblePanelLinkColor        = Color.White;

			this.m_PanelItemBackColor = Color.FromArgb(204, 153, 102);
			this.m_PanelItemAssBackColor = Color.FromArgb(153, 102, 51);
			this.m_PanelItemForeColor = Color.White;
			this.m_PanelItemFlashColor = Color.FromArgb(222, 217, 207);

			this.m_TabControlBackColor = Color.FromArgb(242, 242, 228);

			this.m_DockingBackColor = Color.FromArgb(231, 231, 214);
			this.m_DockingResizeBarColor = Color.FromArgb(231, 231, 214);
			this.m_DockingActiveTextColor = Color.White;
			this.m_DockingActiveColor = Color.FromArgb(206, 206, 181);
			this.m_DockingInactiveTextColor = Color.Black;

			this.m_DataGridAlternatingBackColor = StyleGuide.InteliSelectionColor(PlansColors.Mouse);
			this.m_DataGridBackColor = Color.White;
			this.m_DataGridBackgroundColor = Color.FromArgb(242, 242, 228);
			this.m_DataGridCaptionBackColor = Color.FromArgb(204, 153, 102);
			this.m_DataGridCaptionForeColor = Color.White;
			this.m_DataGridForeColor = Color.Black;
			this.m_DataGridLineColor = Color.FromArgb(222, 217, 207);
			this.m_DataGridHeaderBackColor = Color.FromArgb(222, 217, 207);
			this.m_DataGridHeaderForeColor = Color.Black;
			this.m_DataGridLinkColor = Color.LightSteelBlue;
			this.m_DataGridParentRowsBackColor = Color.FromArgb(222, 217, 207);
			this.m_DataGridParentRowsForeColor = Color.Black;
			this.m_DataGridSelectionBackColor = Color.Navy;
			this.m_DataGridSelectionForeColor = Color.White;

			this.m_TaskPanelBarBackColor = this.m_ClientPanelColor;

			this.m_TaskPanelBackColor = this.m_ClientPanelColor;
			this.m_TaskPanelTitleBackColor = this.m_LeftPanelColor;
			this.m_TaskPanelTitleForeColor = Color.White;
			this.m_SelectionColor = this.m_CalendarTitleBackColor;
		}

		private void SetPlanColorsNeo()
		{
			this.m_PictureBoxColor           = Color.FromArgb(242, 242, 228);

			this.m_ButtonColor               = Color.FromArgb(242, 242, 228);
			this.m_ButtonHotColor            = Color.FromArgb(231, 231, 214);
			this.m_ButtonPressedColor        = Color.FromArgb(222, 217, 207);
			this.m_ButtonBorderColor         = Color.FromArgb(222, 217, 207);
			this.m_ButtonBorderHotColor      = Color.FromArgb(222, 217, 207);
			this.m_ButtonTextColor           = Color.Black;
			this.m_ButtonFlashColor          = Color.FromArgb(170, 170, 221);

			this.m_CalendarBackColor         = Color.White;
			this.m_CalendarForeColor         = Color.Black;
			this.m_CalendarTitleBackColor    = StyleGuide.InteliSelectionColor(PlansColors.NeoTheOne);
			this.m_CalendarTitleForeColor    = Color.White;
			this.m_CalendarTrailingForeColor = Color.Silver;

			this.m_BorderColor               = Color.FromArgb(222, 217, 207);     
			this.m_BorderHotColor            = Color.FromArgb(222, 217, 207);
			
			this.m_CheckColor                = Color.FromArgb(170, 170, 221);
			this.m_CheckBoxColor             = Color.FromArgb(242, 242, 228);
			this.m_RadioButtonColor          = Color.FromArgb(242, 242, 228);
			
			this.m_EditColor                 = Color.FromArgb(242, 242, 228);
			this.m_EditFocusedColor          = Color.White;
			this.m_EditReadOnlyColor         = Color.FromArgb(238, 238, 225);
			this.m_EditDisabledColor         = Color.FromArgb(238, 238, 225);
			this.m_DisabledTextColor		 = Color.FromKnownColor(KnownColor.GrayText);
			this.m_FlashColor                = Color.FromArgb(170, 170, 221);
			this.m_TextColor                 = Color.Black;
			this.m_NegativeNumberColor       = Color.Black;
			
			this.m_LabelColor                = Color.FromArgb(231, 231, 214);
			
			this.m_LeftPanelColor            = Color.FromArgb(231, 231, 214);
			this.m_TopPanelColor             = Color.FromArgb(170, 170, 221);
			this.m_BottomPanelColor          = Color.FromArgb(222, 217, 207);
			this.m_ClientPanelColor          = Color.FromArgb(242, 242, 228);

			this.m_InfiniteProgressStartColor = Color.FromArgb(170, 170, 221);
			this.m_InfiniteProgressEndColor   = Color.White;
			
			this.m_PanelAssLeftTitleColor = Color.FromArgb(242, 242, 228);
			this.m_PanelAssRightTitleColor = Color.FromArgb(231, 231, 214);
			this.m_PanelAssLeftOptionsColor = Color.FromArgb(231, 231, 214);
			this.m_PanelAssClientAreaColor = Color.FromArgb(242, 242, 228);
			this.m_PanelAssBottomAreaColor = Color.FromArgb(222, 217, 207);

			this.m_CollapsiblePanelBarBackColor     = Color.FromArgb(231, 231, 214);
			this.m_CollapsiblePanelStartColor       = Color.FromArgb(170, 170, 221);
			this.m_CollapsiblePanelEndColor         = Color.FromArgb(170, 170, 221);
			this.m_CollapsiblePanelBackColor        = Color.FromArgb(237, 237, 224);
			this.m_CollapsiblePanelTitleFontColor   = Color.White; 
			this.m_CollapsiblePanelLineStartColor   = Color.White; 
			this.m_CollapsiblePanelLineEndColor     = Color.FromArgb(237, 237, 224);
			this.m_CollapsiblePanelLinkColor        = Color.White;

			this.m_PanelItemBackColor = Color.FromArgb(237, 237, 224);
			this.m_PanelItemAssBackColor = Color.FromArgb(231, 231, 214);
			this.m_PanelItemForeColor = Color.FromArgb(170, 170, 221);
			this.m_PanelItemFlashColor = Color.LightSteelBlue;

			this.m_TabControlBackColor = Color.FromArgb(242, 242, 228);

			this.m_DockingBackColor = Color.FromArgb(231, 231, 214);
			this.m_DockingResizeBarColor = Color.FromArgb(231, 231, 214);
			this.m_DockingActiveTextColor = Color.White;
			this.m_DockingActiveColor = Color.FromArgb(206, 206, 181);
			this.m_DockingInactiveTextColor = Color.Black;

			this.m_DataGridAlternatingBackColor = StyleGuide.InteliSelectionColor(PlansColors.NeoTheOne);
			this.m_DataGridBackColor = Color.White;
			this.m_DataGridBackgroundColor = Color.FromArgb(242, 242, 228);
			this.m_DataGridCaptionBackColor = Color.FromArgb(170, 170, 221);
			this.m_DataGridCaptionForeColor = Color.White;
			this.m_DataGridForeColor = Color.Black;
			this.m_DataGridLineColor = Color.FromArgb(222, 217, 207);
			this.m_DataGridHeaderBackColor = Color.FromArgb(222, 217, 207);
			this.m_DataGridHeaderForeColor = Color.Black;
			this.m_DataGridLinkColor = Color.LightSteelBlue;
			this.m_DataGridParentRowsBackColor = Color.FromArgb(222, 217, 207);
			this.m_DataGridParentRowsForeColor = Color.Black;
			this.m_DataGridSelectionBackColor = Color.Navy;
			this.m_DataGridSelectionForeColor = Color.White;

			this.m_TaskPanelBarBackColor = this.m_ClientPanelColor;

			this.m_TaskPanelBackColor = this.m_ClientPanelColor;
			this.m_TaskPanelTitleBackColor = this.m_LeftPanelColor;
			this.m_TaskPanelTitleForeColor = Color.White;

			this.m_SelectionColor = this.m_CalendarTitleBackColor;
		}

		private void SetPlanColorsAssGreen()
		{
			this.m_ButtonColor               = Color.FromArgb(123, 156, 159);
			this.m_ButtonHotColor            = Color.FromArgb(131,171,170);
			this.m_ButtonPressedColor        = Color.FromArgb(99, 133, 137);
			this.m_ButtonBorderColor         = Color.FromArgb(123, 156, 159);
			this.m_ButtonBorderHotColor      = Color.FromArgb(123, 156, 159);
			this.m_ButtonTextColor           = Color.FromArgb(224, 231, 213);
			this.m_ButtonFlashColor          = Color.FromArgb(109, 135, 125);

			this.m_EditButtonColor           = Color.FromArgb(224, 231, 214);
			this.m_EditButtonHotColor        = Color.FromArgb(231, 231, 214);
			this.m_EditButtonPressedColor    = Color.FromArgb(222, 217, 207);
			
			this.m_BorderColor               = Color.FromArgb(222, 217, 207);     
			this.m_BorderHotColor            = Color.FromArgb(222, 217, 207);

			this.m_CheckColor                = Color.FromArgb(147, 167, 159);
			this.m_CheckBoxColor             = Color.FromArgb(232, 237, 223);
			this.m_RadioButtonColor          = Color.FromArgb(232, 237, 223);

			this.m_EditColor                 = Color.FromArgb(232, 237, 223);
			this.m_EditFocusedColor          = Color.FromArgb(240, 240, 240);
			this.m_EditReadOnlyColor         = Color.FromArgb(238, 238, 225);
			this.m_EditDisabledColor         = Color.FromArgb(238, 238, 225);
			this.m_DisabledTextColor		 = Color.FromKnownColor(KnownColor.GrayText);
			this.m_FlashColor                = Color.FromArgb(147, 167, 159);
			this.m_TextColor                 = Color.Black;
			this.m_NegativeNumberColor       = Color.Black;

			this.m_LabelColor                = Color.FromArgb(224, 231, 214);
		
			this.m_LeftPanelColor            = Color.FromArgb(147, 167, 159);
			this.m_TopPanelColor             = Color.FromArgb(119, 145, 135); 
			this.m_BottomPanelColor          = Color.FromArgb(222, 230, 210);
			this.m_ClientPanelColor          = Color.FromArgb(232, 237, 223);
			this.m_PanelAssLeftTitleColor    = Color.FromArgb(232, 237, 223);
			this.m_PanelAssRightTitleColor   = Color.FromArgb(147, 167, 159);
			this.m_PanelAssLeftOptionsColor  = Color.FromArgb(147, 167, 159);
			this.m_PanelAssClientAreaColor   = Color.FromArgb(232, 237, 223);
			this.m_PanelAssBottomAreaColor   = Color.FromArgb(222, 230, 210);
			
			this.m_InfiniteProgressStartColor = Color.FromArgb(147, 167, 159);
			this.m_InfiniteProgressEndColor   = Color.FromArgb(240, 240, 240);
			
			this.m_PictureBoxColor           = Color.FromArgb(232, 237, 223);

			this.m_CalendarBackColor         = Color.FromArgb(232, 237, 223);
			this.m_CalendarForeColor         = Color.Black;
			this.m_CalendarTitleBackColor    = Color.FromArgb(222, 217, 207);
			this.m_CalendarTitleForeColor    = Color.White;
			this.m_CalendarTrailingForeColor = Color.FromArgb(147, 167, 159);

			this.m_CollapsiblePanelBarBackColor     = Color.FromArgb(147, 167, 159);
			this.m_CollapsiblePanelStartColor       = Color.FromArgb(114, 139, 129);
			this.m_CollapsiblePanelEndColor         = Color.White;
			this.m_CollapsiblePanelBackColor        = Color.FromArgb(183, 196, 190);
			this.m_CollapsiblePanelTitleFontColor   = Color.White; 
			this.m_CollapsiblePanelLineStartColor   = Color.White; 
			this.m_CollapsiblePanelLineEndColor     = Color.White;
			this.m_CollapsiblePanelLinkColor        = Color.White;

			this.m_PanelItemBackColor = Color.FromArgb(183, 196, 190);
			this.m_PanelItemAssBackColor = Color.FromArgb(147, 167, 159);
			this.m_PanelItemForeColor = Color.FromArgb(228, 234, 218);
			this.m_PanelItemFlashColor = Color.FromArgb(108, 108, 108);

			this.m_TabControlBackColor = Color.FromArgb(232, 237, 223);

			this.m_DockingBackColor = Color.FromArgb(232, 237, 223);
			this.m_DockingResizeBarColor = Color.FromArgb(231, 231, 214);
			this.m_DockingActiveTextColor = Color.White;
			this.m_DockingActiveColor = StyleGuide.InteliSelectionColor(PlansColors.AssGreen);
			//this.m_DockingActiveColor = Color.FromArgb(222, 230, 210);
			this.m_DockingInactiveTextColor = Color.Black;

			this.m_DataGridAlternatingBackColor = StyleGuide.InteliSelectionColor(PlansColors.AssGreen);
			//this.m_DataGridAlternatingBackColor = Color.FromArgb(222, 230, 210);
			this.m_DataGridBackColor = Color.FromArgb(240, 240, 240);
			this.m_DataGridBackgroundColor = Color.FromArgb(232, 237, 223);
			this.m_DataGridCaptionBackColor = Color.FromArgb(109, 135, 125);
			this.m_DataGridCaptionForeColor = Color.White;
			this.m_DataGridForeColor = Color.Black;
			this.m_DataGridLineColor = Color.FromArgb(222, 217, 207);
			this.m_DataGridHeaderBackColor = Color.FromArgb(222, 217, 207);
			this.m_DataGridHeaderForeColor = Color.Black;
			this.m_DataGridLinkColor = Color.LightSteelBlue;
			this.m_DataGridParentRowsBackColor = Color.FromArgb(222, 217, 207);
			this.m_DataGridParentRowsForeColor = Color.Black;
			this.m_DataGridSelectionBackColor = Color.Navy;
			this.m_DataGridSelectionForeColor = Color.White;

			this.m_TaskPanelBarBackColor = this.m_ClientPanelColor;

			this.m_TaskPanelBackColor = this.m_ClientPanelColor;
			this.m_TaskPanelTitleBackColor = this.m_LeftPanelColor;
			this.m_TaskPanelTitleForeColor = Color.White;

			this.m_SelectionColor = StyleGuide.InteliSelectionColor(PlansColors.AssGreen);
		}
		
		//2003-08-10 create by Stray Bullet
		private void SetPlanColorsTweakGreen()
		{
			this.m_ButtonColor               = Color.FromArgb(123, 156, 159);
			this.m_ButtonHotColor            = Color.FromArgb(131,171,170);
			this.m_ButtonPressedColor        = Color.FromArgb(99, 133, 137);
			this.m_ButtonBorderColor         = Color.FromArgb(123, 156, 159);
			this.m_ButtonBorderHotColor      = Color.FromArgb(123, 156, 159);
			this.m_ButtonTextColor           = Color.FromArgb(224, 231, 213);
			this.m_ButtonFlashColor          = Color.FromArgb(109, 135, 125);

			this.m_EditButtonColor           = Color.FromArgb(224, 231, 214);
			this.m_EditButtonHotColor        = Color.FromArgb(231, 231, 214);
			this.m_EditButtonPressedColor    = Color.FromArgb(222, 217, 207);

			this.m_BorderColor               = Color.FromArgb(199, 190, 173);
			this.m_BorderHotColor            = Color.FromArgb(222, 217, 207);

			this.m_CheckColor                = Color.FromArgb(147, 167, 159);
			this.m_CheckBoxColor             = Color.FromArgb(232, 237, 223);
			this.m_RadioButtonColor          = Color.FromArgb(232, 237, 223);

			this.m_EditColor                 = Color.FromArgb(242, 242, 228);
			this.m_EditFocusedColor          = Color.FromArgb(240, 240, 240);
			this.m_EditReadOnlyColor         = Color.FromArgb(238, 238, 225);
			this.m_EditDisabledColor         = Color.FromArgb(232, 237, 223);
			this.m_FlashColor                = Color.FromArgb(147, 167, 159);
			this.m_TextColor                 = Color.Black;
			this.m_DisabledTextColor		 = Color.FromKnownColor(KnownColor.GrayText);
			this.m_NegativeNumberColor       = Color.Black;

			this.m_LabelColor                = Color.FromArgb(231, 231, 214);

			this.m_LeftPanelColor            = Color.FromArgb(147, 167, 159);
			this.m_TopPanelColor             = Color.FromArgb(119, 145, 135);
			this.m_BottomPanelColor          = Color.FromArgb(222, 230, 210);
			this.m_ClientPanelColor          = Color.FromArgb(232, 237, 223);
			this.m_PanelAssLeftTitleColor    = Color.FromArgb(232, 237, 223);
			this.m_PanelAssRightTitleColor   = Color.FromArgb(147, 167, 159);
			this.m_PanelAssLeftOptionsColor  = Color.FromArgb(147, 167, 159);
			this.m_PanelAssClientAreaColor   = Color.FromArgb(232, 237, 223);
			this.m_PanelAssBottomAreaColor   = Color.FromArgb(222, 230, 210);

			this.m_InfiniteProgressStartColor = Color.FromArgb(147, 167, 159);
			this.m_InfiniteProgressEndColor   = Color.FromArgb(240, 240, 240);

			this.m_PictureBoxColor           = Color.FromArgb(232, 237, 223);

			this.m_CalendarBackColor         = Color.FromArgb(232, 237, 223);
			this.m_CalendarForeColor         = Color.Black;
			this.m_CalendarTitleBackColor    = Color.FromArgb(222, 217, 207);
			this.m_CalendarTitleForeColor    = Color.White;
			this.m_CalendarTrailingForeColor = Color.FromArgb(147, 167, 159);

			this.m_CollapsiblePanelBarBackColor     = Color.FromArgb(147, 167, 159);
			this.m_CollapsiblePanelStartColor       = Color.FromArgb(114, 139, 129);
			this.m_CollapsiblePanelEndColor         = Color.White;
			this.m_CollapsiblePanelBackColor        = Color.FromArgb(183, 196, 190);
			this.m_CollapsiblePanelTitleFontColor   = Color.White;
			this.m_CollapsiblePanelLineStartColor   = Color.White;
			this.m_CollapsiblePanelLineEndColor     = Color.White;
			this.m_CollapsiblePanelLinkColor        = Color.White;

			this.m_PanelItemBackColor = Color.FromArgb(183, 196, 190);
			this.m_PanelItemAssBackColor = Color.FromArgb(147, 167, 159);
			this.m_PanelItemForeColor = Color.FromArgb(228, 234, 218);
			this.m_PanelItemFlashColor = Color.FromArgb(108, 108, 108);

			this.m_TabControlBackColor = Color.FromArgb(232, 237, 223);

			this.m_DockingBackColor = Color.FromArgb(232, 237, 223);
			this.m_DockingResizeBarColor = Color.FromArgb(231, 231, 214);
			this.m_DockingActiveTextColor = Color.White;
			this.m_DockingActiveColor = 
				StyleGuide.InteliSelectionColor(PlansColors.TweakGreen);
			//this.m_DockingActiveColor = Color.FromArgb(222, 230, 210);
			this.m_DockingInactiveTextColor = Color.Black;

			this.m_DataGridAlternatingBackColor = StyleGuide.InteliSelectionColor(PlansColors.TweakGreen);
			//this.m_DataGridAlternatingBackColor = Color.FromArgb(222, 230, 210);
			this.m_DataGridBackColor = Color.FromArgb(240, 240, 240);
			this.m_DataGridBackgroundColor = Color.FromArgb(232, 237, 223);
			this.m_DataGridCaptionBackColor = Color.FromArgb(109, 135, 125);
			this.m_DataGridCaptionForeColor = Color.White;
			this.m_DataGridForeColor = Color.Black;
			this.m_DataGridLineColor = Color.FromArgb(222, 217, 207);
			this.m_DataGridHeaderBackColor = Color.FromArgb(222, 217, 207);
			this.m_DataGridHeaderForeColor = Color.Black;
			this.m_DataGridLinkColor = Color.LightSteelBlue;
			this.m_DataGridParentRowsBackColor = Color.FromArgb(222, 217, 207);
			this.m_DataGridParentRowsForeColor = Color.Black;
			this.m_DataGridSelectionBackColor = Color.Navy;
			this.m_DataGridSelectionForeColor = Color.White;

			this.m_TaskPanelBarBackColor = this.m_ClientPanelColor;

			this.m_TaskPanelBackColor = this.m_ClientPanelColor;
			this.m_TaskPanelTitleBackColor = this.m_LeftPanelColor;
			this.m_TaskPanelTitleForeColor = Color.White;

			this.m_SelectionColor = StyleGuide.InteliSelectionColor(PlansColors.TweakGreen);
		}

		#endregion

		#region Methods

		public static Color InteliBorderColor(bool hot, Color borderHotColor, Color borderColor)
		{
			if(hot)
			{
				return borderHotColor;
			}
			else
			{
				return borderColor;
			}
		}

		public static Color InteliButtonColor(bool hot,bool pressed, Color buttonColor, Color buttonPressedColor, Color buttonHotColor)
		{
			if(hot)
			{
				if(pressed)
				{
					return buttonPressedColor;
				}
				else
				{
					return buttonHotColor;
				}
			}
			else
			{
				return buttonColor;
			}
		}

		public static Color InteliEditColor(bool editReadOnly,bool enabled, Color editColor, Color editReadOnlyColor, Color editDisabledColor)
		{
			if(!editReadOnly && enabled)
			{
				return editColor;
			}
			else
			{
				if(editReadOnly && enabled)
				{
					return editReadOnlyColor;
				}
				else
				{ 
					return editDisabledColor;
				}
			}
		}

		public static Color InteliEditColor(bool editReadOnly,bool enabled, bool flash, Color editColor, Color flashColor, Color editReadOnlyColor, Color editDisabledColor)
		{
			if(!editReadOnly && enabled)
			{
				if (!flash) return editColor;
				else return flashColor;
			}
			else
			{
				if(editReadOnly && enabled)
				{
					return editReadOnlyColor;
				}
				else
				{ 
					return editDisabledColor;
				}
			}
		}

		public static Color InteliSelectionColor(object patern)
		{
			if ((patern != null) && (patern.GetType() == typeof(PlansColors)))
			{
				PlansColors m_patern = (PlansColors)patern;

				if (m_patern == PlansColors.Morpheus) {return ColorUtilities.CalculateColor(Color.FromArgb(255, 204, 102), SystemColors.Window, 70);} 
				else if (m_patern == PlansColors.Cypher) {return ColorUtilities.CalculateColor(Color.FromArgb(153, 153, 102), SystemColors.Window, 70);} 
				else if (m_patern == PlansColors.Apoc) {return ColorUtilities.CalculateColor(Color.FromArgb(153, 204, 204), SystemColors.Window, 70);} 
				else if (m_patern == PlansColors.AgentSmith) {return ColorUtilities.CalculateColor(Color.FromArgb(102, 153, 204), SystemColors.Window, 70);} 
				else if (m_patern == PlansColors.Trinity) {return ColorUtilities.CalculateColor(Color.FromArgb(204, 128, 128), SystemColors.Window, 70);} 
				else if (m_patern == PlansColors.Mouse) {return ColorUtilities.CalculateColor(Color.FromArgb(204, 153, 102), SystemColors.Window, 70);}
				else if (m_patern == PlansColors.NeoTheOne) {return ColorUtilities.CalculateColor(Color.FromArgb(170, 170, 221), SystemColors.Window, 70);}
				else if (m_patern == PlansColors.AssGreen) {return Color.FromArgb(224, 231, 214);} 
				else if (m_patern == PlansColors.TweakGreen) {return Color.FromArgb(224, 231, 214);} //2003-08-10 create by Stray Bullet
				else {return ColorUtilities.VsNetSelectionColor;} 
			}
			else {return ColorUtilities.VsNetSelectionColor;}
		}

		public Color InteliEditColor(bool editReadOnly,bool enabled)
		{
			if(!editReadOnly && enabled)
			{
				return this.EditColor;
			}
			else
			{
				if(editReadOnly && enabled)
				{
					return this.EditReadOnlyColor;
				}
				else
				{ 
					return this.EditDisabledColor;
				}
			}
		}

		public Color InteliEditColor(bool editReadOnly,bool enabled, bool flash)
		{
			if(!editReadOnly && enabled)
			{
				if (!flash) return this.EditColor;
				else return this.FlashColor;
			}
			else
			{
				if(editReadOnly && enabled)
				{
					return this.EditReadOnlyColor;
				}
				else
				{ 
					return this.EditDisabledColor;
				}
			}
		}

		public Color InteliBorderColor(bool hot)
		{
			if(hot)
			{
				return m_BorderHotColor;
			}
			else
			{
				return m_BorderColor;
			}
		}

		public Color InteliButtonBorderColor(bool hot)
		{
			if(hot)
			{
				return m_ButtonBorderHotColor;
			}
			else
			{
				return m_ButtonBorderColor;
			}
		}

		public Color InteliButtonColor(bool hot,bool pressed)
		{
			if(hot)
			{
				if(pressed)
				{
					return m_ButtonPressedColor;
				}
				else
				{
					return m_ButtonHotColor;
				}
			}
			else
			{
				return m_ButtonColor;
			}
		}

		#endregion

		#region Properties

		[Category("Patterns")]
		public virtual PlansColors PlansOfColors
		{
			get {return m_PlansOfColors;}
			set 
			{
				m_PlansOfColors = value;

				if (value == PlansColors.Morpheus) {this.SetPlanColorsMorpheus();}
				else if (value == PlansColors.Cypher) {this.SetPlanColorsCypher();}
				else if (value == PlansColors.Apoc) {this.SetPlanColorsApoc();}
				else if (value == PlansColors.AgentSmith) {this.SetPlanColorsAgentSmith();}
				else if (value == PlansColors.Trinity) {this.SetPlanColorsTrinity();}
				else if (value == PlansColors.Mouse) {this.SetPlanColorsMouse();}
				else if (value == PlansColors.NeoTheOne) {this.SetPlanColorsNeo();}
				else if (value == PlansColors.AssGreen) {this.SetPlanColorsAssGreen();}
				else if (value == PlansColors.TweakGreen) {this.SetPlanColorsTweakGreen();} //2003-08-10 create by Stray Bullet

				OnPlansOfColorsChanged(value);
			}
		}

		[Category("PictureBox")]
		public Color PictureBoxColor
		{
			get{ return m_PictureBoxColor; }

			set
			{ 
				if(m_PictureBoxColor != value)
				{
					m_PictureBoxColor = value;
					OnStyleChanged("PictureBoxColor",value);
				}
			}
		}

		[Category("Common")]
		public Color BorderColor
		{
			get{ return m_BorderColor; }

			set
			{ 
				if(m_BorderColor != value)
				{
					m_BorderColor = value;
					OnStyleChanged("BorderColor",value);
				}
			}
		}

		[Category("Common")]
		public Color BorderHotColor
		{
			get{ return m_BorderHotColor; }

			set
			{ 
				if(m_BorderHotColor != value)
				{
					m_BorderHotColor = value; 
					OnStyleChanged("BorderHotColor",value);
				}
			}
		}

		[Category("Buttons")]
		public Color ButtonColor
		{
			get{ return m_ButtonColor; }

			set
			{ 
				if(m_ButtonColor != value)
				{
					m_ButtonColor = value; 
					OnStyleChanged("ButtonColor",value);
				}
			}
		}

		[Category("Buttons")]
		public Color ButtonHotColor
		{
			get{ return m_ButtonHotColor; }

			set
			{ 
				if(m_ButtonHotColor != value)
				{
					m_ButtonHotColor = value; 
					OnStyleChanged("ButtonHotColor",value);
				}
			}
		}

		[Category("Buttons")]
		public Color ButtonPressedColor
		{
			get{ return m_ButtonPressedColor; }

			set
			{ 
				if(m_ButtonPressedColor != value)
				{
					m_ButtonPressedColor = value; 
					OnStyleChanged("ButtonPressedColor",value);
				}
			}
		}

		[Category("Buttons")]
		public Color ButtonBorderColor
		{
			get{ return m_ButtonBorderColor; }

			set
			{ 
				if(m_ButtonBorderColor != value)
				{
					m_ButtonBorderColor = value; 
					OnStyleChanged("ButtonBorderColor",value);
				}
			}
		}

		[Category("Buttons")]
		public Color ButtonBorderHotColor
		{
			get{ return m_ButtonBorderHotColor; }

			set
			{ 
				if(m_ButtonBorderHotColor != value)
				{
					m_ButtonBorderHotColor = value; 
					OnStyleChanged("ButtonBorderHotColor",value);
				}
			}
		}

		[Category("Buttons")]
		public Color ButtonTextColor
		{
			get{ return m_ButtonTextColor; }

			set
			{ 
				if(m_ButtonTextColor != value)
				{
					m_ButtonTextColor = value; 
					OnStyleChanged("ButtonTextColor",value);
				}
			}
		}

		[Category("Buttons")]
		public Color ButtonFlashColor
		{
			get{ return m_ButtonFlashColor; }

			set
			{ 
				if(m_ButtonFlashColor != value)
				{
					m_ButtonFlashColor = value; 
					OnStyleChanged("ButtonFlashColor",value);
				}
			}
		}

		[Category("Common")]
		public Color FlashColor
		{
			get{ return m_FlashColor; }

			set
			{ 
				if(m_FlashColor != value)
				{
					m_FlashColor = value; 
					OnStyleChanged("FlashColor",value);
				}
			}
		}

		[Category("EditButtons")]
		public Color EditButtonColor
		{
			get{ return m_EditButtonColor; }

			set
			{ 
				if(m_EditButtonColor != value)
				{
					m_EditButtonColor = value; 
					OnStyleChanged("EditButtonColor",value);
				}
			}
		}

		[Category("EditButtons")]
		public Color EditButtonHotColor
		{
			get{ return m_EditButtonHotColor; }

			set
			{ 
				if(m_EditButtonHotColor != value)
				{
					m_EditButtonHotColor = value; 
					OnStyleChanged("EditButtonHotColor",value);
				}
			}
		}

		[Category("EditButtons")]
		public Color EditButtonPressedColor
		{
			get{ return m_EditButtonPressedColor; }

			set
			{ 
				if(m_EditButtonPressedColor != value)
				{
					m_EditButtonPressedColor = value; 
					OnStyleChanged("EditButtonPressedColor",value);
				}
			}
		}

		[Category("EditControls")]
		public Color EditColor
		{
			get{ return m_EditColor; }

			set
			{ 
				if(m_EditColor != value)
				{
					m_EditColor = value; 
					OnStyleChanged("EditColor",value);
				}
			}
		}

		[Category("EditControls")]
		public Color EditFocusedColor
		{
			get{ return m_EditFocusedColor; }

			set
			{ 
				if(m_EditFocusedColor != value)
				{
					m_EditFocusedColor = value; 
					OnStyleChanged("EditFocusedColor",value);
				}
			}
		}

		[Category("EditControls")]
		public Color EditReadOnlyColor
		{
			get{ return m_EditReadOnlyColor; }

			set
			{ 
				if(m_EditReadOnlyColor != value)
				{
					m_EditReadOnlyColor = value; 
					OnStyleChanged("EditReadOnlyColor",value);
				}
			}
		}

		[Category("EditControls")]
		public Color EditDisabledColor
		{
			get{ return m_EditDisabledColor; }

			set
			{ 
				if(m_EditDisabledColor != value)
				{
					m_EditDisabledColor = value; 
					OnStyleChanged("EditDisabledColor",value);
				}
			}
		}

		[Category("EditControls")]
		public Color TextColor
		{
			get{ return m_TextColor; }

			set
			{
				if(m_TextColor != value)
				{
					m_TextColor = value;
					OnStyleChanged("TextColor",value);
				}
			}
		}

		[Category("EditControls")]
		public Color DisabledTextColor
		{
			get{ return m_DisabledTextColor; }

			set
			{
				if(m_DisabledTextColor != value)
				{
					m_TextColor = value;
					OnStyleChanged("DisabledTextColor",value);
				}
			}
		}

		[Category("OptionButton, CheckBox, RadioButton")]
		public Color CheckColor
		{
			get{return m_CheckColor;}
			set
			{
				m_CheckColor = value;
				OnStyleChanged("CheckColor",value);

			}
		}

		[Category("CheckBox")]
		public Color CheckBoxColor
		{
			get{return m_CheckBoxColor;}
			set
			{
				m_CheckBoxColor = value;
				OnStyleChanged("CheckBoxColor",value);

			}
		}

		[Category("RadioButtonColor")]
		public Color RadioButtonColor
		{
			get{return m_RadioButtonColor;}
			set
			{
				m_RadioButtonColor = value;
				OnStyleChanged("RadioButtonColor",value);

			}
		}

		[Category("Calendar")]
		public Color CalendarTitleBackColor
		{
			get{return m_CalendarTitleBackColor;}
			set
			{
				m_CalendarTitleBackColor = value;
				OnStyleChanged("CalendarTitleBackColor",value);
			}
		}

		[Category("Calendar")]
		public Color CalendarTitleForeColor
		{
			get{return m_CalendarTitleForeColor;}
			set
			{
				m_CalendarTitleForeColor = value;
				OnStyleChanged("CalendarTitleForeColor",value);
			}
		}

		[Category("Calendar")]
		public Color CalendarTrailingForeColor
		{
			get{return m_CalendarTrailingForeColor;}
			set
			{
				m_CalendarTrailingForeColor = value;
				OnStyleChanged("CalendarTrailingForeColor",value);
			}
		}

		[Category("Calendar")]
		public Color CalendarBackColor
		{
			get{return m_CalendarBackColor;}
			set
			{
				m_CalendarBackColor = value;
				OnStyleChanged("CalendarBackColor",value);
			}
		}

		[Category("Calendar")]
		public Color CalendarForeColor
		{
			get{return m_CalendarForeColor;}
			set
			{
				m_CalendarForeColor = value;
				OnStyleChanged("CalendarForeColor",value);
			}
		}

		[Category("EditControls")]
		public Color NegativeNumberColor
		{
			get{return m_NegativeNumberColor;}
			set
			{
				m_NegativeNumberColor = value;
				OnStyleChanged("NegativeNumberColor",value);
			}
		}

		[Category("Label")]
		public Color LabelColor
		{
			get{return m_LabelColor;}
			set
			{
				m_LabelColor = value;
				OnStyleChanged("LabelColor",value);
			}
		}

		[Category("Panel")]
		public Color PanelLeftOptionsColor
		{
			get{return m_LeftPanelColor;}
			set
			{
				m_LeftPanelColor = value;
				OnStyleChanged("PanelLeftOptionsColor",value);
			}
		}

		[Category("Panel")]
		public Color PanelTopOptionsColor
		{
			get{return m_TopPanelColor;}
			set
			{
				m_TopPanelColor = value;
				OnStyleChanged("PanelTopOptionsColor",value);
			}
		}

		[Category("Panel")]
		public Color PanelBottomAreaColor
		{
			get{return m_BottomPanelColor;}
			set
			{
				m_BottomPanelColor = value;
				OnStyleChanged("PanelBottomAreaColor",value);
			}
		}

		[Category("Panel")]
		public Color PanelClientAreaColor
		{
			get{return m_ClientPanelColor;}
			set
			{
				m_ClientPanelColor = value;
				OnStyleChanged("PanelClientAreaColor",value);
			}
		}

		[Category("Panel")]
		public Color PanelAssLeftTitleColor
		{
			get{return m_PanelAssLeftTitleColor;}
			set
			{
				m_PanelAssLeftTitleColor = value;
				OnStyleChanged("PanelAssLeftTitleColor",value);
			}
		}

		[Category("Panel")]
		public Color PanelAssRightTitleColor
		{
			get{return m_PanelAssRightTitleColor;}
			set
			{
				m_PanelAssRightTitleColor = value;
				OnStyleChanged("PanelAssRightTitleColor",value);
			}
		}

		[Category("Panel")]
		public Color PanelAssLeftOptionsColor
		{
			get{return m_PanelAssLeftOptionsColor;}
			set
			{
				m_PanelAssLeftOptionsColor = value;
				OnStyleChanged("PanelAssLeftOptionsColor",value);
			}
		}

		[Category("Panel")]
		public Color PanelAssClientAreaColor
		{
			get{return m_PanelAssClientAreaColor;}
			set
			{
				m_PanelAssClientAreaColor = value;
				OnStyleChanged("PanelAssClientAreaColor",value);
			}
		}

		[Category("Panel")]
		public Color PanelAssBottomAreaColor
		{
			get{return m_PanelAssBottomAreaColor;}
			set
			{
				m_PanelAssBottomAreaColor = value;
				OnStyleChanged("PanelAssBottomAreaColor",value);
			}
		}

		[Category("CollapsiblePanel")]
		public Color CollapsiblePanelBarBackColor
		{
			get{return m_CollapsiblePanelBarBackColor;}
			set
			{
				m_CollapsiblePanelBarBackColor = value;
				OnStyleChanged("CollapsiblePanelBarBackColor",value);
			}
		}

		[Category("CollapsiblePanel")]
		public Color CollapsiblePanelBackColor
		{
			get{return m_CollapsiblePanelBackColor;}
			set
			{
				m_CollapsiblePanelBackColor = value;
				OnStyleChanged("CollapsiblePanelBackColor",value);
			}
		}

		[Category("CollapsiblePanel")]
		public Color CollapsiblePanelStartColor
		{
			get{return m_CollapsiblePanelStartColor;}
			set
			{
				m_CollapsiblePanelStartColor = value;
				OnStyleChanged("CollapsiblePanelStartColor",value);
			}
		}

		[Category("CollapsiblePanel")]
		public Color CollapsiblePanelEndColor
		{
			get{return m_CollapsiblePanelEndColor;}
			set
			{
				m_CollapsiblePanelEndColor = value;
				OnStyleChanged("CollapsiblePanelEndColor",value);
			}
		}

		[Category("CollapsiblePanel")]
		public Color CollapsiblePanelTitleFontColor
		{
			get{return m_CollapsiblePanelTitleFontColor;}
			set
			{
				m_CollapsiblePanelTitleFontColor = value;
				OnStyleChanged("CollapsiblePanelTitleFontColor",value);
			}
		}

		[Category("CollapsiblePanel")]
		public Color CollapsiblePanelLineStartColor
		{
			get{return m_CollapsiblePanelLineStartColor;}
			set
			{
				m_CollapsiblePanelLineStartColor = value;
				OnStyleChanged("CollapsiblePanelLineStartColor",value);
			}
		}

		[Category("CollapsiblePanel")]
		public Color CollapsiblePanelLineEndColor
		{
			get{return m_CollapsiblePanelLineEndColor;}
			set
			{
				m_CollapsiblePanelLineEndColor = value;
				OnStyleChanged("CollapsiblePanelLineEndColor",value);
			}
		}

		[Category("CollapsiblePanel")]
		public Color CollapsiblePanelLinkColor
		{
			get{return m_CollapsiblePanelLinkColor;}
			set
			{
				m_CollapsiblePanelLinkColor = value;
				OnStyleChanged("CollapsiblePanelLinkColor",value);
			}
		}

		[Category("PanelItem")]
		public Color PanelItemBackColor
		{
			get{return m_PanelItemBackColor;}
			set
			{
				m_PanelItemBackColor = value;
				OnStyleChanged("PanelItemBackColor",value);
			}
		}

		[Category("PanelItem")]
		public Color PanelItemAssBackColor
		{
			get{return m_PanelItemAssBackColor;}
			set
			{
				m_PanelItemAssBackColor = value;
				OnStyleChanged("PanelItemAssBackColor",value);
			}
		}

		[Category("PanelItem")]
		public Color PanelItemForeColor
		{
			get{return m_PanelItemForeColor;}
			set
			{
				m_PanelItemForeColor = value;
				OnStyleChanged("PanelItemForeColor",value);
			}
		}

		[Category("PanelItem")]
		public Color PanelItemFlashColor
		{
			get{return m_PanelItemFlashColor;}
			set
			{
				m_PanelItemFlashColor = value;
				OnStyleChanged("PanelItemFlashColor",value);
			}
		}

		[Category("TabControl")]
		public Color TabControlBackColor
		{
			get{return m_TabControlBackColor;}
			set
			{
				m_TabControlBackColor = value;
				OnStyleChanged("TabControlBackColor",value);
			}
		}
		
		[Category("Docking")]
		public Color DockingBackColor
		{
			get{return m_DockingBackColor;}
			set
			{
				m_DockingBackColor = value;
				OnStyleChanged("DockingBackColor",value);
			}
		}

		[Category("Docking")]
		public Color DockingResizeBarColor
		{
			get{return m_DockingResizeBarColor;}
			set
			{
				m_DockingResizeBarColor = value;
				OnStyleChanged("DockingResizeBarColor",value);
			}
		}

		[Category("Docking")]
		public Color DockingActiveTextColor
		{
			get{return m_DockingActiveTextColor;}
			set
			{
				m_DockingActiveTextColor = value;
				OnStyleChanged("DockingActiveTextColor",value);
			}
		}

		[Category("Docking")]
		public Color DockingActiveColor
		{
			get{return m_DockingActiveColor;}
			set
			{
				m_DockingActiveColor = value;
				OnStyleChanged("DockingActiveColor",value);
			}
		}

		[Category("Docking")]
		public Color DockingInactiveTextColor
		{
			get{return m_DockingInactiveTextColor;}
			set
			{
				m_DockingInactiveTextColor = value;
				OnStyleChanged("DockingInactiveTextColor",value);
			}
		}

		[Category("DataGrid")]
		public Color DataGridAlternatingBackColor
		{
			get{return m_DataGridAlternatingBackColor;}
			set
			{
				m_DataGridAlternatingBackColor = value;
				OnStyleChanged("DataGridAlternatingBackColor",value);
			}
		}

		[Category("DataGrid")]
		public Color DataGridBackColor
		{
			get{return m_DataGridBackColor;}
			set
			{
				m_DataGridBackColor = value;
				OnStyleChanged("DataGridBackColor",value);
			}
		}

		[Category("DataGrid")]
		public Color DataGridBackgroundColor
		{
			get{return m_DataGridBackgroundColor;}
			set
			{
				m_DataGridBackgroundColor = value;
				OnStyleChanged("DataGridBackgroundColor",value);
			}
		}

		[Category("DataGrid")]
		public Color DataGridCaptionBackColor
		{
			get{return m_DataGridCaptionBackColor;}
			set
			{
				m_DataGridCaptionBackColor = value;
				OnStyleChanged("DataGridCaptionBackColor",value);
			}
		}

		[Category("DataGrid")]
		public Color DataGridCaptionForeColor
		{
			get{return m_DataGridCaptionForeColor;}
			set
			{
				m_DataGridCaptionForeColor = value;
				OnStyleChanged("DataGridCaptionForeColor",value);
			}
		}

		[Category("DataGrid")]
		public Color DataGridForeColor
		{
			get{return m_DataGridForeColor;}
			set
			{
				m_DataGridForeColor = value;
				OnStyleChanged("DataGridForeColor",value);
			}
		}

		[Category("DataGrid")]
		public Color DataGridLineColor
		{
			get{return m_DataGridLineColor;}
			set
			{
				m_DataGridLineColor = value;
				OnStyleChanged("DataGridLineColor",value);
			}
		}

		[Category("DataGrid")]
		public Color DataGridHeaderBackColor
		{
			get{return m_DataGridHeaderBackColor;}
			set
			{
				m_DataGridHeaderBackColor = value;
				OnStyleChanged("DataGridHeaderBackColor",value);
			}
		}

		[Category("DataGrid")]
		public Color DataGridHeaderForeColor
		{
			get{return m_DataGridHeaderForeColor;}
			set
			{
				m_DataGridHeaderForeColor = value;
				OnStyleChanged("DataGridHeaderForeColor",value);
			}
		}

		[Category("DataGrid")]
		public Color DataGridLinkColor
		{
			get{return m_DataGridLinkColor;}
			set
			{
				m_DataGridLinkColor = value;
				OnStyleChanged("DataGridLinkColor",value);
			}
		}

		[Category("DataGrid")]
		public Color DataGridParentRowsBackColor
		{
			get{return m_DataGridParentRowsBackColor;}
			set
			{
				m_DataGridParentRowsBackColor = value;
				OnStyleChanged("DataGridParentRowsBackColor",value);
			}
		}

		[Category("DataGrid")]
		public Color DataGridParentRowsForeColor
		{
			get{return m_DataGridParentRowsForeColor;}
			set
			{
				m_DataGridParentRowsForeColor = value;
				OnStyleChanged("DataGridParentRowsForeColor",value);
			}
		}

		[Category("DataGrid")]
		public Color DataGridSelectionBackColor
		{
			get{return m_DataGridSelectionBackColor;}
			set
			{
				m_DataGridSelectionBackColor = value;
				OnStyleChanged("DataGridSelectionBackColor",value);
			}
		}

		[Category("DataGrid")]
		public Color DataGridSelectionForeColor
		{
			get{return m_DataGridSelectionForeColor;}
			set
			{
				m_DataGridSelectionForeColor = value;
				OnStyleChanged("DataGridSelectionForeColor",value);
			}
		}

		[Category("Infinite progress bar")]
		public Color InfiniteProgressStartColor
		{
			get{return m_InfiniteProgressStartColor;}
			set
			{
				m_InfiniteProgressStartColor = value;
				OnStyleChanged("InfiniteProgressStartColor",value);
			}
		}

		[Category("Infinite progress bar")]
		public Color InfiniteProgressEndColor
		{
			get{return m_InfiniteProgressEndColor;}
			set
			{
				m_InfiniteProgressEndColor = value;
				OnStyleChanged("InfiniteProgressEndColor",value);
			}
		}

		[Category("TaskPanelBar")]
		public Color TaskPanelBarBackColor
		{
			get{return m_TaskPanelBarBackColor;}
			set
			{
				m_TaskPanelBarBackColor = value;
				OnStyleChanged("TaskPanelBarBackColor",value);
			}
		}

		[Category("TaskPanel")]
		public Color TaskPanelBackColor
		{
			get{return m_TaskPanelBackColor;}
			set
			{
				m_TaskPanelBackColor = value;
				OnStyleChanged("TaskPanelBackColor",value);
			}
		}

		[Category("TaskPanel")]
		public Color TaskPanelTitleBackColor
		{
			get{return m_TaskPanelTitleBackColor;}
			set
			{
				m_TaskPanelTitleBackColor = value;
				OnStyleChanged("TaskPanelTitleBackColor",value);
			}
		}

		[Category("TaskPanel")]
		public Color TaskPanelTitleForeColor
		{
			get{return m_TaskPanelTitleForeColor;}
			set
			{
				m_TaskPanelTitleForeColor = value;
				OnStyleChanged("TaskPanelTitleForeColor",value);
			}
		}

		[Category("MenuListBox")]
		public Color SelectionColor
		{
			get{return m_SelectionColor;}
			set
			{
				m_SelectionColor = value;
				OnStyleChanged("SelectionColor",value);
			}
		}

		#endregion		

		// 2002-08-07 - GWO - Added to retrieve assembly information for the serialization/deserialization process.
		#region Serialization/Deserialization

		public void Save(string filename)
		{

			//PallaControls.Utilities.Security.SymmetricEncryption sec = new PallaControls.Utilities.Security.SymmetricEncryption(PallaControls.Utilities.Security.SymmetricEncryption.PallaControlsSymmetricSecretKey);
			FileStream fs = new FileStream(filename, FileMode.Create);
			MemoryStream m = new MemoryStream();

			SaveToMemoryStream(m);
			//MemoryStream m2 = sec.EncryptStream(m);
			
			//fs.Write(m2.GetBuffer(), 0, m2.GetBuffer().Length);
			fs.Write(m.GetBuffer(), 0, m.GetBuffer().Length);
			fs.Flush();
			fs.Close();
			m.Close();
			//m2.Close();
		}
		
		public void Load(string filename)
		{
			FileStream fs = new FileStream(filename, FileMode.Open);
			Byte[] b = new Byte[fs.Length];
			try
			{
				fs.Read(b, 0, (int)fs.Length);
				MemoryStream m = new MemoryStream(b);
				//PallaControls.Utilities.Security.SymmetricEncryption sec = new PallaControls.Utilities.Security.SymmetricEncryption(PallaControls.Utilities.Security.SymmetricEncryption.PallaControlsSymmetricSecretKey);
				//LoadFromMemoryStream(sec.DecryptStream(m));
				LoadFromMemoryStream(m);
				m.Close();
			}
			finally
			{
				fs.Close();
			}
		}
		
		private void SaveToMemoryStream(MemoryStream m) 
		{
			// Create a hashtable of values that will eventually be serialized.
			AssemblyName assemblyname	= Assembly.GetExecutingAssembly().GetName();
			string version				= string.Format("{0}.{1}.{2}", assemblyname.Version.Major.ToString(), assemblyname.Version.Minor.ToString(), assemblyname.Version.Build.ToString());
			Hashtable hash			 	= new Hashtable();

			hash.Add("Version",	version);
			hash.Add("Product",	Assembly.GetExecutingAssembly().GetName().FullName);
			hash.Add("PictureBoxColor",	this.m_PictureBoxColor.ToArgb());													
			hash.Add("BorderColor",	this.m_BorderColor.ToArgb());														
			hash.Add("BorderHotColor", this.m_BorderHotColor.ToArgb());													
			hash.Add("ButtonColor",	this.m_ButtonColor.ToArgb());													
			hash.Add("ButtonHotColor", this.m_ButtonHotColor.ToArgb());												
			hash.Add("ButtonPressedColor", this.m_ButtonPressedColor.ToArgb());								
			hash.Add("ButtonBorderColor", this.m_ButtonBorderColor.ToArgb());												
			hash.Add("ButtonBorderHotColor", this.m_ButtonBorderHotColor.ToArgb());										
			hash.Add("ButtonTextColor", this.m_ButtonTextColor.ToArgb());													
			hash.Add("ButtonFlashColor", this.m_ButtonFlashColor.ToArgb());												
			hash.Add("EditButtonColor", this.m_EditButtonColor.ToArgb());													
			hash.Add("EditButtonHotColor", this.m_EditButtonHotColor.ToArgb());											
			hash.Add("EditButtonPressedColor", this.m_EditButtonPressedColor.ToArgb());									
			hash.Add("EditColor", this.m_EditColor.ToArgb());																
			hash.Add("EditFocusedColor", this.m_EditFocusedColor.ToArgb());												
			hash.Add("EditReadOnlyColor", this.m_EditReadOnlyColor.ToArgb());												
			hash.Add("EditDisabledColor", this.m_EditDisabledColor.ToArgb());											
			hash.Add("FlashColor", this.m_FlashColor.ToArgb());													
			hash.Add("TextColor", this.m_TextColor.ToArgb());				
			hash.Add("NegativeNumberColor", this.m_NegativeNumberColor.ToArgb());						
			hash.Add("CheckColor", this.m_CheckColor.ToArgb());
			hash.Add("CheckBoxColor", this.m_CheckBoxColor.ToArgb());				
			hash.Add("RadioButtonColor", this.m_RadioButtonColor.ToArgb());												
			hash.Add("CalendarTitleBackColor", this.m_CalendarTitleBackColor.ToArgb());									
			hash.Add("CalendarTitleForeColor", this.m_CalendarTitleForeColor.ToArgb());									
			hash.Add("CalendarTrailingForeColor", this.m_CalendarTrailingForeColor.ToArgb());								
			hash.Add("CalendarBackColor", this.m_CalendarBackColor.ToArgb());												
			hash.Add("CalendarForeColor", this.m_CalendarForeColor.ToArgb());												
			hash.Add("LabelColor", this.m_LabelColor.ToArgb());															
			hash.Add("LeftPanelColor", this.m_LeftPanelColor.ToArgb());													
			hash.Add("TopPanelColor", this.m_TopPanelColor.ToArgb());														
			hash.Add("BottomPanelColor", this.m_BottomPanelColor.ToArgb());												
			hash.Add("ClientPanelColor", this.m_ClientPanelColor.ToArgb());												
			hash.Add("PanelAssLeftTitleColor", this.m_PanelAssLeftTitleColor.ToArgb());									
			hash.Add("PanelAssRightTitleColor", this.m_PanelAssRightTitleColor.ToArgb());									
			hash.Add("PanelAssLeftOptionsColor", this.m_PanelAssLeftOptionsColor.ToArgb());								
			hash.Add("PanelAssClientAreaColor", this.m_PanelAssClientAreaColor.ToArgb());									
			hash.Add("PanelAssBottomAreaColor", this.m_PanelAssBottomAreaColor.ToArgb());									
			hash.Add("CollapsiblePanelBarBackColor", this.m_CollapsiblePanelBarBackColor.ToArgb());						
			hash.Add("CollapsiblePanelBackColor", this.m_CollapsiblePanelBackColor.ToArgb());								
			hash.Add("CollapsiblePanelStartColor", this.m_CollapsiblePanelStartColor.ToArgb());							
			hash.Add("CollapsiblePanelEndColor", this.m_CollapsiblePanelEndColor.ToArgb());								
			hash.Add("CollapsiblePanelTitleFontColor", this.m_CollapsiblePanelTitleFontColor.ToArgb());					
			hash.Add("CollapsiblePanelLineStartColor", this.m_CollapsiblePanelLineStartColor.ToArgb());					
			hash.Add("CollapsiblePanelLineEndColor", this.m_CollapsiblePanelLineEndColor.ToArgb());						
			hash.Add("CollapsiblePanelLinkColor", this.m_CollapsiblePanelLinkColor.ToArgb());								
			hash.Add("PanelItemBackColor", this.m_PanelItemBackColor.ToArgb());											
			hash.Add("PanelItemAssBackColor", this.m_PanelItemAssBackColor.ToArgb());										
			hash.Add("PanelItemForeColor", this.m_PanelItemForeColor.ToArgb());											
			hash.Add("PanelItemFlashColor", this.m_PanelItemFlashColor.ToArgb());											
			hash.Add("TabControlBackColor", this.m_TabControlBackColor.ToArgb());											
			hash.Add("DockingBackColor", this.m_DockingBackColor.ToArgb());												
			hash.Add("DockingResizeBarColor", this.m_DockingResizeBarColor.ToArgb());										
			hash.Add("DockingActiveTextColor", this.m_DockingActiveTextColor.ToArgb());								
			hash.Add("DockingActiveColor", this.m_DockingActiveColor.ToArgb());										
			hash.Add("DockingInactiveTextColor", this.m_DockingInactiveTextColor.ToArgb());
			hash.Add("DataGridAlternatingBackColor", this.m_DataGridAlternatingBackColor.ToArgb());						
			hash.Add("DataGridBackColor", this.m_DataGridBackColor.ToArgb());												
			hash.Add("DataGridBackgroundColor", this.m_DataGridBackgroundColor.ToArgb());									
			hash.Add("DataGridCaptionBackColor", this.m_DataGridCaptionBackColor.ToArgb());								
			hash.Add("DataGridCaptionForeColor", this.m_DataGridCaptionForeColor.ToArgb());								
			hash.Add("DataGridForeColor", this.m_DataGridForeColor.ToArgb());												
			hash.Add("DataGridLineColor", this.m_DataGridLineColor.ToArgb());												
			hash.Add("DataGridHeaderBackColor", this.m_DataGridHeaderBackColor.ToArgb());									
			hash.Add("DataGridHeaderForeColor", this.m_DataGridHeaderForeColor.ToArgb());									
			hash.Add("DataGridLinkColor", this.m_DataGridLinkColor.ToArgb());												
			hash.Add("DataGridParentRowsBackColor", this.m_DataGridParentRowsBackColor.ToArgb());							
			hash.Add("DataGridParentRowsForeColor", this.m_DataGridParentRowsForeColor.ToArgb());							
			hash.Add("DataGridSelectionBackColor", this.m_DataGridSelectionBackColor.ToArgb());							
			hash.Add("DataGridSelectionForeColor", this.m_DataGridSelectionForeColor.ToArgb());							
			hash.Add("InfiniteProgressStartColor", this.m_InfiniteProgressStartColor.ToArgb());							
			hash.Add("InfiniteProgressEndColor", this.m_InfiniteProgressEndColor.ToArgb());								
			hash.Add("TaskPanelBarBackColor", this.m_TaskPanelBarBackColor.ToArgb());										
			hash.Add("TaskPanelBackColor", this.m_TaskPanelBackColor.ToArgb());											
			hash.Add("TaskPanelTitleBackColor", this.m_TaskPanelTitleBackColor.ToArgb());									
			hash.Add("TaskPanelTitleForeColor", this.m_TaskPanelTitleForeColor.ToArgb());									
			hash.Add("SelectionColor", this.m_SelectionColor.ToArgb());
			hash.Add("DisabledTextColor", this.m_DisabledTextColor.ToArgb());

			//Construct a BinaryFormatter and use it to serialize the data to the stream.
			BinaryFormatter formatter = new BinaryFormatter();
			try 
			{
				formatter.Serialize(m, hash);
			}
			catch (SerializationException e) 
			{
				throw new Exception(e.Message);
			}
		}

		private void LoadFromMemoryStream(MemoryStream m) 
		{
			Hashtable hash  = null;
			try 
			{
				BinaryFormatter formatter = new BinaryFormatter();
				hash = (Hashtable) formatter.Deserialize(m);
			}
			catch (SerializationException e) 
			{
				throw new Exception("Failed to deserialze: " + e.Message);
			}

			string	thisproduct	= Assembly.GetExecutingAssembly().GetName().FullName;
			Version thisversion	= Assembly.GetExecutingAssembly().GetName().Version;
			string	fileproduct	= hash["Product"].ToString();
			string	fileversion	= hash["Version"].ToString(); 

			if (thisproduct != fileproduct)
			{
				throw new Exception("Incorrect product.");
			}

			//Check for current versions.
			string[] asVersion = fileversion.Split(new char[] {'.'});
			if (asVersion.Length != 3)
			{
				//Something is wrong with the version. Doesn't seem to have 3 parts.
				throw new Exception("Incorrect version format.");
			}

			Version version = new Version(int.Parse(asVersion[0]), int.Parse(asVersion[1]), int.Parse(asVersion[2]));
			if (thisversion.Major == version.Major && thisversion.Minor == version.Minor && thisversion.Build == version.Build)
			{
				// Current version. From hash to variables...
				this.m_PictureBoxColor = Color.FromArgb((int)hash["PictureBoxColor"]);																	
				this.m_BorderColor = Color.FromArgb((int)hash["BorderColor"]);																		
				this.m_BorderHotColor = Color.FromArgb((int)hash["BorderHotColor"]);																	
				this.m_ButtonColor = Color.FromArgb((int)hash["ButtonColor"]);																	
				this.m_ButtonHotColor = Color.FromArgb((int)hash["ButtonHotColor"]);																
				this.m_ButtonPressedColor = Color.FromArgb((int)hash["ButtonPressedColor"]);												
				this.m_ButtonBorderColor = Color.FromArgb((int)hash["ButtonBorderColor"]);																
				this.m_ButtonBorderHotColor = Color.FromArgb((int)hash["ButtonBorderHotColor"]);														
				this.m_ButtonTextColor = Color.FromArgb((int)hash["ButtonTextColor"]);																	
				this.m_ButtonFlashColor = Color.FromArgb((int)hash["ButtonFlashColor"]);																
				this.m_EditButtonColor = Color.FromArgb((int)hash["EditButtonColor"]);																	
				this.m_EditButtonHotColor = Color.FromArgb((int)hash["EditButtonHotColor"]);															
				this.m_EditButtonPressedColor = Color.FromArgb((int)hash["EditButtonPressedColor"]);													
				this.m_EditColor = Color.FromArgb((int)hash["EditColor"]);																				
				this.m_EditFocusedColor = Color.FromArgb((int)hash["EditFocusedColor"]);																
				this.m_EditReadOnlyColor = Color.FromArgb((int)hash["EditReadOnlyColor"]);																
				this.m_EditDisabledColor = Color.FromArgb((int)hash["EditDisabledColor"]);															
				this.m_FlashColor = Color.FromArgb((int)hash["FlashColor"]);																	
				this.m_TextColor = Color.FromArgb((int)hash["TextColor"]);													
				this.m_NegativeNumberColor = Color.FromArgb((int)hash["NegativeNumberColor"]);										
				this.m_CheckColor = Color.FromArgb((int)hash["CheckColor"]);												
				this.m_CheckBoxColor = Color.FromArgb((int)hash["CheckBoxColor"]);											
				this.m_RadioButtonColor = Color.FromArgb((int)hash["RadioButtonColor"]);																
				this.m_CalendarTitleBackColor = Color.FromArgb((int)hash["CalendarTitleBackColor"]);													
				this.m_CalendarTitleForeColor = Color.FromArgb((int)hash["CalendarTitleForeColor"]);													
				this.m_CalendarTrailingForeColor = Color.FromArgb((int)hash["CalendarTrailingForeColor"]);												
				this.m_CalendarBackColor = Color.FromArgb((int)hash["CalendarBackColor"]);																
				this.m_CalendarForeColor = Color.FromArgb((int)hash["CalendarForeColor"]);																
				this.m_LabelColor = Color.FromArgb((int)hash["LabelColor"]);																			
				this.m_LeftPanelColor = Color.FromArgb((int)hash["LeftPanelColor"]);																	
				this.m_TopPanelColor = Color.FromArgb((int)hash["TopPanelColor"]);																		
				this.m_BottomPanelColor = Color.FromArgb((int)hash["BottomPanelColor"]);																
				this.m_ClientPanelColor = Color.FromArgb((int)hash["ClientPanelColor"]);																
				this.m_PanelAssLeftTitleColor = Color.FromArgb((int)hash["PanelAssLeftTitleColor"]);													
				this.m_PanelAssRightTitleColor = Color.FromArgb((int)hash["PanelAssRightTitleColor"]);													
				this.m_PanelAssLeftOptionsColor = Color.FromArgb((int)hash["PanelAssLeftOptionsColor"]);												
				this.m_PanelAssClientAreaColor = Color.FromArgb((int)hash["PanelAssClientAreaColor"]);													
				this.m_PanelAssBottomAreaColor = Color.FromArgb((int)hash["PanelAssBottomAreaColor"]);													
				this.m_CollapsiblePanelBarBackColor = Color.FromArgb((int)hash["CollapsiblePanelBarBackColor"]);						
				this.m_CollapsiblePanelBackColor = Color.FromArgb((int)hash["CollapsiblePanelBackColor"]);												
				this.m_CollapsiblePanelStartColor = Color.FromArgb((int)hash["CollapsiblePanelStartColor"]);											
				this.m_CollapsiblePanelEndColor = Color.FromArgb((int)hash["CollapsiblePanelEndColor"]);												
				this.m_CollapsiblePanelTitleFontColor = Color.FromArgb((int)hash["CollapsiblePanelTitleFontColor"]);				
				this.m_CollapsiblePanelLineStartColor = Color.FromArgb((int)hash["CollapsiblePanelLineStartColor"]);				
				this.m_CollapsiblePanelLineEndColor = Color.FromArgb((int)hash["CollapsiblePanelLineEndColor"]);					
				this.m_CollapsiblePanelLinkColor = Color.FromArgb((int)hash["CollapsiblePanelLinkColor"]);												
				this.m_PanelItemBackColor = Color.FromArgb((int)hash["PanelItemBackColor"]);															
				this.m_PanelItemAssBackColor = Color.FromArgb((int)hash["PanelItemAssBackColor"]);														
				this.m_PanelItemForeColor = Color.FromArgb((int)hash["PanelItemForeColor"]);															
				this.m_PanelItemFlashColor = Color.FromArgb((int)hash["PanelItemFlashColor"]);															
				this.m_TabControlBackColor = Color.FromArgb((int)hash["TabControlBackColor"]);															
				this.m_DockingBackColor = Color.FromArgb((int)hash["DockingBackColor"]);																
				this.m_DockingResizeBarColor = Color.FromArgb((int)hash["DockingResizeBarColor"]);														
				this.m_DockingActiveTextColor = Color.FromArgb((int)hash["DockingActiveTextColor"]);												
				this.m_DockingActiveColor = Color.FromArgb((int)hash["DockingActiveColor"]);														
				this.m_DockingInactiveTextColor = Color.FromArgb((int)hash["DockingInactiveTextColor"]);					
				this.m_DataGridAlternatingBackColor = Color.FromArgb((int)hash["DataGridAlternatingBackColor"]);								
				this.m_DataGridBackColor =	Color.FromArgb((int)hash["DataGridBackColor"]);																
				this.m_DataGridBackgroundColor = Color.FromArgb((int)hash["DataGridBackgroundColor"]);													
				this.m_DataGridCaptionBackColor = Color.FromArgb((int)hash["DataGridCaptionBackColor"]);												
				this.m_DataGridCaptionForeColor = Color.FromArgb((int)hash["DataGridCaptionForeColor"]);												
				this.m_DataGridForeColor = Color.FromArgb((int)hash["DataGridForeColor"]);																
				this.m_DataGridLineColor = Color.FromArgb((int)hash["DataGridLineColor"]);																
				this.m_DataGridHeaderBackColor = Color.FromArgb((int)hash["DataGridHeaderBackColor"]);													
				this.m_DataGridHeaderForeColor = Color.FromArgb((int)hash["DataGridHeaderForeColor"]);													
				this.m_DataGridLinkColor = Color.FromArgb((int)hash["DataGridLinkColor"]);																
				this.m_DataGridParentRowsBackColor = Color.FromArgb((int)hash["DataGridParentRowsBackColor"]);									
				this.m_DataGridParentRowsForeColor = Color.FromArgb((int)hash["DataGridParentRowsForeColor"]);								
				this.m_DataGridSelectionBackColor = Color.FromArgb((int)hash["DataGridSelectionBackColor"]);											
				this.m_DataGridSelectionForeColor = Color.FromArgb((int)hash["DataGridSelectionForeColor"]);											
				this.m_InfiniteProgressStartColor = Color.FromArgb((int)hash["InfiniteProgressStartColor"]);											
				this.m_InfiniteProgressEndColor = Color.FromArgb((int)hash["InfiniteProgressEndColor"]);												
				this.m_TaskPanelBarBackColor = Color.FromArgb((int)hash["TaskPanelBarBackColor"]);														
				this.m_TaskPanelBackColor = Color.FromArgb((int)hash["TaskPanelBackColor"]);
				this.m_TaskPanelTitleBackColor = Color.FromArgb((int)hash["TaskPanelTitleBackColor"]);
				this.m_TaskPanelTitleForeColor = Color.FromArgb((int)hash["TaskPanelTitleForeColor"]);
				this.m_SelectionColor = Color.FromArgb((int)hash["SelectionColor"]);
				this.m_DisabledTextColor = Color.FromArgb((int)hash["DisabledTextColor"]);

				PlansOfColors = PlansColors.CustomGoodLuckman;
			}
			else
			{
				// Code here to support other formats.
			}
		}

		#endregion
	}
}
