using System;
using System.Collections;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.Drawing;
using System.Data;
using System.Windows.Forms;
using System.Runtime.Serialization;
using PallaControls.Utilities;
using PallaControls.Resources;
using PallaControls.Resources.Keys;
using PallaControls.Utilities.Win32;
using PallaControls.Windows.Forms.Helpers;

namespace PallaControls.Windows.Forms
{
	#region ComboBox

	[DefaultEvent("SelectedIndexChanged"),
	 System.ComponentModel.ToolboxItem(true)]
	public class ComboBox : ButtonEdit
	{
		#region ComboAutoFillManager
	
		private class ComboAutoFillManager
		{
			private ComboBox m_Combo = null;

			#region Constructors
			
			public ComboAutoFillManager(ComboBox combo)
			{
				m_Combo = combo;
				if (!m_Combo.DesignMode)
				{
					if (m_Combo.AutoFill == ComboAutoFill.States) this.FillStates();
					else if (m_Combo.AutoFill == ComboAutoFill.CivilStatus) this.FillCivilStatus();
					else if (m_Combo.AutoFill == ComboAutoFill.Sex) this.FillSex();
					else if (m_Combo.AutoFill == ComboAutoFill.Months) this.FillMonths();
				}
			}

			#endregion

			#region Methods
			
			private void FillStates()
			{
				if (CultureInfo.CurrentCulture.Name == "pt-BR")
				{
					((System.Windows.Forms.ListBox)m_Combo.InternalListBox).Items.Clear();
					((System.Windows.Forms.ListBox)m_Combo.InternalListBox).Items.Add("AC");
					((System.Windows.Forms.ListBox)m_Combo.InternalListBox).Items.Add("AL");
					((System.Windows.Forms.ListBox)m_Combo.InternalListBox).Items.Add("AP");
					((System.Windows.Forms.ListBox)m_Combo.InternalListBox).Items.Add("AM");
					((System.Windows.Forms.ListBox)m_Combo.InternalListBox).Items.Add("BA");
					((System.Windows.Forms.ListBox)m_Combo.InternalListBox).Items.Add("CE");
					((System.Windows.Forms.ListBox)m_Combo.InternalListBox).Items.Add("DF");
					((System.Windows.Forms.ListBox)m_Combo.InternalListBox).Items.Add("ES");
					((System.Windows.Forms.ListBox)m_Combo.InternalListBox).Items.Add("GO");
					((System.Windows.Forms.ListBox)m_Combo.InternalListBox).Items.Add("MA");
					((System.Windows.Forms.ListBox)m_Combo.InternalListBox).Items.Add("MT");
					((System.Windows.Forms.ListBox)m_Combo.InternalListBox).Items.Add("MS");
					((System.Windows.Forms.ListBox)m_Combo.InternalListBox).Items.Add("MG");
					((System.Windows.Forms.ListBox)m_Combo.InternalListBox).Items.Add("PA");
					((System.Windows.Forms.ListBox)m_Combo.InternalListBox).Items.Add("PB");
					((System.Windows.Forms.ListBox)m_Combo.InternalListBox).Items.Add("PR");
					((System.Windows.Forms.ListBox)m_Combo.InternalListBox).Items.Add("PE");
					((System.Windows.Forms.ListBox)m_Combo.InternalListBox).Items.Add("PI");
					((System.Windows.Forms.ListBox)m_Combo.InternalListBox).Items.Add("RJ");
					((System.Windows.Forms.ListBox)m_Combo.InternalListBox).Items.Add("RN");
					((System.Windows.Forms.ListBox)m_Combo.InternalListBox).Items.Add("RS");
					((System.Windows.Forms.ListBox)m_Combo.InternalListBox).Items.Add("RO");
					((System.Windows.Forms.ListBox)m_Combo.InternalListBox).Items.Add("RR");
					((System.Windows.Forms.ListBox)m_Combo.InternalListBox).Items.Add("SC");
					((System.Windows.Forms.ListBox)m_Combo.InternalListBox).Items.Add("SP");
					((System.Windows.Forms.ListBox)m_Combo.InternalListBox).Items.Add("SE");
					((System.Windows.Forms.ListBox)m_Combo.InternalListBox).Items.Add("TO");
				}
				else if (CultureInfo.CurrentCulture.Name == "es-DO")
				{
					((System.Windows.Forms.ListBox)m_Combo.InternalListBox).Items.Clear();
				}
				else
				{
					//TODO: NEW CULTURES...
					((System.Windows.Forms.ListBox)m_Combo.InternalListBox).Items.Clear();
				}
			}

			private void FillCivilStatus()
			{
				if (CultureInfo.CurrentCulture.Name == "pt-BR")
				{
					((System.Windows.Forms.ListBox)m_Combo.InternalListBox).Items.Clear();
					((System.Windows.Forms.ListBox)m_Combo.InternalListBox).Items.Add("Casado(a)");
					((System.Windows.Forms.ListBox)m_Combo.InternalListBox).Items.Add("Solteiro(a)");
					((System.Windows.Forms.ListBox)m_Combo.InternalListBox).Items.Add("Divorciado(a)");
					((System.Windows.Forms.ListBox)m_Combo.InternalListBox).Items.Add("Viuvo(a)");
				}
				else if (CultureInfo.CurrentCulture.Name == "es-DO")
				{
					((System.Windows.Forms.ListBox)m_Combo.InternalListBox).Items.Clear();
					((System.Windows.Forms.ListBox)m_Combo.InternalListBox).Items.Add("Se casado");
					((System.Windows.Forms.ListBox)m_Combo.InternalListBox).Items.Add("Solo");
					((System.Windows.Forms.ListBox)m_Combo.InternalListBox).Items.Add("Se divorciado");
					((System.Windows.Forms.ListBox)m_Combo.InternalListBox).Items.Add("El viudo");
				}
				else if (CultureInfo.CurrentCulture.TwoLetterISOLanguageName == "en")
				{
					((System.Windows.Forms.ListBox)m_Combo.InternalListBox).Items.Clear();
					((System.Windows.Forms.ListBox)m_Combo.InternalListBox).Items.Add("Married");
					((System.Windows.Forms.ListBox)m_Combo.InternalListBox).Items.Add("Single");
					((System.Windows.Forms.ListBox)m_Combo.InternalListBox).Items.Add("Divorced");
					((System.Windows.Forms.ListBox)m_Combo.InternalListBox).Items.Add("Widower");
				}
			}

			private void FillSex()
			{
				if (CultureInfo.CurrentCulture.Name == "pt-BR")
				{
					((System.Windows.Forms.ListBox)m_Combo.InternalListBox).Items.Clear();
					((System.Windows.Forms.ListBox)m_Combo.InternalListBox).Items.Add("Masculino");
					((System.Windows.Forms.ListBox)m_Combo.InternalListBox).Items.Add("Feminino");
				}
				else if (CultureInfo.CurrentCulture.Name == "es-DO")
				{
					((System.Windows.Forms.ListBox)m_Combo.InternalListBox).Items.Clear();
					((System.Windows.Forms.ListBox)m_Combo.InternalListBox).Items.Add("El masculino");
					((System.Windows.Forms.ListBox)m_Combo.InternalListBox).Items.Add("El femenino");
				}
				else if (CultureInfo.CurrentCulture.TwoLetterISOLanguageName == "en")
				{
					((System.Windows.Forms.ListBox)m_Combo.InternalListBox).Items.Clear();
					((System.Windows.Forms.ListBox)m_Combo.InternalListBox).Items.Add("Masculine");
					((System.Windows.Forms.ListBox)m_Combo.InternalListBox).Items.Add("Feminine");
				}
			}

			private void FillMonths()
			{
				if (CultureInfo.CurrentCulture.Name == "pt-BR")
				{
					((System.Windows.Forms.ListBox)m_Combo.InternalListBox).Items.Clear();
					((System.Windows.Forms.ListBox)m_Combo.InternalListBox).Items.Add("Janeiro");
					((System.Windows.Forms.ListBox)m_Combo.InternalListBox).Items.Add("Fevereiro");
					((System.Windows.Forms.ListBox)m_Combo.InternalListBox).Items.Add("Mar�o");
					((System.Windows.Forms.ListBox)m_Combo.InternalListBox).Items.Add("Abril");
					((System.Windows.Forms.ListBox)m_Combo.InternalListBox).Items.Add("Maio");
					((System.Windows.Forms.ListBox)m_Combo.InternalListBox).Items.Add("Junho");
					((System.Windows.Forms.ListBox)m_Combo.InternalListBox).Items.Add("Julho");
					((System.Windows.Forms.ListBox)m_Combo.InternalListBox).Items.Add("Agosto");
					((System.Windows.Forms.ListBox)m_Combo.InternalListBox).Items.Add("Setembro");
					((System.Windows.Forms.ListBox)m_Combo.InternalListBox).Items.Add("Outubro");
					((System.Windows.Forms.ListBox)m_Combo.InternalListBox).Items.Add("Novembro");
					((System.Windows.Forms.ListBox)m_Combo.InternalListBox).Items.Add("Dezembro");
				}
				else if (CultureInfo.CurrentCulture.Name == "es-DO")
				{
					((System.Windows.Forms.ListBox)m_Combo.InternalListBox).Items.Clear();
					((System.Windows.Forms.ListBox)m_Combo.InternalListBox).Items.Add("Enero");
					((System.Windows.Forms.ListBox)m_Combo.InternalListBox).Items.Add("Febrero");
					((System.Windows.Forms.ListBox)m_Combo.InternalListBox).Items.Add("Marzo");
					((System.Windows.Forms.ListBox)m_Combo.InternalListBox).Items.Add("Abril");
					((System.Windows.Forms.ListBox)m_Combo.InternalListBox).Items.Add("Mayo");
					((System.Windows.Forms.ListBox)m_Combo.InternalListBox).Items.Add("Junio");
					((System.Windows.Forms.ListBox)m_Combo.InternalListBox).Items.Add("Julio");
					((System.Windows.Forms.ListBox)m_Combo.InternalListBox).Items.Add("Agosto");
					((System.Windows.Forms.ListBox)m_Combo.InternalListBox).Items.Add("Septiembre");
					((System.Windows.Forms.ListBox)m_Combo.InternalListBox).Items.Add("Octubre");
					((System.Windows.Forms.ListBox)m_Combo.InternalListBox).Items.Add("Noviembre");
					((System.Windows.Forms.ListBox)m_Combo.InternalListBox).Items.Add("Diciembre");
				}
				else if (CultureInfo.CurrentCulture.TwoLetterISOLanguageName == "en")
				{
					((System.Windows.Forms.ListBox)m_Combo.InternalListBox).Items.Clear();
					((System.Windows.Forms.ListBox)m_Combo.InternalListBox).Items.Add("January");
					((System.Windows.Forms.ListBox)m_Combo.InternalListBox).Items.Add("February");
					((System.Windows.Forms.ListBox)m_Combo.InternalListBox).Items.Add("March");
					((System.Windows.Forms.ListBox)m_Combo.InternalListBox).Items.Add("April");
					((System.Windows.Forms.ListBox)m_Combo.InternalListBox).Items.Add("May");
					((System.Windows.Forms.ListBox)m_Combo.InternalListBox).Items.Add("June");
					((System.Windows.Forms.ListBox)m_Combo.InternalListBox).Items.Add("July");
					((System.Windows.Forms.ListBox)m_Combo.InternalListBox).Items.Add("August");
					((System.Windows.Forms.ListBox)m_Combo.InternalListBox).Items.Add("September");
					((System.Windows.Forms.ListBox)m_Combo.InternalListBox).Items.Add("October");
					((System.Windows.Forms.ListBox)m_Combo.InternalListBox).Items.Add("November");
					((System.Windows.Forms.ListBox)m_Combo.InternalListBox).Items.Add("December");
				}
			}

		#endregion
		}

		#endregion

		private System.ComponentModel.IContainer components = null;
		private Icon mButtonIcon = null;
		private int m_DropDownWidth;
		private int m_VisibleItems  = 10;
		private ComboPopUp  m_ComboPopUp = null;
		private ComboAutoFill m_AutoFill = ComboAutoFill.None;
		private System.Windows.Forms.ListBox internalListBox;
		private bool m_JustAcceptItems = false;

		[Category("Property changed")]
		public event EventHandler SelectedValueChanged = null;
		
		#region Constructors
		
		public ComboBox()
		{
			InitializeComponent();
			mpTextBox.LostFocus += new System.EventHandler(this.m_pTextBox_OnLostFocus);
			m_DropDownWidth = this.Width;
			mButtonIcon = GraphicsUtils.LoadIcon("down.ico");
		}

		#endregion

		#region Dispose

		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#endregion

		#region Component Designer generated code
		private void InitializeComponent()
		{
			this.internalListBox = new System.Windows.Forms.ListBox();
			this.SuspendLayout();
			// 
			// mpTextBox
			// 
			this.mpTextBox.Size = new System.Drawing.Size(130, 13);
			this.mpTextBox.ProccessMessage += new PallaControls.Windows.Forms.MessageEventHandler(this.m_pTextBox_ProccessMessage);
			// 
			// internalListBox
			// 
			this.internalListBox.Location = new System.Drawing.Point(72, 7);
			this.internalListBox.Name = "internalListBox";
			this.internalListBox.Size = new System.Drawing.Size(10, 4);
			this.internalListBox.TabIndex = 1;
			this.internalListBox.Visible = false;
			this.internalListBox.SelectedValueChanged += new System.EventHandler(this.internalListBox_SelectedValueChanged);
			this.internalListBox.SelectedIndexChanged += new System.EventHandler(this.internalListBox_SelectedIndexChanged);
			// 
			// ComboBox
			// 
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.mpTextBox,
																		  this.internalListBox});
			this.Name = "ComboBox";
			this.Size = new System.Drawing.Size(150, 19);
			this.Load += new System.EventHandler(this.ComboBox_Load);
			this.ResumeLayout(false);

		}
		#endregion

		#region Events handlers

		private void ComboBox_Load(object sender, System.EventArgs e)
		{
			ComboAutoFillManager m_EnterpriseComboAutoFillMan = new ComboAutoFillManager(this);
		}

		private void OnPopUpVisibleChanged(object sender,System.EventArgs e)
		{
			mDroppedDown = false;
			Invalidate(false);

			if(!this.ContainsFocus){
				this.BackColor = StyleGuide.InteliEditColor(this.mpTextBox.ReadOnly,this.Enabled, base.EditColor,
					                                        base.EditReadOnlyColor, base.EditDisabledColor);
			}
		}

		private void m_pTextBox_ProccessMessage(object sender, MessageEventArgs e)
		{
			Message m = e.WindowsMessage;
			if(mDroppedDown && m_ComboPopUp != null && IsNeeded(ref m))
			{
				m_ComboPopUp.PostMessage(ref m);
				e.Result = true;
			}
			else e.Result = false;
		}

		private void m_pTextBox_OnLostFocus(object sender, System.EventArgs e)
		{
			if(mDroppedDown && m_ComboPopUp != null)
			{
				m_ComboPopUp.Close();
				mDroppedDown = false;
			}
		}

		private void internalListBox_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			if (this.internalListBox.SelectedIndex>-1)
			{
				object pitem = null;
				if (this.internalListBox.SelectedItem is DataRowView) 
					{pitem = ((DataRowView)this.internalListBox.SelectedItem).Row[this.DisplayMember.Substring(this.DisplayMember.IndexOf(".")+1)];}
				else if (this.internalListBox.SelectedItem is string) 
					{pitem = (string)this.internalListBox.SelectedItem;}

				this.Text = (string)pitem;		
			}
		}

		private void internalListBox_SelectedValueChanged(object sender, System.EventArgs e)
		{
			this.OnSelectedValueChanged(e);
		}

		#endregion

		#region Virtuals

		protected virtual void OnSelectedValueChanged(EventArgs e)
		{
			if (this.SelectedValueChanged!=null)
				this.SelectedValueChanged(this, e);
		}

		#endregion

		#region Overrides

		protected override void OnResize(EventArgs e)
		{
			base.OnResize(e);
			m_DropDownWidth = this.Width;
		}

		protected override void OnButtonPressed(EventArgs e)
		{
			if(mDroppedDown)
			{
				m_ComboPopUp.Close();
				return;
			}	
		
			ShowPopUp();			
		}

		protected override void OnPlusKeyPressed()
		{
			base.OnPlusKeyPressed();
			
			if(mDroppedDown){
				return;
			}	
		
			ShowPopUp();			
		}

		protected override void OnSizeChanged(System.EventArgs e)
		{
			base.OnSizeChanged(e);

			if(this.DesignMode)
			{
				((System.Windows.Forms.ListBox)this.internalListBox).Width = this.Width;
			}
		}

		protected override void OnValidating(System.ComponentModel.CancelEventArgs e)
		{
			base.OnValidating(e);
			e.Cancel = Validate_Item();
		
			if (e.Cancel)
			{
				base.MpTextBoxErrorOcurred(this, new ErrorOcurredEventArgs(ResourceLibrary.GetString(WindowsControlsResourceKeys.ContentNotExistInList, WindowsControlsResourceKeys.Root)));
			}
		}

		protected override void OnEnterKeyPressed()
		{				
			if(mDroppedDown && m_ComboPopUp != null)
			{
				object pitem = null;
				if (m_ComboPopUp.SelectedItem is DataRowView) 
					{pitem = ((DataRowView)m_ComboPopUp.SelectedItem).Row[this.DisplayMember.Substring(this.DisplayMember.IndexOf(".")+1)];}
				else if (m_ComboPopUp.SelectedItem is string) 
					{pitem = (string)m_ComboPopUp.SelectedItem;}

				int index = this.internalListBox.FindStringExact((string)pitem);
				if (index > -1) this.internalListBox.SelectedIndex = index;

				m_ComboPopUp.Close();
			}

			this.OnKeyDown(new KeyEventArgs(Keys.Enter));
			this.OnKeyPress(new KeyPressEventArgs((char)13));
		}

		protected override void OnKeyDown(KeyEventArgs e)
		{
			base.OnKeyDown(e);

			if (e.Alt && e.KeyCode == Keys.Down)
			{
				ShowPopUp();
			}
			else if (((e.Alt && e.KeyCode == Keys.Up) || e.KeyCode == Keys.Escape) && (m_ComboPopUp!=null))
			{
				m_ComboPopUp.Close();
			}
		}

		#endregion

		#region Internal helpers

		private void OnPopUpClosed(object sender,System.EventArgs e)
		{
			mDroppedDown = false;
			m_ComboPopUp.Dispose();
			Invalidate(false);
		}

		[UseApiElements("ShowPopUp")]
		private void ShowPopUp()
		{
			Point pt = new Point(this.Left,this.Bottom + 1);
			m_ComboPopUp = new ComboPopUp(this,this.EditColor,
										  this.Style!=null?(object)this.Style.PlansOfColors:null,
										  m_VisibleItems, this.Text, this.m_DropDownWidth, this.internalListBox);
			m_ComboPopUp.Location = this.Parent.PointToScreen(pt);
			m_ComboPopUp.Closed += new System.EventHandler(this.OnPopUpClosed);
	
			User32.ShowWindow(m_ComboPopUp.Handle,4);

			m_ComboPopUp.Start = true;
			mDroppedDown = true;
		}

		[UseApiElements("WM_MOUSEWHEEL, WM_KEYUP, WM_KEYDOWN, WM_CHAR")]
		private bool IsNeeded(ref  System.Windows.Forms.Message m)
		{
			if(m.Msg == (int)Msgs.WM_MOUSEWHEEL)
			{
				return true;
			}

			if(m.Msg == (int)Msgs.WM_KEYUP || m.Msg == (int)Msgs.WM_KEYDOWN)
			{
				return true;
			}

			if(m.Msg == (int)Msgs.WM_CHAR)
			{
				return true;
			}

			return false;
		}

		private bool Validate_Item()
		{
			if (this.JustAcceptItems)
			{
				int index = ((System.Windows.Forms.ListBox)this.internalListBox).Items.IndexOf(this.Text);
				if (index > -1) 
				{
					((System.Windows.Forms.ListBox)this.internalListBox).SelectedIndex = index;
				}
				return (index<0);
			}
			return false;
		}
		
		#endregion

		#region Properties

		[Browsable(false)]
		public System.Windows.Forms.ListBox InternalListBox
		{
			get {return this.internalListBox;}
		}

		protected override Icon ButtonIcon
		{
			get{return this.mButtonIcon;}
		}

		[Category("Appearance")]
		public int VisibleItems
		{
			get{ return m_VisibleItems; }
			set{ m_VisibleItems = value; }
		}
		
		[Category("Data")]
		public ComboAutoFill AutoFill
		{
			get {return m_AutoFill;}
			set {m_AutoFill = value;}
		}

		[Category("Behavior")]
		public bool JustAcceptItems
		{
			get {return m_JustAcceptItems;}
			set {m_JustAcceptItems = value;}
		}

		[Category("Data"), 
		Browsable(true),
		DefaultValue(null),
		RefreshProperties(RefreshProperties.Repaint),
		TypeConverter("System.Windows.Forms.Design.DataSourceConverter, System.Design")]
		public object DataSource
		{
			get{ return ((System.Windows.Forms.ListBox)this.internalListBox).DataSource; }
			set{ ((System.Windows.Forms.ListBox)this.internalListBox).DataSource = value; }
		}
			
		[Category("Data"),
		Browsable(true),
		DefaultValue("")]
		public string DisplayMember
		{
			get{ return ((System.Windows.Forms.ListBox)this.internalListBox).DisplayMember; }
			set{ ((System.Windows.Forms.ListBox)this.internalListBox).DisplayMember = value; }
		}

		[Category("Data"),
		Browsable(true)]
		public string ValueMember
		{
			get{ return ((System.Windows.Forms.ListBox)this.internalListBox).ValueMember; }
			set{ ((System.Windows.Forms.ListBox)this.internalListBox).ValueMember = value; }
		}

		[MergableProperty(false),
		DesignerSerializationVisibility(DesignerSerializationVisibility.Content),
		Category("Data")]
		public System.Windows.Forms.ListBox.ObjectCollection Items
		{
			get{ return ((System.Windows.Forms.ListBox)this.internalListBox).Items;}
		}

		[Browsable(false)]
		public object SelectedItem
		{
			get{return ((System.Windows.Forms.ListBox)this.internalListBox).SelectedItem;}
			set{((System.Windows.Forms.ListBox)this.internalListBox).SelectedItem = value;}
		}

		[Browsable(false)]
		public object SelectedValue
		{
			get{return ((System.Windows.Forms.ListBox)this.internalListBox).SelectedValue;}
			set{((System.Windows.Forms.ListBox)this.internalListBox).SelectedValue = value;}
		}

		[Browsable(false)]
		public int SelectedIndex
		{
			get
			{
				if(this.SelectedItem != null)
				{
					return ((System.Windows.Forms.ListBox)this.internalListBox).Items.IndexOf(this.SelectedItem); 
				}
				else
				{
					return -1;
				}
			}

			set
			{
				if(value > -1 && value < ((System.Windows.Forms.ListBox)this.internalListBox).Items.Count)
				{
					((System.Windows.Forms.ListBox)this.internalListBox).SelectedItem = ((System.Windows.Forms.ListBox)this.internalListBox).Items[value];
					this.Text = ((System.Windows.Forms.ListBox)this.internalListBox).SelectedItem.ToString();
				}
			}
		}

		[Category("Behavior"),
		Browsable(true)]
		public new EditMask Mask
		{
			get{ return mpTextBox.Mask; }
			set{mpTextBox.Mask = value;}
		}

		#endregion
	}

	#endregion

	#region ComboListBox

	[System.ComponentModel.ToolboxItem(false)]
	internal class ComboListBox : ListBoxBase
	{
		private System.ComponentModel.Container components = null;

		#region Constructors
		
		public ComboListBox()
		{
			InitializeComponent();
		}

		#endregion

		#region Dispose

		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#endregion

		#region Component Designer generated code
		private void InitializeComponent()
		{
			components = new System.ComponentModel.Container();
		}
		#endregion

		#region Overrides

		[UseApiElements("WM_LBUTTONUP, WM_LBUTTONDOWN, WM_MBUTTONDOWN")]
		protected override void WndProc(ref Message m)
		{			
			if(m.Msg == (int)Msgs.WM_LBUTTONUP)
			{
				ComboPopUp frm = (ComboPopUp)this.FindForm();
				
				object pitem = null;
				if (frm.SelectedItem is DataRowView) 
				{pitem = ((DataRowView)frm.SelectedItem).Row[this.DisplayMember.Substring(this.DisplayMember.IndexOf(".")+1)];}
				else if (frm.SelectedItem is string) 
				{pitem = (string)frm.SelectedItem;}

				int index = ((ComboBox)frm.Parent).InternalListBox.FindStringExact((string)pitem);
				if (index > -1) ((ComboBox)frm.Parent).InternalListBox.SelectedIndex = index;

				frm.Close();
				return;
			}

			if(m.Msg == (int)Msgs.WM_LBUTTONDOWN)
			{
				return;
			}

			if(m.Msg == (int)Msgs.WM_MBUTTONDOWN)
			{
				return;
			}

			base.WndProc(ref m);
		}

		#endregion

		#region Methods
		
		public void PostMessage(ref Message m)
		{
			base.WndProc(ref m);
		}

		#endregion
	}

	#endregion
}