using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using PallaControls.Utilities;
using PallaControls.Utilities.Win32;

namespace PallaControls.Windows.Forms
{
	internal class ComboPopUp : PopUpFormBase
	{
		private System.ComponentModel.IContainer components = null;
		private ComboListBox m_pListBox;
		private Control parent = null;

		public event ComboSelectionChangedEventHandler SelectionChanged = null;
        		
		#region Constructors

		public ComboPopUp(Control parent, Color editColor,object planColor, 
							int visibleItems,string selectedText,int dropDownWidth, System.Windows.Forms.ListBox items) : base(parent)
		{
			this.parent = parent;
			InitializeComponent();

			m_pListBox.Items.AddRange(items.Items);
			m_pListBox.DataSource = items.DataSource;
			m_pListBox.DisplayMember = items.DisplayMember;
			m_pListBox.ValueMember = items.ValueMember;

			if(visibleItems > m_pListBox.Items.Count)
			{
				visibleItems = m_pListBox.Items.Count;
			}

			this.Width  = dropDownWidth;
			this.Height = (m_pListBox.ItemHeight * visibleItems)+2;

			m_pListBox.BackColor = editColor;
			m_pListBox.SelectionColor = StyleGuide.InteliSelectionColor(planColor);
					       
			int index = m_pListBox.FindStringExact(selectedText);
			if(index > -1)
			{
				m_pListBox.SelectedIndex = index;
			}
		}

		#endregion

		#region Dispose

		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#endregion

		#region Designer generated code
		private void InitializeComponent()
		{
			this.m_pListBox = new PallaControls.Windows.Forms.ComboListBox();
			this.SuspendLayout();
			// 
			// m_pListBox
			// 
			this.m_pListBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.m_pListBox.Dock = System.Windows.Forms.DockStyle.Fill;
			this.m_pListBox.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
			this.m_pListBox.Location = new System.Drawing.Point(1, 1);
			this.m_pListBox.Name = "m_pListBox";
			this.m_pListBox.Size = new System.Drawing.Size(118, 65);
			this.m_pListBox.TabIndex = 0;
			this.m_pListBox.KeyUp += new System.Windows.Forms.KeyEventHandler(this.m_pListBox_KeyUp);
			this.m_pListBox.MouseMove += new System.Windows.Forms.MouseEventHandler(this.listBox_MouseMove);
			// 
			// EnterpriseComboPopUp
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(120, 72);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.m_pListBox});
			this.DockPadding.All = 1;
			this.Name = "EnterpriseComboPopUp";
			this.ResumeLayout(false);

		}
		#endregion

		#region Events handlers

		private void listBox_MouseMove(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			int index = m_pListBox.IndexFromPoint(e.X,e.Y);

			if(m_pListBox.SelectedIndex != index){
				m_pListBox.SelectedIndex = index;
			}
		}

		private void m_pListBox_KeyUp(object sender, System.Windows.Forms.KeyEventArgs e)
		{
			if(e.KeyData == Keys.Escape){
				this.Close();
			}

			if(e.KeyData == Keys.Enter){
				OnSelectionChanged();
				this.Close();
			}
		}

		#endregion

		#region Overrides

		protected override void OnPaint(System.Windows.Forms.PaintEventArgs e)
		{
			base.OnPaint(e);
		}

		public override void PostMessage(ref Message m)
		{
			Message msg = new Message();
			msg.HWnd    = m_pListBox.Handle;
			msg.LParam  = m.LParam;
			msg.Msg     = m.Msg;
			msg.Result  = m.Result;
			msg.WParam  = m.WParam;

			m_pListBox.PostMessage(ref msg);
		}

		#endregion

		#region Methods
        
		public int SearchItem(string value)
		{
			int index = m_pListBox.FindString(value);
			if (index > -1) m_pListBox.SelectedIndex = index;

			return index;
		}

		#endregion

		#region Internal helpers

		private void OnSelectionChanged()
		{
			if(m_pListBox.SelectedItem != null){
				ComboSelChangedEventArgs oArgs = new ComboSelChangedEventArgs(m_pListBox.Text);

				if(this.SelectionChanged != null){
					this.SelectionChanged(this,oArgs);
				}
			}
		}

		#endregion

		#region Properties

		public object SelectedItem
		{
			get {return m_pListBox.SelectedItem;}
		}

		public new Control Parent
		{
			get {return parent;}
		}

		#endregion
	}
}