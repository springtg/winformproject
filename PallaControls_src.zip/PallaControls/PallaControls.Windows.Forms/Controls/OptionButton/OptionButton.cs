using System;
using System.Data;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Text;
using System.Windows.Forms;

namespace PallaControls.Windows.Forms
{
	[System.ComponentModel.ToolboxItem(true)]
	public class OptionButton : PallaControls.Windows.Forms.Button
	{
		private System.ComponentModel.Container components = null;
		private bool m_Checked = false;
		private int m_groupIndex = -1;
		private OptionTypes m_OptionTypes = OptionTypes.ClientOption;
		private OptionHighLight m_OptionHighLight = OptionHighLight.Rectangle;
		//Style, default Neo ClientOption
		private Color m_CheckColor = Color.Black;

		#region Constructors

		public OptionButton()
		{
			InitializeComponent();
		}

		#endregion

		#region Dispose

		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#endregion

		#region Component Designer generated code
		private void InitializeComponent()
		{
			// 
			// EnterpriseOptionButton
			// 
			this.Name = "OptionButton";
		}
		#endregion

		#region Overrides

		protected override void OnKeyUp(System.Windows.Forms.KeyEventArgs e)
		{
			if(this.Enabled && e.KeyData == Keys.Space)
			{
				if(!this.Checked)
				{
					this.Checked = true;
				}
				
				using(Graphics g = this.CreateGraphics())
				{
					DrawControl(g,false);
				}

				if (this.CanFocus) this.Focus();
				this.OnButtonClicked();
			}
		}

		protected override void OnKeyDown(System.Windows.Forms.KeyEventArgs e)
		{
			if(this.Enabled && e.KeyData == Keys.Space)
			{
				using(Graphics g = this.CreateGraphics())
				{
					DrawControl(g,true);
				}
				
				if (this.CanFocus) this.Focus();
			}
		}
		
		protected override void OnMouseUp(System.Windows.Forms.MouseEventArgs e)
		{
			if(this.Enabled && this.IsMouseInControl)
			{
				if(!this.Checked)
				{
					this.Checked = true;
				}
				
				using(Graphics g = this.CreateGraphics())
				{
					DrawControl(g,false);
				}

				OnButtonClicked();
			}
		}

		protected override void OnMouseDown(System.Windows.Forms.MouseEventArgs e)
		{
			if(this.Enabled)
			{
				using(Graphics g = this.CreateGraphics())
				{
					DrawControl(g,true);
				}
				
				if (this.CanFocus) this.Focus();
			}
		}
		
		protected override void DrawControl(Graphics g,bool hot)
		{	
			//g.Clear(StyleGuide.InteliButtonColor(hot,false, this.ButtonColor, this.ButtonPressedColor, this.ButtonHotColor));
			this.BackColor = StyleGuide.InteliButtonColor(hot,false, this.ButtonColor, this.ButtonPressedColor, this.ButtonHotColor);
			
			using (Pen pen1 = new Pen(StyleGuide.InteliBorderColor(hot, this.BorderHotColor, this.BorderColor),2))
			{
				g.DrawRectangle(pen1,this.ClientRectangle);
			}
			
			StringFormat format  = new StringFormat();
			format.LineAlignment = StringAlignment.Center;
			format.Alignment     = StringAlignment.Center;
			format.HotkeyPrefix  = HotkeyPrefix.Show;

			Rectangle txtRect = this.ClientRectangle;

			if(this.Enabled)
			{
				using (Brush brush1 = new SolidBrush(this.ForeColor))
				{
					g.DrawString(this.Text,this.Font,brush1,txtRect,format);
				}
			}
			else
			{
				using (Brush brush1 = new SolidBrush(Color.FromArgb(128,128,128)))
				{
					g.DrawString(this.Text,this.Font,brush1,txtRect,format);
				}
			}

			if(m_Checked)
			{
				using (Pen pen1 = new Pen(new SolidBrush(this.Enabled ? this.CheckColor : Color.Silver),2))
				{
					if (this.m_OptionHighLight == OptionHighLight.Rectangle)
						g.DrawRectangle(pen1, this.ClientRectangle);
					else
					{
						using (Brush brush1 = new SolidBrush(this.Enabled? this.CheckColor : Color.FromArgb(128,128,128)))
						{
							g.DrawString(this.Text,this.Font,brush1,txtRect,format);
						}
					}
				}
			}
		}

		protected override bool ProcessMnemonic(char charCode)
		{
			base.ProcessMnemonic(charCode);
			//
			if (this.CanSelect && IsMnemonic(charCode, this.Text))
			{
				if(!this.Checked)
				{
					this.Checked = true;
				}
				//
				this.Focus();
				return true;
			}
			else {return false;}
		}

		protected override void OnPlansOfColorsChanged(object sender, PlansOfColorsChangedEventArgs args)
		{
			this.TextColor = Color.Black;
			if (args.NewPlan == PlansColors.Morpheus)
			{
				if (this.OptionType == OptionTypes.ClientOption)
				{
					this.BorderColor         = Color.FromArgb(242, 242, 228);     
					this.BorderHotColor      = Color.FromArgb(242, 242, 228);
					this.CheckColor          = Color.Black;
					this.ButtonColor         = Color.FromArgb(242, 242, 228);
					this.ButtonHotColor      = Color.FromArgb(231, 231, 214);
					this.ButtonPressedColor  = Color.FromArgb(222, 217, 207);
					this.FlashColor          = Color.FromArgb(255, 204, 102);
				}
				else if (this.OptionType == OptionTypes.LeftOption)
				{
					this.BorderColor         = Color.FromArgb(255, 153, 0);     
					this.BorderHotColor      = Color.FromArgb(255, 153, 0);
					this.CheckColor          = Color.Black;
					this.ButtonColor         = Color.FromArgb(255, 153, 0);
					this.ButtonHotColor      = Color.FromArgb(255, 191, 57);
					this.ButtonPressedColor  = Color.FromArgb(255, 153, 0);
					this.FlashColor          = Color.FromArgb(255, 204, 102);
				}
				else if (this.OptionType == OptionTypes.TopOption)
				{
					this.BorderColor         = Color.FromArgb(255, 204, 102);     
					this.BorderHotColor      = Color.FromArgb(255, 204, 102);
					this.CheckColor          = Color.Black;
					this.ButtonColor         = Color.FromArgb(255, 204, 102);
					this.ButtonHotColor      = Color.FromArgb(255, 191, 57);
					this.ButtonPressedColor  = Color.FromArgb(255, 204, 102);
					this.FlashColor          = Color.White;
				}
			}
			else if (args.NewPlan == PlansColors.Cypher)
			{
				if (this.OptionType == OptionTypes.ClientOption)
				{
					this.BorderColor         = Color.FromArgb(242, 242, 228);     
					this.BorderHotColor      = Color.FromArgb(242, 242, 228);
					this.CheckColor          = Color.Black;
					this.ButtonColor         = Color.FromArgb(242, 242, 228);
					this.ButtonHotColor      = Color.FromArgb(231, 231, 214);
					this.ButtonPressedColor  = Color.FromArgb(222, 217, 207);
					this.FlashColor          = Color.FromArgb(204, 204, 153);
				}
				else if (this.OptionType == OptionTypes.LeftOption)
				{
					this.BorderColor         = Color.FromArgb(153, 153, 102);     
					this.BorderHotColor      = Color.FromArgb(153, 153, 102);
					this.CheckColor          = Color.Black;
					this.ButtonColor         = Color.FromArgb(153, 153, 102);
					this.ButtonHotColor      = Color.FromArgb(204, 204, 153);
					this.ButtonPressedColor  = Color.FromArgb(153, 153, 102);
					this.FlashColor          = Color.FromArgb(204, 204, 153);
				}
				else if (this.OptionType == OptionTypes.TopOption)
				{
					this.BorderColor         = Color.FromArgb(204, 204, 153);     
					this.BorderHotColor      = Color.FromArgb(204, 204, 153);
					this.CheckColor          = Color.Black;
					this.ButtonColor         = Color.FromArgb(204, 204, 153);
					this.ButtonHotColor      = Color.FromArgb(216, 216, 175);
					this.ButtonPressedColor  = Color.FromArgb(204, 204, 153);
					this.FlashColor          = Color.White;
				}
			}
			else if (args.NewPlan == PlansColors.Apoc)
			{
				if (this.OptionType == OptionTypes.ClientOption)
				{
					this.BorderColor         = Color.FromArgb(242, 242, 228);     
					this.BorderHotColor      = Color.FromArgb(242, 242, 228);
					this.CheckColor          = Color.Black;
					this.ButtonColor         = Color.FromArgb(242, 242, 228);
					this.ButtonHotColor      = Color.FromArgb(231, 231, 214);
					this.ButtonPressedColor  = Color.FromArgb(222, 217, 207);
					this.FlashColor          = Color.FromArgb(153, 204, 204);
				}
				else if (this.OptionType == OptionTypes.LeftOption)
				{
					this.BorderColor         = Color.FromArgb(51, 153, 153);     
					this.BorderHotColor      = Color.FromArgb(51, 153, 153);
					this.CheckColor          = Color.Black;
					this.ButtonColor         = Color.FromArgb(51, 153, 153);
					this.ButtonHotColor      = Color.FromArgb(153, 204, 204);
					this.ButtonPressedColor  = Color.FromArgb(51, 153, 153);
					this.FlashColor          = Color.FromArgb(153, 204, 204);
				}
				else if (this.OptionType == OptionTypes.TopOption)
				{
					this.BorderColor         = Color.FromArgb(153, 204, 204);     
					this.BorderHotColor      = Color.FromArgb(153, 204, 204);
					this.CheckColor          = Color.Black;
					this.ButtonColor         = Color.FromArgb(153, 204, 204);
					this.ButtonHotColor      = Color.FromArgb(173, 214, 214);
					this.ButtonPressedColor  = Color.FromArgb(153, 204, 204);
					this.FlashColor          = Color.White;
				}
			}
			else if (args.NewPlan == PlansColors.AgentSmith)
			{
				if (this.OptionType == OptionTypes.ClientOption)
				{
					this.BorderColor         = Color.FromArgb(242, 242, 228);     
					this.BorderHotColor      = Color.FromArgb(242, 242, 228);
					this.CheckColor          = Color.Black;
					this.ButtonColor         = Color.FromArgb(242, 242, 228);
					this.ButtonHotColor      = Color.FromArgb(231, 231, 214);
					this.ButtonPressedColor  = Color.FromArgb(222, 217, 207);
					this.FlashColor          = Color.FromArgb(102, 153, 204);
				}
				else if (this.OptionType == OptionTypes.LeftOption)
				{
					this.BorderColor         = Color.FromArgb(51, 102, 153);     
					this.BorderHotColor      = Color.FromArgb(51, 102, 153);
					this.CheckColor          = Color.Black;
					this.ButtonColor         = Color.FromArgb(51, 102, 153);
					this.ButtonHotColor      = Color.FromArgb(102, 153, 204);
					this.ButtonPressedColor  = Color.FromArgb(51, 102, 153);
					this.FlashColor          = Color.FromArgb(102, 153, 204);
				}
				else if (this.OptionType == OptionTypes.TopOption)
				{
					this.BorderColor         = Color.FromArgb(102, 153, 204);     
					this.BorderHotColor      = Color.FromArgb(102, 153, 204);
					this.CheckColor          = Color.Black;
					this.ButtonColor         = Color.FromArgb(102, 153, 204);
					this.ButtonHotColor      = Color.FromArgb(137, 176, 216);
					this.ButtonPressedColor  = Color.FromArgb(102, 153, 204);
					this.FlashColor          = Color.White;
				}
			}
			else if (args.NewPlan == PlansColors.Trinity)
			{
				if (this.OptionType == OptionTypes.ClientOption)
				{
					this.BorderColor         = Color.FromArgb(242, 242, 228);     
					this.BorderHotColor      = Color.FromArgb(242, 242, 228);
					this.CheckColor          = Color.Black;
					this.ButtonColor         = Color.FromArgb(242, 242, 228);
					this.ButtonHotColor      = Color.FromArgb(231, 231, 214);
					this.ButtonPressedColor  = Color.FromArgb(222, 217, 207);
					this.FlashColor          = Color.FromArgb(204, 128, 128);
				}
				else if (this.OptionType == OptionTypes.LeftOption)
				{
					this.BorderColor         = Color.FromArgb(153, 51, 51);     
					this.BorderHotColor      = Color.FromArgb(153, 51, 51);
					this.CheckColor          = Color.Black;
					this.ButtonColor         = Color.FromArgb(153, 51, 51);
					this.ButtonHotColor      = Color.FromArgb(204, 128, 128);
					this.ButtonPressedColor  = Color.FromArgb(153, 51, 51);
					this.FlashColor          = Color.FromArgb(204, 128, 128);
				}
				else if (this.OptionType == OptionTypes.TopOption)
				{
					this.BorderColor         = Color.FromArgb(204, 128, 128);     
					this.BorderHotColor      = Color.FromArgb(204, 128, 128);
					this.CheckColor          = Color.Black;
					this.ButtonColor         = Color.FromArgb(204, 128, 128);
					this.ButtonHotColor      = Color.FromArgb(217, 159, 159);
					this.ButtonPressedColor  = Color.FromArgb(204, 128, 128);
					this.FlashColor          = Color.White;
				}
			}
			else if (args.NewPlan == PlansColors.Mouse)
			{
				if (this.OptionType == OptionTypes.ClientOption)
				{
					this.BorderColor         = Color.FromArgb(242, 242, 228);     
					this.BorderHotColor      = Color.FromArgb(242, 242, 228);
					this.CheckColor          = Color.Black;
					this.ButtonColor         = Color.FromArgb(242, 242, 228);
					this.ButtonHotColor      = Color.FromArgb(231, 231, 214);
					this.ButtonPressedColor  = Color.FromArgb(222, 217, 207);
					this.FlashColor          = Color.FromArgb(204, 153, 102);
				}
				else if (this.OptionType == OptionTypes.LeftOption)
				{
					this.BorderColor         = Color.FromArgb(153, 102, 51);     
					this.BorderHotColor      = Color.FromArgb(153, 102, 51);
					this.CheckColor          = Color.Black;
					this.ButtonColor         = Color.FromArgb(153, 102, 51);
					this.ButtonHotColor      = Color.FromArgb(204, 153, 102);
					this.ButtonPressedColor  = Color.FromArgb(153, 102, 51);
					this.FlashColor          = Color.FromArgb(204, 153, 102);
				}
				else if (this.OptionType == OptionTypes.TopOption)
				{
					this.BorderColor         = Color.FromArgb(204, 153, 102);     
					this.BorderHotColor      = Color.FromArgb(204, 153, 102);
					this.CheckColor          = Color.Black;
					this.ButtonColor         = Color.FromArgb(204, 153, 102);
					this.ButtonHotColor      = Color.FromArgb(216, 177, 139);
					this.ButtonPressedColor  = Color.FromArgb(204, 153, 102);
					this.FlashColor          = Color.White;
				}
			}
			else if (args.NewPlan == PlansColors.NeoTheOne)
			{
				if (this.OptionType == OptionTypes.ClientOption)
				{
					this.BorderColor         = Color.FromArgb(242, 242, 228);     
					this.BorderHotColor      = Color.FromArgb(242, 242, 228);
					this.CheckColor          = Color.Black;
					this.ButtonColor         = Color.FromArgb(242, 242, 228);
					this.ButtonHotColor      = Color.FromArgb(231, 231, 214);
					this.ButtonPressedColor  = Color.FromArgb(222, 217, 207);
					this.FlashColor          = Color.FromArgb(170, 170, 221);
				}
				else if (this.OptionType == OptionTypes.LeftOption)
				{
					this.BorderColor         = Color.FromArgb(231, 231, 214);     
					this.BorderHotColor      = Color.FromArgb(231, 231, 214);
					this.CheckColor          = Color.Black;
					this.ButtonColor         = Color.FromArgb(231, 231, 214);
					this.ButtonHotColor      = Color.FromArgb(220, 220, 194);
					this.ButtonPressedColor  = Color.FromArgb(231, 231, 214);
					this.FlashColor          = Color.FromArgb(170, 170, 221);
				}
				else if (this.OptionType == OptionTypes.TopOption)
				{
					this.BorderColor         = Color.FromArgb(170, 170, 221);     
					this.BorderHotColor      = Color.FromArgb(170, 170, 221);
					this.CheckColor          = Color.Black;
					this.ButtonColor         = Color.FromArgb(170, 170, 221);
					this.ButtonHotColor      = Color.FromArgb(199, 199, 233);
					this.ButtonPressedColor  = Color.FromArgb(170, 170, 221);
					this.FlashColor          = Color.White;
				}
			}
			else if (args.NewPlan == PlansColors.AssGreen)
			{
				if (this.OptionType == OptionTypes.ClientOption)
				{
					this.BorderColor         = Color.FromArgb(222, 217, 207);
					this.BorderHotColor      = Color.FromArgb(222, 217, 207);
					this.CheckColor          = Color.Black;
					this.ButtonColor         = Color.FromArgb(232, 237, 223);
					this.ButtonHotColor      = Color.FromArgb(231, 231, 214);
					this.ButtonPressedColor  = Color.FromArgb(222, 217, 207);
					this.FlashColor          = Color.FromArgb(147, 167, 159);
				}
				else if (this.OptionType == OptionTypes.LeftOption)
				{
					this.BorderColor         = Color.FromArgb(147, 167, 159);
					this.BorderHotColor      = Color.FromArgb(147, 167, 159);
					this.CheckColor          = Color.Black;
					this.ButtonColor         = Color.FromArgb(147, 167, 159);
					this.ButtonHotColor      = Color.FromArgb(109, 135, 125);
					this.ButtonPressedColor  = Color.FromArgb(119, 145, 135);
					this.FlashColor          = Color.White;
					this.TextColor           = Color.FromArgb(228, 234, 218);
				}
				else if (this.OptionType == OptionTypes.TopOption)
				{
					this.BorderColor         = Color.FromArgb(119, 145, 135); 
					this.BorderHotColor      = Color.FromArgb(119, 145, 135); 
					this.CheckColor          = Color.Black;
					this.ButtonColor         = Color.FromArgb(119, 145, 135);
					this.ButtonHotColor      = Color.FromArgb(109, 135, 125);
					this.ButtonPressedColor  = Color.FromArgb(119, 145, 135);
					this.FlashColor          = Color.White;
					this.TextColor           = Color.FromArgb(228, 234, 218);
				}
			}
			//
			this.Invalidate(true);
		}

		#endregion

		#region Properties

		[MergableProperty(false),
		 Bindable(true),
		 Category("Appearance")]
		public bool Checked
		{
			get{ return m_Checked; }

			set
			{
				m_Checked = value;
				//
				if (m_Checked && this.Parent != null)
				{
					foreach (Control currentControl in this.Parent.Controls)
					{
						if (currentControl is OptionButton && 
							currentControl != this &&
							((OptionButton)currentControl).GroupIndex == this.GroupIndex) 
						{
							((OptionButton)currentControl).Checked = false;	
						}
					}
				}
				//	
				this.Invalidate(false);				
			}
		}

		[Category("Appearance")]
		public OptionTypes OptionType
		{
			get{return m_OptionTypes;}
			set
			{
				m_OptionTypes = value;
				//
				if (this.DesignMode)
				{
					if (m_OptionTypes == OptionTypes.TopOption) 
					{
						this.Height = 18;
						this.Width  = 77;
					}
					else 
					{
						this.Height = 19;
						this.Width  = 78;
					}
				}
				//
				if (this.Style!=null) this.OnPlansOfColorsChanged(this, new PlansOfColorsChangedEventArgs((this.Style!=null)?this.Style.PlansOfColors:PlansColors.NeoTheOne));
			 }
		}

		[Category("Appearance")]
		public OptionHighLight HighLighType
		{
			get{return this.m_OptionHighLight;}
			set{this.m_OptionHighLight = value;}
		}

		[Browsable(true),
		DesignerSerializationVisibility(DesignerSerializationVisibility.Visible),
		Category("Behavior")]
		public int GroupIndex
		{
			get{return m_groupIndex;}
			set{m_groupIndex = value;}
		}

		[Category("Style")]
		public Color CheckColor
		{
			get{return m_CheckColor;}
			set
			{
				m_CheckColor = value;
				this.Invalidate(true);
			}
		}

		#endregion
	}
}