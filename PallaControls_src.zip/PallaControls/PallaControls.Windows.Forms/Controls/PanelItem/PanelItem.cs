using System;
using System.Data;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Text;
using System.Drawing.Imaging;
using System.Windows.Forms;
using PallaControls.Windows.Forms.Collections;

namespace PallaControls.Windows.Forms
{
	[ToolboxItem(false)]
    [DefaultEvent("ButtonPressed")]
    public class PanelItem : PallaControls.Windows.Forms.ControlBase
    {
		#region PropChangeEventArgs

		public class PropChangeEventArgs : EventArgs
		{
			private PanelItem item = null;
			private string prop = String.Empty;
			private object oldValue = null;

			public PropChangeEventArgs(PanelItem item, string prop, object oldValue)
			{
				this.item = item;
				this.prop = prop;
				this.oldValue = oldValue;
			}

			public PanelItem Item
			{
				get {return this.item;}
			}

			public string PropertyName
			{
				get {return this.prop;}
			}
		
			public object OldValue
			{
				get {return this.oldValue;}
			}
		}

		#endregion

		private string m_Text = String.Empty;
		private PanelItemStyle itemStyle = PanelItemStyle.Item;
		private HorizontalAlignment m_TextAlignment = HorizontalAlignment.Left;
		private bool m_Checked = false;
		private int m_groupIndex = -1;
		
		//Style Neo, default!!
		private Color m_PanelItemBackColor = Color.FromArgb(237, 237, 224); 
		private Color m_PanelItemForeColor = Color.FromArgb(170, 170, 221); 
		private Color m_PanelItemFlashColor = Color.LightSteelBlue;
		
		protected int mimageIndexEnabled;
		protected int mimageIndexDisabled;
		protected ImageList mimageList;
		
		public delegate void PropChangeEventHandler(object sender, PropChangeEventArgs e);
        public event PropChangeEventHandler PropertyChanged;

		[Category("Action")]
		public event ButtonPressedEventHandler ButtonPressed = null;

		#region Constructors
		
		public PanelItem()
        {
            InternalConstruct("PanelItem", null, -1, PanelItemStyle.Item);
        }

		public PanelItem(string title)
		{
			InternalConstruct(title, null, -1, PanelItemStyle.Item);
		}

		public PanelItem(string title, PanelItemStyle itemStyle)
        {
            InternalConstruct(title, null, -1, itemStyle);
        }

        public PanelItem(string title, ImageList imageList, int imageIndex, PanelItemStyle itemStyle)
        {
            InternalConstruct(title, imageList, imageIndex, itemStyle);
        }

        protected void InternalConstruct(string title, 
                                         ImageList imageList, 
                                         int imageIndex,
										 PanelItemStyle itemStyle)
        {
			this.Text = title;
			this.Height = 19;
			
			if (itemStyle == PanelItemStyle.Item  || itemStyle == PanelItemStyle.Option)
				this.Cursor = Cursors.Hand;
			else if (itemStyle == PanelItemStyle.Separator)
				this.Cursor = Cursors.Default;

			SetStyle(ControlStyles.ResizeRedraw,true);
			SetStyle(ControlStyles.DoubleBuffer,true);
			SetStyle(ControlStyles.AllPaintingInWmPaint,true);
			SetStyle(ControlStyles.Selectable,false);
			SetStyle(ControlStyles.FixedHeight,true);
        }

		#endregion

		#region Dispose

		protected override void Dispose( bool disposing )
		{
			base.Dispose( disposing );
		}

		#endregion

		#region Virtuals

		protected virtual void OnButtonClicked()
		{
			if(this.ButtonPressed != null)
			{
				this.ButtonPressed(this,new System.EventArgs());
			}
		}

		public virtual void OnPropertyChanged(object sender, PropChangeEventArgs e)
		{
			if (PropertyChanged != null)
			{
				PropertyChanged(this, new PropChangeEventArgs(e.Item, e.PropertyName, e.OldValue));
			}
		}

		protected virtual void DrawControl(Graphics g,bool hot,bool pressed)
		{
			this.BackColor = this.PanelItemBackColor;

			if (this.itemStyle == PanelItemStyle.Item || itemStyle == PanelItemStyle.Option)
			{
				StringFormat format  = new StringFormat();
				format.LineAlignment = StringAlignment.Center;

				if(m_TextAlignment == HorizontalAlignment.Left)
					format.Alignment = StringAlignment.Near;
				if(m_TextAlignment == HorizontalAlignment.Center)
					format.Alignment = StringAlignment.Center;
				if(m_TextAlignment == HorizontalAlignment.Right)
					format.Alignment = StringAlignment.Far;

				format.HotkeyPrefix  = HotkeyPrefix.Show;
				Rectangle txtRect = this.ClientRectangle;

				if(pressed)
					txtRect.Location = new Point(txtRect.Left+1,txtRect.Top+1);

				if (mimageList != null)
				{
					if (!this.Enabled)
					{
						if (mimageIndexDisabled != -1 && mimageIndexDisabled < mimageList.Images.Count)
						{
							Point pointImage = new Point(2, 
								(int)(this.Height-mimageList.Images[mimageIndexDisabled].Height)/2);
							g.DrawImage(mimageList.Images[mimageIndexDisabled], pressed?new Point(pointImage.X, pointImage.Y+1):pointImage);
							txtRect.X += mimageList.Images[mimageIndexDisabled].Width;
						}
						else
						{
							if (mimageIndexEnabled != -1 && mimageIndexEnabled < mimageList.Images.Count)
							{
								ControlPaint.DrawImageDisabled(g, mimageList.Images[mimageIndexEnabled], 1, 1, this.BackColor);
								txtRect.X += mimageList.Images[mimageIndexEnabled].Width;
							}
							else
							{
							
							}
						}
					}
					else
					{
						if (mimageIndexEnabled < mimageList.Images.Count)
						{
							Point pointImage = new Point(2, 
								(int)(this.Height-mimageList.Images[mimageIndexEnabled].Height)/2);

							g.DrawImage(mimageList.Images[mimageIndexEnabled], 
								pressed?new Point(pointImage.X, pointImage.Y+1):pointImage);

							txtRect.X += mimageList.Images[mimageIndexEnabled].Width;
						}
					}
				}

				//Esta parte � um pouco diferente para os dois...
				if (this.itemStyle == PanelItemStyle.Item)
				{
					using(Brush brush = this.DesignMode?new SolidBrush(this.PanelItemForeColor):
							  base.IsMouseInControl?new SolidBrush(this.PanelItemFlashColor):
							  new SolidBrush(this.PanelItemForeColor))
					{
						g.DrawString(m_Text,this.Font,brush,txtRect,format);
					}
				}
				else if (itemStyle == PanelItemStyle.Option)
				{
					using(Brush brush = this.DesignMode?new SolidBrush(this.PanelItemForeColor):
							  this.m_Checked?new SolidBrush(this.PanelItemFlashColor):
							  new SolidBrush(this.PanelItemForeColor))
					{
						g.DrawString(m_Text,this.Font,brush,txtRect,format);
					}
				}
			}
			else if (this.itemStyle == PanelItemStyle.Separator)
			{
				this.Cursor = Cursors.Default;
				
				if (this.Parent is OptionPanel)
					this.Width = this.Parent.Width-10;

				using (LinearGradientBrush lineBrush = new LinearGradientBrush(new Rectangle(0,0,this.Width,this.Height), this.m_PanelItemForeColor, Color.Transparent,
						   LinearGradientMode.Horizontal))
				{

					using (GraphicsPath linePath = new GraphicsPath())
					{
						linePath.AddLine(0,(int)this.Height/2,this.Width,(int)this.Height/2);

						using (Pen pen = new Pen(lineBrush, 1))
						{
							g.DrawPath(pen, linePath);
						}
					}
				}
			}
		}

		#endregion

		#region Overrides

		protected override void OnKeyUp(System.Windows.Forms.KeyEventArgs e)
		{
			if(this.Enabled && e.KeyData == Keys.Space) 
			{
				if (this.itemStyle == PanelItemStyle.Option)
				{
					if(!this.Checked)
					{
						this.Checked = true;
					}
				
					using(Graphics g = this.CreateGraphics())
					{
						DrawControl(g,false);
					}
				}

				if (this.CanFocus) this.Focus();
				this.OnButtonClicked();
			}
		}

		protected override void OnKeyDown(System.Windows.Forms.KeyEventArgs e)
		{
			if(this.Enabled && e.KeyData == Keys.Space) 
			{
				if (this.itemStyle == PanelItemStyle.Option)
				{
					using(Graphics g = this.CreateGraphics())
					{
						DrawControl(g,true);
					}
				}

				if (this.CanFocus) this.Focus();
			}
		}
		
		protected override void OnMouseUp(System.Windows.Forms.MouseEventArgs e)
		{
			if(this.Enabled && this.IsMouseInControl)
			{
				if (this.itemStyle == PanelItemStyle.Option)
				{

					if(!this.Checked)
					{
						this.Checked = true;
					}
				
					using(Graphics g = this.CreateGraphics())
					{
						DrawControl(g,false);
					}
				}

				this.OnButtonClicked();
			}
		}

		protected override void OnMouseDown(System.Windows.Forms.MouseEventArgs e)
		{
			if(this.Enabled)
			{
				if (this.itemStyle == PanelItemStyle.Option)
				{
					using(Graphics g = this.CreateGraphics())
					{
						DrawControl(g,true);
					}
				}

				if (this.CanFocus) this.Focus();
			}
		}

		protected override void OnStyleChanged(object sender, StyleEventArgs args)
		{
			base.OnStyleChanged(sender, args);

			if (this.Parent is OptionPanel)
			{
				if (args.PropertyName == "PanelItemForeColor") {this.PanelItemForeColor = (Color)args.PropertyValue;}
				else if (args.PropertyName == "PanelItemAssBackColor") {this.PanelItemBackColor = (Color)args.PropertyValue;}
				else if (args.PropertyName == "PanelItemFlashColor") {this.PanelItemFlashColor= (Color)args.PropertyValue;}
			}

			this.Invalidate(true);
		}

		protected override void OnPlansOfColorsChanged(object sender, PlansOfColorsChangedEventArgs args)
		{
			base.OnPlansOfColorsChanged(sender, args);

			if (this.Style!=null)
			{
				if (this.Parent is OptionPanel)
					this.PanelItemBackColor  = this.Style.PanelItemAssBackColor;
			
				this.PanelItemForeColor = this.Style.PanelItemForeColor;
				this.PanelItemFlashColor = this.Style.PanelItemFlashColor;
			}

			this.Invalidate(true);
		}

		protected override void OnPaint(PaintEventArgs e)
		{
			this.DrawControl(e.Graphics, false , false);
		}

		protected override void OnMouseEnter(System.EventArgs e)
		{
			this.Invalidate(false);
		}

		protected override void OnMouseLeave(System.EventArgs e)
		{
			this.Invalidate(false);
		}

		protected override void OnGotFocus(System.EventArgs e)
		{
			this.Invalidate(false);
		}

		protected override void OnLostFocus(System.EventArgs e)
		{
			this.Invalidate(false);
		}

		protected override bool ProcessMnemonic(char charCode)
		{
			base.ProcessMnemonic(charCode);

			if (this.Enabled && IsMnemonic(charCode, m_Text))
			{
				if (this.itemStyle == PanelItemStyle.Option)
				{
					if(!this.Checked)
					{
						this.Checked = true;
					}
				}
				
				OnButtonClicked();
				this.Focus();
				return true;
			}
			else {return false;}
		}

		#endregion

		#region Properties

		[Category("Behavior")]
		public PanelItemStyle ItemStyle
		{
			get{ return this.itemStyle; }

			set
			{
				this.itemStyle = value;
				this.Invalidate();
			}
		}
		
		[Category("Appearance")]
		public HorizontalAlignment TextAlign
		{
			get{ return m_TextAlignment; }

			set
			{
				m_TextAlignment = value;
				this.Invalidate();
			}
		}

		[Browsable(true),
		DesignerSerializationVisibility(DesignerSerializationVisibility.Visible),
		Bindable(true)]
		public override string Text
		{
			get {return m_Text;}

			set
			{ 
				m_Text = value; 
				this.Invalidate();
			}
		}

		[Category("Style")]
		public Color PanelItemForeColor
		{
			get {return m_PanelItemForeColor;}
			set 
			{
				m_PanelItemForeColor = value;
				this.ForeColor = value;
				this.Invalidate();
			}
		}

		[Category("Style")]
		public Color PanelItemBackColor
		{
			get {return m_PanelItemBackColor;}
			set 
			{
				m_PanelItemBackColor = value;
				this.BackColor = value;
				this.Invalidate();
			}
		}

		[Category("Style")]
		public Color PanelItemFlashColor
		{
			get {return m_PanelItemFlashColor;}
			set 
			{
				m_PanelItemFlashColor = value;
				this.Invalidate();
			}
		}

		[Browsable(false)]
		public override Color BackColor
		{
			get {return m_PanelItemBackColor;}
			set 
			{
				m_PanelItemBackColor = value;
			}
		}

		[Browsable(false)]
		public override Color ForeColor
		{
			get {return m_PanelItemForeColor;}
			set 
			{
				m_PanelItemForeColor = value;
			}
		}

		[Category("Appearance")]
		[DefaultValue(null)]
		public ImageList ImageList
		{
			get { return mimageList; }

			set
			{
				if (mimageList != value)
				{
					mimageList = value;
					Invalidate();
				}
			}
		}

		[Category("Appearance")]
		[DefaultValue(-1)]
		public int ImageIndexEnabled
		{
			get { return mimageIndexEnabled; }

			set
			{
				if (mimageIndexEnabled != value)
				{
					mimageIndexEnabled = value;
					Invalidate();
				}
			}
		}

		[Category("Appearance")]
		[DefaultValue(-1)]
		public int ImageIndexDisabled
		{
			get { return mimageIndexDisabled; }

			set
			{
				if (mimageIndexDisabled != value)
				{
					mimageIndexDisabled = value;
					Invalidate();
				}
			}
		}

		[MergableProperty(false),
		Bindable(true),
		Category("Appearance")]
		public bool Checked
		{
			get{ return m_Checked; }

			set
			{
				if (this.itemStyle == PanelItemStyle.Option)
				{
					m_Checked = value;
					//
					if (m_Checked && this.Parent != null)
					{
						foreach (Control currentControl in this.Parent.Controls)
						{
							if (currentControl is PanelItem && 
								currentControl != this &&
								((PanelItem)currentControl).GroupIndex == this.GroupIndex) 
							{
								((PanelItem)currentControl).Checked = false;	
							}
						}
					}
					//	
					this.Invalidate(false);				
				}
			}
		}

		[Browsable(true),
		DesignerSerializationVisibility(DesignerSerializationVisibility.Visible),
		Category("Behavior")]
		public int GroupIndex
		{
			get{return m_groupIndex;}
			set{m_groupIndex = value;}
		}

		#endregion
    }
}
