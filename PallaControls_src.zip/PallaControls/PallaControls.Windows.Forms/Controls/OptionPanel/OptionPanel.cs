using System;
using System.Collections;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using System.Threading;
using PallaControls.Windows.Forms.Helpers;
using PallaControls.Windows.Forms.Collections;

namespace PallaControls.Windows.Forms
{
	[ToolboxItem(true)]
	//[Designer(typeof(PallaControls.Windows.Forms.OptionPanelDesigner))]
	public class OptionPanel : PallaControls.Windows.Forms.PanelBase, PallaControls.Windows.Forms.IFlashabledControl
	{
		private System.ComponentModel.Container components = null;
		private PanelItemCollection _panelItens;
		private PanelTypes m_PanelTypes = PanelTypes.ClientArea;
		private int mInitialSpace = 0;
		//Style Neo, default!!
		private Color m_PanelLeftOptionsColor = Color.FromArgb(231, 231, 214);
		private Color m_PanelTopOptionsColor = Color.FromArgb(170, 170, 221);
		private Color m_PanelClientAreaColor = Color.FromArgb(242, 242, 228);
		private Color m_PanelBottomAreaColor = Color.FromArgb(222, 217, 207);
		private Color m_PanelAssLeftTitleColor = Color.FromArgb(232, 237, 223);
		private Color m_PanelAssRightTitleColor = Color.FromArgb(147, 167, 159);
		private Color m_PanelAssLeftOptionsColor = Color.FromArgb(147, 167, 159);
		private Color m_PanelAssClientAreaColor = Color.FromArgb(232, 237, 223);
		private Color m_PanelAssBottomAreaColor = Color.FromArgb(222, 230, 210);

		#region Constructors
		
		public OptionPanel()
		{
			InitializeComponent();
			SetStyle(ControlStyles.ContainerControl,true);

			_panelItens = new PanelItemCollection();
			_panelItens.Clearing += new PallaControls.Windows.Forms.Collections.CollectionClearEventHandler(OnClearingItens);
			_panelItens.Cleared += new PallaControls.Windows.Forms.Collections.CollectionClearEventHandler(OnClearedItens);
			_panelItens.Inserting += new PallaControls.Windows.Forms.Collections.CollectionChangeEventHandler(OnInsertingItem);
			_panelItens.Inserted += new PallaControls.Windows.Forms.Collections.CollectionChangeEventHandler(OnInsertedItem);
			_panelItens.Removing += new PallaControls.Windows.Forms.Collections.CollectionChangeEventHandler(OnRemovingItem);
			_panelItens.Removed += new PallaControls.Windows.Forms.Collections.CollectionChangeEventHandler(OnRemovedItem);
		}

		#endregion

		#region Dispose
		
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#endregion

		#region Designer generated code

		private void InitializeComponent()
		{
			components = new System.ComponentModel.Container();
		}

		#endregion

		#region Virtuals

		protected virtual void Recalculate()
		{
			int top = this.mInitialSpace + 7;
			//
			foreach(PanelItem item in _panelItens)
			{
				item.Top = top;
				top += item.Height+2;
			}
		}

		protected virtual void OnClearingItens(object sender, EventArgs e)
		{
			foreach(PanelItem item in _panelItens)
				RemoveItem(item);
		}

		protected virtual void OnClearedItens(object sender, EventArgs e)
		{
		}

		protected virtual void OnInsertingItem(object sender, PallaControls.Windows.Forms.Collections.CollectionChangeEventArgs e)
		{
		}

		protected virtual void OnInsertedItem(object sender, PallaControls.Windows.Forms.Collections.CollectionChangeEventArgs e)
		{
			PanelItem item = sender as PanelItem;
			item.Parent = this;
			item.Width = this.Width -1;
			AddItem(item);

			Recalculate();
			Invalidate();
		}

		protected virtual void OnRemovingItem(object sender, PallaControls.Windows.Forms.Collections.CollectionChangeEventArgs e)
		{
		}

		protected virtual void OnRemovedItem(object sender, PallaControls.Windows.Forms.Collections.CollectionChangeEventArgs e)
		{
			RemoveItem(this.PanelItens[e.Index]);
			Recalculate();
			Invalidate();
		}

		protected virtual void RemoveItem(PanelItem item)
		{
			if (item != null)
				Controls.Remove(item);
		}

		protected virtual void AddItem(PanelItem item)
		{
			if (item != null)
			{
				item.Left = 3;
				Controls.Add(item);
			}
		}

		#endregion

		#region Overrides

		protected override void OnStyleChanged(object sender, StyleEventArgs args)
		{
			base.OnStyleChanged(sender, args);

			if (args.PropertyName == "PanelLeftOptionsColor") {this.m_PanelLeftOptionsColor = (Color)args.PropertyValue;}
			else if (args.PropertyName == "PanelTopOptionsColor") {this.m_PanelTopOptionsColor = (Color)args.PropertyValue;}
			else if (args.PropertyName == "PanelClientAreaColor") {this.m_PanelClientAreaColor = (Color)args.PropertyValue;}
			else if (args.PropertyName == "PanelBottomAreaColor") {this.m_PanelBottomAreaColor = (Color)args.PropertyValue;}
			else if (args.PropertyName == "PanelAssLeftTitleColor") {this.m_PanelAssLeftTitleColor = (Color)args.PropertyValue;}
			else if (args.PropertyName == "PanelAssRightTitleColor") {this.m_PanelAssRightTitleColor = (Color)args.PropertyValue;}
			else if (args.PropertyName == "PanelAssLeftOptionsColor") {this.m_PanelAssLeftOptionsColor = (Color)args.PropertyValue;}
			else if (args.PropertyName == "PanelAssClientAreaColor") {this.m_PanelAssClientAreaColor = (Color)args.PropertyValue;}
			else if (args.PropertyName == "PanelAssBottomAreaColor") {this.m_PanelAssBottomAreaColor = (Color)args.PropertyValue;}

			this.Invalidate(true);
		}

		protected override void OnPlansOfColorsChanged(object sender, PlansOfColorsChangedEventArgs args)
		{
			base.OnPlansOfColorsChanged(sender, args);

			if (this.Style!=null)
			{
				this.m_PanelLeftOptionsColor = this.Style.PanelLeftOptionsColor;
				this.m_PanelTopOptionsColor = this.Style.PanelTopOptionsColor;
				this.m_PanelClientAreaColor = this.Style.PanelClientAreaColor;
				this.m_PanelBottomAreaColor = this.Style.PanelBottomAreaColor;
				this.m_PanelAssLeftTitleColor = this.Style.PanelAssLeftTitleColor;
				this.m_PanelAssRightTitleColor = this.Style.PanelAssRightTitleColor;
				this.m_PanelAssLeftOptionsColor = this.Style.PanelAssLeftOptionsColor;
				this.m_PanelAssClientAreaColor = this.Style.PanelAssClientAreaColor;
				this.m_PanelAssBottomAreaColor = this.Style.PanelAssBottomAreaColor;
			}

			this.Invalidate(true);
		}
		
		protected override void OnPaint(PaintEventArgs e)
		{
			if (m_PanelTypes == PanelTypes.LeftOptions) {base.BackColor = this.m_PanelLeftOptionsColor;}
			else if (m_PanelTypes == PanelTypes.TopOptions) {base.BackColor = this.m_PanelTopOptionsColor;}
			else if (m_PanelTypes == PanelTypes.BottomArea) {base.BackColor = this.m_PanelBottomAreaColor;}
			else if (m_PanelTypes == PanelTypes.ClientArea) {base.BackColor = this.m_PanelClientAreaColor;}
			else if (m_PanelTypes == PanelTypes.AssLeftTitle) {base.BackColor = this.m_PanelAssLeftTitleColor;}
			else if (m_PanelTypes == PanelTypes.AssRightTitle) {base.BackColor = this.m_PanelAssRightTitleColor;}
			else if (m_PanelTypes == PanelTypes.AssLeftOptions) {base.BackColor = this.m_PanelAssLeftOptionsColor;}
			else if (m_PanelTypes == PanelTypes.AssClientArea) {base.BackColor = this.m_PanelAssClientAreaColor;}
			else if (m_PanelTypes == PanelTypes.AssBottomArea) {base.BackColor = this.m_PanelAssBottomAreaColor;}

			base.OnPaint(e);
		}

		#endregion

		#region Properties

		[Category("Behavior")]
		public int InitialSpaceForItens
		{
			get{return this.mInitialSpace;} 
			set{this.mInitialSpace = value;}
		}
		
		[Category("Behavior")]
		[DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
		public virtual PanelItemCollection PanelItens
		{
			get {return _panelItens;}
		}

		[Category("Style")]
		public Color PanelLeftOptionsColor
		{
			get {return m_PanelLeftOptionsColor;}
			set 
			{
				m_PanelLeftOptionsColor = value;
				this.Invalidate();
			}
		}

		[Category("Style")]
		public Color PanelTopOptionsColor
		{
			get {return m_PanelTopOptionsColor;}
			set 
			{
				m_PanelTopOptionsColor = value;
				this.Invalidate();
			}
		}

		[Category("Style")]
		public Color PanelClientAreaColor
		{
			get {return m_PanelClientAreaColor;}
			set 
			{
				m_PanelClientAreaColor = value;
				this.Invalidate();
			}
		}

		[Category("Style")]
		public Color PanelBottomAreaColor
		{
			get {return m_PanelBottomAreaColor;}
			set 
			{
				m_PanelBottomAreaColor = value;
				this.Invalidate();
			}
		}

		[Category("Style")]
		public Color PanelAssLeftTitleColor
		{
			get{return m_PanelAssLeftTitleColor;}
			set
			{
				m_PanelAssLeftTitleColor = value;
				this.Invalidate();
			}
		}

		[Category("Style")]
		public Color PanelAssRightTitleColor
		{
			get{return m_PanelAssRightTitleColor;}
			set
			{
				m_PanelAssRightTitleColor = value;
				this.Invalidate();
			}
		}

		[Category("Style")]
		public Color PanelAssLeftOptionsColor
		{
			get{return m_PanelAssLeftOptionsColor;}
			set
			{
				m_PanelAssLeftOptionsColor = value;
				this.Invalidate();
			}
		}

		[Category("Style")]
		public Color PanelAssClientAreaColor
		{
			get{return m_PanelAssClientAreaColor;}
			set
			{
				m_PanelAssClientAreaColor = value;
				this.Invalidate();
			}
		}

		[Category("Style")]
		public Color PanelAssBottomAreaColor
		{
			get{return m_PanelAssBottomAreaColor;}
			set
			{
				m_PanelAssBottomAreaColor = value;
				this.Invalidate();
			}
		}

		[Browsable(false)]
		public new Color BackColor
		{
			get {return Color.Empty;}
			set {;}
		}

		[Browsable(false)]
		public new Color ForeColor
		{
			get {return Color.Empty;}
			set {;}
		}
		
		[Category("Appearance")]
		public virtual PanelTypes PanelType
		{
			get {return m_PanelTypes;}
			set
			{
				m_PanelTypes = value;

				if (m_PanelTypes == PanelTypes.LeftOptions) {this.Width = 81;}
				else if (m_PanelTypes == PanelTypes.TopOptions) {this.Height = 18;}
				else if (m_PanelTypes == PanelTypes.BottomArea) {this.Height = 25;}
				else if (m_PanelTypes == PanelTypes.AssLeftTitle) 
				{
					this.Width = 144;
					this.Height = 40;
				}
				else if (m_PanelTypes == PanelTypes.AssRightTitle) 
				{
					this.Height = 40;
				}
				else if (m_PanelTypes == PanelTypes.AssLeftOptions)
				{
					this.Width = 144;
				}
				else if (m_PanelTypes == PanelTypes.AssBottomArea)
				{
					this.Height = 24;
				}
			}
		}

		#endregion

		#region IFlashabledControl

		public void FlashControl()
		{
			foreach(Control m_Control in this.Controls)
			{
				if (m_Control is IFlashabledControl) 
				{
					((IFlashabledControl)m_Control).FlashControl();
				}
			}
		}
		
		#endregion
	}
}

