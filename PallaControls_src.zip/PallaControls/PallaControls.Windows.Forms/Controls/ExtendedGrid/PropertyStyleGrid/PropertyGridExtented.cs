using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using System.Reflection;

namespace ControlWare.Windows.Controls
{
	public class PropertyGridExtented : System.Windows.Forms.UserControl
	{
		private System.ComponentModel.Container components = null;

		public PropertyGridExtented()
		{
			InitializeComponent();
		}

		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Component Designer generated code
		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.panel1 = new System.Windows.Forms.Panel();
			this.propertyGrid = new Grid();
			this.panel1.SuspendLayout();
			this.SuspendLayout();
			// 
			// panel1
			// 
			this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.panel1.Controls.AddRange(new System.Windows.Forms.Control[] {
																				 this.propertyGrid});
			this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(352, 280);
			this.panel1.TabIndex = 0;
			// 
			// propertyGrid
			// 
			this.propertyGrid.AllowAutoSize = true;
			this.propertyGrid.AllowChangeCellHeight = true;
			this.propertyGrid.AllowChangeCellWidth = true;
			this.propertyGrid.AutoSizeMinHeight = 20;
			this.propertyGrid.AutoSizeMinWidth = 20;
			this.propertyGrid.BackColor = System.Drawing.Color.White;
			this.propertyGrid.CellsContainerCursor = System.Windows.Forms.Cursors.Default;
			this.propertyGrid.CellsContainerToolTipText = "";
			this.propertyGrid.Cols = 0;
			this.propertyGrid.CustomScrollArea = new System.Drawing.Size(0, 0);
			this.propertyGrid.CustomScrollPosition = new System.Drawing.Point(0, 0);
			this.propertyGrid.Dock = System.Windows.Forms.DockStyle.Fill;
			this.propertyGrid.FixedCols = 0;
			this.propertyGrid.FixedRows = 0;
			this.propertyGrid.GridScrollPosition = new System.Drawing.Point(0, 0);
			this.propertyGrid.Name = "propertyGrid";
			this.propertyGrid.Rows = 0;
			this.propertyGrid.SelectionMode = GridSelectionMode.Cell;
			this.propertyGrid.Size = new System.Drawing.Size(350, 278);
			this.propertyGrid.TabIndex = 5;
			this.propertyGrid.ToolTipActive = true;
			// 
			// PropertyGridEx
			// 
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.panel1});
			this.Name = "PropertyGridEx";
			this.Size = new System.Drawing.Size(352, 280);
			this.panel1.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		private System.Windows.Forms.Panel panel1;

		private Grid propertyGrid;

		public void LoadProperties(string[] pCaption, Type[] pObjectType, object[] pDefaultValue, bool pbUnloadCurrentObject)
		{
			if (pbUnloadCurrentObject)
				UnLoadProperties();
			InitGrid();
			for (int i = 0; i < pObjectType.Length; i++)
			{
				Cell l_CaptionCell;
				Cell l_ValueCell;
				if (pDefaultValue!=null)
					GetCells(pCaption[i],pObjectType[i],pDefaultValue[i],out l_CaptionCell, out l_ValueCell);
				else
					GetCells(pCaption[i],pObjectType[i],null,out l_CaptionCell, out l_ValueCell);
				int l_CurrentRow = propertyGrid.Rows;
				propertyGrid.AddRow(l_CurrentRow);
				propertyGrid[l_CurrentRow,0] = l_CaptionCell;
				propertyGrid[l_CurrentRow,1] = l_ValueCell;
			}
			EndGrid();
		}
		public void LoadProperties(object pObjectInstance)
		{
			LoadProperties(pObjectInstance,pObjectInstance.GetType().GetProperties());
		}
		public void LoadProperties(object pObjectInstance, PropertyInfo[] pProperties)
		{
			UnLoadProperties();
			InitGrid();
			for (int i = 0; i < pProperties.Length; i++)
			{
				if (IsBrowsable(pProperties[i]))
				{
					Cell l_CaptionCell;
					Cell l_ValueCell;
					GetCells(pProperties[i],pObjectInstance,out l_CaptionCell, out l_ValueCell);
					int l_CurrentRow = propertyGrid.Rows;
					propertyGrid.AddRow(l_CurrentRow);
					propertyGrid[l_CurrentRow,0] = l_CaptionCell;
					propertyGrid[l_CurrentRow,1] = l_ValueCell;
				}
			}
			EndGrid();
		}

		public void LoadProperties(ParameterInfo[] pParameters)
		{
			UnLoadProperties();
			InitGrid();
			for (int i = 0; i < pParameters.Length; i++)
			{
				if (IsBrowsable(pParameters[i]))
				{
					Cell l_CaptionCell;
					Cell l_ValueCell;
					GetCells(pParameters[i],out l_CaptionCell, out l_ValueCell);
					int l_CurrentRow = propertyGrid.Rows;
					propertyGrid.AddRow(l_CurrentRow);
					propertyGrid[l_CurrentRow,0] = l_CaptionCell;
					propertyGrid[l_CurrentRow,1] = l_ValueCell;
				}
			}
			EndGrid();
		}

		public object[] GetValues()
		{
			object[] l_Objs = new object[propertyGrid.Rows];
			for (int r = 0; r < l_Objs.Length; r++)
			{
				l_Objs[r] = propertyGrid[r,1].Value;
			}
			return l_Objs;
		}

		public void UnLoadProperties()
		{
			ClearObjectProperties();
		}

		protected virtual void ClearObjectProperties()
		{
			propertyGrid.Redim(0,0);
		}

		protected virtual void InitGrid()
		{
			propertyGrid.Cols = 2;
			propertyGrid.SelectionMode = GridSelectionMode.Row;
		}

		protected virtual void EndGrid()
		{
			propertyGrid.SetColWidth(0,130);
			propertyGrid.SetColWidth(1,Math.Max(100,propertyGrid.Width-propertyGrid.GetColWidth(0)-30));
		}

		private TypeCreator m_Typereator = new TypeCreator();
		public TypeCreator TypeCreator
		{
			get{return m_Typereator;}
			set{m_Typereator = value;}
		}

		#region Property
		protected virtual void GetCells(PropertyInfo pInfo, object pObjectInstance, out Cell pCaptionCell, out Cell paramValueCell)
		{
			pCaptionCell = new Cell(pInfo.Name);
			pCaptionCell.ToolTipText = pInfo.Name + "("+ pInfo.PropertyType.ToString() + ")";
			pCaptionCell.TextAlignment = ContentAlignment.MiddleLeft;
			pCaptionCell.BackColor = Color.WhiteSmoke;

			try
			{
				//se pu� leggere e puo scrivere o � un reference type
				if (pInfo.CanWrite || pInfo.PropertyType.IsValueType==false )
				{
					paramValueCell = new CellCustom(pInfo.PropertyType,
						new CellFormatterTypeConverter(System.ComponentModel.TypeDescriptor.GetConverter(pInfo.PropertyType)),
						(System.Drawing.Design.UITypeEditor)System.ComponentModel.TypeDescriptor.GetEditor(pInfo.PropertyType,typeof(System.Drawing.Design.UITypeEditor)),
						pInfo.GetValue(pObjectInstance,null),
						pInfo.GetValue(pObjectInstance,null),
						TypeCreator);

					if (pInfo.CanWrite)
						((CellCustom)paramValueCell).BindValueAtProperty(pInfo,pObjectInstance);

					paramValueCell.TextAlignment = ContentAlignment.MiddleLeft;
				}
				else
					paramValueCell = new Cell(pInfo.GetValue(pObjectInstance,null));

				paramValueCell.TextAlignment = ContentAlignment.MiddleLeft;
			}
			catch(Exception err)
			{
				paramValueCell = new Cell(err.Message);
				paramValueCell.TextAlignment = ContentAlignment.MiddleLeft;
			}
		}

		protected virtual bool IsBrowsable(PropertyInfo pInfo)
		{
			object[] l_browsable = pInfo.GetCustomAttributes(typeof(BrowsableAttribute),true);
			for (int i = 0; i < l_browsable.Length; i++)
			{
				BrowsableAttribute l_attribute = (BrowsableAttribute)l_browsable[i];
				if (l_attribute.Browsable == false)
					return false;
			}
			if (pInfo.CanRead)
				return true;
			else
				return false;
		}

		#endregion

		#region Parameter
		protected virtual void GetCells(ParameterInfo pInfo, out Cell pCaptionCell, out Cell paramValueCell)
		{
			pCaptionCell = new Cell(pInfo.Name);
			pCaptionCell.ToolTipText = pInfo.Name + "("+ pInfo.ParameterType.ToString() + ")";
			pCaptionCell.TextAlignment = ContentAlignment.MiddleLeft;
			pCaptionCell.BackColor = Color.WhiteSmoke;

			try
			{
				//if (pInfo.IsIn) //This method depends on an optional metadata flag. This flag can be inserted by compilers, but the compilers are not obligated to do so

				object l_DefaultValue = null;
				if (pInfo.ParameterType.IsValueType)
					l_DefaultValue = Activator.CreateInstance(pInfo.ParameterType);

				paramValueCell = new CellCustom(pInfo.ParameterType,
					new CellFormatterTypeConverter(System.ComponentModel.TypeDescriptor.GetConverter(pInfo.ParameterType)),
					(System.Drawing.Design.UITypeEditor)System.ComponentModel.TypeDescriptor.GetEditor(pInfo.ParameterType,typeof(System.Drawing.Design.UITypeEditor)),
					l_DefaultValue,
					l_DefaultValue,
					TypeCreator);

				paramValueCell.TextAlignment = ContentAlignment.MiddleLeft;
			}
			catch(Exception err)
			{
				paramValueCell = new Cell(err.Message);
				paramValueCell.TextAlignment = ContentAlignment.MiddleLeft;
			}
		}

		protected virtual bool IsBrowsable(ParameterInfo pInfo)
		{
			return true;
		}
		#endregion

		#region CustomType
		protected virtual void GetCells(string pCaption, Type pType, object pDefaultValue, out Cell pCaptionCell, out Cell paramValueCell)
		{
			pCaptionCell = new Cell(pCaption);
			pCaptionCell.ToolTipText = pCaption + "("+ pType.ToString() + ")";
			pCaptionCell.TextAlignment = ContentAlignment.MiddleLeft;
			pCaptionCell.BackColor = Color.WhiteSmoke;

			try
			{
				/*object l_DefaultValue = null;
				if (pType.IsValueType)
					l_DefaultValue = Activator.CreateInstance(pType);*/

				paramValueCell = new CellCustom(pType,
					new CellFormatterTypeConverter(System.ComponentModel.TypeDescriptor.GetConverter(pType)),
					(System.Drawing.Design.UITypeEditor)System.ComponentModel.TypeDescriptor.GetEditor(pType,typeof(System.Drawing.Design.UITypeEditor)),
					pDefaultValue,
					pDefaultValue,
					TypeCreator);

				paramValueCell.TextAlignment = ContentAlignment.MiddleLeft;
			}
			catch(Exception err)
			{
				paramValueCell = new Cell(err.Message);
				paramValueCell.TextAlignment = ContentAlignment.MiddleLeft;
			}
		}
		#endregion
	}
}
