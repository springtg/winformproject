using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;
using ControlWare.Windows.Controls.Helpers;
using ControlWare.Windows.Controls.Collections;

namespace ControlWare.Windows.Controls
{
	public class Cell
	{
		public Cell():this(new CellFormatterBase())
		{
		}

		public Cell(object paramValue):this(paramValue, new CellFormatterBase())
		{
		}
		public Cell(object paramValue, ICellFormatter formatter):this(formatter)
		{
			Value = paramValue;
		}
		public Cell(ICellFormatter formatter)
		{
			TopBorder = new Border(Color.LightGray,1);
			BottomBorder = new Border(Color.LightGray,1);
			LeftBorder = new Border(Color.LightGray,1);
			RightBorder = new Border(Color.LightGray,1);
			FocusBorder = new Border(Color.FromKnownColor(KnownColor.Highlight),2);

			CellFormatter = formatter;
		}

		private ContentAlignment m_TextAlignment = ContentAlignment.MiddleCenter;
		public ContentAlignment TextAlignment
		{
			get{return m_TextAlignment;}
			set
			{
				m_TextAlignment = value;
				RaiseInvalidate();
			}
		}

		public void SetAllBorderColor(Color pColor)
		{
			m_TopBorder.Color = pColor;
			m_BottomBorder.Color = pColor;
			m_LeftBorder.Color = pColor;
			m_RightBorder.Color = pColor;
		}
		public void SetAllBorderWidth(int pWidth)
		{
			m_TopBorder.Width = pWidth;
			m_BottomBorder.Width = pWidth;
			m_LeftBorder.Width = pWidth;
			m_RightBorder.Width = pWidth;
		}

		private Border m_FocusBorder = null;
		public Border FocusBorder
		{
			get{return m_FocusBorder;}
			set
			{
				if (value==null)
					throw new ArgumentNullException("Border");
				if (m_FocusBorder!=null)
					m_FocusBorder.Change-=new EventHandler(Border_Change);
				m_FocusBorder = value;
				m_FocusBorder.Change+=new EventHandler(Border_Change);
				RaiseInvalidate();
			}		
		}

		private Border m_TopBorder = null;
		public Border TopBorder
		{
			get{return m_TopBorder;}
			set
			{
				if (value==null)
					throw new ArgumentNullException("Border");
				if (m_TopBorder!=null)
					m_TopBorder.Change-=new EventHandler(Border_Change);
				m_TopBorder = value;
				m_TopBorder.Change+=new EventHandler(Border_Change);
				RaiseInvalidate();
			}
		}

		private Border m_BottomBorder = null;
		public Border BottomBorder
		{
			get{return m_BottomBorder;}
			set
			{
				if (value==null)
					throw new ArgumentNullException("Border");
				if (m_BottomBorder!=null)
					m_BottomBorder.Change-=new EventHandler(Border_Change);
				m_BottomBorder = value;
				m_BottomBorder.Change+=new EventHandler(Border_Change);
				RaiseInvalidate();
			}
		}
		
		private Border m_LeftBorder = null;
		public Border LeftBorder
		{
			get{return m_LeftBorder;}
			set
			{
				if (value==null)
					throw new ArgumentNullException("Border");
				if (m_LeftBorder!=null)
					m_LeftBorder.Change-=new EventHandler(Border_Change);
				m_LeftBorder = value;
				m_LeftBorder.Change+=new EventHandler(Border_Change);
				RaiseInvalidate();
			}
		}

		private Border m_RightBorder = null;
		public Border RightBorder
		{
			get{return m_RightBorder;}
			set
			{
				if (value==null)
					throw new ArgumentNullException("Border");
				if (m_RightBorder!=null)
					m_RightBorder.Change-=new EventHandler(Border_Change);
				m_RightBorder = value;
				m_RightBorder.Change+=new EventHandler(Border_Change);
				RaiseInvalidate();
			}
		}

		private Font m_Font = new Font(FontFamily.GenericSansSerif,8.25f);
		public Font Font
		{
			get{return m_Font;}
			set{m_Font = value;}
		}

		private Color m_BackColor = Color.FromKnownColor(KnownColor.Window); 
		public Color BackColor
		{
			get{return m_BackColor;}
			set{m_BackColor = value;RaiseInvalidate();}
		}
		private Color m_ForeColor = Color.FromKnownColor(KnownColor.WindowText); 
		public Color ForeColor
		{
			get{return m_ForeColor;}
			set{m_ForeColor = value;}
		}

		private Color m_SelectionForeColor = Color.FromKnownColor(KnownColor.HighlightText); 
		public Color SelectionForeColor
		{
			get{return m_SelectionForeColor;}
			set{m_SelectionForeColor = value;}
		}

		private Color m_SelectionBackColor = Color.FromKnownColor(KnownColor.Highlight); 
		public Color SelectionBackColor
		{
			get{return m_SelectionBackColor;}
			set{m_SelectionBackColor = value;}
		}
	
		private Cursor m_Cursor = null;
		public Cursor Cursor
		{
			get{return m_Cursor;}
			set{m_Cursor = value;}
		}

		private Image m_Image = null;
		public Image Image
		{
			get{return m_Image;}
			set
			{
				m_Image = value;
				RaiseInvalidate();
			}
		}
		private bool m_ImageStretch = false;
		public bool ImageStretch
		{
			get{return m_ImageStretch;}
			set{m_ImageStretch = value;}
		}

		private ContentAlignment m_ImageAlignment = ContentAlignment.MiddleLeft;
		public ContentAlignment ImageAlignment
		{
			get{return m_ImageAlignment;}
			set
			{
				m_ImageAlignment = value;
				RaiseInvalidate();
			}
		}

		private Grid m_Grid;
		public virtual Grid Grid
		{
			get{return m_Grid;}
		}
		public virtual void BindToGrid(Grid pgrid)
		{
			m_Grid = pgrid;
			OnAddToGrid(new EventArgs());
		}
		public virtual void UnBindToGrid()
		{
			OnRemoveToGrid(new EventArgs());
			m_Grid = null;
		}

		private int m_Row = -1;
		public int Row
		{
			get{return m_Row;}
			set
			{
				if (value != m_Row)
				{
					m_Row = value;
					OnRowChange(new EventArgs());
				}
			}
		}
		private int m_Col = -1;
		public int Col
		{
			get{return m_Col;}
			set
			{
				if (value != m_Col)
				{
					m_Col = value;
					OnColChange(new EventArgs());
				}
			}
		}

		private int m_RowSpan = 1;
		private int m_ColSpan = 1;
		public int ColSpan
		{
			get{return m_ColSpan;}
			set
			{
				m_ColSpan = value;
				RaiseInvalidate();
			}
		}
		public int RowSpan
		{
			get{return m_RowSpan;}
			set
			{
				m_RowSpan = value;
				RaiseInvalidate();
			}
		}

		protected virtual void OnRowChange(EventArgs e)
		{
		}
		protected virtual void OnColChange(EventArgs e)
		{
		}

		public event InvalidateEventHandler Invalidated;
		protected virtual void OnInvalidated(InvalidateEventArgs e)
		{
			if (Invalidated!= null)
				Invalidated(this,e);
		}

		protected void Border_Change(object sender, EventArgs e)
		{
			RaiseInvalidate();
		}

		public virtual string DisplayText
		{
			get
			{
				try
				{
					if (CellFormatter.SupportStringConversion)
						return CellFormatter.ObjectToString(Value);
					else
						return CellFormatter.GetStringRappresentation(Value);
				}
				catch(Exception err)
				{
					return "Error:"+err.Message;
				}
			}
		}

		private object m_Value = null;
		public virtual object Value
		{
			get{return m_Value;}
			set
			{
				if (m_Value != value)
				{
					m_Value = value;
					OnValueChanged(new EventArgs());
					RaiseInvalidate();
				}
			}
		}

		private ICellFormatter m_CellFormatter;
		public ICellFormatter CellFormatter
		{
			get{return m_CellFormatter;}
			set
			{
				if (value==null)
					throw new ArgumentNullException("CellFormatter");
				m_CellFormatter = value;
			}
		}

		public event EventHandler ValueChanged;
		protected virtual void OnValueChanged(EventArgs e)
		{
			if (ValueChanged!=null)
				ValueChanged(this,e);
		}

		private object m_Tag = null;
		public virtual object Tag
		{
			get{return m_Tag;}
			set{m_Tag = value;}
		}

		private EditableMode m_EditableMode = EditableMode.F2Key|EditableMode.DoubleClick;
		public EditableMode EditableMode
		{
			get{return m_EditableMode;}
			set
			{
				m_EditableMode = value;
				RaiseInvalidate();
			}
		}

		private ICellEditor m_CellEditor = null;
		public ICellEditor CellEditor
		{
			get{return m_CellEditor;}
			set
			{
				m_CellEditor = value;
				RaiseInvalidate();
				if (m_CellEditor!=null)
					m_CellEditor.Cell = this;
			}
		}

		public const int DefaultHeight = 20;
		public const int DefaultWidth = 50;

		public Rectangle AbsoluteRectangle
		{
			get
			{
				if (m_Grid != null)
					return m_Grid.GetCellAbsoluteRectangle(m_Row,m_Col,m_RowSpan,m_ColSpan);
				else
					return new Rectangle(0,0,0,0);
			}
		}

		public Rectangle DisplayRectangle
		{
			get
			{
				if (m_Grid != null)
					return m_Grid.GetCellDisplayRectangle(m_Row,m_Col,m_RowSpan,m_ColSpan);
				else
					return new Rectangle(0,0,0,0);
			}
		}

		public virtual bool IsInDisplayRegion(Rectangle pDisplayRectangle)
		{
			Rectangle l_rc = DisplayRectangle;

			return l_rc.IntersectsWith(pDisplayRectangle);
		}

		protected static PointF GetObjAlignment(ContentAlignment pAlign, int pClientLeft, int pClientTop, int pClientWidth, int pClientHeight, float pObjWidth, float pObjHeight)
		{
			PointF l_pointf = new PointF((float)pClientLeft,(float)pClientTop);

			if (pAlign == ContentAlignment.TopCenter ||
				pAlign == ContentAlignment.TopLeft ||
				pAlign == ContentAlignment.TopRight) 
				l_pointf.Y = (float)pClientTop;
			else if (pAlign == ContentAlignment.BottomCenter ||
				pAlign == ContentAlignment.BottomLeft ||
				pAlign == ContentAlignment.BottomRight) 
				l_pointf.Y = (float)pClientTop + ((float)pClientHeight) - pObjHeight;
			else 
				l_pointf.Y = (float)pClientTop + ((float)pClientHeight)/2.0F - pObjHeight/2.0F;

			if ( pAlign == ContentAlignment.BottomCenter ||
				pAlign == ContentAlignment.MiddleCenter ||
				pAlign == ContentAlignment.TopCenter)
				l_pointf.X = (float)pClientLeft + ((float)pClientWidth)/2.0F - pObjWidth/2.0F;
			else if (pAlign == ContentAlignment.BottomRight ||
				pAlign == ContentAlignment.MiddleRight ||
				pAlign == ContentAlignment.TopRight)
				l_pointf.X = (float)pClientLeft + (float)pClientWidth - pObjWidth;

			return l_pointf;
		}

		public void StartEdit(object pNewStartEditValue)
		{
			try
			{
				if (IsEditing == false && Focus())
				{
					if (m_CellEditor != null)
					{
						m_CellEditor.StartEdit(pNewStartEditValue);
					}
					RaiseInvalidate();
				}
			}
			catch(Exception err)
			{
				MessageBox.Show(err.Message,"Error");
			}
		}
		public void StartEdit()
		{
			StartEdit(null);
		}

		public bool EndEdit(bool pbCancel)
		{
			bool l_success = true;
			try
			{
				if (IsEditing)
				{
					if (m_CellEditor != null)
					{
						l_success = m_CellEditor.EndEdit(pbCancel);
					}
					else
						l_success = true;
				}
				else
					l_success = true;
			}
			catch(Exception)
			{
				l_success = false;
			}
			RaiseInvalidate();
			return l_success;
		}

		public bool IsEditing
		{
			get
			{
				if (m_CellEditor!=null)
					return m_CellEditor.IsEditing;
				else
					return false;
			}
		}

		public override string ToString()
		{
			return DisplayText;
		}

		private MenuCollection m_ContextMenuItems = new MenuCollection();
		public MenuCollection ContextMenuItems
		{
			get{return m_ContextMenuItems;}
			set{m_ContextMenuItems = value;}
		}

		public virtual void ContextMenuPopup(EventArgs e)
		{
		}

		public virtual CellFormat GetCellFormat()
		{
			CellFormat l_format = new CellFormat();
			l_format.Font = (Font)Font.Clone();
			l_format.BackColor = BackColor;
			l_format.Cursor = Cursor;
			l_format.ForeColor = ForeColor;
			l_format.SelectionBackColor = SelectionBackColor;
			l_format.TextAlignment = TextAlignment;
			l_format.Image = Image;
			l_format.ImageAlignment = ImageAlignment;
			l_format.TopBorder = (Border)TopBorder.Clone();
			l_format.LeftBorder = (Border)LeftBorder.Clone();
			l_format.RightBorder = (Border)RightBorder.Clone();
			l_format.BottomBorder = (Border)BottomBorder.Clone();
			l_format.FocusBorder = (Border)FocusBorder.Clone();
			l_format.SelectionForeColor = SelectionForeColor;
			l_format.ImageStretch = ImageStretch;

			return l_format;
		}

		public virtual void ApplyCellFormat(CellFormat pFormat)
		{
			Font = (Font)pFormat.Font.Clone();
			BackColor = pFormat.BackColor;
			Cursor = pFormat.Cursor;
			ForeColor = pFormat.ForeColor;
			SelectionBackColor = pFormat.SelectionBackColor;
			TextAlignment = pFormat.TextAlignment;
			Image = pFormat.Image;
			ImageAlignment = pFormat.ImageAlignment;
			TopBorder = (Border)pFormat.TopBorder.Clone();
			LeftBorder = (Border)pFormat.LeftBorder.Clone();
			RightBorder = (Border)pFormat.RightBorder.Clone();
			BottomBorder = (Border)pFormat.BottomBorder.Clone();
			FocusBorder = (Border)pFormat.FocusBorder.Clone();
			SelectionForeColor = pFormat.SelectionForeColor;
			ImageStretch = pFormat.ImageStretch;

		}

		public virtual Size GetRequiredSize(Graphics g)
		{
			SizeF l_fontSize;
			if (DisplayText != null)
				l_fontSize = g.MeasureString(DisplayText,Font);
			else
				l_fontSize = new SizeF(2,2);
			if (m_Image != null)
			{
				if (m_Image.Height > l_fontSize.Height)
					l_fontSize.Height = m_Image.Height;
				if (m_Image.Width > l_fontSize.Width)
					l_fontSize.Width = m_Image.Width;
			}
			l_fontSize.Width += m_LeftBorder.Width+m_RightBorder.Width + 2; 
			l_fontSize.Height += m_TopBorder.Width+m_BottomBorder.Width + 2; 
	
			return l_fontSize.ToSize();
		}

		public void RaiseInvalidate()
		{
			if (m_Grid != null)
			{
				OnInvalidated(new InvalidateEventArgs(DisplayRectangle));
			}
		}

		public virtual void RaisePaint(PaintEventArgs e)
		{
			if (IsInDisplayRegion(e.ClipRectangle))
			{
				Graphics g = e.Graphics;

				Region l_OldClip = g.Clip;
				g.Clip = new Region(DisplayRectangle);

				if (IsEditing == false)
				{
					Rectangle l_rc = DisplayRectangle;
					int l_left = l_rc.X;
					int l_top = l_rc.Y;
					int l_width = l_rc.Width;
					int l_height = l_rc.Height;

					if (!Select && !Focused)
					{
						using (SolidBrush br = new SolidBrush(BackColor))
						{
							g.FillRectangle(br,l_rc);
						}
					}
					else
					{
						if (Focused) 
						{
							using (SolidBrush br = new SolidBrush(BackColor))
							{
								g.FillRectangle(br,l_rc);
							}
							using (Pen p = new Pen(m_FocusBorder.Color,m_FocusBorder.Width))
						    {
								GraphicsUtils.DrawRectangleWithExternBound(g,p,l_rc);
							}
						}
						else 
						{
							using (SolidBrush br = new SolidBrush(SelectionBackColor))
							{
								g.FillRectangle(br,l_rc);
							}
						}
					}

					Pen l_CurrentPen = new Pen(m_TopBorder.Color,m_TopBorder.Width);

					if (m_TopBorder.Width>0)
						g.DrawLine(l_CurrentPen,
							l_left,l_top,l_left + l_width-m_LeftBorder.Width,l_top);

					if (m_BottomBorder.Width>0)
					{
						if (l_CurrentPen.Color!=m_BottomBorder.Color || l_CurrentPen.Width != m_BottomBorder.Width)
						{
							l_CurrentPen.Width = m_BottomBorder.Width;
							l_CurrentPen.Color = m_BottomBorder.Color;
						}
						g.DrawLine(l_CurrentPen,
							l_left+m_RightBorder.Width,l_top+l_height-m_BottomBorder.Width,l_left+l_width-m_LeftBorder.Width,l_top+l_height-m_BottomBorder.Width);
					}

					if (m_RightBorder.Width>0)
					{
						if (l_CurrentPen.Color!=m_RightBorder.Color || l_CurrentPen.Width != m_RightBorder.Width)
						{
							l_CurrentPen.Color = m_RightBorder.Color;
							l_CurrentPen.Width = m_RightBorder.Width;
						}
						g.DrawLine(l_CurrentPen,
							l_left+l_width-m_LeftBorder.Width,l_top,l_left+l_width-m_LeftBorder.Width,l_top+l_height);
					}

					if (m_LeftBorder.Width>0)
					{
						if (l_CurrentPen.Color!=m_LeftBorder.Color || l_CurrentPen.Width != m_LeftBorder.Width)
						{
							l_CurrentPen.Color = m_LeftBorder.Color;
							l_CurrentPen.Width = m_LeftBorder.Width;
						}
						g.DrawLine(l_CurrentPen,
							l_left,l_top,l_left,l_top+l_height);
					}
					l_CurrentPen.Dispose();
					l_CurrentPen = null;

					if (DisplayText != null && DisplayText.Length>0 && l_width > 2 && l_height > 2)
					{
						SizeF l_fontSize = g.MeasureString(DisplayText,Font);
						
						if (Select && Focused==false) 
						{
							using (SolidBrush br = new SolidBrush(SelectionForeColor))
							{
								g.DrawString(DisplayText,
									Font,
									br,
									GetObjAlignment(m_TextAlignment,l_left,l_top,l_width,l_height,l_fontSize.Width,l_fontSize.Height));
							}
						}
						else
						{
							using (SolidBrush br = new SolidBrush(ForeColor))
							{
								g.DrawString(DisplayText,
									Font,
									br,
									GetObjAlignment(m_TextAlignment,l_left,l_top,l_width,l_height,l_fontSize.Width,l_fontSize.Height));
							}
						}
					}

					if (m_Image != null)
					{
						if (m_ImageStretch) 
						{
							PointF l_PointImage = GetObjAlignment(m_ImageAlignment,l_left,l_top,l_width,l_height,l_width,l_height);
							g.DrawImage(m_Image,l_PointImage.X,l_PointImage.Y,l_width,l_height);
						}
						else
						{
							PointF l_PointImage = GetObjAlignment(m_ImageAlignment,l_left,l_top,l_width,l_height,m_Image.Width,m_Image.Height);
							g.DrawImage(m_Image,l_PointImage.X,l_PointImage.Y);
						}
					}
				}

				g.Clip = l_OldClip;
			}
		}

		public event MouseEventHandler MouseDown;
		public event MouseEventHandler MouseUp;
		public event MouseEventHandler MouseMove;
		public event EventHandler MouseEnter;
		public event EventHandler MouseLeave;

		public virtual void RaiseMouseDown(MouseEventArgs e)
		{
			if (Select==false||e.Button==MouseButtons.Left) 
				Focus();

			if (MouseDown != null)
				MouseDown(this,e);
		}
		public virtual void RaiseMouseUp(MouseEventArgs e)
		{
			if (MouseUp != null)
				MouseUp(this,e);
		}

		public virtual void RaiseMouseMove(MouseEventArgs e)
		{
			if (MouseMove != null)
				MouseMove(this,e);
		}

		private Cursor m_OldCursor = null;
		private string m_OldToolTipText = null;
		

		public virtual void RaiseMouseEnter(EventArgs e)
		{
			if (m_Cursor != null)
			{
				m_OldCursor = m_Grid.CellsContainerCursor;
				m_Grid.CellsContainerCursor = m_Cursor;
			}
			if (ToolTipText!=null && ToolTipText.Length > 0)
			{
				m_OldToolTipText = m_Grid.CellsContainerToolTipText;
				m_Grid.CellsContainerToolTipText = ToolTipText;
			}

			if (MouseEnter!=null)
				MouseEnter(this,e);
		}
		public virtual void RaiseMouseLeave(EventArgs e)
		{
			if (m_OldCursor != null)
			{
				m_Grid.CellsContainerCursor = m_OldCursor;
				m_OldCursor = null;
			}
			if (m_OldToolTipText!=null)
			{
				m_Grid.CellsContainerToolTipText = m_OldToolTipText;
				m_OldToolTipText = null;
			}

			if (MouseLeave!=null)
				MouseLeave(this,e);
		}

		public virtual void RaiseKeyUp ( KeyEventArgs e)
		{
			if (KeyUp!=null)
				KeyUp(this,e);
		}
		public virtual void RaiseKeyPress ( KeyPressEventArgs e)
		{
			if (KeyPress!=null)
				KeyPress(this,e);
			if ( (m_EditableMode & EditableMode.AnyKey) == EditableMode.AnyKey && IsEditing == false)
			{
				StartEdit(e.KeyChar.ToString());
			}
		}
		public event KeyPressEventHandler KeyPress;
		public virtual void RaiseKeyDown ( KeyEventArgs e)
		{
			if (KeyDown!=null)
				KeyDown(this,e);

			if (e.KeyCode == Keys.F2 && ((m_EditableMode & EditableMode.F2Key) == EditableMode.F2Key))
				StartEdit();

			if (e.KeyCode == Keys.Delete && IsEditing == false && m_CellEditor != null)
			{
				m_CellEditor.ClearCell();
			}
		}

		public event KeyEventHandler KeyDown;
		public event KeyEventHandler KeyUp;

		public virtual void RaiseDoubleClick ()
		{
			if (DoubleClick!=null)
				DoubleClick(this,new EventArgs());
			if ((m_EditableMode & EditableMode.DoubleClick) == EditableMode.DoubleClick)
				StartEdit();
		}
		public virtual void RaiseClick ()
		{
			if (Click!=null)
				Click(this,new EventArgs());
			if ((m_EditableMode & EditableMode.SingleClick) == EditableMode.SingleClick)
				StartEdit();
		}

		public event EventHandler Click;
		public event EventHandler DoubleClick;

		public event EventHandler SelectionChange;
		protected void OnSelectionChange(EventArgs e)
		{
			if (SelectionChange!=null)
				SelectionChange(this,e);
		}

		private bool m_isSelect = false;
		public bool Select
		{
			get{return m_isSelect;}
			set
			{
				if (m_isSelect != value)
				{
					m_isSelect = value;
					OnSelectionChange(new EventArgs());
					RaiseInvalidate();
				}
			}
		}

		private bool m_Focused = false;
		public bool Focused
		{
			get{return m_Focused;}
		}

		public virtual bool Focus()
		{
			if (Focused==false)
			{
				m_Focused = m_Grid.SetFocusOnCellsContainer();

				if (m_Focused==true)
				{
					if (m_Grid.FocusCell!=null)
					{
						if (m_Grid.FocusCell.LeaveFocus())
						{
							OnFocusChange(new EventArgs());
							RaiseInvalidate();
						}
						else
							m_Focused = false;
					}
					else
					{
						OnFocusChange(new EventArgs());
						RaiseInvalidate();
					}
				}
			}
			return m_Focused;
		}
		
		public virtual bool LeaveFocus()
		{
			if (Focused == true)
			{
				m_Focused = !(EndEdit(false));

				if (m_Focused==false)
				{
					OnFocusChange(new EventArgs());
					RaiseInvalidate();
				}
			}
			return (!m_Focused);
		}

		public event EventHandler FocusChange;
		protected virtual void OnFocusChange(EventArgs e)
		{
			if (FocusChange != null)
				FocusChange(this,e);
		}

		protected virtual void OnAddToGrid(EventArgs e)
		{
			if (AddToGrid!=null)
				AddToGrid(this,e);
		}
		public event EventHandler AddToGrid;
		protected virtual void OnRemoveToGrid(EventArgs e)
		{
			if (RemoveToGrid!=null)
				RemoveToGrid(this,e);
		}
		public event EventHandler RemoveToGrid;
		
		private string m_ToolTipText = "";
		public virtual string ToolTipText
		{
			get{return m_ToolTipText;}
			set{m_ToolTipText = value;}
		}

		public static void FormatBorder(Cell paramCell, CommonBorderStyle pStyle, float pwidth, Color pShadowColor, Color pLightColor)
		{
			paramCell.TopBorder.Width = pwidth;
			paramCell.LeftBorder.Width = pwidth;
			paramCell.BottomBorder.Width = pwidth;
			paramCell.RightBorder.Width = pwidth;

			if (pStyle == CommonBorderStyle.Inset)
			{
				paramCell.TopBorder.Color = pShadowColor;
				paramCell.LeftBorder.Color = pShadowColor;
				paramCell.BottomBorder.Color = pLightColor;
				paramCell.RightBorder.Color = pLightColor;
			}
			else if (pStyle == CommonBorderStyle.Raised)
			{
				paramCell.TopBorder.Color = pLightColor;
				paramCell.LeftBorder.Color = pLightColor;
				paramCell.BottomBorder.Color = pShadowColor;
				paramCell.RightBorder.Color = pShadowColor;
			}
			else
			{
				paramCell.TopBorder.Color = pShadowColor;
				paramCell.LeftBorder.Color = pShadowColor;
				paramCell.BottomBorder.Color = pShadowColor;
				paramCell.RightBorder.Color = pShadowColor;
			}
		}
	}
}
