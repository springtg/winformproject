using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;
using ControlWare.Windows.Controls.Helpers;
using ControlWare.Windows.Controls.Collections;

namespace ControlWare.Windows.Controls
{
	public class Grid : CustomScrollControl
	{
		private System.ComponentModel.IContainer components;
		private System.Windows.Forms.ImageList imageListCommon;
		private BackContainer backContainer;
		private ControlWare.Windows.Controls.Helpers.MenuImageHelper m_MenuImage;

		public Grid()
		{
			InitializeComponent();

			backContainer.Grid = this;

			m_Selection = new Selection(this);

			base.ContextMenu = new ContextMenu();
			base.ContextMenu.Popup += new EventHandler(ContextMenuPopup);
			m_MenuImage.ImageList = imageListCommon;

			backContainer.Paint += new PaintEventHandler(BackContainer_Paint);
			backContainer.MouseDown += new MouseEventHandler(BackContainer_MouseDown);
			backContainer.MouseUp += new MouseEventHandler(BackContainer_MouseUp);
			backContainer.MouseMove += new MouseEventHandler(BackContainer_MouseMove);
			backContainer.Click += new EventHandler(BackContainer_Click);
			backContainer.DoubleClick += new EventHandler(BackContainer_DoubleClick);
			backContainer.MouseLeave += new EventHandler(BackContainer_MouseLeave);
			backContainer.KeyDown += new KeyEventHandler(BackContainer_KeyDown);
			backContainer.KeyUp += new KeyEventHandler(BackContainer_KeyUp);
			backContainer.KeyPress += new KeyPressEventHandler(BackContainer_KeyPress);
		}

		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Component Designer generated code
		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			this.imageListCommon = new System.Windows.Forms.ImageList(this.components);
			this.m_MenuImage = new ControlWare.Windows.Controls.Helpers.MenuImageHelper(this.components);
			this.backContainer = new BackContainer();
			this.SuspendLayout();
			// 
			// imageListCommon
			// 
			this.imageListCommon.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit;
			this.imageListCommon.ImageSize = new System.Drawing.Size(16, 16);
			this.imageListCommon.TransparentColor = System.Drawing.Color.Transparent;
			// 
			// m_MenuImage
			// 
			this.m_MenuImage.ImageList = null;
			// 
			// backContainer
			// 
			this.backContainer.AutoScroll = false;
			this.backContainer.Dock = System.Windows.Forms.DockStyle.Fill;
			this.backContainer.Grid = null;
			this.backContainer.Name = "backContainer";
			this.backContainer.Size = new System.Drawing.Size(200, 200);
			this.backContainer.TabIndex = 0;
			this.backContainer.ToolTipActive = true;
			this.backContainer.ToolTipText = "";
			// 
			// Grid
			// 
			this.BackColor = System.Drawing.Color.White;
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.backContainer});
			this.Name = "Grid";
			this.Size = new System.Drawing.Size(200, 200);
			this.ResumeLayout(false);

		}
		#endregion

		public int AddMenuImage(Image pImage)
		{
			imageListCommon.Images.Add(pImage);
			return imageListCommon.Images.Count-1;
		}

		public void SetMenuImage(MenuItem pMenu, int pimageIndex)
		{
			m_MenuImage.SetMenuImage(pMenu,pimageIndex.ToString());
		}
		public void SetMenuImage(MenuItem pMenu, Image pimage)
		{
			m_MenuImage.SetMenuImage(pMenu,AddMenuImage(pimage).ToString());
		}

		private void ContextMenuPopup(object sender, EventArgs e)
		{
			OnContextMenuPopup(e);
		}

		private ContextMenu  m_OriginalContextMenu = null;
		public override ContextMenu ContextMenu
		{
			get{return m_OriginalContextMenu;}
			set{m_OriginalContextMenu = value;}
		}

		protected virtual void OnContextMenuPopup(EventArgs e)
		{
			base.ContextMenu.MenuItems.Clear();

			m_Selection.ContextMenuPopup(e);
			if (m_Selection.ContextMenuItems != null)
			{
				base.ContextMenu.MenuItems.AddRange(m_Selection.ContextMenuItems);
			}

			if (m_FocusCell != null)
			{
				m_FocusCell.ContextMenuPopup(e);

				if (m_FocusCell.ContextMenuItems != null && m_FocusCell.ContextMenuItems.Count > 0)
				{
					MenuItem l_menuBreak = new MenuItem("-");
					base.ContextMenu.MenuItems.Add(l_menuBreak);

					foreach (MenuItem m in m_FocusCell.ContextMenuItems)
						base.ContextMenu.MenuItems.Add(m);
				}
			}
			
			if ((m_bAllowChangeCellHeight == true || mbAllowChangeCellWidth == true)
				&& (m_Rows > 0 || m_Cols > 0) )
			{
				MenuItem l_menuBreak = new MenuItem("-");
				base.ContextMenu.MenuItems.Add(l_menuBreak);
				if (m_bAllowChangeCellHeight)
				{
					base.ContextMenu.MenuItems.Add(new MenuItem("Column Width ...",new EventHandler(Menu_ColumnWidth)));
				}
				if (m_bAllowChangeCellHeight)
				{
					base.ContextMenu.MenuItems.Add(new MenuItem("Row Height ...",new EventHandler(Menu_RowHeight)));
				}
				MenuItem l_menuBreak2 = new MenuItem("-");
				base.ContextMenu.MenuItems.Add(l_menuBreak2);
				if (m_bAllowChangeCellHeight && m_FocusCell != null && m_bAllowAutoSize)
				{
					base.ContextMenu.MenuItems.Add(new MenuItem("AutoSize Column Width ...",new EventHandler(Menu_AutoSizeColumnWidth)));
				}
				if (m_bAllowChangeCellHeight && m_FocusCell != null && m_bAllowAutoSize)
				{
					base.ContextMenu.MenuItems.Add(new MenuItem("AutoSize Row Height ...",new EventHandler(Menu_AutoSizeRowHeight)));
				}
				if (m_bAllowChangeCellHeight && mbAllowChangeCellWidth && m_bAllowAutoSize)
				{
					base.ContextMenu.MenuItems.Add(new MenuItem("AutoSize All ...",new EventHandler(Menu_AutoSizeAll)));
				}
			}

			if (m_OriginalContextMenu != null)
			{
				MenuItem l_menuBreak = new MenuItem("-");
				base.ContextMenu.MenuItems.Add(l_menuBreak);

				base.ContextMenu.MergeMenu(m_OriginalContextMenu);
			}
		}
		private void Menu_AutoSizeColumnWidth(object sender, EventArgs e)
		{
			if (m_FocusCell != null)
				AutoSizeColumn(m_FocusCell.Col,m_AutoSizeMinWidth);
		}
		private void Menu_AutoSizeRowHeight(object sender, EventArgs e)
		{
			if (m_FocusCell != null)
				AutoSizeRow(m_FocusCell.Row,m_AutoSizeMinHeight);
		}
		private void Menu_AutoSizeAll(object sender, EventArgs e)
		{
			AutoSizeAll(m_AutoSizeMinHeight,m_AutoSizeMinWidth);
		}

		private int m_AutoSizeMinHeight = 20;
		public int AutoSizeMinHeight
		{
			get{return m_AutoSizeMinHeight;}
			set{m_AutoSizeMinHeight = value;}
		}

		private int m_AutoSizeMinWidth = 20;
		public int AutoSizeMinWidth
		{
			get{return m_AutoSizeMinWidth;}
			set{m_AutoSizeMinWidth = value;}
		}

		private void Menu_ColumnWidth(object sender, EventArgs e)
		{
			if (m_FocusCell != null)
				ShowColumnWidthSettings(m_FocusCell.Col);
			else
				ShowColumnWidthSettings(0);
		}
		
		private void Menu_RowHeight(object sender, EventArgs e)
		{
			if (m_FocusCell != null)
				ShowRowHeightSettings(m_FocusCell.Row);
			else
				ShowRowHeightSettings(0);
		}

		public virtual void ShowColumnWidthSettings(int pcol)
		{
			if (m_Cols > 0 && pcol >= 0 && pcol < m_Cols)
			{
				frmCellSize l_frmCellSize = new frmCellSize();
				l_frmCellSize.LoadSetting(this,pcol,-1,CellSizeMode.Col);
				l_frmCellSize.ShowDialog();
			}
		}

		public virtual void ShowRowHeightSettings(int prow)
		{
			if (m_Rows > 0 && prow >= 0 && prow < m_Rows)
			{
				frmCellSize l_frmCellSize = new frmCellSize();
				l_frmCellSize.LoadSetting(this,-1,prow,CellSizeMode.Row);
				l_frmCellSize.ShowDialog();
			}
		}

		protected bool mbAllowChangeCellWidth = true;
		protected bool m_bAllowChangeCellHeight = true;

		public bool AllowChangeCellWidth
		{
			get{return mbAllowChangeCellWidth;}
			set{mbAllowChangeCellWidth = value;}
		}

		public bool AllowChangeCellHeight
		{
			get{return m_bAllowChangeCellHeight;}
			set{m_bAllowChangeCellHeight = value;}
		}

		private bool m_bAllowAutoSize = true;

		public bool AllowAutoSize
		{
			get{return m_bAllowAutoSize;}
			set{m_bAllowAutoSize = value;}
		}

		protected int m_Cols = 0;
		public int Cols
		{
			get
			{
				return m_Cols;
			}
			set
			{
				if (m_Cols<value)
					AddColumn(m_Cols,value-m_Cols);
				else if (m_Cols>value)
					RemoveColumn(value, m_Cols-value);
			}
		}

		protected int m_Rows = 0;
		public int Rows
		{
			get
			{
				return m_Rows;
			}
			set
			{
				if (m_Rows<value)
					AddRow(m_Rows,value-m_Rows);
				else if (m_Rows>value)
					RemoveRow(value, m_Rows-value);
			}
		}

		public void Redim(int pRows, int pCols)
		{
			Rows = pRows;
			Cols = pCols;
		}

		protected int m_FixedRows = 0;
		public int FixedRows
		{
			get{return m_FixedRows;}
			set{m_FixedRows = value;}
		}
		protected int m_FixedCols = 0;
		public int FixedCols
		{
			get{return m_FixedCols;}
			set{m_FixedCols = value;}
		}

		protected Cell[,] m_Cells = null;



		protected RowInfoCollection m_RowsInfo = new RowInfoCollection();
		protected ColInfoCollection m_ColsInfo = new ColInfoCollection();


		public Rectangle GetCellDisplayRectangle(Cell paramCell)
		{
			return GetCellDisplayRectangle(paramCell.Row,paramCell.Col,paramCell.RowSpan,paramCell.ColSpan);
		}
		public Rectangle GetCellDisplayRectangle(int pRow, int pCol, int pRowSpan, int pColSpan)
		{
			Rectangle l_tmp = GetCellAbsoluteRectangle(pRow,pCol,pRowSpan,pColSpan);
			int l_x = l_tmp.X;
			int l_y = l_tmp.Y;
			if (pRow>=FixedRows)
				l_y += CustomScrollPosition.Y;
			if (pCol>=FixedCols)
				l_x += CustomScrollPosition.X;
			return (new Rectangle(l_x,l_y,l_tmp.Width,l_tmp.Height));
		}

		public Rectangle GetCellAbsoluteRectangle(Cell paramCell)
		{
			return GetCellAbsoluteRectangle(paramCell.Row,paramCell.Col,paramCell.RowSpan,paramCell.ColSpan);
		}

		public Rectangle GetCellAbsoluteRectangle(int pRow, int pCol, int pRowSpan, int pColSpan)
		{
			if (pRow >= 0 && pRow < m_Rows &&
				pCol >= 0 && pCol < m_Cols)
			{
				int l_Width = m_ColsInfo[pCol].Width;
				int l_Height = m_RowsInfo[pRow].Height;

				if (pRowSpan > 1)
				{
					for (int r = pRow+1; (r < pRow + pRowSpan) && (r < m_Rows); r++)
						l_Height += m_RowsInfo[r].Height;
				}
				if (pColSpan > 1)
				{
					for (int c = pCol+1; (c < pCol + pColSpan) && (c < m_Cols); c++)
						l_Width += m_ColsInfo[c].Width;
				}

				return new Rectangle(m_ColsInfo[pCol].Left,
					m_RowsInfo[pRow].Top,
					l_Width,
					l_Height);
			}
			else
				return new Rectangle(0,0,0,0);
		}

		public virtual int GetColWidth(int col)
		{
			return m_ColsInfo[col].Width;
		}

		public virtual void SetColWidth(int col, int paramValue)
		{
			int l_DeltaWidth = m_ColsInfo[col].Width-paramValue;

			if (l_DeltaWidth != 0)
			{
				m_ColsInfo[col].Width = paramValue;

				for (int c = col+1; c < m_Cols; c++)
				{
					m_ColsInfo[c].Left -= l_DeltaWidth;
				}
				RecalculateScrollBar();
				InvalidateCells();
			}
		}

		public virtual int GetRowHeight(int row)
		{
			return m_RowsInfo[row].Height;
		}

		public virtual void SetRowHeight(int row, int paramValue)
		{
			int l_DeltaHeight = m_RowsInfo[row].Height-paramValue;

			if (l_DeltaHeight!=0)
			{
				m_RowsInfo[row].Height = paramValue;

				for (int r = row+1; r < m_Rows; r++)
				{
					m_RowsInfo[r].Top -= l_DeltaHeight;
				}
				RecalculateScrollBar();
				InvalidateCells();
			}
		}

		protected void RecalculateScrollBar()
		{
			int l_MaxY = 0;
			int l_MaxX = 0;
			for (int r = 0; r < Rows; r++)
				l_MaxY += GetRowHeight(r);
			for (int c = 0; c < Cols; c++)
				l_MaxX += GetColWidth(c);

			CustomScrollArea = new Size(l_MaxX,l_MaxY);
		}

		public Cell this[int row, int col]
		{
			get
			{				
				return m_Cells[row,col];
			}
			set
			{					
				InsertCell(row,col,value);
			}
		}

		public void RemoveCell(int row, int col)
		{
			if (m_Cells[row,col]!= null)
			{
				m_Cells[row,col].Select = false;
				m_Cells[row,col].LeaveFocus();


				m_Cells[row,col].SelectionChange -= new EventHandler(Cell_SelectionChange); 
				m_Cells[row,col].Invalidated -= new InvalidateEventHandler(Cell_Invalidated);
				m_Cells[row,col].FocusChange -= new EventHandler(Cell_FocusChange);

				m_Cells[row,col].UnBindToGrid();

				m_Cells[row,col] = null;
			}
		}

		public void InsertCell(int row, int col, Cell pcell)
		{
			RemoveCell(row,col);
			m_Cells[row,col] = pcell;

			if (pcell!=null)
			{
				pcell.Row = row;
				pcell.Col = col;

				pcell.Select = false; 
				pcell.LeaveFocus(); 

				pcell.SelectionChange += new EventHandler(Cell_SelectionChange); 
				pcell.Invalidated += new InvalidateEventHandler(Cell_Invalidated);
				pcell.FocusChange += new EventHandler(Cell_FocusChange);

				pcell.BindToGrid(this);

				pcell.RaiseInvalidate();
			}

		}

		public bool IsCellVisible(Cell paramCell)
		{
			return paramCell.IsInDisplayRegion(ClientRectangle);
		}

		public void ShowCell(Cell paramCellToShow)
		{
			if (IsCellVisible(paramCellToShow) == false)
			{
				Rectangle l_cellRect = paramCellToShow.DisplayRectangle;
				Point l_newCustomScrollPosition = new Point(CustomScrollPosition.X,CustomScrollPosition.Y);
				bool l_ApplyScroll = false;
				Rectangle l_ClientRectangle = CustomClientRectangle;
				if (l_cellRect.Location.X <ColLeft(Math.Min(FixedCols,paramCellToShow.Col)))
				{
					l_newCustomScrollPosition.X -= l_cellRect.Location.X-ColLeft(Math.Min(FixedCols,paramCellToShow.Col));
					l_ApplyScroll = true;
				}
				if (l_cellRect.Location.Y <RowTop(Math.Min(FixedRows,paramCellToShow.Row)))
				{
					l_newCustomScrollPosition.Y -= l_cellRect.Location.Y-RowTop(Math.Min(FixedRows,paramCellToShow.Row));
					l_ApplyScroll = true;
				}
				if (l_cellRect.Right > l_ClientRectangle.Width)
				{
					l_newCustomScrollPosition.X -= l_cellRect.Right-l_ClientRectangle.Width;
					l_ApplyScroll = true;
				}
				if (l_cellRect.Bottom >l_ClientRectangle.Height)
				{
					l_newCustomScrollPosition.Y -= l_cellRect.Bottom-l_ClientRectangle.Height;
					l_ApplyScroll = true;
				}

				if (l_ApplyScroll)
				{
					CustomScrollPosition = l_newCustomScrollPosition;
					if (FixedRows > 0 || FixedCols > 0)
						InvalidateCells();
				}
			}
		}

		public void InvalidateCells()
		{
			Invalidate(true);
		}

		private void Cell_FocusChange(object sender, EventArgs e)
		{
			OnCellFocusChange(new CellEventArgs((Cell)sender));
		}

		private void Cell_SelectionChange(object sender, EventArgs e)
		{
			OnCellSelectionChange(new CellEventArgs((Cell)sender));
		}

		private void Cell_Invalidated(object sender, InvalidateEventArgs e)
		{
			backContainer.Invalidate(e.InvalidRect,false);
		}

		protected virtual void OnCellFocusChange(CellEventArgs e)
		{
			if (e.Cell.Focused)
			{
				InnerChangeFocusCell(e.Cell);
				if (m_FocusCell!=null)
					ShowCell(m_FocusCell);
			}
			else
				InnerChangeFocusCell(null);

			if (mCellFocusChange != null)
				mCellFocusChange(this,e);
		}

		protected virtual void OnCellSelectionChange(CellEventArgs e)
		{
			if (m_CellSelectionChange != null)
				m_CellSelectionChange(this,e);
		}

		protected event CellEventHandler m_CellSelectionChange;
		public event CellEventHandler CellSelectionChange
		{
			add{m_CellSelectionChange += value;}
			remove{m_CellSelectionChange -= value;}
		}
		protected event CellEventHandler mCellFocusChange;
		public event CellEventHandler CellFocusChange
		{
			add{mCellFocusChange += value;}
			remove{mCellFocusChange -= value;}
		}

		public int ColLeft(int col)
		{
			return m_ColsInfo[col].Left;
		}

		public int RowTop(int row)
		{
			return m_RowsInfo[row].Top;
		}

		public virtual Cell CellAtPoint(Point p)
		{
			Point l_ModPoint = new Point(p.X-GridScrollPosition.X, p.Y-GridScrollPosition.Y);
			for (int r = 0; r < m_Rows; r++)
			{
				if (m_RowsInfo[r].Top <= l_ModPoint.Y)
				{
					for (int c = 0; c < m_Cols; c++)
					{
						if (m_ColsInfo[c].Left <= l_ModPoint.X)
						{
							if (m_Cells[r,c]!= null)
							{
								if (m_Cells[r,c].DisplayRectangle.Contains(p))
								{
									return m_Cells[r,c];
								}
							}
						}
					}
				}
			}
			return null;
		}


		protected Cell m_CellUnderMouse = null;

		public Cell CellUnderMouse
		{
			get{return m_CellUnderMouse;}
		}

		protected void ChangeCellUnderMouse(Cell paramCell)
		{
			if (m_CellUnderMouse != paramCell)
			{
				if (m_CellUnderMouse != null)
					m_CellUnderMouse.RaiseMouseLeave(new EventArgs());
				m_CellUnderMouse = paramCell;
				if (paramCell != null)
					paramCell.RaiseMouseEnter(new EventArgs());
			}
		}


		protected virtual void OnMouseSelectionFinish(CellArrayEventArgs e)
		{
			m_OldMouseSelection = new Cell[0];
		}

		public virtual Cell[] MouseSelection
		{
			get
			{
				int l_Count = 0;
				int l_StartRow = 0;
				int l_StartCol = 0;
				int l_EndRow = -1;
				int l_EndCol = -1;

				if (m_StartMouseSelectionCell != null && m_EndMouseSelectionCell != null)
				{
					l_StartRow = Math.Min(m_StartMouseSelectionCell.Row,m_EndMouseSelectionCell.Row);
					l_StartCol = Math.Min(m_StartMouseSelectionCell.Col,m_EndMouseSelectionCell.Col);
					l_EndRow = Math.Max(m_StartMouseSelectionCell.Row,m_EndMouseSelectionCell.Row);
					l_EndCol = Math.Max(m_StartMouseSelectionCell.Col,m_EndMouseSelectionCell.Col);

					for (int r = l_StartRow; r <= l_EndRow; r++)
						for (int c = l_StartCol; c <= l_EndCol; c++)
							if (m_Cells[r,c] != null)
								l_Count++;
				}

				Cell[] l_cells = new Cell[l_Count];

				if (m_StartMouseSelectionCell != null && m_EndMouseSelectionCell != null)
				{
					int l_index = 0;
					for (int r = l_StartRow; r <= l_EndRow; r++)
						for (int c = l_StartCol; c <= l_EndCol; c++)
							if (m_Cells[r,c] != null)
							{
								l_cells[l_index] = m_Cells[r,c];
								l_index++;
							}
				}

				return l_cells;
			}
		}

		protected virtual void OnUndoMouseSelection(CellArrayEventArgs e)
		{
			foreach (Cell c in e.Cells)
			{
				if (c != m_FocusCell)
					c.Select = false;
			}
		}

		protected virtual void OnApplyMouseSelection(CellArrayEventArgs e)
		{
			foreach (Cell c in e.Cells)
			{
				c.Select = true;
			}
		}
		private Cell[] m_OldMouseSelection = new Cell[0];
		protected virtual void OnMouseSelectionChange(EventArgs e)
		{
			Cell[] l_Cells = MouseSelection;

			OnUndoMouseSelection(new CellArrayEventArgs(m_OldMouseSelection));

			OnApplyMouseSelection(new CellArrayEventArgs(l_Cells));

			m_OldMouseSelection = l_Cells;
		}

		protected void MouseSelectionFinish()
		{
			if (m_StartMouseSelectionCell != null || m_EndMouseSelectionCell != null)
				OnMouseSelectionFinish(new CellArrayEventArgs(m_OldMouseSelection));

			m_StartMouseSelectionCell = null;
			m_EndMouseSelectionCell = null;
		}

		protected virtual void ChangeMouseSelectionCorner(Cell pCorner)
		{
			bool l_bChange = false;
			if (m_StartMouseSelectionCell != m_FocusCell)
			{
				m_StartMouseSelectionCell = m_FocusCell;
				l_bChange = true;
			}
			if (m_EndMouseSelectionCell != pCorner)
			{
				m_EndMouseSelectionCell = pCorner;
				l_bChange = true;
			}

			if (l_bChange)
				OnMouseSelectionChange(new EventArgs());
		}

		protected Cell m_StartMouseSelectionCell = null;
		protected Cell m_EndMouseSelectionCell = null;

		private void BackContainer_MouseMove(object sender, MouseEventArgs e)
		{
			Cell tmp = CellAtPoint(new Point(e.X,e.Y));
			if (tmp != null)
			{
				tmp.RaiseMouseMove(e);

				if (m_FocusCell!=null && m_FocusCell.IsEditing==false)
				{
					#region Gestione multiselezione tramite mouse
					if (e.Button == MouseButtons.Left)
					{
						ChangeMouseSelectionCorner(tmp);
					}
					else
					{
						MouseSelectionFinish();
					}
					#endregion
				}
			}
			ChangeCellUnderMouse(tmp);
		}

		protected Cell m_MouseDownCell = null; 
		private void BackContainer_MouseDown(object sender, MouseEventArgs e)
		{

			m_MouseDownCell = CellAtPoint(new Point(e.X,e.Y));
			if (m_MouseDownCell != null)
			{
				m_MouseDownCell.RaiseMouseDown(e);
			}
		}


		private void BackContainer_MouseUp(object sender, MouseEventArgs e)
		{
			MouseSelectionFinish();

			if (m_MouseDownCell != null)
				m_MouseDownCell.RaiseMouseUp(e);
		}

		private void BackContainer_MouseLeave(object sender, EventArgs e)
		{
			ChangeCellUnderMouse(null);

			MouseSelectionFinish();
		}

		protected override void OnMouseWheel(MouseEventArgs e)
		{
			base.OnMouseWheel(e);
			try
			{
				if (e.Delta >= 120 || e.Delta <= -120)
				{
					Point t = CustomScrollPosition;
					int l_NewY = t.Y + 
						(SystemInformation.MouseWheelScrollLines*6) * 
						Math.Sign(e.Delta) ;
					CustomScrollPosition = new Point(t.X,
						l_NewY);
				}
			}
			catch(Exception)
			{
			}
		}

		private void BackContainer_Click(object sender, EventArgs e)
		{
			if (m_MouseDownCell != null)
				m_MouseDownCell.RaiseClick();
		}
		private void BackContainer_DoubleClick(object sender, EventArgs e)
		{
			if (m_MouseDownCell != null)
				m_MouseDownCell.RaiseDoubleClick();
		}

		private void BackContainer_KeyDown(object sender, KeyEventArgs e)
		{
			if (e.KeyCode == Keys.Delete)
			{
				m_Selection.CellEditorClear();
			}
			else if (m_FocusCell != null)
			{
				m_FocusCell.RaiseKeyDown(e);

				#region Process ArrowKey For navigate into cells and tab
				Cell tmp = null;
				if (e.KeyCode == Keys.Down)
				{
					int tmpRow = m_FocusCell.Row;
					tmpRow++;
					while (tmp == null && tmpRow < Rows)
					{
						tmp = m_Cells[tmpRow,m_FocusCell.Col];
						tmpRow++;
					}
				}
				else if (e.KeyCode == Keys.Up)
				{
					int tmpRow = m_FocusCell.Row;
					tmpRow--;
					while (tmp == null && tmpRow >= 0)
					{
						tmp = m_Cells[tmpRow,m_FocusCell.Col];
						tmpRow--;
					}
				}
				else if (e.KeyCode == Keys.Right || e.KeyCode == Keys.Tab)
				{
					int tmpCol = m_FocusCell.Col;
					tmpCol++;
					while (tmp == null && tmpCol < Cols)
					{
						tmp = m_Cells[m_FocusCell.Row,tmpCol];
						tmpCol++;
					}
				}
				else if (e.KeyCode == Keys.Left)
				{
					int tmpCol = m_FocusCell.Col;
					tmpCol--;
					while (tmp == null && tmpCol >= 0)
					{
						tmp = m_Cells[m_FocusCell.Row,tmpCol];
						tmpCol--;
					}
				}

				if (tmp!=null)
					tmp.Focus();
				#endregion
			}
		}


		private void BackContainer_KeyUp(object sender, KeyEventArgs e)
		{
			if (m_FocusCell != null)
			{
				m_FocusCell.RaiseKeyUp(e);
			}
		}

		private void BackContainer_KeyPress(object sender, KeyPressEventArgs e)
		{
			if (m_FocusCell == null || e.KeyChar == '\t' || e.KeyChar == 13 )
			{
			}
			else
			{
				if (e.KeyChar == 3) 
				{
					if (m_Selection.Count > 0)
						m_Selection.ClipboardCopy();
				}
				else if (e.KeyChar == 22) 
				{
					if (m_Selection.Count > 0)
						m_Selection.ClipboardPaste();
				}
				else if (e.KeyChar == 24) 
				{
					if (m_Selection.Count > 0)
						m_Selection.ClipboardCut();
				}
				else
					m_FocusCell.RaiseKeyPress(e);
			}
		}

		private void InnerChangeFocusCell(Cell pnewCell)
		{
			if (pnewCell == m_FocusCell)
			{
				if ((Control.ModifierKeys & Keys.Control) != Keys.Control)
					m_Selection.Clear(m_FocusCell);
			}
			else
			{
				if ((Control.ModifierKeys & Keys.Control) != Keys.Control) 
					m_Selection.Clear(pnewCell);
				if (pnewCell!=null)
					pnewCell.Select = true;

				m_FocusCell = pnewCell;
			}

			if (m_FocusCell != null)
			{
				if (m_SelMode == GridSelectionMode.Row)
				{
					for(int c = 0;c < m_Cols; c++)
						if (m_Cells[m_FocusCell.Row, c] != null)
							m_Cells[m_FocusCell.Row, c].Select = true;
				}
				else if (m_SelMode == GridSelectionMode.Col)
				{
					for(int r = 0;r < m_Rows; r++)
						if (m_Cells[r, m_FocusCell.Col] != null)
							m_Cells[r, m_FocusCell.Col].Select = true;
				}
			}
		}

		protected Cell m_FocusCell = null;
		public Cell FocusCell
		{
			get{return m_FocusCell;}
		}

		protected Selection m_Selection = null;
		public Selection Selection
		{
			get{return m_Selection;}
		}

		public virtual void AddRow(int pNewRowPosition, params Cell[] paramCells)
		{
			AddRow(pNewRowPosition);
			if (paramCells!=null)
			{
				int l_Lenght = Math.Min(Cols,paramCells.Length);
				for (int i = 0; i < l_Lenght; i++)
					this[pNewRowPosition,i] = paramCells[i];
			}
		}

		public virtual void AddRow(int pNewRowPosition)
		{
			AddRow(pNewRowPosition,1);
		}

		public virtual void AddRow(int pNewRowPosition, int pNewRowNumber)
		{
			if (pNewRowNumber <= 0)
				throw new ApplicationException("Invalid row number, must be positive");
			RedimMatrix(m_Rows+pNewRowNumber,m_Cols);

			for (int r = pNewRowPosition; r < (pNewRowPosition+pNewRowNumber); r++)
			{
				InnerRowAdded(r);
			}

			for (int r = m_Rows-1; r > (pNewRowPosition+pNewRowNumber-1); r--)
			{
				for (int c = 0; c < m_Cols; c++)
				{
					m_Cells[r,c] = m_Cells[r-pNewRowNumber,c];
					if (m_Cells[r,c] != null)
						m_Cells[r,c].Row = r;
					m_Cells[r-pNewRowNumber,c] = null;
				}
			}

			for (int r = pNewRowPosition; r < (pNewRowPosition+pNewRowNumber); r++)
			{
				OnRowAdded(new RowEventArgs(r));
			}

			RecalculateScrollBar();
			InvalidateCells();
		}

		public virtual void RemoveRow(int pRowToRemove)
		{
			RemoveRow(pRowToRemove,1);
		}

		public virtual void RemoveRow(int pStartRemoveRow, int pRowToRemove)
		{
			for (int r = (pStartRemoveRow+pRowToRemove); r < m_Rows; r++)
			{
				for (int c = 0; c < m_Cols; c++)
				{
					m_Cells[r-pRowToRemove,c] = m_Cells[r,c];
					if (m_Cells[r-pRowToRemove,c] != null)
						m_Cells[r-pRowToRemove,c].Row = r-pRowToRemove;
					m_Cells[r,c] = null;
				}
			}

			RedimMatrix(m_Rows-pRowToRemove,m_Cols);

			for (int r = pStartRemoveRow; r < (pStartRemoveRow+pRowToRemove); r++)
			{
				InnerOnRowRemoved(new RowEventArgs(pStartRemoveRow)); 
			}

			RecalculateScrollBar();
			InvalidateCells();
		}

		public virtual void AddColumn(int pNewColPosition)
		{
			AddColumn(pNewColPosition,1);
		}
		public virtual void AddColumn(int pNewColPosition, int pNewColNumber)
		{
			if (pNewColNumber <= 0)
				throw new ApplicationException("Invalid column number, must be positive");
			RedimMatrix(m_Rows,m_Cols+pNewColNumber);

			for (int c = pNewColPosition; c < (pNewColPosition+pNewColNumber); c++)
			{
				InnerColumnAdded(c);
			}

			for (int c = m_Cols-1; c > (pNewColPosition+pNewColNumber-1); c--)
			{
				for (int r = 0; r < m_Rows; r++)
				{
					m_Cells[r,c] = m_Cells[r,c-pNewColNumber];
					if (m_Cells[r,c] != null)
						m_Cells[r,c].Col = c;
					m_Cells[r,c-pNewColNumber] = null;
				}
			}

			for (int c = pNewColPosition; c < (pNewColPosition+pNewColNumber); c++)
			{
				OnColumnAdded(new ColumnEventArgs(c));
			}

			RecalculateScrollBar();
			InvalidateCells();
		}
		public virtual void RemoveColumn(int pColumnToRemove)
		{
			RemoveColumn(pColumnToRemove,1);
		}
		public virtual void RemoveColumn(int pStartRemoveColumn, int pColumnToRemove)
		{
			for (int c = (pStartRemoveColumn+pColumnToRemove); c < m_Cols; c++)
			{
				for (int r = 0; r < m_Rows; r++)
				{
					m_Cells[r,c-pColumnToRemove] = m_Cells[r,c];
					if (m_Cells[r,c-pColumnToRemove] != null)
						m_Cells[r,c-pColumnToRemove].Col = c-pColumnToRemove;
					m_Cells[r,c] = null;
				}
			}

			RedimMatrix(m_Rows,m_Cols-pColumnToRemove);

			for (int c = pStartRemoveColumn; c < (pStartRemoveColumn+pColumnToRemove); c++)
			{
				InnerOnColumnRemoved(new ColumnEventArgs(pStartRemoveColumn)); //cancello sempre nella posizione pi� piccola
			}

			RecalculateScrollBar();
			InvalidateCells();
		}

		private void InnerRowAdded(int pRow)
		{
			int l_Top = 0;
			if (pRow > 0)
			{
				l_Top = m_RowsInfo[pRow-1].Top;
				l_Top += m_RowsInfo[pRow-1].Height;
			}
			m_RowsInfo.Add(pRow,new RowInfo(Cell.DefaultHeight,l_Top));

			for (int r = pRow+1; r < m_RowsInfo.Count;r++)
				m_RowsInfo[r].Top += m_RowsInfo[pRow].Height;
		}

		protected virtual void OnRowAdded(RowEventArgs e)
		{
		}

		private void InnerOnRowRemoved(RowEventArgs e)
		{
			int l_OldTop = m_RowsInfo[e.Row].Top;
			for (int r = e.Row+1; r < m_RowsInfo.Count;r++)
			{
				m_RowsInfo[r].Top = l_OldTop;
				l_OldTop = l_OldTop+m_RowsInfo[r].Height;
			}

			m_RowsInfo.RemoveAt(e.Row);
			OnRowRemoved(e);
		}
		protected virtual void OnRowRemoved(RowEventArgs e)
		{
		}
		private void InnerColumnAdded(int pCol)
		{
			int l_Left = 0;
			if (pCol > 0)
			{
				l_Left = m_ColsInfo[pCol-1].Left;
				l_Left += m_ColsInfo[pCol-1].Width;
			}
			m_ColsInfo.Add(pCol,new ColInfo(Cell.DefaultWidth,l_Left));

			for (int c = pCol+1; c < m_ColsInfo.Count;c++)
				m_ColsInfo[c].Left += m_ColsInfo[pCol].Width;
		}
		protected virtual void OnColumnAdded(ColumnEventArgs e)
		{
		}

		private void InnerOnColumnRemoved(ColumnEventArgs e)
		{
			int l_OldLeft = m_ColsInfo[e.Column].Left;
			for (int c = e.Column+1; c < m_ColsInfo.Count;c++)
			{
				m_ColsInfo[c].Left = l_OldLeft;
				l_OldLeft = l_OldLeft+m_ColsInfo[c].Width;
			}

			m_ColsInfo.RemoveAt(e.Column);
			OnColumnRemoved(e);
		}
		protected virtual void OnColumnRemoved(ColumnEventArgs e)
		{
		}
		
		private void RedimMatrix(int rows, int cols)
		{
			if (m_Cells == null)
			{
				m_Cells = new Cell[rows,cols];
			}
			else
			{
				if (rows != Rows || cols != Cols)
				{
					Cell[,] l_tmp = m_Cells;
					int l_minRows = Math.Min(l_tmp.GetLength(0),rows);
					int l_minCols = Math.Min(l_tmp.GetLength(1),cols);

					for (int i = l_minRows; i <l_tmp.GetLength(0); i++)
						for (int j = 0; j < l_tmp.GetLength(1); j++)
							RemoveCell(i,j);
					for (int i = 0; i <l_minRows; i++)
						for (int j = l_minCols; j < l_tmp.GetLength(1); j++)
							RemoveCell(i,j);

					m_Cells = new Cell[rows,cols];

					for (int i = 0; i <l_minRows; i++)
						for (int j = 0; j < l_minCols; j++)
							m_Cells[i,j] = l_tmp[i,j];
				}
			}

			m_Rows = m_Cells.GetLength(0);
			m_Cols = m_Cells.GetLength(1);
		}

		public virtual void AutoSizeColumn(int pCol, int pMinWidth)
		{
			int l_minWidth = pMinWidth;
			Graphics l_graphics = CreateGraphics();
			for (int r = 0; r < m_Rows; r++)
			{
				if (m_Cells[r,pCol] != null)
				{
					Size l_size = m_Cells[r,pCol].GetRequiredSize(l_graphics);
					if (l_size.Width > l_minWidth)
						l_minWidth = l_size.Width;
				}
			}
			SetColWidth(pCol,l_minWidth);
		}
		public virtual void AutoSizeRow(int pRow, int pMinHeight)
		{
			int l_minHeight = pMinHeight;
			Graphics l_graphics = CreateGraphics();
			for (int c = 0; c < m_Cols; c++)
			{
				if (m_Cells[pRow,c] != null)
				{
					Size l_size = m_Cells[pRow,c].GetRequiredSize(l_graphics);
					if (l_size.Height > l_minHeight)
						l_minHeight = l_size.Height;
				}
			}
			SetRowHeight(pRow,l_minHeight);
		}

		public virtual void AutoSizeAll(int pMinHeight, int pMinWidth)
		{
			for (int c = 0; c < m_Cols; c++)
				AutoSizeColumn(c,pMinWidth);
			for (int r = 0; r < m_Rows; r++)
				AutoSizeRow(r,pMinHeight);
		}

		public virtual void AutoSizeAll()
		{
			AutoSizeAll(AutoSizeMinHeight,AutoSizeMinWidth);
		}

		public int SelecteRow
		{
			get
			{
				if (m_FocusCell != null)
				{
					return m_FocusCell.Row;
				}
				else
					return -1;
			}
		}

		public int SelecteColumn
		{
			get
			{
				if (m_FocusCell != null)
				{
					return m_FocusCell.Col;
				}
				else
					return -1;
			}
		}

		private GridSelectionMode m_SelMode = GridSelectionMode.Cell;
		public GridSelectionMode SelectionMode
		{
			get{return m_SelMode;}
			set{m_SelMode = value;}
		}

		public Point GridScrollPosition
		{
			get{return CustomScrollPosition;}
			set{CustomScrollPosition = value;}
		}

		public bool ToolTipActive
		{
			get{return backContainer.ToolTipActive;}
			set{backContainer.ToolTipActive = value;}
		}

		protected override bool ProcessCmdKey(
			ref Message msg,
			Keys keyData
			)
		{
			if (keyData == Keys.Escape)
			{
				if (m_FocusCell!=null && m_FocusCell.IsEditing)
					m_FocusCell.EndEdit(true);
				return true;
			}
			if (keyData == Keys.Enter )
			{
				if (m_FocusCell!=null && m_FocusCell.IsEditing)
					m_FocusCell.EndEdit(false);
				return true;
			}
			return base.ProcessCmdKey(ref msg,keyData);
		}


		public bool SetFocusOnCellsContainer()
		{
			return backContainer.Focus();
		}

		public Cursor CellsContainerCursor
		{
			get{return backContainer.Cursor;}
			set{backContainer.Cursor = value;}
		}
		public string CellsContainerToolTipText
		{
			get{return backContainer.ToolTipText;}
			set{backContainer.ToolTipText = value;}
		}

		private void BackContainer_Paint(object sender, PaintEventArgs e)
		{
			Point l_ScrollPoint = GridScrollPosition;
			for (int r = FixedRows; r < m_Rows; r++)
			{
					if ( (m_RowsInfo[r].Top + l_ScrollPoint.Y) > e.ClipRectangle.Bottom)
						break;

					for (int c = FixedCols; c < m_Cols; c++)
					{
							if ( (m_ColsInfo[c].Left + l_ScrollPoint.X) > e.ClipRectangle.Right)
								break;

							if (m_Cells[r,c] != null)
								m_Cells[r,c].RaisePaint(e);
					}
			}

			for (int r = 0; r < FixedRows; r++)
			{
					if ( (m_RowsInfo[r].Top + l_ScrollPoint.Y) > e.ClipRectangle.Bottom)
						break;

					for (int c = 0; c < m_Cols; c++)
						if (m_Cells[r,c] != null)
							m_Cells[r,c].RaisePaint(e);
			}

			for (int r = 0; r < m_Rows; r++)
			{
					if ( (m_RowsInfo[r].Top + l_ScrollPoint.Y) > e.ClipRectangle.Bottom)
						break;

					for (int c = 0; c < FixedCols; c++)
						if (m_Cells[r,c] != null)
							m_Cells[r,c].RaisePaint(e);
			}
		}
	}
}
