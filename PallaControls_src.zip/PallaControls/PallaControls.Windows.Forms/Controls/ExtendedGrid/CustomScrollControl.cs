using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;

namespace ControlWare.Windows.Controls
{
	public class CustomScrollControl : System.Windows.Forms.UserControl
	{
		private System.ComponentModel.Container components = null;

		public CustomScrollControl()
		{
			InitializeComponent();

			base.AutoScroll = false;

			ControlRemoved += new ControlEventHandler(Controls_Removed);
		}

		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Component Designer generated code
		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			components = new System.ComponentModel.Container();
		}
		#endregion

		public override bool AutoScroll
		{
			get{return false;}
			set
			{
				if (value)
					throw new ApplicationException("Auto Scroll not supported in this control");
				base.AutoScroll = false;
			}
		}

		private VScrollBar m_VScroll = null;
		private HScrollBar m_HScroll = null;
		private Panel m_BottomRightPanel = null;

		private Size m_CustomScrollArea = new Size(0,0);
		public virtual Size CustomScrollArea
		{
			get{return m_CustomScrollArea;}
			set
			{
				m_CustomScrollArea = value;
				RecalcCustomScrollBars();
			}
		}

		public virtual Point CustomScrollPosition
		{
			get
			{
				int l_x = 0;
				if (m_HScroll!=null)
					l_x = -m_HScroll.Value;
				int l_y = 0;
				if (m_VScroll!=null)
					l_y = -m_VScroll.Value;
				return new Point(l_x,l_y);
			}
			set
			{
				if (m_HScroll!=null)
				{
					m_HScroll.Value = -value.X;
				}
				if (m_VScroll!=null)
				{
					m_VScroll.Value = -value.Y;
				}
			}
		}

		public virtual Rectangle CustomClientRectangle
		{
			get
			{
				if (m_HScroll!=null && m_VScroll != null)
					return new Rectangle(ClientRectangle.X,ClientRectangle.Y,ClientRectangle.Width-m_VScroll.Width,ClientRectangle.Height-m_HScroll.Height);
				else
					return ClientRectangle;
			}
		}

		protected virtual void RemoveHScrollBar()
		{
			if (m_HScroll != null)
			{
				m_HScroll.ValueChanged -= new EventHandler(HscrollChange);
				Controls.Remove(m_HScroll);
				m_HScroll.Dispose();
				m_HScroll = null;
			}
		}
		protected virtual void RemoveVScrollBar()
		{
			if (m_VScroll != null)
			{
				m_VScroll.ValueChanged -= new EventHandler(VscrollChange);
				Controls.Remove(m_VScroll);
				m_VScroll.Dispose();
				m_VScroll = null;
			}		
		}

		protected virtual void RecalcHScrollBar()
		{
			m_HScroll.Location = new Point(0,ClientRectangle.Height-m_HScroll.Height);
			m_HScroll.Width = ClientRectangle.Width-m_VScroll.Width;
			m_HScroll.Minimum = 0;
			m_HScroll.Maximum = Math.Max(0,m_CustomScrollArea.Width); 
			m_HScroll.LargeChange = Math.Max(5,ClientRectangle.Width - m_VScroll.Width);
			m_HScroll.SmallChange = m_HScroll.LargeChange / 5;
			m_HScroll.BringToFront();
		}
		protected virtual void RecalcVScrollBar()
		{
			m_VScroll.Location = new Point(ClientRectangle.Width-m_VScroll.Width,0);
			m_VScroll.Height = ClientRectangle.Height-m_HScroll.Height;
			m_VScroll.Minimum = 0;
			m_VScroll.Maximum = Math.Max(0,m_CustomScrollArea.Height); 
			m_VScroll.LargeChange = Math.Max(5,ClientRectangle.Height - m_HScroll.Height);
			m_VScroll.SmallChange = m_VScroll.LargeChange / 5;
			m_VScroll.BringToFront();
		}

		public virtual int MaximumVScroll
		{
			get
			{
				if (m_VScroll == null)
					return 0;
				else
					return m_VScroll.Maximum;
			}
		}
		public virtual int MinimumVScroll
		{
			get
			{
				return 0;
			}
		}
		public virtual int MinimumHScroll
		{
			get
			{
				return 0;
			}
		}
		public virtual int MaximumHScroll
		{
			get
			{
				if (m_HScroll == null)
					return 0;
				else
					return m_HScroll.Maximum;
			}
		}

		public virtual void RecalcCustomScrollBars()
		{
			Rectangle l_Client = ClientRectangle;
			if (l_Client.Height < m_CustomScrollArea.Height || l_Client.Width < m_CustomScrollArea.Width)
			{
				if (m_VScroll == null)
				{
					m_VScroll = new VScrollBar();
					m_VScroll.ValueChanged += new EventHandler(VscrollChange);
					Controls.Add(m_VScroll);
				}
				if (m_HScroll == null)
				{
					m_HScroll = new HScrollBar();
					m_HScroll.ValueChanged += new EventHandler(HscrollChange);
					Controls.Add(m_HScroll);
				}

				if (m_BottomRightPanel==null)
				{
					m_BottomRightPanel = new Panel();
					m_BottomRightPanel.BackColor = Color.FromKnownColor(KnownColor.Control);
					Controls.Add(m_BottomRightPanel);
				}

				RecalcVScrollBar();
				RecalcHScrollBar();

				m_BottomRightPanel.Location = new Point(m_HScroll.Right,m_VScroll.Bottom);
				m_BottomRightPanel.Size = new Size(m_VScroll.Width,m_HScroll.Height);
				m_BottomRightPanel.BringToFront();
			}
			else
			{
				m_OldHScrollValue = 0;
				m_OldVScrollValue = 0;
				RemoveVScrollBar();
				RemoveHScrollBar();

				if (m_BottomRightPanel!=null)
				{
					Controls.Remove(m_BottomRightPanel);
					m_BottomRightPanel.Dispose();
					m_BottomRightPanel = null;
				}
			}
		}

		protected override void OnSizeChanged(EventArgs e)
		{
			base.OnSizeChanged(e);
			RecalcCustomScrollBars();
		}

		private int m_OldVScrollValue = 0;
		protected virtual void VscrollChange(object sender, EventArgs e)
		{
			OnVScrollPositionChanged(new ScrollPositionChangedEventArgs(-m_VScroll.Value,-m_OldVScrollValue));

			Invalidate(true);
			m_OldVScrollValue = m_VScroll.Value;
		}
		private int m_OldHScrollValue = 0;
		protected virtual void HscrollChange(object sender, EventArgs e)
		{
			OnHScrollPositionChanged(new ScrollPositionChangedEventArgs(-m_HScroll.Value,-m_OldHScrollValue));

			Invalidate(true);
			m_OldHScrollValue = m_HScroll.Value;
		}


		public event ScrollPositionChangedEventHandler VScrollPositionChanged;
		protected virtual void OnVScrollPositionChanged(ScrollPositionChangedEventArgs e)
		{
			foreach(Control c in Controls)
			{
				if (c != m_HScroll && c != m_VScroll && c != m_BottomRightPanel && m_NotScrollableControls.Contains(c) == false && c.Dock == DockStyle.None)
					c.Top -= e.Delta;
			}

			if (VScrollPositionChanged!=null)
				VScrollPositionChanged(this,e);
		}

		public event ScrollPositionChangedEventHandler HScrollPositionChanged;
		protected virtual void OnHScrollPositionChanged(ScrollPositionChangedEventArgs e)
		{
			foreach(Control c in Controls)
			{
				if (c != m_HScroll && c != m_VScroll && c != m_BottomRightPanel && m_NotScrollableControls.Contains(c) == false && c.Dock == DockStyle.None)
					c.Left -= e.Delta;
			}

			if (HScrollPositionChanged!=null)
				HScrollPositionChanged(this,e);
		}

		private ArrayList m_NotScrollableControls = new ArrayList();
		public void AddNotScrollableControls(Control paramControl)
		{
			m_NotScrollableControls.Add(paramControl);
		}
		public void RemoveNotScrollableControls(Control paramControl)
		{
			if (m_NotScrollableControls.Contains(paramControl))
				m_NotScrollableControls.Remove(paramControl);
		}
		private void Controls_Removed(object sender, ControlEventArgs e)
		{
			RemoveNotScrollableControls(e.Control);
		}
	}
}
