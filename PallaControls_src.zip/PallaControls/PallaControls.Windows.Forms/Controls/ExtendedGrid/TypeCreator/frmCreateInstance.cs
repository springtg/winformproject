using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Reflection;

namespace ControlWare.Windows.Controls
{
	public class frmCreateInstance : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Button btOK;
		private System.Windows.Forms.Button btCancel;
		private System.Windows.Forms.TabControl tabs;
		private System.ComponentModel.Container components = null;

		public frmCreateInstance()
		{
			InitializeComponent();

		}

		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.tabs = new System.Windows.Forms.TabControl();
			this.btOK = new System.Windows.Forms.Button();
			this.btCancel = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// tabs
			// 
			this.tabs.Anchor = (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right);
			this.tabs.Location = new System.Drawing.Point(8, 8);
			this.tabs.Name = "tabs";
			this.tabs.SelectedIndex = 0;
			this.tabs.Size = new System.Drawing.Size(336, 232);
			this.tabs.TabIndex = 0;
			// 
			// btOK
			// 
			this.btOK.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right);
			this.btOK.BackColor = System.Drawing.SystemColors.Control;
			this.btOK.DialogResult = System.Windows.Forms.DialogResult.OK;
			this.btOK.Location = new System.Drawing.Point(184, 248);
			this.btOK.Name = "btOK";
			this.btOK.Size = new System.Drawing.Size(72, 24);
			this.btOK.TabIndex = 4;
			this.btOK.Text = "&OK";
			// 
			// btCancel
			// 
			this.btCancel.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right);
			this.btCancel.BackColor = System.Drawing.SystemColors.Control;
			this.btCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.btCancel.Location = new System.Drawing.Point(272, 248);
			this.btCancel.Name = "btCancel";
			this.btCancel.Size = new System.Drawing.Size(72, 24);
			this.btCancel.TabIndex = 3;
			this.btCancel.Text = "&Cancel";
			// 
			// frmCreateInstance
			// 
			this.AcceptButton = this.btOK;
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.CancelButton = this.btCancel;
			this.ClientSize = new System.Drawing.Size(352, 275);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.btOK,
																		  this.btCancel,
																		  this.tabs});
			this.Name = "frmCreateInstance";
			this.ShowInTaskbar = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "frmCreateInstance";
			this.ResumeLayout(false);

		}
		#endregion


		public object CreateInstanceDialog(IWin32Window pOwner, Type pTypeToCreate, string pDialogText,TypeCreator pTypeCreator)
		{
			Text = pDialogText;
			ConstructorInfo[] l_Constructors = pTypeToCreate.GetConstructors();
			foreach (ConstructorInfo c in l_Constructors)
			{
				System.Windows.Forms.TabPage l_Page = new System.Windows.Forms.TabPage("Constructor " + (tabs.TabPages.Count+1).ToString());
				tabs.TabPages.Add(l_Page);
				PropertyGridExtented l_Grid = new PropertyGridExtented();
				l_Grid.TypeCreator = pTypeCreator;
				l_Grid.LoadProperties(c.GetParameters());
				l_Page.Controls.Add(l_Grid);
				l_Grid.Dock = DockStyle.Fill;
			}
			if (l_Constructors.Length == 0 || ShowDialog(pOwner) == DialogResult.OK)
			{
				if (l_Constructors.Length == 0)
				{
					return Activator.CreateInstance(pTypeToCreate);
				}
				else
				{
					PropertyGridExtented l_Grid = null;
					foreach (Control l_c in tabs.SelectedTab.Controls)
						if (l_c is PropertyGridExtented)
							l_Grid = (PropertyGridExtented)l_c;
					if (l_Grid == null)
						throw new ApplicationException("Property grid not found");

					return Activator.CreateInstance(pTypeToCreate,l_Grid.GetValues());
				}
			}
			else
				return null;
		}
	}
}
