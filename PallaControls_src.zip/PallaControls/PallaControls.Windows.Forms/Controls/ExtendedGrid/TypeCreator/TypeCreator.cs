using System;
using System.Reflection;
using System.Collections;
using System.Windows.Forms;

namespace ControlWare.Windows.Controls
{
	public class TypeCreator
	{
		public TypeCreator()
		{
		}

		public TypeCreator(Type[] pTypesToSearch, Assembly[] pAssemblyToSearch)
			:this(new ReferencesInfo(pTypesToSearch,pAssemblyToSearch))
		{
		}

		private ReferencesInfo m_ReferencesToSearch = null;
		public TypeCreator(ReferencesInfo pReferencesToSearch)
		{
			m_ReferencesToSearch = pReferencesToSearch;
		}
		public ReferencesInfo ReferencesToSearch
		{
			get{return m_ReferencesToSearch;}
			set{m_ReferencesToSearch = value;}
		}

		protected virtual void SearchValidTypes(Type pRequestedType, Type[] pTypesToSearch, ArrayList pDestination)
		{
			for (int j = 0; j < pTypesToSearch.Length; j++)
			{
				if (pTypesToSearch[j].IsAbstract == false &&
					pTypesToSearch[j].IsInterface == false &&
					pRequestedType.IsAssignableFrom(pTypesToSearch[j]) && 
					pRequestedType != pTypesToSearch[j])
				{
					pDestination.Add(pTypesToSearch[j]);
				}
				SearchValidTypes(pRequestedType,pTypesToSearch[j].GetNestedTypes(),pDestination);
			}
		}

		protected virtual ArrayList SearchValidTypes(Type pRequestedType)
		{
			ArrayList l_TypeMatchs = new ArrayList();

			if (pRequestedType.IsAbstract == false &&
				pRequestedType.IsInterface == false)
				l_TypeMatchs.Add(pRequestedType);

			if (ReferencesToSearch!=null)
			{
				if (ReferencesToSearch.AssemblyToSearch!=null)
				{
					for (int i = 0; i < ReferencesToSearch.AssemblyToSearch.Length; i++)
					{
						Type[] l_AssemblyTypes = ReferencesToSearch.AssemblyToSearch[i].GetExportedTypes();
						SearchValidTypes(pRequestedType,l_AssemblyTypes,l_TypeMatchs);
					}
				}

				if (ReferencesToSearch.TypeToSearchToSearch!=null)
				{
					SearchValidTypes(pRequestedType,ReferencesToSearch.TypeToSearchToSearch,l_TypeMatchs);
				}
			}
		
			return l_TypeMatchs;
		}

		protected virtual Type SelectTypeFromList(IWin32Window pOwner,Type pRequestedType, ArrayList pValidTypes)
		{
			using (frmSelectValidType l_frm = new frmSelectValidType())
			{
				Type l_SelType = l_frm.SelectTypeFromList(pOwner,pRequestedType,pValidTypes);
				if (l_SelType==null)
					throw new ApplicationException("Type not valid " + pRequestedType.FullName);
				return l_SelType;
			}
		}

		protected virtual Type GetTypeToCreate(IWin32Window pOwner, Type pRequestedType)
		{
			if (pRequestedType.IsSealed)
				return pRequestedType;

			ArrayList l_List = SearchValidTypes(pRequestedType);

			if (l_List.Count<=0)
				throw new ApplicationException("No types were found for " + pRequestedType.ToString());

			return SelectTypeFromList(pOwner,pRequestedType, l_List);
		}

		public virtual object CreateInstanceUI(IWin32Window pOwner, Type innerType,string pCaption)
		{
			using (frmCreateInstance l_frm = new frmCreateInstance())
			{
				object tmp = l_frm.CreateInstanceDialog(pOwner,GetTypeToCreate(pOwner,innerType),pCaption,this);
				return tmp;
			}
		}

		public virtual void BrowseInstanceUI(IWin32Window pOwner, object paramValue, string pCaption)
		{
			using (frmBrowseInstance l_frm = new frmBrowseInstance())
			{
				l_frm.LoadProperties(pOwner,paramValue,pCaption,this);
			}
		}
	}

	public class ReferencesInfo
	{
		private Assembly[] m_AssemblyToSearch = null;
		private Type[] m_TypesToSearch = null;
		
		public ReferencesInfo()
		{
		}
		public ReferencesInfo(Type[] pTypesToSearch, Assembly[] pAssemblyToSearch)
		{
			m_TypesToSearch = pTypesToSearch;
			m_AssemblyToSearch = pAssemblyToSearch;
		}

		public Assembly[] AssemblyToSearch
		{
			get{return m_AssemblyToSearch;}
			set{m_AssemblyToSearch = value;}
		}

		public Type[] TypeToSearchToSearch
		{
			get{return m_TypesToSearch;}
			set{m_TypesToSearch = value;}
		}
	}
}
