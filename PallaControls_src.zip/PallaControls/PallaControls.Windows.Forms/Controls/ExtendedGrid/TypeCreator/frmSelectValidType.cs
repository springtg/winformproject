using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace ControlWare.Windows.Controls
{
	public class frmSelectValidType : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Button btOK;
		private System.Windows.Forms.Button btCancel;
		private System.Windows.Forms.ListView listType;
		private System.Windows.Forms.Button btBrowse;
		private System.ComponentModel.Container components = null;

		public frmSelectValidType()
		{
			InitializeComponent();

			ColumnHeader l_Col1 = new ColumnHeader();
			l_Col1.Text = "Name";
			l_Col1.Width = 100;
			listType.Columns.Add(l_Col1);

			ColumnHeader l_Col2 = new ColumnHeader();
			l_Col2.Text = "FullName";
			l_Col2.Width = 200;
			listType.Columns.Add(l_Col2);

			ColumnHeader l_Col3 = new ColumnHeader();
			l_Col3.Text = "Assembly";
			l_Col3.Width = 300;
			listType.Columns.Add(l_Col3);
		}

		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.btOK = new System.Windows.Forms.Button();
			this.btCancel = new System.Windows.Forms.Button();
			this.listType = new System.Windows.Forms.ListView();
			this.btBrowse = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// btOK
			// 
			this.btOK.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right);
			this.btOK.BackColor = System.Drawing.SystemColors.Control;
			this.btOK.DialogResult = System.Windows.Forms.DialogResult.OK;
			this.btOK.Enabled = false;
			this.btOK.Location = new System.Drawing.Point(128, 271);
			this.btOK.Name = "btOK";
			this.btOK.Size = new System.Drawing.Size(72, 24);
			this.btOK.TabIndex = 6;
			this.btOK.Text = "&OK";
			// 
			// btCancel
			// 
			this.btCancel.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right);
			this.btCancel.BackColor = System.Drawing.SystemColors.Control;
			this.btCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.btCancel.Location = new System.Drawing.Point(216, 271);
			this.btCancel.Name = "btCancel";
			this.btCancel.Size = new System.Drawing.Size(72, 24);
			this.btCancel.TabIndex = 5;
			this.btCancel.Text = "&Cancel";
			// 
			// listType
			// 
			this.listType.Anchor = (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right);
			this.listType.FullRowSelect = true;
			this.listType.GridLines = true;
			this.listType.Location = new System.Drawing.Point(8, 8);
			this.listType.MultiSelect = false;
			this.listType.Name = "listType";
			this.listType.Size = new System.Drawing.Size(280, 248);
			this.listType.TabIndex = 7;
			this.listType.View = System.Windows.Forms.View.Details;
			this.listType.DoubleClick += new System.EventHandler(this.listType_DoubleClick);
			this.listType.SelectedIndexChanged += new System.EventHandler(this.listType_SelectedIndexChanged);
			// 
			// btBrowse
			// 
			this.btBrowse.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left);
			this.btBrowse.Enabled = false;
			this.btBrowse.Location = new System.Drawing.Point(8, 272);
			this.btBrowse.Name = "btBrowse";
			this.btBrowse.TabIndex = 8;
			this.btBrowse.Text = "Browse";
			// 
			// frmSelectValidType
			// 
			this.AcceptButton = this.btOK;
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.CancelButton = this.btCancel;
			this.ClientSize = new System.Drawing.Size(296, 299);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.btBrowse,
																		  this.listType,
																		  this.btOK,
																		  this.btCancel});
			this.Name = "frmSelectValidType";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Select valid type";
			this.ResumeLayout(false);

		}
		#endregion

		public virtual Type SelectTypeFromList(IWin32Window pOwner,Type pRequestedType, ArrayList pValidTypes)
		{
			foreach (Type t in pValidTypes)
			{
				ListViewItem l_Item = new ListViewItem(t.Name);
				l_Item.SubItems.Add(t.FullName);
				l_Item.SubItems.Add(t.Assembly.FullName);
				l_Item.Tag = t;
				listType.Items.Add(l_Item);
			}

			if (ShowDialog(pOwner) == DialogResult.OK)
			{
				if (listType.SelectedItems.Count>0)
				{
					ListViewItem l_Item = listType.SelectedItems[0];
					Type l_SelType = (Type)l_Item.Tag;
					return l_SelType;
				}
			}

			return null;
		}

		private void listType_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			if (listType.SelectedItems.Count>0)
				btOK.Enabled = true;
			else
				btOK.Enabled = false;
		}

		private void listType_DoubleClick(object sender, System.EventArgs e)
		{
			if (listType.SelectedItems.Count>0)
			{
				DialogResult = DialogResult.OK;
			}
		}
	}
}
