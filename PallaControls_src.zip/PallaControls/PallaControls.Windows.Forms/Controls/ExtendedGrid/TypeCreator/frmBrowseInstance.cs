using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace ControlWare.Windows.Controls
{
	internal class frmBrowseInstance : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Button btOK;
		private PropertyGridExtented propertyGridEx1;
		private System.ComponentModel.Container components = null;

		public frmBrowseInstance()
		{
			InitializeComponent();
		}

		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.btOK = new System.Windows.Forms.Button();
			this.propertyGridEx1 = new PropertyGridExtented();
			this.SuspendLayout();
			// 
			// btOK
			// 
			this.btOK.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right);
			this.btOK.BackColor = System.Drawing.SystemColors.Control;
			this.btOK.DialogResult = System.Windows.Forms.DialogResult.OK;
			this.btOK.Location = new System.Drawing.Point(296, 272);
			this.btOK.Name = "btOK";
			this.btOK.Size = new System.Drawing.Size(72, 24);
			this.btOK.TabIndex = 2;
			this.btOK.Text = "&OK";
			// 
			// propertyGridEx1
			// 
			this.propertyGridEx1.Anchor = (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right);
			this.propertyGridEx1.Location = new System.Drawing.Point(8, 8);
			this.propertyGridEx1.Name = "propertyGridEx1";
			this.propertyGridEx1.Size = new System.Drawing.Size(368, 256);
			this.propertyGridEx1.TabIndex = 3;
			// 
			// frmBrowseInstance
			// 
			this.AcceptButton = this.btOK;
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(378, 304);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.propertyGridEx1,
																		  this.btOK});
			this.Name = "frmBrowseInstance";
			this.ShowInTaskbar = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Format Cells Dialog";
			this.ResumeLayout(false);

		}
		#endregion

		public void LoadProperties(IWin32Window pOwner, object pObjectInstance, string pDialogText,TypeCreator pTypeCreator)
		{
			Text = pDialogText;
			propertyGridEx1.TypeCreator = pTypeCreator;
			propertyGridEx1.LoadProperties(pObjectInstance);
			ShowDialog(pOwner);
		}
	}
}
