using System;

namespace ControlWare.Windows.Controls
{
	public class CellFormatterBase : ICellFormatter
	{
		public CellFormatterBase()
		{
			NullAlias.Add(NullString);
		}

		public virtual bool IsNullObject(object paramValue)
		{
			if (paramValue==null)
				return true;
			foreach(object o in NullAlias)
				if (o.Equals(paramValue))
					return true;
			return false;
		}

		public virtual bool IsNullString(string pstr)
		{
			if (IsNullObject(pstr) || pstr==NullString)
				return true;
			else
				return false;
		}

		public virtual object StringToObject(string pstrValue)
		{
			if (IsNullString(pstrValue))
				return null;
			else
				return pstrValue;
		}

		public virtual string ObjectToString(object pObjValue)
		{
			try
			{
				if (IsNullObject(pObjValue))
					return NullString;
				else
					return pObjValue.ToString();
			}
			catch(Exception)
			{
				return ErrorString;
			}
		}

		public virtual bool SupportStringConversion
		{
			get{return true;}
		}

		public virtual string GetStringRappresentation(object paramValue)
		{
			if (paramValue!=null)
				return paramValue.ToString();
			else
				return "null";
		}

		public virtual bool IsValidString(string pstrValue)
		{
			return true;
		}

		public virtual string ExportValue(object pObjValue)
		{
			return ObjectToString(pObjValue);
		}

		public virtual object ImportValue(string pstrImport)
		{
			return StringToObject(pstrImport);
		}

		private System.Collections.ArrayList m_NullAlias = new System.Collections.ArrayList();
		private string m_NullString = ""; 
		private string m_ErrorString = "#ERROR!"; 

		public virtual System.Collections.ArrayList NullAlias
		{
			get{return m_NullAlias;}
		}

		public virtual string NullString
		{
			get{return m_NullString;}
			set{m_NullString = value;}
		}

		public virtual bool IsErrorString(string pstr)
		{
			if (pstr == ErrorString)
				return true;
			else
				return false;
		}

		public virtual string ErrorString
		{
			get{return m_ErrorString;}
			set{m_ErrorString = value;}
		}

		public virtual System.Collections.ICollection GetStandardValues()
		{
			return null;
		}

	}
}
