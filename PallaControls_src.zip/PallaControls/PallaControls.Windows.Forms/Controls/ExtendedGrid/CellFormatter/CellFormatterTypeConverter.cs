using System;
using System.ComponentModel;

namespace ControlWare.Windows.Controls
{
	public class CellFormatterTypeConverter : CellFormatterBase
	{
		private TypeConverter m_Converter;
		private System.Collections.ICollection m_StandardValues;

		public CellFormatterTypeConverter(Type pType):this(System.ComponentModel.TypeDescriptor.GetConverter(pType))
		{
		}
		public CellFormatterTypeConverter(TypeConverter pConverter)
		{
			m_Converter = pConverter;
			if (pConverter.GetStandardValuesSupported())
				m_StandardValues = pConverter.GetStandardValues();
			else
				m_StandardValues = null;
		}

		public CellFormatterTypeConverter(Type pType, System.Collections.ICollection pOverrideStandardValues)
			:this(System.ComponentModel.TypeDescriptor.GetConverter(pType),pOverrideStandardValues)
		{
		}
		public CellFormatterTypeConverter(TypeConverter pConverter, System.Collections.ICollection pOverrideStandardValues)
		{
			m_Converter = pConverter;
			m_StandardValues = pOverrideStandardValues;
		}

		public override object StringToObject(string pstrValue)
		{
			if (IsNullString(pstrValue))
				return null;
			else
				return m_Converter.ConvertFromString(pstrValue);
		}

		public override string ObjectToString(object pObjValue)
		{
			try
			{
				if (IsNullObject(pObjValue))
					return NullString;
				else
					return m_Converter.ConvertToString(pObjValue);
			}
			catch(Exception)
			{
				return ErrorString;
			}
		}

		public override bool SupportStringConversion
		{
			get{return (m_Converter.CanConvertFrom(typeof(string)) && m_Converter.CanConvertTo(typeof(string)));}
		}

		public override bool IsValidString(string pstrValue)
		{
			if ( m_Converter.IsValid(pstrValue)) 
			{
				try
				{
					object tmp = StringToObject(pstrValue);
					return true;
				}
				catch(Exception)
				{
					return false;
				}
			}
			else
				return false;
		}

		public override System.Collections.ICollection GetStandardValues()
		{
			return m_StandardValues;
		}
	}
}
