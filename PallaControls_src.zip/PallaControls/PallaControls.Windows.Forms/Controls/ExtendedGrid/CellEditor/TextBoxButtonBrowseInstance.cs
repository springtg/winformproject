using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace ControlWare.Windows.Controls
{
	public class TextBoxButtonBrowseInstance : TextBoxButton
	{
		private TypeCreator m_TypeCreator = null;

		public TextBoxButtonBrowseInstance()
		{
		}

		public TextBoxButtonBrowseInstance(Type innerType, TypeCreator pTypeCreator):this()
		{
			m_InnerType = innerType;
			m_TypeCreator = pTypeCreator;
		}

		private Type m_InnerType;
		protected override void OnButtonClick(object sender, EventArgs e)
		{
			try
			{
				base.OnButtonClick(this, e);

				object tmp = EditObject;
				if (tmp == null)
					tmp = m_TypeCreator.CreateInstanceUI(this,m_InnerType,"Create new instance of:" + m_InnerType.ToString());

				m_TypeCreator.BrowseInstanceUI(this,tmp,"Browse instance of type:" + m_InnerType.ToString());

				EditObject = tmp;
			}
			catch(Exception err)
			{
				MessageBox.Show(err.Message,"Error");
			}
		}
	}
}

