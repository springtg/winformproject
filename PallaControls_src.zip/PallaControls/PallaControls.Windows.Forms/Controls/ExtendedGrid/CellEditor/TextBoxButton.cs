using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;

namespace ControlWare.Windows.Controls
{
	[ToolboxItem(false)]
	public class TextBoxButton : ControlWare.Windows.Controls.ButtonEdit
	{
		public TextBoxButton():base()
		{
			this.ButtonPressed += new ButtonPressedEventHandler(this.OnButtonClick);
		}

		#region Dispose

		protected override void Dispose( bool disposing )
		{
			this.ButtonPressed -= new ButtonPressedEventHandler(this.OnButtonClick);
			base.Dispose(disposing);
		}

		#endregion

		public void FillControl()
		{
			this.Location = new Point(0,0);
			this.Size = new Size(Width,Height);
		}

		protected override void OnSizeChanged(EventArgs e)
		{
			base.OnSizeChanged(e);
			FillControl();
		}

		protected virtual void OnButtonClick(object sender, EventArgs e)
		{
			if (m_Cell==null)
				throw new ApplicationException("LoadCell not called");
		}

		private object m_EditObject = null;
		public object EditObject
		{
			get
			{
				if (m_Cell!=null && m_Cell.CellFormatter!=null)
				{
					if (m_Cell.CellFormatter.SupportStringConversion)
						return m_Cell.CellFormatter.StringToObject(this.Text);
					else
						return m_EditObject;
				}
				else
					return m_EditObject;
			}
			set
			{
				if (m_Cell!=null && m_Cell.CellFormatter!=null)
				{
					if (m_Cell.CellFormatter.SupportStringConversion)
						this.Text = m_Cell.CellFormatter.ObjectToString(value);
					else
						this.Text = m_Cell.CellFormatter.GetStringRappresentation(value);
				}

				m_EditObject = value;
			}
		}

		private bool ReadOnlyTextBox
		{
			get{return this.ReadOnly;}
			set{this.ReadOnly = value;}
		}

		private Cell m_Cell = null;
		public Cell Cell
		{
			get{return m_Cell;}
		}

		public virtual void LoadCell(Cell paramCell, object paramStartEditValue)
		{
			m_Cell = paramCell;

			if (paramStartEditValue!=null)
				EditObject = paramStartEditValue;
			else
				EditObject = m_Cell.Value;;

			if (m_Cell.CellFormatter.SupportStringConversion)
				ReadOnlyTextBox = false;
			else
				ReadOnlyTextBox = true;
		}
	}
}
