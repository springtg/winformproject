using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace ControlWare.Windows.Controls
{
	public class TextBoxButtonEditor : CellEditorBase
	{
		private TextBoxButton m_TextBoxButton = null;
		public TextBoxButton TextBoxButton
		{
			get{return m_TextBoxButton;}
			set{m_TextBoxButton = value;}
		}

		public TextBoxButtonEditor(TextBoxButton textBoxButton)
		{
			m_TextBoxButton = textBoxButton;
		}

		public override void StartEdit(object paramStartEditValue)
		{
			m_TextBoxButton.Location = Cell.DisplayRectangle.Location; 
			m_TextBoxButton.Size = Cell.DisplayRectangle.Size;

			InnerStartEdit(m_TextBoxButton,false);

			m_TextBoxButton.LoadCell(Cell,paramStartEditValue);
		}

		public override object GetEditedValue()
		{
			return m_TextBoxButton.EditObject;
		}
	}
}

