using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using System.Drawing.Design;

namespace ControlWare.Windows.Controls
{
	public class TextBoxButtonUITypeEditor : TextBoxButton, IServiceProvider, System.Windows.Forms.Design.IWindowsFormsEditorService
	{
		private System.ComponentModel.IContainer components = null;

		public TextBoxButtonUITypeEditor()
		{
			InitializeComponent();

		}

		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			components = new System.ComponentModel.Container();
		}
		#endregion


		protected override void OnButtonClick(object sender, EventArgs e)
		{
			base.OnButtonClick(sender, e);
			ShowUITypeEditor();
		}

		protected virtual void ShowUITypeEditor()
		{
			try
			{
				UITypeEditorEditStyle l_Style = m_UITypeEditor.GetEditStyle();
				if (l_Style == UITypeEditorEditStyle.DropDown ||
					l_Style == UITypeEditorEditStyle.Modal)
				{
					object tmp = m_UITypeEditor.EditValue(this,EditObject);
					EditObject = tmp;
				}
			}
			catch(Exception err)
			{
				MessageBox.Show(err.Message,"Error");
			}
		}

		private UITypeEditor m_UITypeEditor;
		public UITypeEditor UITypeEditor
		{
			get{return m_UITypeEditor;}
			set{m_UITypeEditor = value;}
		}

		System.Object IServiceProvider.GetService ( System.Type serviceType )
		{
			if (serviceType == typeof(System.Windows.Forms.Design.IWindowsFormsEditorService))
				return this;

			return null;
		}

		#region System.Windows.Forms.Design.IWindowsFormsEditorService

		private frmDropDownCustom m_dropDown = null;
		public virtual void CloseDropDown ()
		{
			if (m_dropDown!=null)
			{
				m_dropDown.Hide();
			}
		}

		public virtual void DropDownControl ( System.Windows.Forms.Control control )
		{
			m_dropDown = new frmDropDownCustom(this, control);
			m_dropDown.ShowDropDown();
			m_dropDown = null;
		}

		public virtual System.Windows.Forms.DialogResult ShowDialog ( System.Windows.Forms.Form dialog )
		{
			return dialog.ShowDialog(this);
		}
		#endregion
	}
}

