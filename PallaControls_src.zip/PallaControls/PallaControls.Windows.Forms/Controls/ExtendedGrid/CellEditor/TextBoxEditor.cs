using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;

using System.Windows.Forms;


namespace ControlWare.Windows.Controls
{
	public class TextBoxEditor : CellEditorBase
	{
		private ControlWare.Windows.Controls.TextBox m_TextBox = null;

		public TextBoxEditor()
		{
		}

		public override void StartEdit(object paramStartEditValue)
		{
			m_TextBox = new ControlWare.Windows.Controls.TextBox();
			m_TextBox.Location = Cell.DisplayRectangle.Location; 
			m_TextBox.Size = Cell.DisplayRectangle.Size;
			InnerStartEdit(m_TextBox);

			if (paramStartEditValue!=null)
			{
				m_TextBox.Text = paramStartEditValue.ToString();
				//m_TextBox.SelectionStart = m_TextBox.Text.Length;
			}
			else
			{
				m_TextBox.Text = Cell.DisplayText;
				//m_TextBox.SelectAll();
			}
		}

		public override object GetEditedValue()
		{
			return m_TextBox.Text;
		}
	}
}