using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace ControlWare.Windows.Controls
{
	public class ComboBoxEditor : CellEditorBase
	{
		private ControlWare.Windows.Controls.ComboBox m_ComboBoxEx = null;

		private ICellFormatter m_Formatter;

		public ComboBoxEditor(ICellFormatter formatter)
		{
			m_Formatter = formatter;
		}

		public override void StartEdit(object paramStartEditValue)
		{
			ArrayList l_Items = null;
			ICollection l_tmp = m_Formatter.GetStandardValues();
			if (l_tmp!=null)
				l_Items = new ArrayList(l_tmp);

			if (paramStartEditValue!=null)
			{
				m_ComboBoxEx = new ControlWare.Windows.Controls.ComboBox();
				//m_ComboBoxEx.Items.Add
			}
			else
				m_ComboBoxEx = new ControlWare.Windows.Controls.ComboBox();

			/*if (m_Formatter.SupportStringConversion)
				m_ComboBoxEx.ReadOnlyTextBox = false;
			else
				m_ComboBoxEx.ReadOnlyTextBox = true;*/

			m_ComboBoxEx.Location = Cell.DisplayRectangle.Location;
			m_ComboBoxEx.Size = Cell.DisplayRectangle.Size;
			InnerStartEdit(m_ComboBoxEx);

			//m_ComboBoxEx.SelectAllDisplayText();
		}

		public override object GetEditedValue()
		{
			//return m_ComboBoxEx.EditObject;
			return null;
		}
	}
}

