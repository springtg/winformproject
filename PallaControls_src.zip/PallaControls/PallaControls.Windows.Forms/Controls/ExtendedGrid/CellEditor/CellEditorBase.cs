using System;
using System.Windows.Forms;

namespace ControlWare.Windows.Controls
{
	public abstract class  CellEditorBase : ICellEditor, IDisposable
	{
		private Cell m_Cell = null;
		public Cell Cell
		{
			get{return m_Cell;}
			set
			{
				if (m_Cell == null || value == null)
					m_Cell = value;
				else
					throw new ApplicationException("CellEditor already have a cell associated");
			}
		}


		private object m_DefaultValue = null;
		public virtual object DefaultValue
		{
			get{return m_DefaultValue;}
			set{m_DefaultValue = value;}
		}

		public CellEditorBase()
		{
		}

		private System.Windows.Forms.Control m_Control = null;

		private bool m_DisposeControlOnEndEdit;
		private bool m_IsEditing = false;
		public bool IsEditing
		{
			get{return m_IsEditing;}
		}

		public abstract void StartEdit(object paramStartEditValue);

		public virtual bool ApplyEdit()
		{
			if (IsEditing == true)
			{
				bool l_bSuccess;

				try
				{
					l_bSuccess = ChangeCellValue(GetEditedValue());
				}
				catch(Exception err)
				{
					MessageBox.Show(err.Message,"Error editing cell(" + m_Cell.Row +"," +m_Cell.Col + ") error");
					l_bSuccess = false;
				}

				return l_bSuccess;
			}
			else
				return true;
		}
		public virtual bool EndEdit(bool paramCancel)
		{
			if (IsEditing == true)
			{
				bool l_bSuccess = true;
				if (paramCancel==false)
					l_bSuccess = ApplyEdit();

				if (l_bSuccess)
					InnerEndEdit(true);

				return l_bSuccess;
			}
			else
				return true;
		}

		protected virtual void InnerStartEdit(Control paramControl)
		{
			InnerStartEdit(paramControl,true);
		}
		protected virtual void InnerStartEdit(Control paramControl, bool disposeControlOnEndEdit)
		{
			if (IsEditing == false)
			{
				InnerRemoveControl();

				m_DisposeControlOnEndEdit = disposeControlOnEndEdit;
				m_Control = paramControl;
				if (m_Control!=null)
				{
					m_Cell.Grid.Controls.Add(m_Control);

					m_Control.Validating += new System.ComponentModel.CancelEventHandler(InnerControlValidating);
					m_Control.Validated += new EventHandler(InnerControlValidated);

					m_Control.Show();
					m_Control.BringToFront();
					m_Control.Focus();
				}
				m_IsEditing = true;
			}
		}


		private void InnerRemoveControl()
		{
			try
			{
				if (m_Control!=null)
				{
					m_Control.Validating -= new System.ComponentModel.CancelEventHandler(InnerControlValidating);
					m_Control.Validated -= new EventHandler(InnerControlValidated);
						
					//.Net bug : application doesn't close when a active control is removed from the control collection
					// change the focus first
					m_Cell.Grid.SetFocusOnCellsContainer();

					m_Control.Hide();
					m_Cell.Grid.Controls.Remove(m_Control);
					if (m_DisposeControlOnEndEdit)
						m_Control.Dispose();
				}
			}
			catch(Exception)
			{
				System.Diagnostics.Debug.Assert(false);
			}
			finally
			{
				m_Control = null;
			}
		}

		private void InnerEndEdit(bool pRemoveControl)
		{
			if (IsEditing == true)
			{
				if (m_Control!=null)
					m_Control.Hide();

				if (pRemoveControl)
					InnerRemoveControl();

				m_IsEditing = false;
			}
		}

		protected virtual void InnerControlValidated(object sender, EventArgs e)
		{
			try
			{
				bool l_bSuccess = ApplyEdit();
				
				InnerEndEdit(false);
			}
			catch(Exception)
			{
				System.Diagnostics.Debug.Assert(false);
			}
		}
		protected virtual void InnerControlValidating(object sender, System.ComponentModel.CancelEventArgs e)
		{
			try
			{
				ValidatingEventArgs l_cancelEvent = new ValidatingEventArgs(GetEditedValue());
				OnValidatingValue(l_cancelEvent);

				e.Cancel = l_cancelEvent.Cancel;
			}
			catch(Exception)
			{
				e.Cancel = true;
			}
		}

		public virtual void ClearCell()
		{
			ChangeCellValue(DefaultValue);
		}

		public virtual bool ChangeCellValue(object paramNewValue)
		{
			ValidatingEventArgs l_cancelEvent = new ValidatingEventArgs(paramNewValue);
			OnValidating(l_cancelEvent);

			if (l_cancelEvent.Cancel == false)
			{
				object l_PrevValue = m_Cell.Value;
				try
				{
					m_Cell.Value = l_cancelEvent.NewValue;
				}
				catch(Exception err)
				{
					m_Cell.Value = l_PrevValue;
					throw err;
				}
				OnValidated(new EventArgs());
			}

			return (l_cancelEvent.Cancel==false);
		}

		protected virtual void OnValidated(EventArgs e)
		{
			if (m_Validated!=null)
				m_Validated(this,e);
		}
		protected virtual void OnValidating(ValidatingEventArgs e)
		{
			if (m_Validating!=null)
				m_Validating(this,e);
			OnValidatingValue(e);
		}
		protected virtual void OnValidatingValue(ValidatingEventArgs e)
		{
			if (m_ValidatingValue!=null)
				m_ValidatingValue(this,e);
		}
		private event ValidatingEventHandler m_Validating;
		private event EventHandler m_Validated;
		private event ValidatingEventHandler m_ValidatingValue;

		public event ValidatingEventHandler Validating
		{
			add{m_Validating+=value;}
			remove{m_Validating-=value;}
		}
		public event EventHandler Validated
		{
			add{m_Validated+=value;}
			remove{m_Validated-=value;}
		}
		public event ValidatingEventHandler ValidatingValue
		{
			add{m_ValidatingValue+=value;}
			remove{m_ValidatingValue-=value;}
		}
		public bool IsValidValue(object paramValue)
		{
			ValidatingEventArgs l_Valid = new ValidatingEventArgs(paramValue);
			OnValidatingValue(l_Valid);
			return (l_Valid.Cancel == false);
		}

		public abstract object GetEditedValue();

		private bool disposed = false;

		public void Dispose()
		{
			Dispose(true);
			GC.SuppressFinalize(this);
		}

		protected virtual void Dispose(bool disposing)
		{
			if(!this.disposed)
			{
				if(disposing)
				{
					if (m_Control!=null)
						m_Control.Dispose();
				}
			}
			disposed = true;         
		}

		~CellEditorBase()      
		{
			Dispose(false);
		}
	}

}
