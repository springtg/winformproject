using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;


namespace ControlWare.Windows.Controls
{
	public class DateTimeEditor : CellEditorBase
	{
		protected ControlWare.Windows.Controls.DatePicker m_dtPicker = null;

		public DateTimeEditor()
		{
		}

		public override void StartEdit(object paramStartEditValue)
		{
			m_dtPicker = new ControlWare.Windows.Controls.DatePicker();

			m_dtPicker.Location = Cell.DisplayRectangle.Location; 
			m_dtPicker.Size = Cell.DisplayRectangle.Size;
			InnerStartEdit(m_dtPicker);

			if (paramStartEditValue != null)
			{
				if (paramStartEditValue is DateTime)
					m_dtPicker.Value = (DateTime)paramStartEditValue;
				else if (paramStartEditValue == null)
					m_dtPicker.Value = DateTime.Now;
				else
					throw new ApplicationException("Invalid StartEditValue, expected DateTime");
			}
			else
			{
				if (Cell.Value is DateTime)
					m_dtPicker.Value = (DateTime)Cell.Value;
				else if (Cell.Value == null)
					m_dtPicker.Value = DateTime.Now;
				else
					throw new ApplicationException("Invalid cell value, expected DateTime");
			}
		}

		public override object GetEditedValue()
		{
			return m_dtPicker.Value;
		}
	}
}