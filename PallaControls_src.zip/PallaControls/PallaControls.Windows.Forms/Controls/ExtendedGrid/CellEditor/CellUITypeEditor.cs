using System;
using System.Windows.Forms;
using System.ComponentModel;
using System.Drawing.Design;

namespace ControlWare.Windows.Controls
{
	public class CellUITypeEditor : TextBoxButtonEditor
	{
		private TextBoxButtonUITypeEditor m_TxtBt;
		public CellUITypeEditor(UITypeEditor uiTypeEditor):base(new TextBoxButtonUITypeEditor())
		{
			m_TxtBt = (TextBoxButtonUITypeEditor)base.TextBoxButton;
			m_TxtBt.UITypeEditor = uiTypeEditor;
		}
		
		public UITypeEditor UITypeEditor
		{
			get{return m_TxtBt.UITypeEditor;}
			set{m_TxtBt.UITypeEditor = value;}
		}
	}
}
