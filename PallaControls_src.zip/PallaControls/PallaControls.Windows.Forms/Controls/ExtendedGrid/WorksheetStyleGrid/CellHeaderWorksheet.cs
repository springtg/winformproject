using System;

namespace ControlWare.Windows.Controls
{
	public class CellHeaderWorksheetCol : CellHeader
	{
		protected override void OnRowChange(EventArgs e)
		{
			CalcLabel();
		}
		protected override void OnColChange(EventArgs e)
		{
			CalcLabel();
		}
		private void CalcLabel()
		{
			Value = Row.ToString();
		}
	}

	public class CellHeaderWorksheetRow : CellHeader
	{
		protected override void OnRowChange(EventArgs e)
		{
			CalcLabel();
		}
		protected override void OnColChange(EventArgs e)
		{
			CalcLabel();
		}
		private void CalcLabel()
		{
			if (Col >=0)
				Value = GridWorksheet.GetColCaption(Col);
			else
				Value = "NA";
		}
	}
}
