using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using ControlWare.Windows.Controls.Helpers;

namespace ControlWare.Windows.Controls
{
	public class GridWorksheet : Grid
	{
		private System.ComponentModel.IContainer components = null;

		public GridWorksheet()
		{
			InitializeComponent();

			m_iImageAddColumn = GetImage("InsertCol.ico");
			m_iImageAddRow = GetImage("InsertRow.ico");
			m_iImageRemoveColumn = GetImage("DeleteCol.ico");
			m_iImageRemoveRow = GetImage("DeleteRow.ico");

			FixedCols = 1;
			FixedRows = 1;

			Redim(36,36);
		}

		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.SuspendLayout();
			// 
			// GridWorksheet
			// 
			this.Name = "GridWorksheet";
			this.Size = new System.Drawing.Size(200, 200);
			this.ResumeLayout(false);

		}
		#endregion



		private int GetImage(string pImage)
		{
			System.Reflection.Assembly l_as = System.Reflection.Assembly.GetExecutingAssembly();
			return AddMenuImage(Image.FromStream(l_as.GetManifestResourceStream("ControlWare.Windows.Controls.res." + pImage)));
		}

		private int m_iImageAddColumn;
		private int m_iImageAddRow;
		private int m_iImageRemoveColumn;
		private int m_iImageRemoveRow;

		protected Cell CreateCaptionToparamCell()
		{
			Cell tmp = new CellHeaderWorksheetRow();
			tmp.TextAlignment = ContentAlignment.MiddleCenter;

			MenuItem l_mnAddCol = new MenuItem("Add Column", new EventHandler(ContextMenuAddColumn));
			SetMenuImage(l_mnAddCol,m_iImageAddColumn);
			MenuItem l_mnRemoveCol = new MenuItem("Remove Column", new EventHandler(ContextMenuRemoveColumn));
			SetMenuImage(l_mnRemoveCol,m_iImageRemoveColumn);
			tmp.ContextMenuItems.Add(l_mnAddCol);
			tmp.ContextMenuItems.Add(l_mnRemoveCol);

			return tmp;
		}
		protected Cell CreateCaptionLeftCell()
		{
			Cell tmp = new CellHeaderWorksheetCol();
			tmp.TextAlignment = ContentAlignment.MiddleCenter;

			MenuItem l_mnAddRow = new MenuItem("Add Row", new EventHandler(ContextMenuAddRow));
			SetMenuImage(l_mnAddRow,m_iImageAddRow);
			MenuItem l_mnRemoveRow = new MenuItem("Remove Row", new EventHandler(ContextMenuRemoveRow));
			SetMenuImage(l_mnRemoveRow,m_iImageRemoveRow);
			tmp.ContextMenuItems.Add(l_mnAddRow);
			tmp.ContextMenuItems.Add(l_mnRemoveRow);

			return tmp;
		}

		protected void ContextMenuAddRow(object sender, EventArgs e)
		{
			if (FocusCell != null)
				AddRow(FocusCell.Row);
		}
		protected void ContextMenuRemoveRow(object sender, EventArgs e)
		{
			if (FocusCell != null)
				RemoveRow(FocusCell.Row);
		}
		protected void ContextMenuAddColumn(object sender, EventArgs e)
		{
			if (FocusCell != null)
				AddColumn(FocusCell.Col);
		}
		protected void ContextMenuRemoveColumn(object sender, EventArgs e)
		{
			if (FocusCell != null)
				RemoveColumn(FocusCell.Col);
		}

		protected Cell CreateNormalCell()
		{
			Cell tmp = new CellWorksheet();
			return tmp;
		}

		protected bool m_EnableExpandSelection = false;
		public bool EnableExpandSelection
		{
			get{return m_EnableExpandSelection;}
			set{m_EnableExpandSelection = value;}
		}

		protected override void OnUndoMouseSelection(CellArrayEventArgs e)
		{
			if (m_EnableExpandSelection)
			{
				foreach (Cell c in e.Cells)
				{
					if (c.Select == false)
						c.SetAllBorderColor(Color.LightGray);
				}
			}
			else
				base.OnUndoMouseSelection(e);
		}

		protected override void OnApplyMouseSelection(CellArrayEventArgs e)
		{
			if (m_EnableExpandSelection)
			{
				foreach (Cell c in e.Cells)
				{
					if (c.Select == false)
						c.SetAllBorderColor(Color.Black);
				}
			}
			else
				base.OnApplyMouseSelection(e);
		}

		protected override void OnMouseSelectionFinish(CellArrayEventArgs e)
		{
			if (m_EnableExpandSelection)
			{
				foreach (Cell c in e.Cells)
				{
					if (c.Select == false)
						c.SetAllBorderColor(Color.LightGray);
				}

				int l_DestLeft = int.MaxValue;
				int l_DestTop = int.MaxValue;
				int l_DestRight = int.MinValue;
				int l_DestBottom = int.MinValue;
				foreach (Cell c in e.Cells)
				{
					if (c.Col > l_DestRight)
						l_DestRight = c.Col;
					if (c.Row > l_DestBottom)
						l_DestBottom = c.Row;
					if (c.Col < l_DestLeft)
						l_DestLeft = c.Col;
					if (c.Row < l_DestTop)
						l_DestTop = c.Row;
				}

				int l_SourceLeft = int.MaxValue;
				int l_SourceTop = int.MaxValue;
				int l_SourceRight = int.MinValue;
				int l_SourceBottom = int.MinValue;
				
				foreach (Cell c in Selection)
				{
					if (c.Col > l_SourceRight)
						l_SourceRight = c.Col;
					if (c.Row > l_SourceBottom)
						l_SourceBottom = c.Row;
					if (c.Col < l_SourceLeft)
						l_SourceLeft = c.Col;
					if (c.Row < l_SourceTop)
						l_SourceTop = c.Row;
				}

				for (int l_DestRow = l_DestTop; l_DestRow <= l_DestBottom; l_DestRow++)
				{
					for (int l_DestCol = l_DestLeft; l_DestCol <= l_DestRight; l_DestCol++)
					{
						Cell l_DestCell = this[l_DestRow,l_DestCol];
						if (l_DestCell != null && l_DestCell.Select == false)
						{
							int l_SourceRow;
							int l_SourceCol;
							if (l_DestCol>l_SourceRight)
								l_SourceCol = l_DestCol-(l_SourceRight-l_SourceLeft+1);
							else
								l_SourceCol = l_DestCol;

							if (l_DestRow>l_SourceBottom)
								l_SourceRow = l_DestRow-(l_SourceBottom-l_SourceTop+1);
							else
								l_SourceRow = l_DestRow;

							Cell l_SourceCell = this[l_SourceRow,l_SourceCol];

							if (l_DestCell.CellEditor != null)
								l_DestCell.CellEditor.ChangeCellValue(l_SourceCell.Value);
						}
					}
				}
			}

			base.OnMouseSelectionFinish(e);
		}

		public static string GetColCaption(int pCol)
		{
			int l_NumLap = ((pCol-1) / 26);
			int l_Remainder = (pCol) - (l_NumLap * 26);
			string l_tmp = "";

			if (l_NumLap>0)
				l_tmp += GetColCaption(l_NumLap);

			l_tmp += new string((char)('A'+l_Remainder-1),1);
			return l_tmp;
		}

		protected override void OnRowAdded(RowEventArgs e)
		{
			base.OnRowAdded(e);
			if (e.Row < FixedRows)
				for (int c = FixedCols; c < Cols; c++)
					InsertCell(e.Row,c,CreateCaptionToparamCell());
			else
			{
				for (int c = FixedCols; c < Cols; c++)
					InsertCell(e.Row,c,CreateNormalCell());

				for (int c = 0; c < Math.Min(Cols,FixedCols); c++)
					InsertCell(e.Row,c,CreateCaptionLeftCell());
			}
		}
		protected override void OnRowRemoved(RowEventArgs e)
		{
			base.OnRowRemoved(e);

		}
		protected override void OnColumnAdded(ColumnEventArgs e)
		{
			base.OnColumnAdded(e);
			if (e.Column < FixedCols)
				for (int r = FixedRows; r < Rows; r++)
					InsertCell(r,e.Column,CreateCaptionLeftCell());
			else
			{
				for (int r = FixedRows; r < Rows; r++)
					InsertCell(r,e.Column,CreateNormalCell());

				for (int r = 0; r < Math.Min(FixedRows,Rows); r++)
					InsertCell(r,e.Column,CreateCaptionToparamCell());
			}
		}
		protected override void OnColumnRemoved(ColumnEventArgs e)
		{
			base.OnColumnRemoved(e);

		}
	}
}

