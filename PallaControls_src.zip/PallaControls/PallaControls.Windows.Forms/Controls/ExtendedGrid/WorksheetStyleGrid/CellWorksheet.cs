using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;
using ControlWare.Windows.Controls.Helpers;

namespace ControlWare.Windows.Controls
{
	public class CellWorksheet : Cell
	{

		protected GridWorksheet mGridWorksheet;

		protected override void OnAddToGrid(EventArgs e)
		{
			base.OnAddToGrid(e);
			mGridWorksheet = (GridWorksheet)Grid;
		}

		public CellWorksheet()
		{
			mSelectionExpander = new SelectionExpander(this);
			CellEditor = new TextBoxEditor();
			EditableMode = EditableMode.DoubleClick|EditableMode.AnyKey;
		}

		public override void RaisePaint(PaintEventArgs e)
		{
			base.RaisePaint(e);

			if (mSelectionExpander != null && Grid.Selection.RightBottomCell == this)
			{
				mSelectionExpander.Draw(e,
					SelectionExpanderLocation);
			}
		}

		protected Point SelectionExpanderLocation
		{
			get
			{
				Rectangle l_rcSelectionExpander = DisplayRectangle;
				return new Point(l_rcSelectionExpander.Right - mSelectionExpander.Size.Width,
					l_rcSelectionExpander.Bottom - mSelectionExpander.Size.Height);
			}
		}

		bool m_isMouseOverSeletionExpander = false;
		protected bool IsPointInSelectionExpander(Point p)
		{
			Point l_SelectionExpanderLocation = SelectionExpanderLocation;
			if (p.X>=l_SelectionExpanderLocation.X && p.X <=(l_SelectionExpanderLocation.X + mSelectionExpander.Size.Width)&&
				p.Y>=l_SelectionExpanderLocation.Y && p.Y <=(l_SelectionExpanderLocation.Y + mSelectionExpander.Size.Height))
			{
				if (Grid.Selection.RightBottomCell == this)
				{
					return true;
				}
			}

			return false;
		}
		public override void RaiseMouseMove(MouseEventArgs e)
		{
			if (mSelectionExpander != null)
			{
				if (IsPointInSelectionExpander(new Point(e.X,e.Y)))
				{
					if (m_isMouseOverSeletionExpander == false && Grid.Selection.RightBottomCell == this)
					{
						m_isMouseOverSeletionExpander = true;
						mSelectionExpander.MouseEnter(new EventArgs());
					}
				}
				else
				{
					if (m_isMouseOverSeletionExpander)
					{
						m_isMouseOverSeletionExpander = false;
						mSelectionExpander.MouseLeave(new EventArgs());
					}
				}
			}
			base.RaiseMouseMove(e);
		}

		protected SelectionExpander mSelectionExpander = null;
		public SelectionExpander SelectionExpander
		{
			get{return mSelectionExpander;}
			set{mSelectionExpander = value;RaiseInvalidate();}
		}


		public override void RaiseMouseLeave(EventArgs e)
		{
			if (mSelectionExpander != null && m_isMouseOverSeletionExpander)
			{
				m_isMouseOverSeletionExpander = false;
				mSelectionExpander.MouseLeave(e);
			}
			base.RaiseMouseLeave(e);
		}

		public override void RaiseMouseDown(MouseEventArgs e)
		{
			if (IsPointInSelectionExpander(new Point(e.X,e.Y)))
			{
				mGridWorksheet.EnableExpandSelection = true;
			}
			else
			{
				base.RaiseMouseDown(e);
			}
		}
		public override void RaiseMouseUp(MouseEventArgs e)
		{
			base.RaiseMouseUp(e);
			mGridWorksheet.EnableExpandSelection = false;
		}
	}
}
