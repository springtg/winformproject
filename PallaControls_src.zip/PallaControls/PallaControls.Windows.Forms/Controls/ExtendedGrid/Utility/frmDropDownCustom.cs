using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace ControlWare.Windows.Controls
{
	internal class frmDropDownCustom : System.Windows.Forms.Form
	{
		private Point StartLocation = new Point(0,0);
		private Rectangle ParentRectangle;
		private Control m_InnerControl = null;

		private System.ComponentModel.Container components = null;

		public frmDropDownCustom()
		{
			InitializeComponent();

		}
		public frmDropDownCustom(Control pParentControl, Control pInnerControl):this()
		{
			m_InnerControl = pInnerControl;
			m_InnerControl.Width = Math.Max(pParentControl.Width,pInnerControl.Width);
			ParentRectangle = pParentControl.RectangleToScreen(pParentControl.ClientRectangle);
			Controls.Add(m_InnerControl);
			m_InnerControl.Location = new Point(0,0);
			Size = m_InnerControl.Size;
		}

		private void InnerControlResize(object sender, EventArgs e)
		{
			if (m_InnerControl != null)
			{
				Size = m_InnerControl.Size;
			}
		}

		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			// 
			// ctlDropDownCustom
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(40, 32);
			this.ControlBox = false;
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "ctlDropDownCustom";
			this.ShowInTaskbar = false;
			this.Text = "ctlDropDownCustom";
			this.Activated += new System.EventHandler(this.ctlDropDownCustom_Activated);
			this.Deactivate += new System.EventHandler(this.ctlDropDownCustom_Deactivate);

		}
		#endregion

		private void CalcLocation()
		{
			Screen DisplayedOnScreen = Screen.FromPoint(new Point(ParentRectangle.X, ParentRectangle.Bottom));
			int MinScreenXPos = DisplayedOnScreen.Bounds.X;
			int MinScreenYPos = DisplayedOnScreen.Bounds.Y;
			int MaxScreenXPos = DisplayedOnScreen.Bounds.X + DisplayedOnScreen.Bounds.Width;
			int MaxScreenYPos = DisplayedOnScreen.Bounds.Y + DisplayedOnScreen.Bounds.Height;

			int DropdownWidth  = Width; 
			int DropdownHeight = Height; 

			if((ParentRectangle.X + DropdownWidth) <= MaxScreenXPos )
			{
				if( ParentRectangle.X < MinScreenXPos )
					StartLocation.X = MinScreenXPos;
				else
					StartLocation.X = ParentRectangle.X;
			}
			else
			{
				if( Screen.FromPoint(new Point((ParentRectangle.X + ParentRectangle.Width), 0)) == DisplayedOnScreen )
					StartLocation.X = ParentRectangle.Right-DropdownWidth;
				else
					StartLocation.X = MaxScreenXPos - DropdownWidth;
			}

			if( (ParentRectangle.Bottom + DropdownHeight) <= MaxScreenYPos )
				StartLocation.Y = ParentRectangle.Bottom;
			else
			{
				StartLocation.Y = ParentRectangle.Y-DropdownHeight;
			}

			this.Location = StartLocation;
		}

		private void ctlDropDownCustom_Activated(object sender, System.EventArgs e)
		{
			CalcLocation();
		}

		protected override bool ProcessCmdKey(
			ref Message msg,
			Keys keyData
			)
		{
			if (keyData == Keys.Escape)
			{
				DialogResult = DialogResult.Cancel;
				Hide();
				return true;
			}
			return base.ProcessCmdKey(ref msg,keyData);
		}


		private bool m_bIsDeactivated = false;
		private void ctlDropDownCustom_Deactivate(object sender, System.EventArgs e)
		{
			m_bIsDeactivated = true;
			Hide();
		}

		public void ShowDropDown()
		{
			m_InnerControl.Resize += new EventHandler(InnerControlResize);

			Show();

			Size = m_InnerControl.Size;

			while(m_bIsDeactivated==false)
				Application.DoEvents();

			m_InnerControl.Resize -= new EventHandler(InnerControlResize);
		}
	}
}
