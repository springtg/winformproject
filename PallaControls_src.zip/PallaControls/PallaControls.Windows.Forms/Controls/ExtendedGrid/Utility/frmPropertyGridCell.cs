using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using ControlWare.Windows.Controls.Helpers;

namespace ControlWare.Windows.Controls
{
	internal class frmPropertyGridCell : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Button btCancel;
		private System.Windows.Forms.Button btOK;
		private PropertyGridExtented propertyGridEx1;
		private System.ComponentModel.Container components = null;

		public frmPropertyGridCell()
		{
			InitializeComponent();

		}

		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		private void InitializeComponent()
		{
			this.btCancel = new System.Windows.Forms.Button();
			this.btOK = new System.Windows.Forms.Button();
			this.propertyGridEx1 = new PropertyGridExtented();
			this.SuspendLayout();
			// 
			// btCancel
			// 
			this.btCancel.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right);
			this.btCancel.BackColor = System.Drawing.SystemColors.Control;
			this.btCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.btCancel.Location = new System.Drawing.Point(296, 272);
			this.btCancel.Name = "btCancel";
			this.btCancel.Size = new System.Drawing.Size(72, 24);
			this.btCancel.TabIndex = 1;
			this.btCancel.Text = "&Cancel";
			// 
			// btOK
			// 
			this.btOK.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right);
			this.btOK.BackColor = System.Drawing.SystemColors.Control;
			this.btOK.DialogResult = System.Windows.Forms.DialogResult.OK;
			this.btOK.Location = new System.Drawing.Point(208, 272);
			this.btOK.Name = "btOK";
			this.btOK.Size = new System.Drawing.Size(72, 24);
			this.btOK.TabIndex = 2;
			this.btOK.Text = "&OK";
			this.btOK.Click += new System.EventHandler(this.btOK_Click);
			// 
			// propertyGridEx1
			// 
			this.propertyGridEx1.Anchor = (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right);
			this.propertyGridEx1.Location = new System.Drawing.Point(8, 8);
			this.propertyGridEx1.Name = "propertyGridEx1";
			this.propertyGridEx1.Size = new System.Drawing.Size(368, 256);
			this.propertyGridEx1.TabIndex = 3;
			// 
			// frmPropertyGridCell
			// 
			this.AcceptButton = this.btOK;
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.CancelButton = this.btCancel;
			this.ClientSize = new System.Drawing.Size(378, 304);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.propertyGridEx1,
																		  this.btOK,
																		  this.btCancel});
			this.Name = "frmPropertyGridCell";
			this.ShowInTaskbar = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Format Cells Dialog";
			this.ResumeLayout(false);

		}
		#endregion

		protected Cell[] m_Cells;

		private void btOK_Click(object sender, System.EventArgs e)
		{
			if (m_Cells != null)
			{
				for (int i = 0; i < m_Cells.Length; i++)
					m_Cells[i].ApplyCellFormat(m_Format);
			}
		}
		
		CellFormat m_Format;
		public void LoadCellFormat(Cell paramCellInitSource, Cell[] pDestination)
		{
			m_Format = paramCellInitSource.GetCellFormat();
			m_Cells = pDestination;

			propertyGridEx1.LoadProperties(m_Format);
		}
	}
}
