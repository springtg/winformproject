using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;

namespace ControlWare.Windows.Controls
{
	public class BackContainer : System.Windows.Forms.UserControl
	{
		private System.ComponentModel.IContainer components;

		public BackContainer()
		{
			InitializeComponent();

			ToolTipText = "";


			SetStyle(ControlStyles.UserPaint, true);
			SetStyle(ControlStyles.AllPaintingInWmPaint, true);
			SetStyle(ControlStyles.DoubleBuffer, true);
		}

		private System.Windows.Forms.ToolTip toolTip;

		private Grid m_Grid = null;
		public Grid Grid
		{
			get{return m_Grid;}
			set{m_Grid = value;}
		}

		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Component Designer generated code
		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			this.toolTip = new System.Windows.Forms.ToolTip(this.components);
			// 
			// BackContainer
			// 
			this.Name = "BackContainer";
			this.Size = new System.Drawing.Size(296, 288);

		}
		#endregion

		protected override bool IsInputKey(Keys keyData)
		{
			switch (keyData)
			{
				case Keys.Up:
				case Keys.Down:
				case Keys.Left:
				case Keys.Right:
				case Keys.Tab:
					return true;
				default:
					return base.IsInputKey(keyData);
			}
		}

		public string ToolTipText
		{
			get{return toolTip.GetToolTip(this);}
			set{toolTip.SetToolTip(this,value);}
		}
		public bool ToolTipActive
		{
			get{return toolTip.Active;}
			set{toolTip.Active = value;}
		}
	}
}
