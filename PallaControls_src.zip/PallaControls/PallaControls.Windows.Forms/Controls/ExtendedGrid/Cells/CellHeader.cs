using System;
using System.Drawing;
using ControlWare.Windows.Controls.Helpers;

namespace ControlWare.Windows.Controls
{
	public class CellHeader : Cell
	{
		public CellHeader(object paramValue):base(paramValue)
		{
			BackColor = Color.FromKnownColor(KnownColor.Control);
			BorderStyle = CommonBorderStyle.Raised;
		}

		public CellHeader()
		{
			BackColor = Color.FromKnownColor(KnownColor.Control);
			BorderStyle = CommonBorderStyle.Raised;
		}

		private CommonBorderStyle m_BorderStyle;
		public CommonBorderStyle BorderStyle
		{
			get{return m_BorderStyle;}
			set
			{
				m_BorderStyle = value;
				Cell.FormatBorder(this,m_BorderStyle,1,Color.FromKnownColor(KnownColor.ControlDark),Color.FromKnownColor(KnownColor.ControlLight));
			}
		}
	}
}
