using System;
using System.Windows.Forms;

namespace ControlWare.Windows.Controls
{
	public class CellCheckBox : CellControl
	{
		public CellCheckBox(string pCaption, bool pInitValue)
			:base(new CheckBox())
		{
			Value = pInitValue;
			((CheckBox)InnerControl).Text = pCaption;
			((CheckBox)InnerControl).CheckedChanged += new EventHandler(CheckBox_Changed);
		}

		private void CheckBox_Changed(object sender, EventArgs e)
		{
			if (Checked != ((CheckBox)InnerControl).Checked)
				Checked = ((CheckBox)InnerControl).Checked;
		}

		protected override void OnValueChanged(EventArgs e)
		{
			base.OnValueChanged(e);
			if (Checked != ((CheckBox)InnerControl).Checked)
				((CheckBox)InnerControl).Checked = Checked;
		}

		public virtual bool Checked
		{
			get
			{
				if (Value == null)
					return false;
				else
					return (bool)Value;
			}
			set{Value = value;}
		}
	}
}
