using System;
using System.Reflection;
using System.Windows.Forms;
using ControlWare.Windows.Controls.Helpers;

namespace ControlWare.Windows.Controls
{
	public class CellCustom : Cell
	{
		public CellCustom(Type paramValueType):
				this(paramValueType,
					null,
					null)
		{
		}

		public CellCustom(Type paramValueType, object pInitialValue, object pDefaultValue):
						this(paramValueType,
							new CellFormatterTypeConverter(System.ComponentModel.TypeDescriptor.GetConverter(paramValueType)),
							pInitialValue,
							pDefaultValue)
		{
		}

		public CellCustom(Type paramValueType,ICellFormatter paramCellFormatter, object pInitialValue, object pDefaultValue):
			this(paramValueType,
					paramCellFormatter,
					(System.Drawing.Design.UITypeEditor)System.ComponentModel.TypeDescriptor.GetEditor(paramValueType,typeof(System.Drawing.Design.UITypeEditor)),
					pInitialValue,
					pDefaultValue,
					null)
		{
		}

		public CellCustom(Type paramValueType,
						ICellFormatter paramCellFormatter,
						System.Drawing.Design.UITypeEditor uiTypeEditor,
						object pInitialValue,
						object pDefaultValue,
						TypeCreator pTypeCreator):this(paramValueType,
													System.ComponentModel.TypeDescriptor.GetConverter(paramValueType),
													paramCellFormatter,
													GetCellEditorForType(paramValueType,paramCellFormatter,uiTypeEditor,pDefaultValue, pTypeCreator),
													pInitialValue,
													pDefaultValue,
													null,
													null,
													true,
													true,
													true,
													pTypeCreator)
		{
		}

		public CellCustom(Type paramValueType,
								object pInitialValue,
								object pDefaultValue,
								PropertyInfo pLinkProperty,
								object pLinkObject):
											this(paramValueType,
													System.ComponentModel.TypeDescriptor.GetConverter(paramValueType),
													new CellFormatterTypeConverter(System.ComponentModel.TypeDescriptor.GetConverter(paramValueType)),
													GetCellEditorForType(paramValueType,new CellFormatterTypeConverter(System.ComponentModel.TypeDescriptor.GetConverter(paramValueType)),(System.Drawing.Design.UITypeEditor)System.ComponentModel.TypeDescriptor.GetEditor(paramValueType,typeof(System.Drawing.Design.UITypeEditor)),pDefaultValue,null),
													pInitialValue,
													pDefaultValue,
													pLinkProperty,
													pLinkObject,
													true,
													true,
													true,
													null)
		{
		}

		public CellCustom(	Type paramValueType, 
							System.ComponentModel.TypeConverter pTypeConverter,
							ICellFormatter paramCellFormatter,
							ICellEditor paramCellEditor,
							object pInitialValue,
							object pDefaultValue,
							PropertyInfo pLinkProperty,
							object pLinkObject,
							bool pbAllowNull,
							bool pbEnableCreateInstance,
							bool pbEnableBrowseInstance,
							TypeCreator pTypeCreator):base(paramCellFormatter)
		{
			if (paramValueType==null)
				throw new ArgumentNullException("paramValueType");
			m_TypeConverter = pTypeConverter;
			m_InnerType = paramValueType;
			m_DefaultValue = pDefaultValue;
			m_bAllowNull = pbAllowNull;
			CellEditor = paramCellEditor;
			EnableBrowseInstance = pbEnableBrowseInstance;
			EnableCreateInstance = pbEnableCreateInstance;
			if (CellEditor!=null)
				CellEditor.ValidatingValue+= new ValidatingEventHandler(CellEditor_ValidatingValue);

			BindValueAtProperty(pLinkProperty,pLinkObject);

			Value = pInitialValue;

			m_TypeCreator = pTypeCreator;
			if (m_TypeCreator == null) 
				m_TypeCreator = new TypeCreator();
			if (EnableCreateInstance)
				ContextMenuItems.Add(new MenuItem("Create new instance...",new EventHandler(Type_CreateInstance)));
			if (EnableBrowseInstance)
				ContextMenuItems.Add(new MenuItem("Browse instance...",new EventHandler(Type_BrowseInstance)));
		}

		private Type m_InnerType;
		public Type InnerType
		{
			get{return m_InnerType;}
		}


		private System.ComponentModel.TypeConverter m_TypeConverter;
		public System.ComponentModel.TypeConverter TypeConverter
		{
			get{return m_TypeConverter;}
		}

		public static ICellEditor GetCellEditorForType(Type pType, 
			ICellFormatter formatter, 
			System.Drawing.Design.UITypeEditor uiTypeEditor, 
			object pDefaultValue,
			TypeCreator pTypeCreator)
		{
			if (uiTypeEditor == null)
			{
				if (formatter!=null)
				{
					System.Collections.ICollection l_list = formatter.GetStandardValues();
					if (l_list!=null)
					{
						ComboBoxEditor l_EditCombo = new ComboBoxEditor(formatter);
						l_EditCombo.DefaultValue = pDefaultValue;
						return l_EditCombo;
					}
					else if (formatter.SupportStringConversion)
					{
						TextBoxEditor l_EditTextBox = new TextBoxEditor();
						l_EditTextBox.DefaultValue = pDefaultValue;
						return l_EditTextBox;
					}
					else 
					{
						TypeCreator l_Creator = pTypeCreator;
						if (l_Creator==null)
							l_Creator = new TypeCreator();

						TextBoxButtonBrowseInstance l_TxtBt = new TextBoxButtonBrowseInstance(pType, l_Creator);
						TextBoxButtonEditor l_TxtBtEditor = new TextBoxButtonEditor(l_TxtBt);
						l_TxtBtEditor.DefaultValue = pDefaultValue;
						return l_TxtBtEditor;
					}
				}
				else 
				{
					TypeCreator l_Creator = pTypeCreator;
					if (l_Creator==null)
						l_Creator = new TypeCreator();

					TextBoxButtonBrowseInstance l_TxtBt = new TextBoxButtonBrowseInstance(pType, l_Creator);
					TextBoxButtonEditor l_TxtBtEditor = new TextBoxButtonEditor(l_TxtBt);
					l_TxtBtEditor.DefaultValue = pDefaultValue;
					return l_TxtBtEditor;
				}
			}
			else 
			{
				CellUITypeEditor l_UITypeEditor = new CellUITypeEditor(uiTypeEditor);
				l_UITypeEditor.DefaultValue = pDefaultValue;
				return l_UITypeEditor;
			}
		}

		private bool m_bEnableCreateInstance = true;
		private bool m_bEnableBrowseInstance = true;
		public bool EnableCreateInstance
		{
			get{return m_bEnableCreateInstance;}
			set{m_bEnableCreateInstance = value;}
		}
		public bool EnableBrowseInstance
		{
			get{return m_bEnableBrowseInstance;}
			set{m_bEnableBrowseInstance = value;}
		}

		protected virtual void Type_BrowseInstance(object sender, EventArgs e)
		{
			try
			{
				if (Value==null)
					Type_CreateInstance(sender,e);

				if (Value!=null)
				{
					ShowBrowseInstanceDialog(this.Grid,Value,"Instance details for " + m_InnerType.ToString());
				}
				else
					MessageBox.Show("Object is null","Error");
			}
			catch(Exception err)
			{
				MessageBox.Show(err.Message,"Error");
			}
		}

		protected virtual void Type_CreateInstance(object sender, EventArgs e)
		{
			try
			{
				object tmp = ShowCreateInstanceDialog(this.Grid,m_InnerType,"Create new instance for type:" + m_InnerType.ToString());
				if (tmp!=null)
					Value = tmp;
			}
			catch(Exception err)
			{
				MessageBox.Show(err.Message,"Error");
			}
		}


		private PropertyInfo m_LinkPropertyInfo = null;
		private object m_LinkObject = null;

		public virtual void BindValueAtProperty(PropertyInfo pProperty, object pLinkObject)
		{
			m_LinkPropertyInfo = pProperty;
			m_LinkObject = pLinkObject;
		}

		public virtual void UnBindValueAtProperty()
		{
			m_LinkPropertyInfo = null;
			m_LinkObject = null;
		}

		public void BindObject_ValueChanged(object sender, EventArgs e)
		{
			if (m_LinkPropertyInfo!=null)
			{
				object tmp = m_LinkPropertyInfo.GetValue(m_LinkObject,null);
				if (tmp!=Value)
					Value = tmp;
			}
		}

		protected virtual void CellEditor_ValidatingValue(object sender, ValidatingEventArgs e)
		{
			if (CellFormatter.IsNullObject(e.NewValue))
			{
				if (AllowNull == false)
					e.Cancel = true;
			}
			else if (m_InnerType.IsAssignableFrom(e.NewValue.GetType())) 
			{
			}
			else if (e.NewValue.GetType().Equals(typeof(string)) && CellFormatter.SupportStringConversion) 
			{
				if (CellFormatter.IsValidString((string)e.NewValue) == false)
					e.Cancel = true;
			}
			else 
			{
				if (m_TypeConverter!=null)
				{
					if (m_TypeConverter.IsValid(e.NewValue) == false)
						e.Cancel = true;
					else
					{
						try
						{
							m_TypeConverter.ConvertFrom(e.NewValue);
						}
						catch(Exception)
						{
							e.Cancel = true;
						}
					}
				}
				else
					e.Cancel = true;
			}
		}

		private TypeCreator m_TypeCreator = null;
		public TypeCreator TypeCreator
		{
			get{return m_TypeCreator;}
		}

		private bool m_bAllowNull = true;
		public bool AllowNull
		{
			get{return m_bAllowNull;}
			set{m_bAllowNull = value;}
		}

		private object m_DefaultValue = null;
		public object DefaultValue
		{
			get{return m_DefaultValue;}
			set{m_DefaultValue = value;}
		}

		private object m_Value = null;
		public override object Value
		{
			get{return m_Value;}
			set
			{
				if (CellFormatter.IsNullObject(value))
				{
					if (m_bAllowNull == false)
						throw new ArgumentNullException("Value");
					else
						m_Value = null;
				}
				else 
				{
					if (m_InnerType.IsAssignableFrom(value.GetType())) 
						m_Value = value;
					else if (value.GetType() == typeof(string) && CellFormatter.SupportStringConversion) 
					{
						object l_tmp = CellFormatter.StringToObject((string)value);
						if (l_tmp.GetType() == m_InnerType)
							m_Value = l_tmp;
						else
							throw new ArgumentException("Value","Type or value not valid :" + value.GetType() + " " + value.ToString());
					}
					else 
					{
						if (m_TypeConverter!=null)
						{
							object l_tmp = m_TypeConverter.ConvertFrom(value);
							if (l_tmp.GetType() == m_InnerType)
								m_Value = l_tmp;
							else
								throw new ArgumentException("Value","Type or value not valid :" + value.GetType() + " " + value.ToString());
						}
						else
							throw new ArgumentException("Value","Type or value not valid :" + value.GetType() + " " + value.ToString());
					}
				}
				base.Value = m_Value;

				if (m_LinkPropertyInfo != null)
					m_LinkPropertyInfo.SetValue(m_LinkObject,m_Value,null);
			}
		}

		public object ShowCreateInstanceDialog(IWin32Window pOwner, Type innerType,string pCaption)
		{
			try
			{
				return m_TypeCreator.CreateInstanceUI(pOwner,innerType,pCaption);
			}
			catch(Exception err)
			{
				MessageBox.Show(err.Message,"Error");
				return null;
			}		
		}
		public void ShowBrowseInstanceDialog(IWin32Window pOwner, object paramValue, string pCaption)
		{
			try
			{
				m_TypeCreator.BrowseInstanceUI(pOwner,paramValue,pCaption);
			}
			catch(Exception err)
			{
				MessageBox.Show(err.Message,"Error");
			}
		}
	}
}
