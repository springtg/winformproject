using System;
using System.Windows.Forms;
using System.Reflection;
using System.Drawing;

namespace ControlWare.Windows.Controls
{
	public class CellControl : Cell
	{
		private Control m_Control;
		public Control InnerControl
		{
			get{return m_Control;}
		}
		public CellControl(Control paramControl)
		{
			m_Control = paramControl;
		}
		public CellControl(Control paramControl, PropertyInfo pProperty):this(paramControl)
		{
			BindValueAtProperty(pProperty,paramControl);
		}

		private PropertyInfo m_LinkPropertyInfo = null;
		private object m_LinkObject = null;
		public void BindValueAtProperty(PropertyInfo pProperty, object pLinkObject)
		{
			m_LinkPropertyInfo = pProperty;
			m_LinkObject = pLinkObject;
		}
		public void UnBindValueAtProperty()
		{
			m_LinkPropertyInfo = null;
			m_LinkObject = null;
		}

		protected override void OnAddToGrid(EventArgs e)
		{
			base.OnAddToGrid(e);
			RecalcControlSize();
			RecalcControlPosition();
			Grid.Controls.Add(m_Control);
			m_Control.BringToFront();
		}

		protected override void OnRemoveToGrid(EventArgs e)
		{
			base.OnRemoveToGrid(e);

			//.Net bug : application doesn't close when a active control is removed from the control collection
			// change the focus first
			Grid.SetFocusOnCellsContainer();

			Grid.Controls.Remove(m_Control);
		}

		public virtual void RecalcControlPosition()
		{
			Rectangle l_rcClient = DisplayRectangle;
			
			if (m_Control.Location != l_rcClient.Location)
				m_Control.Location = l_rcClient.Location;
		}
		public virtual void RecalcControlSize()
		{
			Rectangle l_rcClient = DisplayRectangle;
			
			if (m_Control.Size != l_rcClient.Size)
				m_Control.Size = l_rcClient.Size;
		}

		public override void RaisePaint(PaintEventArgs e)
		{
			RecalcControlSize();
		}

		public override object Value
		{
			get
			{
				if (m_LinkPropertyInfo != null)
					return m_LinkPropertyInfo.GetValue(m_LinkObject,null);
				else
					return base.Value;
			}
			set
			{
				if (m_LinkPropertyInfo != null)
					m_LinkPropertyInfo.SetValue(m_LinkObject,value,null);
				else
					base.Value = value;
			}
		}
	}
}
