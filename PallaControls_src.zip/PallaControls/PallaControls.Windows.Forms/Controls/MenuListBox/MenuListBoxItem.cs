using System;
using System.ComponentModel;

namespace PallaControls.Windows.Forms
{
	[Serializable()]
	public class MenuListBoxItem
	{
		private string title = String.Empty;
		private string description = String.Empty;
		private string name = String.Empty;
		
		#region Constructors
		
		public MenuListBoxItem()
		{
		}

		public MenuListBoxItem(string title, string description)
		{
			this.title = title;
			this.description = description;
		}

		#endregion

		#region Properties

		public string Title
		{
			get{return this.title;}
			set{this.title = value;}
		}

		public string Description
		{
			get{return this.description;}
			set{this.description = value;}
		}

		public string Name
		{
			get{return this.name;}
			set{this.name = value;}
		}

		#endregion
	}
}
