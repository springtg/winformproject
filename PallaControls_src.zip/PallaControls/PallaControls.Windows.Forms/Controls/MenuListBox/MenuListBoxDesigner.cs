using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Windows.Forms;
using System.Windows.Forms.Design;
using PallaControls.Windows.Forms.Collections;

namespace PallaControls.Windows.Forms
{
    public class MenuListBoxDesigner : System.Windows.Forms.Design.ParentControlDesigner
    {
        private ISelectionService _selectionService = null;
        
		#region Properties

		public override ICollection AssociatedComponents
        {
            get 
            {
                if (base.Control is PallaControls.Windows.Forms.MenuListBox)
                    return ((PallaControls.Windows.Forms.MenuListBox)base.Control).Items;
                else
                    return base.AssociatedComponents;
            }
        }

        public ISelectionService SelectionService
        {
            get
            {
                if (_selectionService == null)
                {
                    _selectionService = (ISelectionService)GetService(typeof(ISelectionService));
                }

                return _selectionService;
            }
        }

        protected override bool DrawGrid
        {
            get { return false; }
        }

		#endregion
    }
}
