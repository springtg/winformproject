using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using PallaControls.Windows.Forms.Collections;
using PallaControls.Resources;
using PallaControls.Resources.Keys;

namespace PallaControls.Windows.Forms
{
	[System.ComponentModel.ToolboxItem(true)]
	[Designer(typeof(PallaControls.Windows.Forms.TaskPanelBarDesigner))]
	public class TaskPanelBar : PallaControls.Windows.Forms.PanelBase
	{
		private TaskPanelCollection panels = new TaskPanelCollection();
		//Style neo, default
		private Color m_TaskPanelBarBackColor = Color.FromArgb(242, 242, 228);
		private Color m_TextColor = Color.Black;

		#region Constructors

		public TaskPanelBar() : base()
		{
			InitializeComponent();

			panels.Clearing += new PallaControls.Windows.Forms.Collections.CollectionClearEventHandler(OnClearingItens);
			panels.Cleared += new PallaControls.Windows.Forms.Collections.CollectionClearEventHandler(OnClearedItens);
			panels.Inserting += new PallaControls.Windows.Forms.Collections.CollectionChangeEventHandler(OnInsertingItem);
			panels.Inserted += new PallaControls.Windows.Forms.Collections.CollectionChangeEventHandler(OnInsertedItem);
			panels.Removing += new PallaControls.Windows.Forms.Collections.CollectionChangeEventHandler(OnRemovingItem);
			panels.Removed += new PallaControls.Windows.Forms.Collections.CollectionChangeEventHandler(OnRemovedItem);
		}

		#endregion

		#region Windows Form Designer generated code
		
		private void InitializeComponent()
		{
		}

		#endregion

		#region Virtuals

		protected virtual void OnClearingItens(object sender, EventArgs e)
		{
			foreach(TaskPanel item in panels)
				RemoveItem(item);
		}

		protected virtual void OnClearedItens(object sender, EventArgs e)
		{
		}

		protected virtual void OnInsertingItem(object sender, PallaControls.Windows.Forms.Collections.CollectionChangeEventArgs e)
		{
		}

		protected virtual void OnInsertedItem(object sender, PallaControls.Windows.Forms.Collections.CollectionChangeEventArgs e)
		{
			TaskPanel item = sender as TaskPanel;
			int lastBottom = 0;

			if (this.Controls.Count > 0) {lastBottom = this.Controls[this.Controls.Count-1].Bottom;}

			item.Top = lastBottom+1;
			
			this.AddItem(item);
			item.Dock = DockStyle.Top;
		}

		protected virtual void OnRemovingItem(object sender, PallaControls.Windows.Forms.Collections.CollectionChangeEventArgs e)
		{
		}

		protected virtual void OnRemovedItem(object sender, PallaControls.Windows.Forms.Collections.CollectionChangeEventArgs e)
		{
			TaskPanel item = this.panels[e.Index];

			if (item!=null)
			{
				this.RemoveItem(item);
				this.Invalidate();
			}
		}

		protected virtual void RemoveItem(TaskPanel item)
		{
			if (item != null)
				Controls.Remove(item);
		}

		protected virtual void AddItem(TaskPanel item)
		{
			if (item != null)
				Controls.Add(item);
		}

		#endregion
		
		#region Overrides

		protected override void OnStyleChanged(object sender, StyleEventArgs args)
		{
			base.OnStyleChanged(sender, args);

			if (args.PropertyName == "TaskPanelBarBackColor") {this.m_TaskPanelBarBackColor = (Color)args.PropertyValue;}

			this.Invalidate(true);
		}

		protected override void OnPlansOfColorsChanged(object sender, PlansOfColorsChangedEventArgs args)
		{
			base.OnPlansOfColorsChanged(sender, args);

			if (this.Style!=null)
				this.m_TaskPanelBarBackColor = this.Style.TaskPanelBarBackColor;

			this.Invalidate(true);
		}
		
		protected override void OnPaint(System.Windows.Forms.PaintEventArgs e)
		{
			this.BackColor = this.TaskPanelBarBackColor;
			this.ForeColor = this.TextColor;

			base.OnPaint(e);

			if (this.panels.Count == 0)
			{
				StringFormat format  = new StringFormat();
				format.LineAlignment = StringAlignment.Center;
				format.Alignment = StringAlignment.Center;
					
				
				using (Brush brush1=new SolidBrush(this.m_TextColor))
				{
					e.Graphics.DrawString(ResourceLibrary.GetString(WindowsControlsResourceKeys.NoExistTaskPanels, WindowsControlsResourceKeys.Root), this.Font,
						brush1, this.ClientRectangle, format);
				}
			}
		}		

		#endregion

		#region Properties

		[Category("Style")]
		public Color TaskPanelBarBackColor
		{
			get {return m_TaskPanelBarBackColor;}
			set 
			{
				m_TaskPanelBarBackColor = value;
				this.BackColor = value;
				this.Invalidate(true);
			}
		}
			
		[Category("Style")]
		public Color TextColor
		{
			get {return m_TextColor;}
			set 
			{
				m_TextColor = value;
				this.ForeColor = value;
				this.Invalidate(true);
			}
		}

		[Browsable(false)]
		public override Color BackColor
		{
			get {return m_TaskPanelBarBackColor;}
			set {m_TaskPanelBarBackColor = value;}
		}

		[Browsable(false)]
		public override Color ForeColor
		{
			get {return m_TextColor;}
			set {m_TextColor = value;}
		}
			
		[Category("Behavior")]
		[DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
		public TaskPanelCollection TaskPanels
		{
			get
			{
				return this.panels;
			}
		}

		#endregion
	}
}