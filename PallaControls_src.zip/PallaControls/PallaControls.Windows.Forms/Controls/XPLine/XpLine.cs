using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace PallaControls.Windows.Forms
{
	[System.ComponentModel.ToolboxItem(true)]
	public class XpLine : System.Windows.Forms.UserControl
	{
		private System.ComponentModel.IContainer components = null;
		private LineDirection m_LineDirection = LineDirection.Horizontal;
		private bool m_UseInterpolation = true;
		private int m_LineWidth = 1;
		private Color m_StartColor = Color.White;
		private Color m_EndColor = Color.Black;
		
		#region Constructors
		public XpLine()
		{
			InitializeComponent();
		}
		#endregion

		#region Dispose
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}
		#endregion

		#region Designer generated code
		private void InitializeComponent()
		{
			// 
			// XPLine
			// 
			this.Name = "XpLine";
			this.Size = new System.Drawing.Size(168, 8);

		}
		#endregion

		#region Overrides
		protected override void OnPaint(PaintEventArgs e)
		{
			base.OnPaint(e);

			e.Graphics.Clear(this.BackColor);

			using (LinearGradientBrush lineBrush = new LinearGradientBrush(new Rectangle(0,0,this.Width,this.Height), this.m_StartColor, this.m_EndColor,
					   this.m_LineDirection == LineDirection.Horizontal?LinearGradientMode.Horizontal:
					   LinearGradientMode.Vertical))
			{

				if (this.m_UseInterpolation)
				{
					ColorBlend cb = new ColorBlend(3);
					cb.Colors = new Color[3] {this.m_EndColor, this.m_StartColor, this.m_EndColor};
					cb.Positions = new float[3] {0.0f, 0.5f, 1.0f};
					lineBrush.InterpolationColors = cb;
				}
				
				using (GraphicsPath linePath = new GraphicsPath())
				{
					if (this.m_LineDirection == LineDirection.Horizontal)
						linePath.AddLine(0,(int)this.Height/2,this.Width,(int)this.Height/2);
					else
						linePath.AddLine((int)this.Width/2, 0, (int)this.Width/2, this.Bottom); 

					using (Pen pen = new Pen(lineBrush, this.m_LineWidth))
					{
						e.Graphics.DrawPath(pen, linePath);
					}
				}
			}
		}

		protected override void OnResize(EventArgs e)
		{
			base.OnResize(e);
			this.Invalidate(false);
		}
		#endregion

		#region Properties
		[Category("Behavior")]
		public LineDirection LineDirection
		{
			get {return this.m_LineDirection;}
			set 
			{
				this.m_LineDirection = value;
				this.Invalidate(false);
			}
		}

		[Category("Behavior")]
		public bool UseGradientInterpolation
		{
			get {return this.m_UseInterpolation;}
			set 
			{
				this.m_UseInterpolation = value;
				this.Invalidate(false);
			}
		}

		[Category("Behavior")]
		public int LineWidth
		{
			get {return this.m_LineWidth;}
			set 
			{
				this.m_LineWidth = value;
				this.Invalidate(false);
			}
		}

		[Category("Style")]
		public Color StartColor
		{
			get {return this.m_StartColor;}
			set 
			{
				this.m_StartColor = value;
				this.Invalidate(false);
			}
		}

		[Category("Style")]
		public Color EndColor
		{
			get {return this.m_EndColor;}
			set 
			{
				this.m_EndColor = value;
				this.Invalidate(false);
			}
		}
		#endregion
	}
}

