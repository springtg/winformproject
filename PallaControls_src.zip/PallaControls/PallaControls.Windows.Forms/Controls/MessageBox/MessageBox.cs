using System;
using System.Threading;
using System.Drawing;
using System.Windows.Forms;
using PallaControls.Resources;
using PallaControls.Resources.Keys;
using PallaControls.Windows.Forms.Helpers;

namespace PallaControls.Windows.Forms
{
	/// <summary>
	/// Classe que permite a visualiza��o de "box de mensagens" no estilo
	/// dos componentes da biblioteca PallaControls.
	/// </summary>
	[System.ComponentModel.ToolboxItem(false)]
	public class MessageBox
	{
		private static StyleGuide mStyle = new StyleGuide();
		private static bool varChack = false;
		private static System.Windows.Forms.Timer timer = null;
		private static Thread staticthread = null;
		private static Form staticForm = null;

		public static bool CancelProgressClicked = false;

		private const int LarguraJanela = 407;
		private const int AlturaJanela  = 250;
		
		#region Constructors

		public MessageBox()
		{
		}

		#endregion

		#region Internal helpers

		private static void OnTick(object sender, EventArgs e)
		{
			if (staticthread!=null && !staticthread.IsAlive)
			{
				if (staticForm!=null)
				{
					staticthread = null;
					if (timer!=null) timer.Dispose();
					staticForm.Close();
					staticForm.Dispose();
				}
			}
		}
		
		private static void OKClick(object sender, EventArgs e)
		{
			((PallaControls.Windows.Forms.Button)sender).FindForm().DialogResult = DialogResult.OK;
		}

		private static void CancelClick(object sender, EventArgs e)
		{
			((PallaControls.Windows.Forms.Button)sender).FindForm().DialogResult = DialogResult.Cancel;			
		}

		private static void IgnoreClick(object sender, EventArgs e)
		{
			((PallaControls.Windows.Forms.Button)sender).FindForm().DialogResult = DialogResult.Ignore;			
		}

		private static void NoClick(object sender, EventArgs e)
		{
			((PallaControls.Windows.Forms.Button)sender).FindForm().DialogResult = DialogResult.No;			
		}

		private static void YesClick(object sender, EventArgs e)
		{
			((PallaControls.Windows.Forms.Button)sender).FindForm().DialogResult = DialogResult.Yes;			
		}

		private static void RetryClick(object sender, EventArgs e)
		{
			((PallaControls.Windows.Forms.Button)sender).FindForm().DialogResult = DialogResult.Retry;
		}

		private static void AbortClick(object sender, EventArgs e)
		{
			((PallaControls.Windows.Forms.Button)sender).FindForm().DialogResult = DialogResult.Abort;
		}

		private static void CancelFormKeyDown(object sender, KeyEventArgs e)
		{
			if (e.KeyCode == Keys.Escape)
			{
				((Form)sender).DialogResult = DialogResult.Cancel;
			}
		}

		private static void CancelProgressClick(object sender, EventArgs e)
		{
			if (timer!=null)
			{
				timer.Enabled = false;
				timer.Dispose();
			}
			CancelProgressClicked = true;
			((PallaControls.Windows.Forms.Button)sender).FindForm().Close();
		}

		private static void ProgressClosing(object sender, System.ComponentModel.CancelEventArgs e)
		{
			Form localForm = sender as Form;

			if (CancelProgressClicked)
			{
				if (localForm != null)
				{
					if (timer!=null)
						timer.Enabled = false;
				}
			}
			else
				e.Cancel = true;

			localForm.Dispose();
		}

		#endregion 

		#region Methods

		/// <summary>
		/// Mostra uma caixa de mensagem sobre uma janela especificada e com um 
		/// texto especificado.
		/// </summary>
		/// <param name="owner">owner da mensagem</param>
		/// <param name="text">Texto do corpo da mensagem</param>
		/// <param name="caption">Caption da janela</param>
		/// <param name="buttons">bot�es que devem aparecer na mensagem</param>
		/// <param name="icon">�cone da mensagem</param>
		/// <param name="defaultButton">Bot�o default</param>
		/// <param name="style">Estilo da mensagem. Null utilizar� o padr�o "neo"</param>
		/// <param name="checkboxText">Texto do check box, se houver. Empty ou "" n�o usar� checkbox</param>
		/// <param name="checkboxValue">Valor retornado pelo checkbox</param>
		/// <returns>O result modal segundo o bot�o pressionado pelo usu�rio</returns>
		public static DialogResult Show(IWin32Window owner,
			string text,
			string caption,
			MessageBoxButtons buttons,
			MessageBoxIcon icon,
			MessageBoxDefaultButton defaultButton,
			StyleGuide style,
			string checkboxText,
			ref bool checkboxValue)
		{
			Form form = new Form();
			try
			{
				form.Text = caption;
				form.MaximizeBox = false;
				form.MinimizeBox = false;
				form.FormBorderStyle = FormBorderStyle.FixedDialog;
				form.StartPosition = FormStartPosition.CenterScreen;
				form.Width = LarguraJanela;
				form.Height = AlturaJanela;
				form.KeyPreview = true;

				StyleGuide localStyle = style!=null?style:mStyle;

				PallaControls.Windows.Forms.Panel leftPanel = new PallaControls.Windows.Forms.Panel();
				leftPanel.Dock = DockStyle.Left;
				leftPanel.Style = localStyle;
				leftPanel.PanelType = PanelTypes.LeftOptions;

				PallaControls.Windows.Forms.Panel bottomPanel = new PallaControls.Windows.Forms.Panel();
				bottomPanel.Dock = DockStyle.Bottom;
				bottomPanel.Style = localStyle;
				bottomPanel.PanelType = PanelTypes.BottomArea;

				PallaControls.Windows.Forms.Panel clientPanel = new PallaControls.Windows.Forms.Panel();
				clientPanel.Dock = DockStyle.Fill;
				clientPanel.Style = localStyle;
				clientPanel.PanelType = PanelTypes.ClientArea;

				form.Controls.Add(leftPanel);
				form.Controls.Add(clientPanel);
				clientPanel.Controls.Add(bottomPanel);

				System.Windows.Forms.PictureBox pic = new System.Windows.Forms.PictureBox();
				pic.SizeMode = PictureBoxSizeMode.AutoSize;
				pic.Top = 8;
				pic.Left = 19;
				pic.BackColor = leftPanel.Style.PanelLeftOptionsColor;

				leftPanel.Controls.Add(pic);

				if (icon == MessageBoxIcon.Asterisk)
				{
					pic.Image = GraphicsUtils.LoadImage("error.ico");
					if (form.Text.Length==0) form.Text = ResourceLibrary.GetString(CommonResourceKeys.Information, CommonResourceKeys.Root);
				}
				else if (icon == MessageBoxIcon.Error)
				{
					pic.Image = GraphicsUtils.LoadImage("error.ico");
					if (form.Text.Length==0) form.Text = ResourceLibrary.GetString(CommonResourceKeys.Error, CommonResourceKeys.Root);
				}
				else if (icon == MessageBoxIcon.Exclamation)
				{
					pic.Image = GraphicsUtils.LoadImage("information.ico");
					if (form.Text.Length==0) form.Text = ResourceLibrary.GetString(CommonResourceKeys.Error, CommonResourceKeys.Root);
				}
				else if (icon == MessageBoxIcon.Hand)
				{
					pic.Image = GraphicsUtils.LoadImage("information.ico");
					if (form.Text.Length==0) form.Text = ResourceLibrary.GetString(CommonResourceKeys.Error, CommonResourceKeys.Root);
				}
				else if (icon == MessageBoxIcon.Information)
				{
					pic.Image = GraphicsUtils.LoadImage("information.ico");
					if (form.Text.Length==0) form.Text = ResourceLibrary.GetString(CommonResourceKeys.Information, CommonResourceKeys.Root);
				}
				else if (icon == MessageBoxIcon.Question)
				{
					pic.Image = GraphicsUtils.LoadImage("confirmation.ico");
					if (form.Text.Length==0) form.Text = ResourceLibrary.GetString(CommonResourceKeys.Confirmation, CommonResourceKeys.Root);
				}
				else if (icon == MessageBoxIcon.Stop)
				{
					pic.Image = GraphicsUtils.LoadImage("warning.ico");
					if (form.Text.Length==0) form.Text = ResourceLibrary.GetString(CommonResourceKeys.Error, CommonResourceKeys.Root);
				}
				else if (icon == MessageBoxIcon.Warning)
				{
					pic.Image = GraphicsUtils.LoadImage("warning.ico");
					if (form.Text.Length==0) form.Text = ResourceLibrary.GetString(CommonResourceKeys.Error, CommonResourceKeys.Root);
				}

				PallaControls.Windows.Forms.CheckBox check = new PallaControls.Windows.Forms.CheckBox();
				
				if (checkboxText.Length>0) 
				{
					check.Text = checkboxText;
					check.Style = localStyle;

					clientPanel.Controls.Add(check);
					check.Top = 110;
					check.Left = leftPanel.Width + 10;
					check.Width = clientPanel.Width - 15;
					check.Checked = checkboxValue;
				}
				
				PallaControls.Windows.Forms.Button botao1 = new PallaControls.Windows.Forms.Button();
				PallaControls.Windows.Forms.Button botao2 = new PallaControls.Windows.Forms.Button();
				PallaControls.Windows.Forms.Button botao3 = new PallaControls.Windows.Forms.Button();
				
				if (style != null && style.PlansOfColors == PlansColors.AssGreen)
				{
					botao1.Width = 55;
					botao2.Width = 55;
					botao3.Width = 55;

					botao1.Height = 22;
					botao2.Height = 22;
					botao3.Height = 22;

					botao1.Radius = 7;
					botao2.Radius = 7;
					botao3.Radius = 7;
				}
				else
				{
					botao1.Width = 75;
					botao2.Width = 75;
					botao3.Width = 75;
				}
				
				
				botao1.Top = 145;
				botao2.Top = 145;
				botao3.Top = 145;
				botao1.Style = localStyle;
				botao2.Style = localStyle;
				botao3.Style = localStyle;
				
				if (buttons == MessageBoxButtons.AbortRetryIgnore)
				{
					if (style != null && style.PlansOfColors == PlansColors.AssGreen)
					{
						botao1.Left = 149;
						botao2.Left = 209;
						botao3.Left = 269;
					}
					else
					{
						botao1.Left = 157;
						botao2.Left = 237;
						botao3.Left = 317;
					}
					
					botao1.Text = ResourceLibrary.GetString(CommonResourceKeys.Abort, CommonResourceKeys.Root);
					botao2.Text = ResourceLibrary.GetString(CommonResourceKeys.Retry, CommonResourceKeys.Root);
					botao3.Text = ResourceLibrary.GetString(CommonResourceKeys.Ignore, CommonResourceKeys.Root);

					botao1.ButtonPressed += new ButtonPressedEventHandler(AbortClick);
					botao2.ButtonPressed += new ButtonPressedEventHandler(RetryClick);
					botao3.ButtonPressed += new ButtonPressedEventHandler(IgnoreClick);

					clientPanel.Controls.Add(botao1);
					clientPanel.Controls.Add(botao2);
					clientPanel.Controls.Add(botao3);
				}
				else if (buttons == MessageBoxButtons.OK)
				{
					botao1.Left = 210;
					botao1.Text = ResourceLibrary.GetString(CommonResourceKeys.OK, CommonResourceKeys.Root);
					botao1.ButtonPressed += new ButtonPressedEventHandler(OKClick);
					clientPanel.Controls.Add(botao1);
				}
				else if (buttons == MessageBoxButtons.OKCancel)
				{
					if (style != null && style.PlansOfColors == PlansColors.AssGreen)
					{
						botao1.Left = 178;
						botao2.Left = 238;
					}
					else
					{
						botao1.Left = 237;
						botao2.Left = 317;
					}

					botao1.Text = ResourceLibrary.GetString(CommonResourceKeys.OK, CommonResourceKeys.Root);
					botao2.Text = ResourceLibrary.GetString(CommonResourceKeys.Cancel, CommonResourceKeys.Root);

					botao1.ButtonPressed += new ButtonPressedEventHandler(OKClick);
					botao2.ButtonPressed += new ButtonPressedEventHandler(CancelClick);
					form.KeyDown += new KeyEventHandler(CancelFormKeyDown);
					
					clientPanel.Controls.Add(botao1);
					clientPanel.Controls.Add(botao2);
				}
				else if (buttons == MessageBoxButtons.RetryCancel)
				{
					if (style != null && style.PlansOfColors == PlansColors.AssGreen)
					{
						botao1.Left = 178;
						botao2.Left = 238;
					}
					else
					{
						botao1.Left = 237;
						botao2.Left = 317;
					}

					botao1.Text = ResourceLibrary.GetString(CommonResourceKeys.Retry, CommonResourceKeys.Root);
					botao2.Text = ResourceLibrary.GetString(CommonResourceKeys.Cancel, CommonResourceKeys.Root);

					botao1.ButtonPressed += new ButtonPressedEventHandler(RetryClick);
					botao2.ButtonPressed += new ButtonPressedEventHandler(CancelClick);
					form.KeyDown += new KeyEventHandler(CancelFormKeyDown);

					clientPanel.Controls.Add(botao1);
					clientPanel.Controls.Add(botao2);
				}
				else if (buttons == MessageBoxButtons.YesNo)
				{
					if (style != null && style.PlansOfColors == PlansColors.AssGreen)
					{
						botao1.Left = 178;
						botao2.Left = 238;
					}
					else
					{
						botao1.Left = 237;
						botao2.Left = 317;
					}

					botao1.Text = ResourceLibrary.GetString(CommonResourceKeys.Yes, CommonResourceKeys.Root);
					botao2.Text = ResourceLibrary.GetString(CommonResourceKeys.No, CommonResourceKeys.Root);

					botao1.ButtonPressed += new ButtonPressedEventHandler(YesClick);
					botao2.ButtonPressed += new ButtonPressedEventHandler(NoClick);

					clientPanel.Controls.Add(botao1);
					clientPanel.Controls.Add(botao2);
				}
				else if (buttons == MessageBoxButtons.YesNoCancel)
				{

					if (style != null && style.PlansOfColors == PlansColors.AssGreen)
					{
						botao1.Left = 149;
						botao2.Left = 209;
						botao3.Left = 269;
					}
					else
					{
						botao1.Left = 157;
						botao2.Left = 237;
						botao3.Left = 317;
					}

					botao1.Text = ResourceLibrary.GetString(CommonResourceKeys.Yes, CommonResourceKeys.Root);
					botao2.Text = ResourceLibrary.GetString(CommonResourceKeys.No, CommonResourceKeys.Root);
					botao3.Text = ResourceLibrary.GetString(CommonResourceKeys.Cancel, CommonResourceKeys.Root);

					botao1.ButtonPressed += new ButtonPressedEventHandler(YesClick);
					botao2.ButtonPressed += new ButtonPressedEventHandler(NoClick);
					botao3.ButtonPressed += new ButtonPressedEventHandler(CancelClick);
					form.KeyDown += new KeyEventHandler(CancelFormKeyDown);
					
					clientPanel.Controls.Add(botao1);
					clientPanel.Controls.Add(botao2);
					clientPanel.Controls.Add(botao3);
				}

				if (defaultButton == MessageBoxDefaultButton.Button1){if (botao1.Parent!=null) form.ActiveControl = botao1;}
				else if (defaultButton == MessageBoxDefaultButton.Button2){if (botao2.Parent!=null) form.ActiveControl = botao2;}
				else if (defaultButton == MessageBoxDefaultButton.Button3){if (botao3.Parent!=null) form.ActiveControl = botao3;}

				PallaControls.Windows.Forms.Label label = new PallaControls.Windows.Forms.Label();				
				label.Style = localStyle;
				clientPanel.Controls.Add(label);

				label.Left = leftPanel.Width + 10;
				label.Width = 300;
				label.Height = 95;
				label.Top = 10;
				label.Text = text;
				
				DialogResult result = form.ShowDialog(owner);
				checkboxValue = check.Checked;

				return result;
			}
			finally
			{
				form.Dispose();
			}
		}

		/// <summary>
		/// Mostra uma caixa de mensagem sobre uma janela especificada e com um 
		/// texto especificado.
		/// </summary>
		/// <param name="owner">owner da mensagem</param>
		/// <param name="text">Texto do corpo da mensagem</param>
		/// <param name="caption">Caption da janela</param>
		/// <param name="buttons">bot�es que devem aparecer na mensagem</param>
		/// <param name="icon">�cone da mensagem</param>
		/// <param name="defaultButton">Bot�o default</param>
		/// <param name="style">Estilo da mensagem. Null utilizar� o padr�o "neo"</param>
		/// <returns>O result modal segundo o bot�o pressionado pelo usu�rio</returns>
		public static DialogResult Show(IWin32Window owner,
			string text,
			string caption,
			MessageBoxButtons buttons,
			MessageBoxIcon icon,
			MessageBoxDefaultButton defaultButton,
			StyleGuide style)
		{
			return Show(owner, text, caption, buttons, icon, defaultButton, style, String.Empty, ref varChack);
		}

		/// <summary>
		/// Mostra uma caixa de mensagem sobre uma janela especificada e com um 
		/// texto especificado.
		/// </summary>
		/// <param name="owner">owner da mensagem</param>
		/// <param name="text">Texto do corpo da mensagem</param>
		/// <param name="caption">Caption da janela</param>
		/// <param name="buttons">bot�es que devem aparecer na mensagem</param>
		/// <param name="icon">�cone da mensagem</param>
		/// <param name="style">Estilo da mensagem. Null utilizar� o padr�o "neo"</param>
		/// <returns>O result modal segundo o bot�o pressionado pelo usu�rio</returns>
		public static DialogResult Show(IWin32Window owner,
			string text,
			string caption,
			MessageBoxButtons buttons,
			MessageBoxIcon icon,
			StyleGuide style)
		{
			return Show(owner, text, caption, buttons, icon, MessageBoxDefaultButton.Button1, style, String.Empty, ref varChack);
		}

		/// <summary>
		/// Mostra uma caixa de mensagem sobre uma janela especificada e com um 
		/// texto especificado.
		/// </summary>
		/// <param name="text">Texto do corpo da mensagem</param>
		/// <param name="caption">Caption da janela</param>
		/// <param name="buttons">bot�es que devem aparecer na mensagem</param>
		/// <param name="icon">�cone da mensagem</param>
		/// <param name="style">Estilo da mensagem. Null utilizar� o padr�o "neo"</param>
		/// <returns>O result modal segundo o bot�o pressionado pelo usu�rio</returns>
		public static DialogResult Show(string text,
										string caption,
										MessageBoxButtons buttons,
										MessageBoxIcon icon,
										StyleGuide style)
		{
			return Show(null, text, caption, buttons, icon, MessageBoxDefaultButton.Button1, style, String.Empty, ref varChack);
		}

		/// <summary>
		/// Mostra uma caixa de mensagem sobre uma janela especificada e com um 
		/// texto especificado.
		/// </summary>
		/// <param name="text">Texto do corpo da mensagem</param>
		/// <param name="buttons">bot�es que devem aparecer na mensagem</param>
		/// <param name="icon">�cone da mensagem</param>
		/// <param name="style">Estilo da mensagem. Null utilizar� o padr�o "neo"</param>
		/// <returns>O result modal segundo o bot�o pressionado pelo usu�rio</returns>
		public static DialogResult Show(string text,
			MessageBoxButtons buttons,
			MessageBoxIcon icon,
			StyleGuide style)
		{
			return Show(null, text, String.Empty, buttons, icon, MessageBoxDefaultButton.Button1, style, String.Empty, ref varChack);
		}

		/// <summary>
		/// Mostra uma caixa de mensagem sobre uma janela especificada e com um 
		/// texto especificado.
		/// </summary>
		/// <param name="text">Texto do corpo da mensagem</param>
		/// <param name="buttons">bot�es que devem aparecer na mensagem</param>
		/// <param name="icon">�cone da mensagem</param>
		/// <param name="defaultButton">Bot�o default</param>
		/// <param name="style">Estilo da mensagem. Null utilizar� o padr�o "neo"</param>
		/// <param name="checkboxText">Texto do check box, se houver. Empty ou "" n�o usar� checkbox</param>
		/// <param name="checkboxValue">Valor retornado pelo checkbox</param>
		/// <returns>O result modal segundo o bot�o pressionado pelo usu�rio</returns>
		public static DialogResult Show(string text,
			MessageBoxButtons buttons,
			MessageBoxIcon icon,
			MessageBoxDefaultButton defaultButton,
			StyleGuide style,
			string checkboxText,
			ref bool checkboxValue)
		{
			return Show(null, text, String.Empty, buttons, icon, defaultButton, style, checkboxText, ref checkboxValue);
		}
		
		/// <summary>
		/// Mostra uma caixa de mensagem sobre uma janela especificada e com um 
		/// texto especificado.
		/// </summary>
		/// <param name="text">Texto do corpo da mensagem</param>
		/// <param name="buttons">bot�es que devem aparecer na mensagem</param>
		/// <param name="icon">�cone da mensagem</param>
		/// <param name="style">Estilo da mensagem. Null utilizar� o padr�o "neo"</param>
		/// <param name="checkboxText">Texto do check box, se houver. Empty ou "" n�o usar� checkbox</param>
		/// <param name="checkboxValue">Valor retornado pelo checkbox</param>
		/// <returns>O result modal segundo o bot�o pressionado pelo usu�rio</returns>
		public static DialogResult Show(string text,
			MessageBoxButtons buttons,
			MessageBoxIcon icon,
			StyleGuide style,
			string checkboxText,
			ref bool checkboxValue)
		{
			return Show(null, text, String.Empty, buttons, icon, MessageBoxDefaultButton.Button1, style, checkboxText, ref checkboxValue);
		}
		
		/// <summary>
		/// Mostra uma caixa de mensagem sobre uma janela especificada e com um 
		/// texto especificado.
		/// </summary>
		/// <param name="text">Texto do corpo da mensagem</param>
		/// <param name="style">Estilo da mensagem. Null utilizar� o padr�o "neo"</param>
		/// <returns>O result modal segundo o bot�o pressionado pelo usu�rio</returns>
		public static DialogResult Show(string text,
			StyleGuide style)
		{
			return Show(null, text, String.Empty, MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, style, String.Empty, ref varChack);
		}

		
		/// <summary>
		/// Mostra uma caixa de progresso sobre uma janela especificada e com um 
		/// texto especificado.
		/// </summary>
		/// <param name="text">Texto do corpo da mensagem</param>
		/// <param name="showCancelButton">Indica se a janela deve ter o bot�o de cancelar</param>
		/// <returns>Form</returns>
		public static System.Windows.Forms.Form ShowProgressDialog(string text,
			bool showCancelButton,
			StyleGuide style, Thread thread)
		{
			CancelProgressClicked = false;

			Form form = new Form();
			form.Text = ResourceLibrary.GetString(CommonResourceKeys.Progress, CommonResourceKeys.Root);
			form.TopMost = true;
			form.MaximizeBox = false;
			form.MinimizeBox = false;
			form.FormBorderStyle = FormBorderStyle.FixedDialog;
			form.StartPosition = FormStartPosition.CenterScreen;
			form.Width = LarguraJanela;
			form.Height = AlturaJanela-50;
			form.KeyPreview = true;
			form.Closing += new System.ComponentModel.CancelEventHandler(ProgressClosing);
			StyleGuide localStyle = style!=null?style:mStyle;

			PallaControls.Windows.Forms.Panel leftPanel = new PallaControls.Windows.Forms.Panel();
			leftPanel.Dock = DockStyle.Left;
			leftPanel.Style = localStyle;
			leftPanel.PanelType = PanelTypes.LeftOptions;

			PallaControls.Windows.Forms.Panel bottomPanel = new PallaControls.Windows.Forms.Panel();
			bottomPanel.Dock = DockStyle.Bottom;
			bottomPanel.Style = localStyle;
			bottomPanel.PanelType = PanelTypes.BottomArea;

			PallaControls.Windows.Forms.Panel clientPanel = new PallaControls.Windows.Forms.Panel();
			clientPanel.Dock = DockStyle.Fill;
			clientPanel.Style = localStyle;
			clientPanel.PanelType = PanelTypes.ClientArea;

			form.Controls.Add(leftPanel);
			form.Controls.Add(clientPanel);
			clientPanel.Controls.Add(bottomPanel);

			PallaControls.Windows.Forms.Button botao1 = new PallaControls.Windows.Forms.Button();
				
			if (style != null && style.PlansOfColors == PlansColors.AssGreen)
			{
				botao1.Width = 55;
				botao1.Height = 22;
				botao1.Radius = 7;
			}
			else
				botao1.Width = 75;
			
			botao1.Top = 110;
			botao1.Style = localStyle;
				
			if (showCancelButton)
			{
				botao1.Left = 210;
				botao1.Text = ResourceLibrary.GetString(CommonResourceKeys.Cancel, CommonResourceKeys.Root);
				botao1.ButtonPressed += new ButtonPressedEventHandler(CancelProgressClick);
				clientPanel.Controls.Add(botao1);

				if (botao1.Parent!=null) form.ActiveControl = botao1;
			}

			PallaControls.Windows.Forms.Label label = new PallaControls.Windows.Forms.Label();				
			label.Style = localStyle;
			clientPanel.Controls.Add(label);

			label.Left = leftPanel.Width + 10;
			label.Width = 300;
			label.Height = 40;
			label.Top = 10;
			label.Text = text;

			PallaControls.Windows.Forms.InfiniteProgress infiniteProgress = new PallaControls.Windows.Forms.InfiniteProgress();
			infiniteProgress.Style = localStyle;
			clientPanel.Controls.Add(infiniteProgress);

			infiniteProgress.Left = leftPanel.Width + 10;
			infiniteProgress.Width = 300;
			infiniteProgress.Height = 2;
			infiniteProgress.Top = label.Top + label.Height + 5;
				
			if (thread!=null)
			{
				staticthread = thread;
				staticForm = form;
				timer = new System.Windows.Forms.Timer();
				timer.Tick += new EventHandler(OnTick);
				timer.Enabled = true;
			}
			
			form.Show();

			return form;
		}

		#endregion
	}
}
