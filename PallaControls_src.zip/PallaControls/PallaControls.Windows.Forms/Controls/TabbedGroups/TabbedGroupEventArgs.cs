using System;
using System.IO;
using System.Xml;
using System.Windows.Forms;
using PallaControls.Windows.Forms;

namespace PallaControls.Windows.Forms
{
    public class TabbedGroupsCloseRequestEventArgs : EventArgs
	{
	    protected TabGroupLeaf mtgl;
	    protected PallaControls.Windows.Forms.TabControl mtc;
	    protected PallaControls.Windows.Forms.TabPage mtp;
	    protected bool mcancel;
	
		#region Constructors
		
		public TabbedGroupsCloseRequestEventArgs(TabGroupLeaf tgl, PallaControls.Windows.Forms.TabControl tc, PallaControls.Windows.Forms.TabPage tp)
		{
		    mtgl = tgl;
		    mtc = tc;
		    mtp = tp;
		    mcancel = false;
		}

		#endregion
		
		#region Properties
		
		public TabGroupLeaf Leaf
		{
		    get { return mtgl; }
		}
    
        public PallaControls.Windows.Forms.TabControl TabControl
        {
            get { return mtc; }
        }

        public PallaControls.Windows.Forms.TabPage TabPage
        {
            get { return mtp; }
        }
        
        public bool Cancel
        {
            get { return mcancel; }
            set { mcancel = value; }
        }

		#endregion
    }

    public class TabbedGroupsContextMenuEventArgs : TabbedGroupsCloseRequestEventArgs
    {
        protected ContextMenu mcontextMenu;
	
		#region Constructors
		
		public TabbedGroupsContextMenuEventArgs(TabGroupLeaf tgl, PallaControls.Windows.Forms.TabControl tc, 
                                      PallaControls.Windows.Forms.TabPage tp, ContextMenu contextMenu)
            : base(tgl, tc, tp)
        {
            mcontextMenu = contextMenu;
        }

		#endregion
		
		#region Properties

		public ContextMenu ContextMenu
        {
            get { return mcontextMenu; }
        }    

		#endregion
    }
    
    public class TabbedGroupsPageLoadingEventArgs : EventArgs
    {
        protected PallaControls.Windows.Forms.TabPage mtp;
        protected XmlTextReader mxmlIn;
        protected bool mcancel;
        
		#region Constructors

		public TabbedGroupsPageLoadingEventArgs(PallaControls.Windows.Forms.TabPage tp, XmlTextReader xmlIn)
        {
            mtp = tp;
            mxmlIn = xmlIn;
            mcancel = false;
        }

		#endregion
        
		#region Properties

		public PallaControls.Windows.Forms.TabPage TabPage
        {
            get { return mtp; }
        }
        
        public XmlTextReader XmlIn
        {
            get { return mxmlIn; }
        }
        
        public bool Cancel
        {
            get { return mcancel; }
            set { mcancel = value; }
        }

		#endregion
    }    

    public class TabbedGroupsPageSavingEventArgs : EventArgs
    {
        protected PallaControls.Windows.Forms.TabPage mtp;
        protected XmlTextWriter mxmlOut;
        
		#region Constructors

		public TabbedGroupsPageSavingEventArgs(PallaControls.Windows.Forms.TabPage tp, XmlTextWriter xmlOut)
        {
            mtp = tp;
            mxmlOut = xmlOut;
        }

		#endregion
        
		#region Properties
		
		public PallaControls.Windows.Forms.TabPage TabPage
        {
            get { return mtp; }
        }
        
        public XmlTextWriter XmlOut
        {
            get { return mxmlOut; }
        }

		#endregion
    }    
}
