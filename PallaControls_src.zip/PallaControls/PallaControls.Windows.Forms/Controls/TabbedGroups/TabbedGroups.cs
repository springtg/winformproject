using System;
using System.IO;
using System.Xml;
using System.Text;
using System.Data;
using System.Drawing;
using System.Collections;
using System.Globalization;
using System.ComponentModel;
using System.Windows.Forms;
using PallaControls.Utilities;
using PallaControls.Resources;
using PallaControls.Resources.Keys;
using PallaControls.Utilities.Win32;
using PallaControls.Windows.Forms;

namespace PallaControls.Windows.Forms
{
    [ToolboxBitmap(typeof(TabbedGroups))]
    public class TabbedGroups : UserControl, ISupportInitialize, IMessageFilter
	{
		#region Nested types

		public class DragProvider
	    {
            protected object mtag;
            
            public DragProvider()
            {
                mtag = null;
            }
            
            public DragProvider(object tag)
            {
                mtag = tag;
            }
            
            public object Tag
            {
                get { return mtag; }
                set { mtag = value; }
            }
	    }
	
	    [Flags()]
		public enum DisplayTabModes
	    {
            HideAll,
            ShowAll,
            ShowActiveLeaf,
            ShowMouseOver,
            ShowActiveAndMouseOver
	    }
	
	    [Flags()]
		public enum CompactFlags
	    {
	        RemoveEmptyTabLeaf = 1,
	        RemoveEmptyTabSequence = 2,
	        ReduceSingleEntries = 4,
	        ReduceSameDirection = 8,
	        All = 15
	    }

		public class TabControlCreatedEventArgs : EventArgs
		{
			private PallaControls.Windows.Forms.TabControl tc;
			
			#region Constructors

			public TabControlCreatedEventArgs(PallaControls.Windows.Forms.TabControl tc)
			{
				this.tc = tc;
			}

			#endregion

			#region Properties

			public PallaControls.Windows.Forms.TabControl TabControl
			{
				get {return this.tc;}
			}

			#endregion
		}

		public class GlobalSavingEventArgs : EventArgs
		{
			private XmlTextWriter xmlOut;
			
			#region Constructors

			public GlobalSavingEventArgs(XmlTextWriter xmlOut)
			{
				this.xmlOut = xmlOut;
			}

			#endregion

			#region Properties

			public XmlTextWriter XmlOut
			{
				get {return this.xmlOut;}
			}

			#endregion
		}

		public class GlobalLoadingEventArgs : EventArgs
		{
			private XmlTextReader xmlIn;
			
			#region Constructors

			public GlobalLoadingEventArgs(XmlTextReader xmlIn)
			{
				this.xmlIn = xmlIn;
			}

			#endregion

			#region Properties

			public XmlTextReader XmlIn
			{
				get {return this.xmlIn;}
			}

			#endregion
		}
		
		public class ExternalDropEventArgs : EventArgs
		{
			private TabGroupLeaf tgl;
			private PallaControls.Windows.Forms.TabControl tc;
			private DragProvider dp;
			
			#region Constructors

			public ExternalDropEventArgs(TabGroupLeaf tgl, PallaControls.Windows.Forms.TabControl tc, DragProvider dp)
			{
				this.tgl = tgl;
				this.tc = tc;
				this.dp = dp;
			}

			#endregion

			#region Properties

			public TabGroupLeaf TabGroupLeaf
			{
				get{return this.tgl;}
			}

			public PallaControls.Windows.Forms.TabControl TabControl
			{
				get{return this.tc;}
			}

			public DragProvider DragProvider
			{
				get{return this.dp;}
			}
				
			#endregion
		}

		
		#endregion
	
	    protected int mnumLeafs;
        protected int mdefMinWidth;
        protected int mdefMinHeight;
		protected int mresizeBarVector;
		protected int msuspendLeafCount;
		protected string mcloseMenuText;
        protected string mprominentMenuText;
        protected string mrebalanceMenuText;
        protected string mmovePreviousMenuText;
        protected string mmoveNextMenuText;
        protected string mnewVerticalMenuText;
        protected string mnewHorizontalMenuText;
        protected ImageList mimageList;
        protected bool mdirty;
        protected bool mautoCalculateDirty;
        protected bool msaveControls;
        protected bool minitializing;
        protected bool matLeastOneLeaf;
        protected bool mautoCompact;
        protected bool mcompacting;
        protected bool mresizeBarLock;
		protected bool mlayoutLock;
		protected bool mpageCloseWhenEmpty;
		protected Color mresizeBarColor;
        protected Shortcut mcloseShortcut;
        protected Shortcut mprominentShortcut;
        protected Shortcut mrebalanceShortcut;
        protected Shortcut mmovePreviousShortcut;
        protected Shortcut mmoveNextShortcut;
        protected Shortcut msplitVerticalShortcut;
        protected Shortcut msplitHorizontalShortcut;
        protected Shortcut mnextTabShortcut;
        protected CompactFlags mcompactOptions;
        protected DisplayTabModes mdisplayTabMode;
        protected TabGroupLeaf mprominentLeaf;
        protected TabGroupLeaf mactiveLeaf;
        protected TabGroupSequence mroot;
		protected StyleGuide menterpriseStyle = null;
	
	    public delegate void TabControlCreatedEventHandler(object sender, TabControlCreatedEventArgs e);
	    public delegate void PageCloseRequestEventHandler(object sender, TabbedGroupsCloseRequestEventArgs e);
        public delegate void PageContextMenuEventHandler(object sender, TabbedGroupsContextMenuEventArgs e);
        public delegate void GlobalSavingEventHandler(object sender, GlobalSavingEventArgs e);
        public delegate void GlobalLoadingEventHandler(object sender, GlobalLoadingEventArgs e);
        public delegate void PageSavingEventHandler(object sender, TabbedGroupsPageSavingEventArgs e);
        public delegate void PageLoadingEventHandler(object sender, TabbedGroupsPageLoadingEventArgs e);
        public delegate void ExternalDropEventHandler(object sender, ExternalDropEventArgs e);
	
	    public event TabControlCreatedEventHandler TabControlCreated;
	    public event PageCloseRequestEventHandler PageCloseRequest;
        public event PageContextMenuEventHandler PageContextMenu;
        public event GlobalSavingEventHandler GlobalSaving;
        public event GlobalLoadingEventHandler GlobalLoading;
        public event PageSavingEventHandler PageSaving;
        public event PageLoadingEventHandler PageLoading;
        public event EventHandler ProminentLeafChanged;
        public event EventHandler ActiveLeafChanged;
        public event EventHandler DirtyChanged;
        public event ExternalDropEventHandler ExternalDrop;
	
		#region Constructors
		
		public TabbedGroups()
        {
            InternalConstruct();
        }
            
        protected void InternalConstruct()
		{
			SetStyle(ControlStyles.DoubleBuffer | 
					 ControlStyles.AllPaintingInWmPaint |
					 ControlStyles.UserPaint, true);
		
		    this.AllowDrop = true;
		
		    
		    mnumLeafs = 0;
		    mcompacting = false;
		    minitializing = false;
			msuspendLeafCount = 0;

            mroot = new TabGroupSequence(this);
		    
		    ResetProminentLeaf();
		    ResetResizeBarVector();
		    ResetResizeBarColor();
		    ResetResizeBarLock();
			ResetLayoutLock();
			ResetCompactOptions();
		    ResetDefaultGroupMinimumWidth();
            ResetDefaultGroupMinimumHeight();
            ResetActiveLeaf();
            ResetAutoCompact();
            ResetAtLeastOneLeaf();
            ResetCloseMenuText();
            ResetProminentMenuText();
            ResetRebalanceMenuText();
            ResetMovePreviousMenuText();
            ResetMoveNextMenuText();
            ResetNewVerticalMenuText();
            ResetNewHorizontalMenuText();
            ResetCloseShortcut();
            ResetProminentShortcut();
            ResetRebalanceShortcut();
            ResetMovePreviousShortcut();
            ResetMoveNextShortcut();
            ResetSplitVerticalShortcut();
            ResetSplitHorizontalShortcut();
            ResetImageList();
            ResetDisplayTabMode();
            ResetSaveControls();
            ResetAutoCalculateDirty();
            ResetDirty();
			ResetPageCloseWhenEmpty();
            
            Application.AddMessageFilter(this);
            
        }

		#endregion
        
		#region Dispose
		
		protected override void Dispose( bool disposing )
		{
			if (disposing)
			{
				Application.RemoveMessageFilter(this);
			}

			base.Dispose(disposing);
		}

		#endregion
		
		#region Virtuals

        protected bool ShouldSerializeResizeBackColor()
        {
            return mresizeBarColor != base.BackColor;
        }

		protected bool ShouldSerializeCloseShortcut()
		{
			return !mcloseShortcut.Equals(Shortcut.CtrlShiftC);
		}

		protected bool ShouldSerializeProminentShortcut()
		{
			return !mprominentShortcut.Equals(Shortcut.CtrlShiftT);
		}

		protected bool ShouldSerializeRebalanceShortcut()
		{
			return !mrebalanceShortcut.Equals(Shortcut.CtrlShiftR);
		}

		protected bool ShouldSerializeMovePreviousShortcut()
		{
			return !mmovePreviousShortcut.Equals(Shortcut.CtrlShiftP);
		}

		protected bool ShouldSerializeMoveNextShortcut()
		{
			return !mmoveNextShortcut.Equals(Shortcut.CtrlShiftN);
		}

		protected bool ShouldSerializeSplitVerticalShortcut()
		{
			return !msplitVerticalShortcut.Equals(Shortcut.CtrlShiftV);
		}

		protected bool ShouldSerializeSplitHorizontalShortcut()
		{
			return !msplitHorizontalShortcut.Equals(Shortcut.CtrlShiftH);
		}

		protected bool ShouldSerializeDirty()
		{
			return false;
		}
        
        
		protected bool ShouldSerializeImageList()
		{
			return mimageList != null;
		}

		public virtual void OnTabControlCreated(TabControlCreatedEventArgs e)
		{
			if (msuspendLeafCount == 0)
			{
				mnumLeafs++;
			}
			
			e.TabControl.Appearance = PallaControls.Windows.Forms.TabControl.VisualAppearance.MultiDocument;
			e.TabControl.BoldSelectedPage = false;
			e.TabControl.DragOverSelect = false;
			e.TabControl.ImageList = mimageList;
			e.TabControl.Style = this.menterpriseStyle;

			switch(mdisplayTabMode)
			{
				case TabbedGroups.DisplayTabModes.ShowAll:
					e.TabControl.HideTabsMode = PallaControls.Windows.Forms.TabControl.HideTabsModes.ShowAlways;
					break;
				case TabbedGroups.DisplayTabModes.HideAll:
					e.TabControl.HideTabsMode = PallaControls.Windows.Forms.TabControl.HideTabsModes.HideAlways;
					break;
			}
            
			if (TabControlCreated != null)
				TabControlCreated(this, e);
		}
        
		public virtual void OnPageCloseRequested(TabbedGroupsCloseRequestEventArgs e)
		{
			if (PageCloseRequest != null)
				PageCloseRequest(this, e);
                
		}

		public virtual void OnPageContextMenu(TabbedGroupsContextMenuEventArgs e)
		{
			if (PageContextMenu != null)
				PageContextMenu(this, e);
		}

		public virtual void OnGlobalSaving(GlobalSavingEventArgs e)
		{
			if (GlobalSaving != null)
				GlobalSaving(this, e);
		}
        
		public virtual void OnGlobalLoading(GlobalLoadingEventArgs e)
		{
			if (GlobalLoading != null)
				GlobalLoading(this, e);
		}
        
		public virtual void OnPageSaving(TabbedGroupsPageSavingEventArgs e)
		{
			if (PageSaving != null)
				PageSaving(this, e);
		}
        
		public virtual void OnPageLoading(TabbedGroupsPageLoadingEventArgs e)
		{
			if (PageLoading != null)
				PageLoading(this, e);
		}

		public virtual void OnProminentLeafChanged(EventArgs e)
		{
			if (ProminentLeafChanged != null)
				ProminentLeafChanged(this, e);
		}
        
		public virtual void OnActiveLeafChanged(EventArgs e)
		{
			if (ActiveLeafChanged != null)
				ActiveLeafChanged(this, e);
		}
        
		public virtual void OnDirtyChanged(EventArgs e)
		{
			if (DirtyChanged != null)
				DirtyChanged(this, e);
		}

		public virtual void OnExternalDrop(ExternalDropEventArgs e)
		{
			if (ExternalDrop != null)
				ExternalDrop(this, e);
		}

		protected TabGroupLeaf RecursiveFindLeafInSequence(TabGroupSequence tgs, bool forwards)
		{
			int count = tgs.Count;
        
			for(int i=0; i<count; i++)
			{
				int index = (forwards == true) ? i : (tgs.Count - i - 1);
                
				if (tgs[index].IsLeaf)
					return tgs[index] as TabGroupLeaf;
				else
				{
					TabGroupLeaf leaf = RecursiveFindLeafInSequence(tgs[index] as TabGroupSequence, forwards);

					if (leaf != null)
						return leaf;
				}
			}
            
			return null;
		}

		protected TabGroupLeaf RecursiveFindLeafInSequence(TabGroupSequence tgs, TabGroupBase tgb, bool forwards)
		{
			int count = tgs.Count;
			int index = tgs.IndexOf(tgb);
        
			if (forwards)
			{
				for(int i=index+1; i<count; i++)
				{
					if (tgs[i].IsLeaf)
						return tgs[i] as TabGroupLeaf;
					else
					{
						TabGroupLeaf leaf = RecursiveFindLeafInSequence(tgs[i] as TabGroupSequence, forwards);
                    
						if (leaf != null)
							return leaf;
					}
				}
			}
			else
			{
				for(int i=index-1; i>=0; i--)
				{
					if (tgs[i].IsLeaf)
						return tgs[i] as TabGroupLeaf;
					else
					{
						TabGroupLeaf leaf = RecursiveFindLeafInSequence(tgs[i] as TabGroupSequence, forwards);
                    
						if (leaf != null)
							return leaf;
					}
				}
			}
                        
			if (tgs.Parent != null)
				return RecursiveFindLeafInSequence(tgs.Parent as TabGroupSequence, tgs, forwards);
			else
				return null;
		}

		protected void MoveActiveInSequence(TabGroupSequence tgs, TabGroupBase child)
		{
			int count = tgs.Count;
			int index = tgs.IndexOf(child);
        
			for(int i=index+1; i<count; i++)
			{
				if (tgs[i].IsLeaf)
				{
					ActiveLeaf = tgs[i] as TabGroupLeaf;
					return;  
				}
				else
				{
					if (RecursiveActiveInSequence(tgs[i] as TabGroupSequence, true))
						return;
				}
			}
            
			for(int i=index-1; i>=0; i--)
			{
				if (tgs[i].IsLeaf)
				{
					ActiveLeaf = tgs[i] as TabGroupLeaf;
					return;  
				}
				else
				{
					if (RecursiveActiveInSequence(tgs[i] as TabGroupSequence, false))
						return;
				}
			}
            
			if (tgs.Parent != null)
				MoveActiveInSequence(tgs.Parent as TabGroupSequence, tgs);
		}
        
		protected bool RecursiveActiveInSequence(TabGroupSequence tgs, bool forwards)
		{
			int count = tgs.Count;
        
			for(int i=0; i<count; i++)
			{
				int index = (forwards == true) ? i : (tgs.Count - i - 1);
                
				if (tgs[index].IsLeaf)
				{
					ActiveLeaf = tgs[index] as TabGroupLeaf;
					return true;
				}
				else
				{
					if (RecursiveActiveInSequence(tgs[index] as TabGroupSequence, forwards))
						return true;
				}
			}
            
			return false;
		}
        
		protected void Notify(TabGroupBase.NotifyCode notifyCode)
		{
			if (mroot != null)
				mroot.Notify(notifyCode);
		}
        
		protected bool TestShortcut(Shortcut sc)
		{
			bool result = false;
        
			if (mactiveLeaf != null)
			{
				PallaControls.Windows.Forms.TabControl tc = mactiveLeaf.GrouparamControl as PallaControls.Windows.Forms.TabControl;
            
				if (tc.SelectedTab != null)
				{
					if (sc.Equals(mcloseShortcut))
					{
						mactiveLeaf.OnClose(mactiveLeaf, EventArgs.Empty);
						result = true;
					}

					if (sc.Equals(mprominentShortcut))
					{
						mactiveLeaf.OnToggleProminent(mactiveLeaf, EventArgs.Empty);
						result = true;
					}
                        
					if (sc.Equals(mmoveNextShortcut))
					{
						mactiveLeaf.OnMoveNext(mactiveLeaf, EventArgs.Empty);
						result = true;
					}
                
					if (sc.Equals(mmovePreviousShortcut))
					{
						mactiveLeaf.OnMovePrevious(mactiveLeaf, EventArgs.Empty);
						result = true;
					}
                
					if (tc.TabPages.Count > 1)
					{
						bool allowVert = false;
						bool allowHorz = false;
                        
						if (mroot.Count <= 1)
						{
							allowVert = true;
							allowHorz = true;
						}
						else
						{
							if (mroot.Direction == Direction.Vertical)
								allowVert = true;
							else
								allowHorz = true;
						}
                    
						if (allowHorz && sc.Equals(msplitVerticalShortcut))
						{
							mactiveLeaf.NewHorizontalGroup(mactiveLeaf, false);
							result = true;
						}

						if (allowVert && sc.Equals(msplitHorizontalShortcut))
						{
							mactiveLeaf.NewVerticalGroup(mactiveLeaf, false);
							result = true;
						}
					}
				}
                
				if (sc.Equals(mrebalanceShortcut))
				{
					mactiveLeaf.OnRebalance(mactiveLeaf, EventArgs.Empty);
					result = true;
				}
			}

			return result;
		}
        
		protected bool SelectNextTab()
		{
			if (mactiveLeaf == null)
				SelectFirstPage();
			else
			{
				bool selectFirst = false;
				TabGroupLeaf startLeaf = mactiveLeaf;
				TabGroupLeaf thisLeaf = startLeaf;
                
				do
				{
					PallaControls.Windows.Forms.TabControl tc = thisLeaf.GrouparamControl as PallaControls.Windows.Forms.TabControl;
                
					if (tc.TabPages.Count > 0)
					{
						if (selectFirst)
						{
							tc.SelectedIndex = 0;
                            
							if (thisLeaf != mactiveLeaf)
								ActiveLeaf = thisLeaf;
                                
							break;
						}
						else
						{
							if (tc.SelectedIndex < tc.TabPages.Count - 1)
							{
								tc.SelectedIndex = tc.SelectedIndex + 1;
								break;
							}         
						}           
					}
                    
					selectFirst = true;
                    
					thisLeaf = NextLeaf(thisLeaf);
                    
					if (thisLeaf == null)
						thisLeaf = FirstLeaf();

					if (thisLeaf == startLeaf)
					{
						if (tc.SelectedIndex > 0)
						{
							tc.SelectedIndex = 0;
						}
					}

				} while(thisLeaf != startLeaf);
			}
            
			return true;
		}

		protected bool SelectPreviousTab()
		{
			if (mactiveLeaf == null)
				SelectLastPage();
			else
			{
				bool selectLast = false;
				TabGroupLeaf startLeaf = mactiveLeaf;
				TabGroupLeaf thisLeaf = startLeaf;
                
				do
				{
					PallaControls.Windows.Forms.TabControl tc = thisLeaf.GrouparamControl as PallaControls.Windows.Forms.TabControl;
                
					if (tc.TabPages.Count > 0)
					{
						if (selectLast)
						{
							tc.SelectedIndex = tc.TabPages.Count - 1;
                            
							if (thisLeaf != mactiveLeaf)
								ActiveLeaf = thisLeaf;
                                
							break;
						}
						else
						{
							if (tc.SelectedIndex > 0)
							{
								tc.SelectedIndex = tc.SelectedIndex - 1;
								break;
							}         
						}           
					}
                    
					selectLast = true;
                    
					thisLeaf = PreviousLeaf(thisLeaf);
                    
					if (thisLeaf == null)
						thisLeaf = LastLeaf();

					if (thisLeaf == startLeaf)
					{
						if (tc.SelectedIndex == 0)
						{
							tc.SelectedIndex = tc.TabPages.Count - 1;
						}
					}

				} while(thisLeaf != startLeaf);
			}
            
			return true;
		}

		protected void SelectFirstPage()
		{
			ActiveLeaf = FirstLeaf();
                    
			if (mactiveLeaf != null)
			{
				if (mactiveLeaf.TabPages.Count > 0)
					mactiveLeaf.TabPages[0].Selected = true;
			}
		}
        
		protected void SelectLastPage()
		{
			ActiveLeaf = LastLeaf();
                    
			if (mactiveLeaf != null)
			{
				if (mactiveLeaf.TabPages.Count > 0)
					mactiveLeaf.TabPages[mactiveLeaf.TabPages.Count - 1].Selected = true;
			}
		}

		#endregion
        
		#region Internal helpers
		
		/*private bool ShouldSerializeActiveLeaf()
		{
			return false;
		}*/

		#endregion

		#region Methods

		public void ResetStyle()
		{
		}

		public void ResetResizeBarVector()
		{
			ResizeBarVector = -1;
		}

		public void ResetResizeBarColor()
		{
			ResizeBarColor = base.BackColor;
		}

		public void ResetLayoutLock()
		{
			LayoutLock = false;
		}
        
		public void ResetProminentLeaf()
		{
			ProminentLeaf = null;
		}
        
		public void ResetDefaultGroupMinimumWidth()
		{
			DefaultGroupMinimumWidth = 4;
		}

		public void ResetDefaultGroupMinimumHeight()
		{
			DefaultGroupMinimumHeight = 4;
		}
        
		public void ResetCloseMenuText()
		{
			CloseMenuText = ResourceLibrary.GetString(WindowsControlsResourceKeys.Close, WindowsControlsResourceKeys.Root);
		}

		public void ResetProminentMenuText()
		{
			ProminentMenuText = ResourceLibrary.GetString(WindowsControlsResourceKeys.Prominent, WindowsControlsResourceKeys.Root);
		}

		public void ResetRebalanceMenuText()
		{
			RebalanceMenuText = ResourceLibrary.GetString(WindowsControlsResourceKeys.CalculateAgain, WindowsControlsResourceKeys.Root);
		}

		public void ResetMovePreviousMenuText()
		{
			MovePreviousMenuText = ResourceLibrary.GetString(WindowsControlsResourceKeys.PreviousPage, WindowsControlsResourceKeys.Root);
		}

		public void ResetMoveNextMenuText()
		{
			MoveNextMenuText = ResourceLibrary.GetString(WindowsControlsResourceKeys.NextPage, WindowsControlsResourceKeys.Root);
		}

		public void ResetNewVerticalMenuText()
		{
			NewVerticalMenuText = ResourceLibrary.GetString(WindowsControlsResourceKeys.NewPageVertical, WindowsControlsResourceKeys.Root);
		}

		public void ResetNewHorizontalMenuText()
		{
			NewHorizontalMenuText = ResourceLibrary.GetString(WindowsControlsResourceKeys.NewPageHorizontal, WindowsControlsResourceKeys.Root);
		}

		public void ResetCloseShortcut()
		{
			CloseShortcut = Shortcut.CtrlShiftC;
		}

		public void ResetProminentShortcut()
		{
			ProminentShortcut = Shortcut.CtrlShiftT;  
		}

		public void ResetRebalanceShortcut()
		{
			RebalanceShortcut = Shortcut.CtrlShiftR;
		}

		public void ResetMovePreviousShortcut()
		{
			MovePreviousShortcut = Shortcut.CtrlShiftP;
		}
        
		public void ResetSplitVerticalShortcut()
		{
			SplitVerticalShortcut = Shortcut.CtrlShiftV;
		}

		public void ResetMoveNextShortcut()
		{
			MoveNextShortcut = Shortcut.CtrlShiftN;
		}

		public void ResetSplitHorizontalShortcut()
		{
			SplitHorizontalShortcut = Shortcut.CtrlShiftH;
		}

		public void ResetDisplayTabMode()
		{
			DisplayTabMode = DisplayTabModes.ShowAll;
		}

		public void ResetSaveControls()
		{
			SaveControls = true;
		}

		public void ResetImageList()
		{
			ImageList = null;
		}
        
		public void ResetDirty()
		{
			Dirty = false;
		}

		public void ResetPageCloseWhenEmpty()
		{
			PageCloseWhenEmpty = false;
		}

		public void ResetAutoCalculateDirty()
		{
			AutoCalculateDirty = true;
		}
        
		public void ResetActiveLeaf()
		{
			ActiveLeaf = null;
		}

		public void ResetAtLeastOneLeaf()
		{
			AtLeastOneLeaf = true;
		}

		public void ResetAutoCompact()
		{
			mautoCompact = true;
		}

		public void Rebalance()
		{
			mroot.Rebalance(true);
		}

		public void Rebalance(bool recurse)
		{
			mroot.Rebalance(recurse);
		}
        
		public void Compact()
		{
			Compact(mcompactOptions);
		}
        
		public void Compact(CompactFlags flags)
		{
			if (!mcompacting)
			{
				if (!minitializing)
				{
					mcompacting = true;
					mroot.Compact(flags);
					mcompacting = false;
                    
					EnforceAtLeastOneLeaf();
				}
			}
		}
        
		public TabGroupLeaf FirstLeaf()
		{
			return RecursiveFindLeafInSequence(mroot, true);
		}

		public TabGroupLeaf LastLeaf()
		{
			return RecursiveFindLeafInSequence(mroot, false);
		}

		public TabGroupLeaf NextLeaf(TabGroupLeaf current)
		{
			TabGroupSequence tgs = current.Parent as TabGroupSequence;
            
			if (tgs != null)
				return RecursiveFindLeafInSequence(tgs, current, true);
			else
				return null;
		}
        
		public TabGroupLeaf PreviousLeaf(TabGroupLeaf current)
		{
			TabGroupSequence tgs = current.Parent as TabGroupSequence;
            
			if (tgs != null)
				return RecursiveFindLeafInSequence(tgs, current, false);
			else
				return null;
		}

		internal void MoveActiveToNearestFromLeaf(TabGroupBase oldLeaf)
		{
			if (oldLeaf != null)
			{
				TabGroupSequence tgs = oldLeaf.Parent as TabGroupSequence;
                
				if (tgs != null)
				{
					MoveActiveInSequence(tgs, oldLeaf);
				}
			}
		}
        
		internal void MoveActiveToNearestFromSequence(TabGroupSequence tgs)
		{
			if (mroot == tgs)
			{
				ActiveLeaf = null;
			}
			else
			{
				TabGroupSequence tgsParent = tgs.Parent as TabGroupSequence;
            
				if (tgs != null)
				{
					MoveActiveInSequence(tgsParent, tgs);
				}
			}
		}

		public void BeginInit()
		{
			minitializing = true;
		}
        
		public void EndInit()
		{
			minitializing = false;
            
			if (AtLeastOneLeaf == false)
				Compact();
			
			mroot.Reposition();
		}

		public byte[] SaveConfigToArray()
		{
			return SaveConfigToArray(Encoding.Unicode);	
		}

		public byte[] SaveConfigToArray(Encoding encoding)
		{
			MemoryStream ms = new MemoryStream();
			
			SaveConfigToStream(ms, encoding);

			ms.Close();

			return ms.GetBuffer();
		}

		public void SaveConfigToFile(string filename)
		{
			SaveConfigToFile(filename, Encoding.Unicode);
		}

		public void SaveConfigToFile(string filename, Encoding encoding)
		{
			FileStream fs = new FileStream(filename, FileMode.Create);
			
			SaveConfigToStream(fs, encoding);		

			fs.Close();
		}

		public void SaveConfigToStream(Stream stream, Encoding encoding)
		{
			XmlTextWriter xmlOut = new XmlTextWriter(stream, encoding); 

			xmlOut.Formatting = Formatting.Indented;
			
			xmlOut.WriteStartDocument();
			xmlOut.WriteComment(" PallaControls Sistemas de Automa��o ");
			xmlOut.WriteComment(" Modificar este arquivo pode resultar em erros de leitura ");

			xmlOut.WriteStartElement("TabbedGroups");
			xmlOut.WriteAttributeString("FormatVersion", "1");
            
			if (mactiveLeaf != null)
				xmlOut.WriteAttributeString("ActiveLeaf", mactiveLeaf.Unique.ToString(CultureInfo.CurrentCulture));
			else
				xmlOut.WriteAttributeString("ActiveLeaf", "-1");

			xmlOut.WriteStartElement("CustomGlobalData");
			OnGlobalSaving(new GlobalSavingEventArgs(xmlOut));
			xmlOut.WriteEndElement();

			mroot.SaveToXml(xmlOut);

			xmlOut.WriteEndElement();
			xmlOut.WriteEndDocument();

			xmlOut.Close();			
            
			if (mautoCalculateDirty)
				mdirty = false;
            
		}

		public void LoadConfigFromArray(byte[] buffer)
		{
			MemoryStream ms = new MemoryStream(buffer);
			
			LoadConfigFromStream(ms);

			ms.Close();
		}

		public void LoadConfigFromFile(string filename)
		{
			FileStream fs = new FileStream(filename, FileMode.Open);
			
			LoadConfigFromStream(fs);		

			fs.Close();
		}

		public void LoadConfigFromStream(Stream stream)
		{
			XmlTextReader xmlIn = new XmlTextReader(stream); 

			xmlIn.WhitespaceHandling = WhitespaceHandling.None;

			xmlIn.MoveToContent();

			if (xmlIn.Name != "TabbedGroups")
				throw new ArgumentException(String.Format(CultureInfo.CurrentCulture, ResourceLibrary.GetString(WindowsControlsResourceKeys.ElementNotFound, WindowsControlsResourceKeys.Root), "TabbedGroups"));

			string version = xmlIn.GetAttribute(0);
			string rawActiveLeaf = xmlIn.GetAttribute(1);

			int formatVersion = (int)Convert.ToDouble(version, CultureInfo.CurrentCulture);
			int activeLeaf = Convert.ToInt32(rawActiveLeaf, CultureInfo.CurrentCulture);
            
			if (formatVersion < 1)
				throw new ArgumentException("Invalid Version");

			try
			{
				BeginInit();
                
				mroot.Clear();
                
				if (!xmlIn.Read())
					throw new ArgumentException(ResourceLibrary.GetString(WindowsControlsResourceKeys.InaccessibleNode, WindowsControlsResourceKeys.Root));

				if (xmlIn.Name != "CustomGlobalData")
					throw new ArgumentException(String.Format(CultureInfo.CurrentCulture, ResourceLibrary.GetString(WindowsControlsResourceKeys.ElementNotFound, WindowsControlsResourceKeys.Root), "CustomData"));

				bool finished = xmlIn.IsEmptyElement;

				OnGlobalLoading(new GlobalLoadingEventArgs(xmlIn));

				while(!finished)
				{
					if (xmlIn.NodeType == XmlNodeType.EndElement)
						finished = (xmlIn.Name == "CustomGlobalData");

					if (!finished)
					{
						if (!xmlIn.Read())
							throw new ArgumentException(WindowsControlsResourceKeys.InaccessibleNode, WindowsControlsResourceKeys.Root);
					}
				} 

				if (!xmlIn.Read())
					throw new ArgumentException(WindowsControlsResourceKeys.InaccessibleNode, WindowsControlsResourceKeys.Root);

				if (xmlIn.Name != "Sequence")
					throw new ArgumentException(String.Format(CultureInfo.CurrentCulture, ResourceLibrary.GetString(WindowsControlsResourceKeys.ElementNotFound, WindowsControlsResourceKeys.Root), "Sequence"));
                
				mroot.LoadFromXml(xmlIn);

				if (!xmlIn.Read())
					throw new ArgumentException(WindowsControlsResourceKeys.InaccessibleNode, WindowsControlsResourceKeys.Root);

				if (xmlIn.NodeType != XmlNodeType.EndElement)
					throw new ArgumentException(String.Format(CultureInfo.CurrentCulture, ResourceLibrary.GetString(WindowsControlsResourceKeys.ElementNotFound, WindowsControlsResourceKeys.Root), "EndElement"));
			}
			finally
			{
				TabGroupLeaf newActive = null;
            
				TabGroupLeaf current = FirstLeaf();
                
				while(current != null)
				{
					if (newActive == null)
						newActive = current;
                        
					if (current.Unique == activeLeaf)
					{
						newActive = current;
						break;
					}
                    
					current = NextLeaf(current);
				}
                
				if (newActive != null)
					ActiveLeaf = newActive;
            
				EndInit();
			}
                        
			xmlIn.Close();			
            
			if (mautoCalculateDirty)
				mdirty = false;
		}

		[Browsable(false)]
		public bool Initializing
		{
			get { return minitializing; }
		}

		/*internal void SuspendLeafCount()
		{
			msuspendLeafCount++;
		}*/

		/*internal void ResumeLeafCount(int adjust)
		{
			msuspendLeafCount--;

			mnumLeafs += adjust;
		}*/
		
		internal void EnforceAtLeastOneLeaf()
		{
			if (!mcompacting)
			{
				if (matLeastOneLeaf)
				{
					if (mnumLeafs == 0)
					{
						mroot.AddNewLeaf();
                        
						ActiveLeaf = FirstLeaf();

						if (mautoCalculateDirty)
							mdirty = true;
					}
				}
			}
		}
        
		internal void GroupRemoved(TabGroupBase tgb)
		{
			if (msuspendLeafCount == 0)
			{
                
				if (tgb.IsLeaf)
				{
					mnumLeafs--;

					if (mnumLeafs == 0)
					{
						if (matLeastOneLeaf)
						{
							ActiveLeaf = null;
						}
					}
				}
				else
				{
					TabGroupSequence tgs = tgb as TabGroupSequence;
                
					for(int i=0; i<tgs.Count; i++)
						GroupRemoved(tgs[i]);
				}
                
				if (mautoCalculateDirty)
					mdirty = true;
			}
		}

		/*internal void SetRootSequence(TabGroupSequence tgs)
		{
			mroot = tgs;
		}*/

		[UseApiElements("VirtualKeys.VK_SHIFT, VirtualKeys.VK_CONTROL, Msgs.WM_SYSKEYDOWN, VirtualKeys.VK_MENU")]
		public bool PreFilterMessage(ref Message msg)
		{
			Form parentForm = this.FindForm();

			if ((parentForm != null) && (parentForm == Form.ActiveForm) && parentForm.ContainsFocus)
			{		
				switch(msg.Msg)
				{
					case (int)Msgs.WM_KEYDOWN:
						if (this.Enabled)
						{
							ushort shiftKey = User32.GetKeyState((int)VirtualKeys.VK_SHIFT);
							ushort controlKey = User32.GetKeyState((int)VirtualKeys.VK_CONTROL);

							int code = (int)msg.WParam;

							bool shiftPressed = (((int)shiftKey & 0x00008000) != 0);

							bool controlPressed = (((int)controlKey & 0x00008000) != 0);

							if ((code == (int)VirtualKeys.VK_TAB) && controlPressed)
							{
								if (shiftPressed)
									return SelectPreviousTab();
								else
									return SelectNextTab();
							}
							else
							{
								if (shiftPressed)
									code += 0x00010000;

								if (controlPressed)
									code += 0x00020000;

								Shortcut sc = (Shortcut)(code);

								return TestShortcut(sc);
							}
						}
						break;
					case (int)Msgs.WM_SYSKEYDOWN:
						if (this.Enabled)
						{
							if ((int)msg.WParam != (int)VirtualKeys.VK_MENU)
							{
								Shortcut sc = (Shortcut)(0x00040000 + (int)msg.WParam);
		
								return TestShortcut(sc);
							}
						}
						break;
					default:
						break;
				}
			}

			return false;
		}

		#endregion

		#region Properties
        
		public StyleGuide Style
		{
			get {return menterpriseStyle;}
			set 
			{
				menterpriseStyle = value;
				this.Invalidate(true);
			}
		}

		[Category("Shortcuts")]
		public Shortcut MoveNextShortcut
		{
			get { return mmoveNextShortcut; }
			set { mmoveNextShortcut = value; }
		}

		[Browsable(false)]
		public TabGroupSequence RootSequence
		{
			get { return mroot; }
		}

		[Category("TabbedGroups")]
		[DefaultValue(-1)]
		public int ResizeBarVector
		{
			get { return mresizeBarVector; }
            
			set
			{
				if (mresizeBarVector != value)
				{
					mresizeBarVector = value;
                    
					Notify(TabGroupBase.NotifyCode.ResizeBarVectorChanged);
				}
			}
		}

		[Category("TabbedGroups")]
		public Color ResizeBarColor
		{
			get { return mresizeBarColor; }
            
			set
			{
				if (!mresizeBarColor.Equals(value))
				{
					mresizeBarColor = value;
                    
					Notify(TabGroupBase.NotifyCode.ResizeBarColorChanged);
				}
			}
		}

		[Category("TabbedGroups")]
		[DefaultValue(false)]
		public bool ResizeBarLock
		{
			get { return mresizeBarLock; }
			set { mresizeBarLock = value; }
		}
        
		public void ResetResizeBarLock()
		{
			ResizeBarLock = false;
		}
        
		[Category("TabbedGroups")]
		[DefaultValue(false)]
		public bool LayoutLock
		{
			get { return mlayoutLock; }
			set { mlayoutLock = value; }
		}

		[Category("TabbedGroups")]
		[Browsable(false)]
		public TabGroupLeaf ProminentLeaf
		{
			get { return mprominentLeaf; }
            
			set
			{
				if (mprominentLeaf != value)
				{
					mprominentLeaf = value;

					if (mautoCalculateDirty)
						mdirty = true;

					Notify(TabGroupBase.NotifyCode.ProminentChanged);
                    
					OnProminentLeafChanged(EventArgs.Empty);
				}
			}
		}

		[Category("TabbedGroups")]
		[DefaultValue(typeof(CompactFlags), "All")]
		public CompactFlags CompactOptions
		{
			get { return mcompactOptions; }
			set { mcompactOptions = value; }
		}

		public void ResetCompactOptions()
		{
			CompactOptions = CompactFlags.All;
		}
        
		[Category("TabbedGroups")]
		[DefaultValue(4)]
		public int DefaultGroupMinimumWidth 
		{
			get { return mdefMinWidth; }
            
			set
			{
				if (mdefMinWidth != value)
				{
					mdefMinWidth = value;
                    
					Notify(TabGroupBase.NotifyCode.MinimumSizeChanged);
				}
			}
		}        

		[Category("TabbedGroups")]
		[DefaultValue(4)]
		public int DefaultGroupMinimumHeight
		{
			get { return mdefMinHeight; }
            
			set
			{
				if (mdefMinHeight != value)
				{
					mdefMinHeight = value;
                    
					Notify(TabGroupBase.NotifyCode.MinimumSizeChanged);
				}
			}
		}        

		[Localizable(true)]
		[Category("Text String")]
		public string CloseMenuText
		{
			get { return mcloseMenuText; }
			set { mcloseMenuText = value; }
		}

		[Localizable(true)]
		[Category("Text String")]
		public string ProminentMenuText
		{
			get { return mprominentMenuText; }
			set { mprominentMenuText = value; }
		}

		[Localizable(true)]
		[Category("Text String")]
		public string RebalanceMenuText
		{
			get { return mrebalanceMenuText; }
			set { mrebalanceMenuText = value; }
		}


		[Localizable(true)]
		[Category("Text String")]
		public string MovePreviousMenuText
		{
			get { return mmovePreviousMenuText; }
			set { mmovePreviousMenuText = value; }
		}

		[Localizable(true)]
		[Category("Text String")]
		public string MoveNextMenuText
		{
			get { return mmoveNextMenuText; }
			set { mmoveNextMenuText = value; }
		}

		[Localizable(true)]
		[Category("Text String")]
		public string NewVerticalMenuText
		{
			get { return mnewVerticalMenuText; }
			set { mnewVerticalMenuText = value; }
		}

		[Localizable(true)]
		[Category("Text String")]
		public string NewHorizontalMenuText
		{
			get { return mnewHorizontalMenuText; }
			set { mnewHorizontalMenuText = value; }
		}

		[Category("Shortcuts")]
		public Shortcut CloseShortcut
		{
			get { return mcloseShortcut; }
			set { mcloseShortcut = value; }
		}

		[Category("Shortcuts")]
		public Shortcut ProminentShortcut
		{
			get { return mprominentShortcut; }
			set { mprominentShortcut = value; }
		}

		[Category("Shortcuts")]
		public Shortcut RebalanceShortcut
		{
			get { return mrebalanceShortcut; }
			set { mrebalanceShortcut = value; }
		}

		[Category("Shortcuts")]
		public Shortcut MovePreviousShortcut
		{
			get { return mmovePreviousShortcut; }
			set { mmovePreviousShortcut = value; }
		}

		[Category("Shortcuts")]
		public Shortcut SplitVerticalShortcut
		{
			get { return msplitVerticalShortcut; }
			set { msplitVerticalShortcut = value; }
		}

		[Category("Shortcuts")]
		public Shortcut SplitHorizontalShortcut
		{
			get { return msplitHorizontalShortcut; }
			set { msplitHorizontalShortcut = value; }
		}

		[Category("TabbedGroups")]
		public ImageList ImageList
		{
			get { return mimageList; }
            
			set 
			{ 
				if (mimageList != value)
				{
					Notify(TabGroupBase.NotifyCode.ImageListChanging);

					mimageList = value;
                    
					Notify(TabGroupBase.NotifyCode.ImageListChanged);
				}
			}
		}

		[Category("TabbedGroups")]
		[DefaultValue(typeof(DisplayTabModes), "ShowAll")]
		public DisplayTabModes DisplayTabMode
		{
			get { return mdisplayTabMode; }
            
			set
			{
				if (mdisplayTabMode != value)
				{
					mdisplayTabMode = value;
                    
					Notify(TabGroupBase.NotifyCode.DisplayTabMode);
				}
			}
		}

		[Category("TabbedGroups")]
		[DefaultValue(true)]
		public bool SaveControls
		{
			get { return msaveControls; }
			set { msaveControls = value; }
		}
        
		[Category("TabbedGroups")]
		public bool Dirty
		{
			get { return mdirty; }
            
			set 
			{
				if (mdirty != value)
				{
					mdirty = value;
                    
					OnDirtyChanged(EventArgs.Empty);
				}
			}
		}
        
		[Category("TabbedGroups")]
		[DefaultValue(false)]
		public bool PageCloseWhenEmpty
		{
			get { return mpageCloseWhenEmpty; }
			set { mpageCloseWhenEmpty = value; }
		}
        
		[Category("TabbedGroups")]
		[DefaultValue(true)]
		public bool AutoCalculateDirty
		{
			get { return mautoCalculateDirty; }
			set { mautoCalculateDirty = value; }
		}

		[Category("TabbedGroups")]
		[Browsable(false)]
		public TabGroupLeaf ActiveLeaf
		{
			get { return mactiveLeaf; }
            
			set
			{
				if (mactiveLeaf != value)
				{
					if (matLeastOneLeaf && (value == null))
						return;
					
					if (mautoCalculateDirty)
						mdirty = true;

					if (mactiveLeaf != null)
					{
						TabControl tc = mactiveLeaf.GrouparamControl as PallaControls.Windows.Forms.TabControl;
                        
						if (tc != null)
							tc.BoldSelectedPage = false;
                        
						mactiveLeaf = null;
					}

					if (value != null)
					{
						TabControl tc = value.GrouparamControl as PallaControls.Windows.Forms.TabControl;
                        
						tc.BoldSelectedPage = true;
                        
						mactiveLeaf = value;
					}

					if ((mdisplayTabMode == DisplayTabModes.ShowActiveLeaf) ||
						(mdisplayTabMode == DisplayTabModes.ShowActiveAndMouseOver))
					{
						Notify(TabGroupBase.NotifyCode.DisplayTabMode);
					}
                        
					OnActiveLeafChanged(EventArgs.Empty);
				}
			}
		}

		[Category("TabbedGroups")]
		public bool AtLeastOneLeaf
		{
			get { return matLeastOneLeaf; }
            
			set
			{
				if (matLeastOneLeaf != value)
				{
					matLeastOneLeaf = value;
                    
					if (matLeastOneLeaf)
					{
						if (mnumLeafs == 0)
						{
							mroot.AddNewLeaf();

							ActiveLeaf = FirstLeaf();
							
							if (mautoCalculateDirty)
								mdirty = true;
						}
					}
					else
					{
						if (mnumLeafs > 0)
						{
							if (mautoCompact)
								Compact();
						}
					}
				}
			}
		}

		[Category("TabbedGroups")]
		[DefaultValue(true)]
		public bool AutoCompact
		{
			get { return mautoCompact; }
			set { mautoCompact = value; }
		}

		#endregion
    }
}
