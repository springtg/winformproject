using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Security.Permissions;
using PallaControls.Utilities;
using PallaControls.Utilities.Win32;

namespace PallaControls.Windows.Forms
{
	internal class DatePickerPopUp : PopUpFormBase
	{
		private MonthCalendar monthCalendar1;
		private System.ComponentModel.IContainer components = null;
		protected Control mparent = null;

		[Category("Behavior")]
		public event DateSelectionChangedEventHandler SelectionChanged = null;
		
		#region Constructors

		public DatePickerPopUp(Control parent,DateTime date) : base(parent)
		{
			mparent = parent;
			InitializeComponent();
			monthCalendar1.SetDate(date);

			if (this.mparent is DatePicker)
			{
				monthCalendar1.TitleBackColor = ((DatePicker)this.mparent).CalendarTitleBackColor;
				monthCalendar1.TitleForeColor = ((DatePicker)this.mparent).CalendarTitleForeColor;
				monthCalendar1.TrailingForeColor = ((DatePicker)this.mparent).CalendarTrailingForeColor;
				monthCalendar1.BackColor = ((DatePicker)this.mparent).CalendarBackColor;
				monthCalendar1.ForeColor = ((DatePicker)this.mparent).CalendarForeColor;
			}
		}
		
		#endregion

		#region Dispose
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}
		#endregion

		#region Windows Form Designer generated code
		private void InitializeComponent()
		{
			this.monthCalendar1 = new PallaControls.Windows.Forms.MonthCalendar();
			this.SuspendLayout();
			// 
			// monthCalendar1
			// 
			this.monthCalendar1.Location = new System.Drawing.Point(1, 1);
			this.monthCalendar1.Name = "monthCalendar1";
			this.monthCalendar1.ShowToday = false;
			this.monthCalendar1.ShowTodayCircle = false;
			this.monthCalendar1.TabIndex = 0;
			this.monthCalendar1.MouseUp += new System.Windows.Forms.MouseEventHandler(this.monthCalendar1_MouseUp);
			this.monthCalendar1.KeyUp += new System.Windows.Forms.KeyEventHandler(this.EnterpriseDatePickerPopUpKeyUp);
			// 
			// DatePickerPopUp
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(194, 157);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.monthCalendar1});
			this.Name = "DatePickerPopUp";
			this.Text = "DatePickerPopUp";
			this.DoubleClick += new System.EventHandler(this.EnterpriseDatePickerPopUpDoubleClick);
			this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.EnterpriseDatePickerPopUpKeyUp);
			this.ResumeLayout(false);

		}
		#endregion
		
		#region Events handlers
		private void EnterpriseDatePickerPopUpKeyUp(object sender, System.Windows.Forms.KeyEventArgs e)
		{
			if(e.KeyData == Keys.Escape)
			{
				this.Close();
			}

			if(e.KeyData == Keys.Enter)
			{
				OnSelectionChanged();
				this.Close();
			}
		}

		private void EnterpriseDatePickerPopUpDoubleClick(object sender, System.EventArgs e)
		{
			System.Windows.Forms.MonthCalendar.HitTestInfo hTest = monthCalendar1.HitTest(this.PointToClient(Control.MousePosition));
			System.Windows.Forms.MonthCalendar.HitArea hArea = hTest.HitArea;

			if(hArea == System.Windows.Forms.MonthCalendar.HitArea.Date)
			{
				monthCalendar1.SelectionStart = hTest.Time;
				OnSelectionChanged();

				this.Close();
			}
		}

		private void monthCalendar1_MouseUp(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			System.Windows.Forms.MonthCalendar.HitTestInfo hTest = monthCalendar1.HitTest(this.PointToClient(Control.MousePosition));
			System.Windows.Forms.MonthCalendar.HitArea hArea = hTest.HitArea;

			if(hArea == System.Windows.Forms.MonthCalendar.HitArea.Date)
			{
				monthCalendar1.SelectionStart = hTest.Time;
				OnSelectionChanged();

				this.Close();
			}
		}

		#endregion

		#region Virtuals

		protected void OnSelectionChanged()
		{
			if(this.SelectionChanged != null)
			{
				this.SelectionChanged(this,new DateChangedEventArgs(monthCalendar1.SelectionStart));
			}
		}
		
		#endregion

		#region Overrides
		protected override void OnPaint(System.Windows.Forms.PaintEventArgs e)
		{
			base.OnPaint(e);

			if (this.mparent is DatePicker)
			{
				Rectangle rect = new Rectangle(this.ClientRectangle.Location,new Size(this.ClientRectangle.Width - 1,this.ClientRectangle.Height - 1));
				
				using(Pen pen = new Pen(((DatePicker)this.mparent).BorderHotColor))
				{
					e.Graphics.DrawRectangle(pen,rect);
				}
			}
		}

		public override void PostMessage(ref Message m)
		{
			Message msg = new Message();
			msg.HWnd    = monthCalendar1.Handle;
			msg.LParam  = m.LParam;
			msg.Msg     = m.Msg;
			msg.Result  = m.Result;
			msg.WParam  = m.WParam;

			monthCalendar1.PostMessage(ref msg);
		}

		#endregion

		#region Properties

		public DateTime SelectedDate
		{
			get {return this.monthCalendar1.SelectionEnd;}
		}

		#endregion
	}
}
