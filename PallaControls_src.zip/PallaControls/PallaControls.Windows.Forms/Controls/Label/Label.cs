using System;
using System.Data;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Text;
using System.Windows.Forms;

namespace PallaControls.Windows.Forms
{
	[System.ComponentModel.ToolboxItem(true)]
	public class Label : PallaControls.Windows.Forms.ControlBase
	{
		private System.ComponentModel.Container components = null;
		private HorizontalAlignment m_TextAlignment = HorizontalAlignment.Left;
		private string m_Text = String.Empty;
		//Style Neo, default!!
		private Color m_TextColor = Color.Black;
		private Color m_LabelColor = Color.FromArgb(231, 231, 214);

		#region Constructors

		public Label()
		{
			InitializeComponent();

			SetStyle(ControlStyles.ResizeRedraw,true);
			SetStyle(ControlStyles.DoubleBuffer,true);
			SetStyle(ControlStyles.AllPaintingInWmPaint,true);
			SetStyle(ControlStyles.Selectable,false);
		}

		#endregion

		#region Dispose

		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#endregion

		#region Component Designer generated code
		private void InitializeComponent()
		{
			// 
			// EnterpriseLabel
			// 
			this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.Name = "Label";
			this.Size = new System.Drawing.Size(150, 19);
		}
		#endregion

		#region Overrides

		protected override void OnStyleChanged(object sender, StyleEventArgs args)
		{
			base.OnStyleChanged(sender, args);

			if (args.PropertyName == "TextColor") {this.TextColor = (Color)args.PropertyValue;}
			else if (args.PropertyName == "LabelColor") {this.LabelColor = (Color)args.PropertyValue;}

			this.Invalidate(true);
		}

		protected override void OnPlansOfColorsChanged(object sender, PlansOfColorsChangedEventArgs args)
		{
			base.OnPlansOfColorsChanged(sender, args);

			if (this.Style!=null)
			{
				this.TextColor = this.Style.TextColor;
				this.LabelColor = this.Style.LabelColor;
			}

			this.Invalidate(true);
		}

		protected override void OnPaint(PaintEventArgs e)
		{
			this.BackColor = this.LabelColor;

			StringFormat format  = new StringFormat();
			format.LineAlignment = StringAlignment.Center;

			if(m_TextAlignment == HorizontalAlignment.Left)
			{
				format.Alignment = StringAlignment.Near;
			}

			if(m_TextAlignment == HorizontalAlignment.Center)
			{
				format.Alignment = StringAlignment.Center;
			}

			if(m_TextAlignment == HorizontalAlignment.Right)
			{
				format.Alignment = StringAlignment.Far;
			}

			format.HotkeyPrefix  = HotkeyPrefix.Show;
			
			Rectangle txtRect = this.ClientRectangle;

			using (Brush brush1 = new SolidBrush(this.TextColor))
			{
				e.Graphics.DrawString(m_Text,this.Font,brush1,txtRect,format);
			}
		}

		protected override void OnMouseEnter(System.EventArgs e)
		{
			this.Invalidate(false);
		}

		protected override void OnMouseLeave(System.EventArgs e)
		{
			this.Invalidate(false);
		}

		protected override void OnGotFocus(System.EventArgs e)
		{
			this.Invalidate(false);
		}

		protected override void OnLostFocus(System.EventArgs e)
		{
			this.Invalidate(false);
		}

		#endregion

		#region Properties

		[Category("Appearance")]
		public HorizontalAlignment TextAlign
		{
			get{ return m_TextAlignment; }

			set{
				m_TextAlignment = value;
				this.Invalidate();
			}
		}

		[Browsable(true),
		DesignerSerializationVisibility(DesignerSerializationVisibility.Visible),
		Bindable(true)]
		public override string Text
		{
			get {return m_Text;}

			set
			{ 
				m_Text = value; 
				this.Invalidate();
			}
		}

		[Category("Style")]
		public Color TextColor
		{
			get {return m_TextColor;}
			set 
			{
				m_TextColor = value;
				this.ForeColor = value;
				this.Invalidate();
			}
		}

		[Category("Style")]
		public Color LabelColor
		{
			get {return m_LabelColor;}
			set 
			{
				m_LabelColor = value;
				this.BackColor = value;
				this.Invalidate();
			}
		}

		[Browsable(false)]
		public override Color BackColor
		{
			get {return m_LabelColor;}
			set 
			{
				m_LabelColor = value;
			}
		}

		[Browsable(false)]
		public override Color ForeColor
		{
			get {return m_TextColor;}
			set 
			{
				m_TextColor = value;
			}
		}

		#endregion
	}
}