using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;
using System.Security.Permissions;

namespace PallaControls.Windows.Forms
{
	[DefaultEvent("ShowStep")]
	[ToolboxItem(false)]
	public class BaseStep : System.Windows.Forms.UserControl
	{
		private static object stepTitleChanged = new object();
		private static object stepTitleTipChanged = new object();
		private static object backClicked = new object();
		private static object nextClicked = new object();
		private static object showStep = new object();
		private static object resetStep = new object();
		private static object validateStep = new object();
		private static object stylizingStep = new object();

		//A classe BaseWizard escreve neste campo que pode ser lido externamente
		//pela propriedade Style!!
		internal StyleGuide menterpriseStyle=null;

		public const string FinishStep = "FINISHED";

		private string title = "";
		private string titleTip = "";
		private BaseWizard wizard = null;
		private bool doneStyle = false;
		protected PallaControls.Windows.Forms.Panel panClientArea;

		private System.ComponentModel.Container components = null;
	
		#region Constructors

		public BaseStep()
		{
			InitializeComponent();
		}

		#endregion

		#region Dispose

		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#endregion

		#region Component Designer generated code
		private void InitializeComponent()
		{
			this.panClientArea = new PallaControls.Windows.Forms.Panel();
			this.SuspendLayout();
			// 
			// panClientArea
			// 
			this.panClientArea.BackColor = System.Drawing.Color.Empty;
			this.panClientArea.Dock = System.Windows.Forms.DockStyle.Fill;
			this.panClientArea.Name = "panClientArea";
			this.panClientArea.PanelAssBottomAreaColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(217)), ((System.Byte)(207)));
			this.panClientArea.PanelAssClientAreaColor = System.Drawing.Color.FromArgb(((System.Byte)(242)), ((System.Byte)(242)), ((System.Byte)(228)));
			this.panClientArea.PanelAssLeftOptionsColor = System.Drawing.Color.FromArgb(((System.Byte)(231)), ((System.Byte)(231)), ((System.Byte)(214)));
			this.panClientArea.PanelAssLeftTitleColor = System.Drawing.Color.FromArgb(((System.Byte)(232)), ((System.Byte)(237)), ((System.Byte)(223)));
			this.panClientArea.PanelAssRightTitleColor = System.Drawing.Color.FromArgb(((System.Byte)(242)), ((System.Byte)(242)), ((System.Byte)(228)));
			this.panClientArea.PanelBottomAreaColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(217)), ((System.Byte)(207)));
			this.panClientArea.PanelClientAreaColor = System.Drawing.Color.FromArgb(((System.Byte)(242)), ((System.Byte)(242)), ((System.Byte)(228)));
			this.panClientArea.PanelLeftOptionsColor = System.Drawing.Color.FromArgb(((System.Byte)(231)), ((System.Byte)(231)), ((System.Byte)(214)));
			this.panClientArea.PanelTopOptionsColor = System.Drawing.Color.FromArgb(((System.Byte)(170)), ((System.Byte)(170)), ((System.Byte)(221)));
			this.panClientArea.PanelType = PallaControls.Windows.Forms.PanelTypes.ClientArea;
			this.panClientArea.Size = new System.Drawing.Size(416, 232);
			this.panClientArea.Style = null;
			this.panClientArea.TabIndex = 0;
			// 
			// BaseStep
			// 
			this.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(242)), ((System.Byte)(242)), ((System.Byte)(228)));
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.panClientArea});
			this.Name = "BaseStep";
			this.Size = new System.Drawing.Size(416, 232);
			this.Load += new System.EventHandler(this.BaseStep_Load);
			this.ResumeLayout(false);

		}
		#endregion

		#region Events

		[Browsable(true)]
		[Category("Wizard Step")]
		public event EventHandler StepTitleChanged
		{
			add
			{
				Events.AddHandler(BaseStep.stepTitleChanged, value);
			}
			remove
			{
				Events.RemoveHandler(BaseStep.stepTitleChanged, value);
			}
		}

		protected virtual void OnStepTitleChanged(EventArgs e)
		{
			EventHandler handler = (EventHandler) Events[BaseStep.stepTitleChanged];

			if( handler != null )
			{
				handler(this, e);
			}
		}

		[Browsable(true)]
		[Category("Wizard Step")]
		public event EventHandler StepTitleTipChanged
		{
			add
			{
				Events.AddHandler(BaseStep.stepTitleTipChanged, value);
			}
			remove
			{
				Events.RemoveHandler(BaseStep.stepTitleTipChanged, value);
			}
		}

		protected virtual void OnStepTitleTipChanged(EventArgs e)
		{
			EventHandler handler = (EventHandler) Events[BaseStep.stepTitleTipChanged];

			if( handler != null )
			{
				handler(this, e);
			}
		}

		[Browsable(true)]
		[Category("Wizard Step")]
		public event EventHandler StepBackClicked
		{
			add
			{
				Events.AddHandler(BaseStep.backClicked, value);
			}
			remove
			{
				Events.RemoveHandler(BaseStep.backClicked, value);
			}
		}

		protected virtual void OnStepBackClicked(EventArgs e)
		{
			EventHandler handler = (EventHandler) Events[BaseStep.backClicked];

			if( handler != null )
			{
				handler(this, e);
			}
		}
		
		[Browsable(true)]
		[Category("Wizard Step")]
		public event EventHandler StepNextClicked
		{
			add
			{
				Events.AddHandler(BaseStep.nextClicked, value);
			}
			remove
			{
				Events.RemoveHandler(BaseStep.nextClicked, value);
			}
		}

		protected virtual void OnStepNextClicked(EventArgs e)
		{
			EventHandler handler = (EventHandler) Events[BaseStep.nextClicked];

			if( handler != null )
			{
				handler(this, e);
			}
		}
		
		[Browsable(true)]
		[Category("Wizard")]
		public event EventHandler ShowStep
		{
			add
			{
				Events.AddHandler(BaseStep.showStep, value);
			}
			remove
			{
				Events.RemoveHandler(BaseStep.showStep, value);
			}
		}

		protected virtual void OnShowStep(EventArgs e)
		{
			EventHandler handler = (EventHandler) Events[BaseStep.showStep];

			if( handler != null )
			{
				handler(this, e);
			}
		}

		[Browsable(true)]
		[Category("Wizard")]
		public event EventHandler ResetStep
		{
			add
			{
				Events.AddHandler(BaseStep.resetStep, value);
			}
			remove
			{
				Events.RemoveHandler(BaseStep.resetStep, value);
			}
		}

		protected virtual void OnResetStep(EventArgs e)
		{
			EventHandler handler = (EventHandler) Events[BaseStep.resetStep];

			if( handler != null )
			{
				handler(this, e);
			}
		}

		[Browsable(true)]
		[Category("Wizard Step")]
		public event System.ComponentModel.CancelEventHandler ValidateStep 
		{
			add
			{
				Events.AddHandler(BaseStep.validateStep, value);
			}
			remove
			{
				Events.RemoveHandler(BaseStep.validateStep, value);
			}
		}

		protected virtual void OnValidateStep(CancelEventArgs e)
		{
			System.ComponentModel.CancelEventHandler handler = (System.ComponentModel.CancelEventHandler) Events[BaseStep.validateStep];

			if( handler != null )
			{
				handler(this, e);
			}
		}

		[Browsable(true)]
		[Category("Wizard")]
		public event EventHandler StylizingStep
		{
			add
			{
				Events.AddHandler(BaseStep.stylizingStep, value);
			}
			remove
			{
				Events.RemoveHandler(BaseStep.stylizingStep, value);
			}
		}

		protected virtual void OnStylizingStep(EventArgs e)
		{
			EventHandler handler = (EventHandler) Events[BaseStep.stylizingStep];

			if( handler != null )
			{
				panClientArea.Style = this.wizard.Style;
				handler(this, e);
			}
		}

		#endregion

		#region Event Handlers

		private void Wizard_OnNextClicked(object o, EventArgs e)
		{
			OnNext();
		}

		private void Wizard_OnBackClicked(object o, EventArgs e)
		{
			OnBack();
		}

		private void Wizard_OnFinishClicked(object o, EventArgs e)
		{
			OnFinish();
		}
		
		private void BaseStep_Load(object sender, System.EventArgs e)
		{
			UIPermission uiP = new UIPermission(UIPermissionWindow.AllWindows);
			uiP.Demand();
		}
		
		#endregion

		#region Virtuals

		protected virtual void OnNext()
		{
			CancelEventArgs e = new CancelEventArgs();
			OnValidateStep(e);
	
			if( !e.Cancel )
			{
				this.FireNextClicked();

				if (Wizard != null)
					Wizard.MoveNext();
			}
		}

		protected virtual void OnBack()
		{
			this.FireBackClicked();

			if (Wizard != null)
				Wizard.MoveBack();
		}

		protected virtual void OnFinish()
		{
			Wizard.Close();
		}

		#endregion

		#region Internal Helpers

		internal void FireShowEvent()
		{
			OnShowStep(EventArgs.Empty);
			if (!this.doneStyle)
			{
				this.doneStyle = true;
				if (this.Style!=null)
					this.BackColor = this.Style.PanelClientAreaColor;
				OnStylizingStep(EventArgs.Empty);
			}
		}

		internal void FireResetStepEvent()
		{
			OnResetStep(EventArgs.Empty);
		}

		internal void FireBackClicked()
		{
			this.OnStepBackClicked(EventArgs.Empty);
		}

		internal void FireNextClicked()
		{
			this.OnStepNextClicked(EventArgs.Empty);
		}

		private void DetachWizard()
		{
			Wizard.NextClicked -= new EventHandler(Wizard_OnNextClicked);
			Wizard.BackClicked -= new EventHandler(Wizard_OnBackClicked);
			Wizard.FinishClicked -= new EventHandler(Wizard_OnFinishClicked);
		}

		private void AttachWizard()
		{
			Wizard.NextClicked += new EventHandler(Wizard_OnNextClicked);
			Wizard.BackClicked += new EventHandler(Wizard_OnBackClicked);
			Wizard.FinishClicked += new EventHandler(Wizard_OnFinishClicked);
		}

		#endregion

		#region Properties

		[Browsable(true)]
		[Localizable(true)]
		[Category("Wizard Step")]
		[DefaultValue("T�tulo do passo")]
		public string StepTitle
		{
			get
			{
				return title;
			}
			set
			{
				title = value;
				OnStepTitleChanged(EventArgs.Empty);
			}
		}

		[Browsable(true)]
		[Localizable(true)]
		[Category("Wizard Step")]
		[DefaultValue("Dica complementar do passo")]
		public string StepTitleTip
		{
			get
			{
				return titleTip;
			}
			set
			{
				titleTip = value;
				OnStepTitleTipChanged(EventArgs.Empty);
			}
		}

		[Browsable(false)]
		public BaseWizard Wizard
		{
			get
			{
				return wizard;
			}
			set
			{
				if( wizard != null )
				{
					DetachWizard();
				}

				wizard = value;

				if( value != null )
					AttachWizard();
			}
		}

		[Category("Style"),
		Browsable(false)]
		public StyleGuide Style
		{
			get {return menterpriseStyle;}
		}

		#endregion
	}
}
