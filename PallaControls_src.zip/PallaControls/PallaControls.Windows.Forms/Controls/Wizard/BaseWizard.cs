using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Security.Permissions;
using PallaControls.Windows.Forms.Helpers;
using PallaControls.Windows.Forms.Collections;
using PallaControls.Resources;
using PallaControls.Resources.Keys;

namespace PallaControls.Windows.Forms
{
	[DefaultEvent("LoadSteps")]
	public class BaseWizard : System.Windows.Forms.Form
	{
		private static object backClicked = new object();
		private static object nextClicked = new object();
		private static object finishClicked = new object();
		private static object loadSteps = new object();

		private StyleGuide m_enterpriseStyle;

		private BaseStep currentStep = null;
		private int currentIndex = 0;

		private string firstStep = "";
		private WizardStepCollection steps;
		private AllowClose allowClose = AllowClose.AlwaysAllow;
		private PallaControls.Windows.Forms.Panel bottomPanel;
		private PallaControls.Windows.Forms.Button next;
		private PallaControls.Windows.Forms.Button cancel;
		private System.Windows.Forms.Panel wizardTop;
		private System.Windows.Forms.Panel panelStep;
		private PallaControls.Windows.Forms.Button back;
		private System.Windows.Forms.PictureBox logo;
		private PallaControls.Windows.Forms.Panel leftPanel;
		private PallaControls.Windows.Forms.Panel clientPanel;
		private System.Windows.Forms.Panel panelTitles;
		private System.Windows.Forms.Label title;
		private System.Windows.Forms.Label titleTip;

		private System.ComponentModel.Container components = null;

		#region Constructors
		
		public BaseWizard()
		{
			InitializeComponent();

			steps = new WizardStepCollection();
			//Logo = GraphicsUtils.LoadImage("wizard.bmp");
			Logo = null;
		}

		#endregion

		#region Dispose
		
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#endregion

		#region Windows Form Designer generated code
		private void InitializeComponent()
		{
			this.leftPanel = new PallaControls.Windows.Forms.Panel();
			this.clientPanel = new PallaControls.Windows.Forms.Panel();
			this.bottomPanel = new PallaControls.Windows.Forms.Panel();
			this.wizardTop = new System.Windows.Forms.Panel();
			this.panelTitles = new System.Windows.Forms.Panel();
			this.titleTip = new System.Windows.Forms.Label();
			this.title = new System.Windows.Forms.Label();
			this.logo = new System.Windows.Forms.PictureBox();
			this.panelStep = new System.Windows.Forms.Panel();
			this.next = new PallaControls.Windows.Forms.Button();
			this.back = new PallaControls.Windows.Forms.Button();
			this.cancel = new PallaControls.Windows.Forms.Button();
			this.clientPanel.SuspendLayout();
			this.wizardTop.SuspendLayout();
			this.panelTitles.SuspendLayout();
			this.SuspendLayout();
			// 
			// leftPanel
			// 
			this.leftPanel.BackColor = System.Drawing.Color.Empty;
			this.leftPanel.Dock = System.Windows.Forms.DockStyle.Left;
			this.leftPanel.Name = "leftPanel";
			this.leftPanel.PanelAssBottomAreaColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(217)), ((System.Byte)(207)));
			this.leftPanel.PanelAssClientAreaColor = System.Drawing.Color.FromArgb(((System.Byte)(242)), ((System.Byte)(242)), ((System.Byte)(228)));
			this.leftPanel.PanelAssLeftOptionsColor = System.Drawing.Color.FromArgb(((System.Byte)(231)), ((System.Byte)(231)), ((System.Byte)(214)));
			this.leftPanel.PanelAssLeftTitleColor = System.Drawing.Color.FromArgb(((System.Byte)(232)), ((System.Byte)(237)), ((System.Byte)(223)));
			this.leftPanel.PanelAssRightTitleColor = System.Drawing.Color.FromArgb(((System.Byte)(242)), ((System.Byte)(242)), ((System.Byte)(228)));
			this.leftPanel.PanelBottomAreaColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(217)), ((System.Byte)(207)));
			this.leftPanel.PanelClientAreaColor = System.Drawing.Color.FromArgb(((System.Byte)(242)), ((System.Byte)(242)), ((System.Byte)(228)));
			this.leftPanel.PanelLeftOptionsColor = System.Drawing.Color.FromArgb(((System.Byte)(231)), ((System.Byte)(231)), ((System.Byte)(214)));
			this.leftPanel.PanelTopOptionsColor = System.Drawing.Color.FromArgb(((System.Byte)(170)), ((System.Byte)(170)), ((System.Byte)(221)));
			this.leftPanel.PanelType = PallaControls.Windows.Forms.PanelTypes.LeftOptions;
			this.leftPanel.Size = new System.Drawing.Size(64, 359);
			this.leftPanel.Style = null;
			this.leftPanel.TabIndex = 2;
			// 
			// clientPanel
			// 
			this.clientPanel.BackColor = System.Drawing.Color.Empty;
			this.clientPanel.Controls.AddRange(new System.Windows.Forms.Control[] {
																					  this.bottomPanel,
																					  this.wizardTop,
																					  this.panelStep,
																					  this.next,
																					  this.back,
																					  this.cancel});
			this.clientPanel.Dock = System.Windows.Forms.DockStyle.Fill;
			this.clientPanel.Location = new System.Drawing.Point(64, 0);
			this.clientPanel.Name = "clientPanel";
			this.clientPanel.PanelAssBottomAreaColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(217)), ((System.Byte)(207)));
			this.clientPanel.PanelAssClientAreaColor = System.Drawing.Color.FromArgb(((System.Byte)(242)), ((System.Byte)(242)), ((System.Byte)(228)));
			this.clientPanel.PanelAssLeftOptionsColor = System.Drawing.Color.FromArgb(((System.Byte)(231)), ((System.Byte)(231)), ((System.Byte)(214)));
			this.clientPanel.PanelAssLeftTitleColor = System.Drawing.Color.FromArgb(((System.Byte)(232)), ((System.Byte)(237)), ((System.Byte)(223)));
			this.clientPanel.PanelAssRightTitleColor = System.Drawing.Color.FromArgb(((System.Byte)(242)), ((System.Byte)(242)), ((System.Byte)(228)));
			this.clientPanel.PanelBottomAreaColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(217)), ((System.Byte)(207)));
			this.clientPanel.PanelClientAreaColor = System.Drawing.Color.FromArgb(((System.Byte)(242)), ((System.Byte)(242)), ((System.Byte)(228)));
			this.clientPanel.PanelLeftOptionsColor = System.Drawing.Color.FromArgb(((System.Byte)(231)), ((System.Byte)(231)), ((System.Byte)(214)));
			this.clientPanel.PanelTopOptionsColor = System.Drawing.Color.FromArgb(((System.Byte)(170)), ((System.Byte)(170)), ((System.Byte)(221)));
			this.clientPanel.PanelType = PallaControls.Windows.Forms.PanelTypes.ClientArea;
			this.clientPanel.Size = new System.Drawing.Size(474, 359);
			this.clientPanel.Style = null;
			this.clientPanel.TabIndex = 3;
			// 
			// bottomPanel
			// 
			this.bottomPanel.BackColor = System.Drawing.Color.Empty;
			this.bottomPanel.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.bottomPanel.Location = new System.Drawing.Point(0, 334);
			this.bottomPanel.Name = "bottomPanel";
			this.bottomPanel.PanelAssBottomAreaColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(217)), ((System.Byte)(207)));
			this.bottomPanel.PanelAssClientAreaColor = System.Drawing.Color.FromArgb(((System.Byte)(242)), ((System.Byte)(242)), ((System.Byte)(228)));
			this.bottomPanel.PanelAssLeftOptionsColor = System.Drawing.Color.FromArgb(((System.Byte)(231)), ((System.Byte)(231)), ((System.Byte)(214)));
			this.bottomPanel.PanelAssLeftTitleColor = System.Drawing.Color.FromArgb(((System.Byte)(232)), ((System.Byte)(237)), ((System.Byte)(223)));
			this.bottomPanel.PanelAssRightTitleColor = System.Drawing.Color.FromArgb(((System.Byte)(242)), ((System.Byte)(242)), ((System.Byte)(228)));
			this.bottomPanel.PanelBottomAreaColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(217)), ((System.Byte)(207)));
			this.bottomPanel.PanelClientAreaColor = System.Drawing.Color.FromArgb(((System.Byte)(242)), ((System.Byte)(242)), ((System.Byte)(228)));
			this.bottomPanel.PanelLeftOptionsColor = System.Drawing.Color.FromArgb(((System.Byte)(231)), ((System.Byte)(231)), ((System.Byte)(214)));
			this.bottomPanel.PanelTopOptionsColor = System.Drawing.Color.FromArgb(((System.Byte)(170)), ((System.Byte)(170)), ((System.Byte)(221)));
			this.bottomPanel.PanelType = PallaControls.Windows.Forms.PanelTypes.BottomArea;
			this.bottomPanel.Size = new System.Drawing.Size(474, 25);
			this.bottomPanel.Style = null;
			this.bottomPanel.TabIndex = 14;
			// 
			// wizardTop
			// 
			this.wizardTop.Controls.AddRange(new System.Windows.Forms.Control[] {
																					this.panelTitles,
																					this.logo});
			this.wizardTop.Dock = System.Windows.Forms.DockStyle.Top;
			this.wizardTop.Name = "wizardTop";
			this.wizardTop.Size = new System.Drawing.Size(474, 56);
			this.wizardTop.TabIndex = 7;
			// 
			// panelTitles
			// 
			this.panelTitles.BackColor = System.Drawing.Color.White;
			this.panelTitles.Controls.AddRange(new System.Windows.Forms.Control[] {
																					  this.titleTip,
																					  this.title});
			this.panelTitles.Dock = System.Windows.Forms.DockStyle.Fill;
			this.panelTitles.Name = "panelTitles";
			this.panelTitles.Size = new System.Drawing.Size(415, 56);
			this.panelTitles.TabIndex = 5;
			// 
			// titleTip
			// 
			this.titleTip.Anchor = ((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right);
			this.titleTip.BackColor = System.Drawing.Color.White;
			this.titleTip.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.titleTip.Location = new System.Drawing.Point(24, 24);
			this.titleTip.Name = "titleTip";
			this.titleTip.Size = new System.Drawing.Size(389, 28);
			this.titleTip.TabIndex = 17;
			this.titleTip.Text = " Dica do passo";
			// 
			// title
			// 
			this.title.BackColor = System.Drawing.Color.White;
			this.title.Dock = System.Windows.Forms.DockStyle.Top;
			this.title.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.title.Name = "title";
			this.title.Size = new System.Drawing.Size(415, 24);
			this.title.TabIndex = 16;
			this.title.Text = "T�tulo do passo";
			this.title.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// logo
			// 
			this.logo.BackColor = System.Drawing.Color.White;
			this.logo.Dock = System.Windows.Forms.DockStyle.Right;
			this.logo.Location = new System.Drawing.Point(415, 0);
			this.logo.Name = "logo";
			this.logo.Size = new System.Drawing.Size(59, 56);
			this.logo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
			this.logo.TabIndex = 4;
			this.logo.TabStop = false;
			// 
			// panelStep
			// 
			this.panelStep.Anchor = (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right);
			this.panelStep.Location = new System.Drawing.Point(8, 64);
			this.panelStep.Name = "panelStep";
			this.panelStep.Size = new System.Drawing.Size(456, 208);
			this.panelStep.TabIndex = 13;
			// 
			// next
			// 
			this.next.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right);
			this.next.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(242)), ((System.Byte)(242)), ((System.Byte)(228)));
			this.next.BorderColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(217)), ((System.Byte)(207)));
			this.next.BorderHotColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(217)), ((System.Byte)(207)));
			this.next.ButtonColor = System.Drawing.Color.FromArgb(((System.Byte)(242)), ((System.Byte)(242)), ((System.Byte)(228)));
			this.next.ButtonHotColor = System.Drawing.Color.FromArgb(((System.Byte)(231)), ((System.Byte)(231)), ((System.Byte)(214)));
			this.next.ButtonPressedColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(217)), ((System.Byte)(207)));
			this.next.FlashColor = System.Drawing.Color.FromArgb(((System.Byte)(170)), ((System.Byte)(170)), ((System.Byte)(221)));
			this.next.ForeColor = System.Drawing.Color.Black;
			this.next.Location = new System.Drawing.Point(397, 295);
			this.next.Name = "next";
			this.next.Radius = 7F;
			this.next.Size = new System.Drawing.Size(55, 22);
			this.next.Style = null;
			this.next.TabIndex = 12;
			this.next.Text = "&Pr�ximo";
			this.next.TextColor = System.Drawing.Color.Black;
			this.next.ButtonPressed += new PallaControls.Windows.Forms.ButtonPressedEventHandler(this.next_Click);
			// 
			// back
			// 
			this.back.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right);
			this.back.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(242)), ((System.Byte)(242)), ((System.Byte)(228)));
			this.back.BorderColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(217)), ((System.Byte)(207)));
			this.back.BorderHotColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(217)), ((System.Byte)(207)));
			this.back.ButtonColor = System.Drawing.Color.FromArgb(((System.Byte)(242)), ((System.Byte)(242)), ((System.Byte)(228)));
			this.back.ButtonHotColor = System.Drawing.Color.FromArgb(((System.Byte)(231)), ((System.Byte)(231)), ((System.Byte)(214)));
			this.back.ButtonPressedColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(217)), ((System.Byte)(207)));
			this.back.FlashColor = System.Drawing.Color.FromArgb(((System.Byte)(170)), ((System.Byte)(170)), ((System.Byte)(221)));
			this.back.ForeColor = System.Drawing.Color.Black;
			this.back.Location = new System.Drawing.Point(338, 295);
			this.back.Name = "back";
			this.back.Radius = 7F;
			this.back.Size = new System.Drawing.Size(55, 22);
			this.back.Style = null;
			this.back.TabIndex = 11;
			this.back.Text = "&Voltar";
			this.back.TextColor = System.Drawing.Color.Black;
			this.back.ButtonPressed += new PallaControls.Windows.Forms.ButtonPressedEventHandler(this.back_Click);
			// 
			// cancel
			// 
			this.cancel.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right);
			this.cancel.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(242)), ((System.Byte)(242)), ((System.Byte)(228)));
			this.cancel.BorderColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(217)), ((System.Byte)(207)));
			this.cancel.BorderHotColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(217)), ((System.Byte)(207)));
			this.cancel.ButtonColor = System.Drawing.Color.FromArgb(((System.Byte)(242)), ((System.Byte)(242)), ((System.Byte)(228)));
			this.cancel.ButtonHotColor = System.Drawing.Color.FromArgb(((System.Byte)(231)), ((System.Byte)(231)), ((System.Byte)(214)));
			this.cancel.ButtonPressedColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(217)), ((System.Byte)(207)));
			this.cancel.FlashColor = System.Drawing.Color.FromArgb(((System.Byte)(170)), ((System.Byte)(170)), ((System.Byte)(221)));
			this.cancel.ForeColor = System.Drawing.Color.Black;
			this.cancel.Location = new System.Drawing.Point(275, 295);
			this.cancel.Name = "cancel";
			this.cancel.Radius = 7F;
			this.cancel.Size = new System.Drawing.Size(55, 22);
			this.cancel.Style = null;
			this.cancel.TabIndex = 10;
			this.cancel.Text = "&Cancelar";
			this.cancel.TextColor = System.Drawing.Color.Black;
			this.cancel.ButtonPressed += new PallaControls.Windows.Forms.ButtonPressedEventHandler(this.cancel_Click);
			// 
			// BaseWizard
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(538, 359);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.clientPanel,
																		  this.leftPanel});
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.MinimumSize = new System.Drawing.Size(304, 232);
			this.Name = "BaseWizard";
			this.Text = "T�tulo do assistente";
			this.Load += new System.EventHandler(this.BaseWizard_Load);
			this.clientPanel.ResumeLayout(false);
			this.wizardTop.ResumeLayout(false);
			this.panelTitles.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		#region Public Methods

		public void MoveNext()
		{
			if( currentStep != null )
			{
				if (this.currentIndex < this.Steps.Count-1)
					this.currentIndex++;

				SetCurrentStep(this.Steps[this.currentIndex].Name);
			}
		}

		public void MoveBack()
		{
			if( currentStep != null )
			{
				if (this.currentIndex > 0)
					this.currentIndex--;

				SetCurrentStep(this.Steps[this.currentIndex].Name);
			}
		}

		public void MoveTo(string step)
		{
			SetCurrentStep(step);
		}

		public void MoveTo(int step)
		{
			if((step < this.Steps.Count) && (step >= 0))
				SetCurrentStep(this.steps[step].Name);
		}

		public void AddStep(BaseStep step, StyleGuide style)
		{
			step.menterpriseStyle = style;
			Steps.Add(step);
		}

		public void AddStepAfter(string nameExistStep, BaseStep step, StyleGuide style)
		{
			WizardStepCollection localSteps = new WizardStepCollection();
			this.Steps.CopyTo(localSteps, 0);
			this.steps.Clear();

			if (nameExistStep.Length != 0)
			{
				foreach(BaseStep keyStep in localSteps)
				{
					if (keyStep.Name == nameExistStep)
					{
						this.AddStep(keyStep, style);
						this.AddStep(step, style);
					}
					else
					{
						this.AddStep(keyStep, style);
					}
				}
			}
			else
				this.AddStep(step, style);
		}
		
		public void AddStepBefore(string nameExistStep, BaseStep step, StyleGuide style)
		{
			WizardStepCollection localSteps = new WizardStepCollection();
			this.Steps.CopyTo(localSteps, 0);
			this.steps.Clear();

			if (nameExistStep.Length != 0)
			{
				foreach(BaseStep keyStep in localSteps)
				{
					if (keyStep.Name == nameExistStep)
					{
						this.AddStep(step, style);
						this.AddStep(keyStep, style);
					}
					else
					{
						this.AddStep(keyStep, style);
					}
				}
			}
			else
				this.AddStep(step, style);
		}

		public BaseStep GetStep(string name)
		{
			return Steps[name];
		}

		public BaseStep RemoveStep(string name)
		{
			BaseStep step = Steps[name];

			if( step != null )
			{
				Steps.Remove(name);
			}

			return step;
		}

		public void SetCurrentStep(string name)
		{
			if( name == null || name == "" )
			{
				throw new ArgumentException(ResourceLibrary.GetString(CommonResourceKeys.NullArgument, CommonResourceKeys.Root));
			}

			BaseStep bws = steps[name];

			if( bws == null )
			{
				throw new ArgumentException(ResourceLibrary.GetString(WindowsControlsResourceKeys.StepNotFound, WindowsControlsResourceKeys.Root));
			}

			SetCurrentStep(bws);
		}

		protected void SetCurrentStep(BaseStep step)
		{
			SuspendLayout();

			if( currentStep != null )
			{
				DetatchStep();
			}

			currentStep = step;
			currentIndex = this.Steps.IndexOf(step);
			
			AttachStep();

			ResumeLayout(true);
		}

		private void DetatchStep()
		{
			currentStep.StepTitleChanged -= new EventHandler(OnStepTitleChanged);
			currentStep.StepTitleTipChanged -= new EventHandler(OnStepTitleTipChanged);

			panelStep.Controls.Remove(currentStep);
			
			currentStep.Wizard = null;
		}

		private void AttachStep()
		{
			currentStep.Wizard = this;

			currentStep.StepTitleChanged += new EventHandler(OnStepTitleChanged);
			currentStep.StepTitleTipChanged += new EventHandler(OnStepTitleTipChanged);
			
			OnStepTitleChanged(null, EventArgs.Empty);
			OnStepTitleTipChanged(null, EventArgs.Empty);

			panelStep.Controls.Add(currentStep);

			OnPreviousStepChanged(null, EventArgs.Empty);
			OnNextStepChanged(null, EventArgs.Empty);

			currentStep.FireShowEvent();
		}

		#endregion

		#region Internal helpers

		private void SetStyleControls()
		{
			leftPanel.Style = this.m_enterpriseStyle;
			clientPanel.Style = this.m_enterpriseStyle;
			bottomPanel.Style = this.m_enterpriseStyle;
			cancel.Style = this.m_enterpriseStyle;
			back.Style = this.m_enterpriseStyle;
			next.Style = this.m_enterpriseStyle;
		}

		#endregion

		#region Protected properties
		
		[Browsable(false)]
		protected WizardStepCollection Steps
		{
			get
			{
				return steps;
			}
		}

		[Browsable(false)]
		protected bool IsFinish
		{
			get
			{
				//return currentStep.NextStep == BaseStep.FinishStep;
				return this.currentIndex == this.Steps.Count-1;
			}
		}

		#endregion

		#region Event Handlers

		private void OnStepTitleChanged(object o, EventArgs e)
		{
			Title = currentStep.StepTitle;
		}

		private void OnStepTitleTipChanged(object o, EventArgs e)
		{
			TitleTip = currentStep.StepTitleTip;
		}

		private void OnStepBackClicked(object o, EventArgs e)
		{
			this.currentStep.FireBackClicked();
		}

		private void OnStepNextClicked(object o, EventArgs e)
		{
			this.currentStep.FireNextClicked();
		}

		private void back_Click(object sender, System.EventArgs e)
		{
			OnBackClicked(EventArgs.Empty);
		}

		private void next_Click(object sender, System.EventArgs e)
		{
			if( !IsFinish )
			{
				OnNextClicked(EventArgs.Empty);
			}
			else
			{
				OnFinishClicked(EventArgs.Empty);
			}
		}

		private void cancel_Click(object sender, System.EventArgs e)
		{
			DialogResult = DialogResult.Cancel;

			if( !Modal )
			{
				Close();
			}
		}

		protected override void OnLoad(System.EventArgs e)
		{
			base.OnLoad(e);

			if( !DesignMode )
			{
				OnLoadSteps(EventArgs.Empty);
			
				if( FirstStepName == "" )
					throw new InvalidOperationException(ResourceLibrary.GetString(WindowsControlsResourceKeys.FirstStepCannotBeNull, WindowsControlsResourceKeys.Root));

				//ResetSteps();

				SetCurrentStep(FirstStepName);
			}
		}

		protected override void OnClosing(System.ComponentModel.CancelEventArgs e)
		{
			switch( AllowClose )
			{
			case AllowClose.AskIfNotFinish:
				if( !IsFinish )
					e.Cancel = !AskToClose();
				break;
			case AllowClose.Ask:
				e.Cancel = !AskToClose();
				break;
			}
		}

		private bool AskToClose()
		{
			DialogResult r = PallaControls.Windows.Forms.MessageBox.Show(
                             ResourceLibrary.GetString(WindowsControlsResourceKeys.MessageToLeaveAssistant, WindowsControlsResourceKeys.Root), 
							 ResourceLibrary.GetString(WindowsControlsResourceKeys.CloseWizard, WindowsControlsResourceKeys.Root), MessageBoxButtons.YesNo, MessageBoxIcon.Question, this.Style);

			if(r == DialogResult.Yes)
				return true;
			else
				return false;
		}

		private void OnPreviousStepChanged(object sender, EventArgs e)
		{
			/*if( currentStep.PreviousStep == "" )
			{
				BackEnabled = false;
			}
			else
			{
				BackEnabled = true;
			}*/

			if(currentIndex == 0)
			{
				BackEnabled = false;
			}
			else
			{
				BackEnabled = true;
			}
		}

		private void OnNextStepChanged(object sender, EventArgs e)
		{
			/*if( currentStep.NextStep == "" )
			{
				SetFinish(false);
				NextEnabled = false;
			}
			else if( currentStep.NextStep == BaseStep.FinishStep )
			{
				NextEnabled = true;
				SetFinish(true);
			}
			else
			{
				NextEnabled = true;
				SetFinish(false);
			}*/

			if( currentIndex < 0)
			{
				SetFinish(false);
				NextEnabled = false;
			}
			else if(currentIndex == this.Steps.Count-1)
			{
				NextEnabled = true;
				SetFinish(true);
			}
			else if(currentIndex > 0)
			{
				NextEnabled = true;
				SetFinish(false);
			}
			else if(currentIndex == 0)
			{
				NextEnabled = true;
				this.BackEnabled = false;
				SetFinish(false);
			}
		}

		#endregion

		#region Events

		[Browsable(false)]
		internal event EventHandler BackClicked
		{
			add
			{
				Events.AddHandler(BaseWizard.backClicked, value);
			}
			remove
			{
				Events.RemoveHandler(BaseWizard.backClicked, value);
			}
		}

		protected virtual void OnBackClicked(EventArgs e)
		{
			EventHandler handler = (EventHandler) Events[BaseWizard.backClicked];

			if( handler != null )
			{
				handler(this, e);
			}
		}

		[Browsable(false)]
		internal event EventHandler NextClicked
		{
			add
			{
				Events.AddHandler(BaseWizard.nextClicked, value);
			}
			remove
			{
				Events.RemoveHandler(BaseWizard.nextClicked, value);
			}
		}

		protected virtual void OnNextClicked(EventArgs e)
		{
			EventHandler handler = (EventHandler)Events[BaseWizard.nextClicked];

			if( handler != null )
			{
				handler(this, e);
			}
		}

		[Browsable(false)]
		internal event EventHandler FinishClicked
		{
			add
			{
				Events.AddHandler(BaseWizard.finishClicked, value);
			}
			remove
			{
				Events.RemoveHandler(BaseWizard.finishClicked, value);
			}
		}

		protected virtual void OnFinishClicked(EventArgs e)
		{
			EventHandler handler = (EventHandler) Events[BaseWizard.finishClicked];

			if( handler != null )
			{
				handler(this, e);
			}
		}

		[Browsable(true)]
		[Category("Wizard")]
		public event EventHandler LoadSteps
		{
			add
			{
				Events.AddHandler(BaseWizard.loadSteps, value);
			}
			remove
			{
				Events.RemoveHandler(BaseWizard.loadSteps, value);
			}
		}

		protected virtual void OnLoadSteps(EventArgs e)
		{
			EventHandler handler = (EventHandler) Events[BaseWizard.loadSteps];

			if( handler != null )
			{
				handler(this, e);
			}
		}

		#endregion

		#region Virtuals
		
		protected void SetFinish( bool finish )
		{
			if( finish )
			{
				next.Text = ResourceLibrary.GetString(WindowsControlsResourceKeys.Finish, WindowsControlsResourceKeys.Root);
			}
			else
			{
				next.Text = ResourceLibrary.GetString(WindowsControlsResourceKeys.Next, WindowsControlsResourceKeys.Root);
			}
		}

		private void BaseWizard_Load(object sender, System.EventArgs e)
		{
			UIPermission uiP = new UIPermission(UIPermissionWindow.AllWindows);
			uiP.Demand();
		}
			
		#endregion	

		#region Properties
		
		[Browsable(true)]
		[Category("Wizard")]
		[DefaultValue("Step Title")]
		public string Title
		{
			get
			{
				return title.Text;
			}
			set
			{
				title.Text = "    " + value;
			}
		}

		[Browsable(true)]
		[Category("Wizard")]
		[DefaultValue("Step Title")]
		public string TitleTip
		{
			get
			{
				return titleTip.Text;
			}
			set
			{
				titleTip.Text = value;
			}
		}

		[Browsable(true)]
		[Category("Wizard")]
		public Image Logo
		{
			get
			{
				return logo.Image;
			}
			set
			{
				logo.Image = value;
			}
		}

		[Browsable(true)]
		[Category("Wizard")]
		[DefaultValue(true)]
		public bool BackEnabled
		{
			get
			{
				return back.Enabled;
			}
			set
			{
				back.Enabled = value;
			}
		}

		[Browsable(true)]
		[Category("Wizard")]
		[DefaultValue(true)]
		public bool NextEnabled
		{
			get
			{
				return next.Enabled;
			}
			set
			{
				next.Enabled = value;
			}
		}

		[Browsable(true)]
		[Category("Wizard")]
		[DefaultValue("")]
		public virtual string FirstStepName
		{
			get
			{
				return firstStep;
			}
			set
			{
				if( value == null )
				{
					value = "";
				}

				firstStep = value;
			}
		}

		[Browsable(true)]
		[Category("Wizard")]
		[DefaultValue(AllowClose.AlwaysAllow)]
		public AllowClose AllowClose
		{
			get
			{
				return allowClose;
			}
			set
			{
				allowClose = value;
			}
		}

		[Category("Style")]
		public StyleGuide Style
		{
			get {return m_enterpriseStyle;}
			set 
			{
				m_enterpriseStyle = value;
				this.SetStyleControls();
			}
		}

		#endregion
	}
}