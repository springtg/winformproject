using System;
using System.Collections;
using System.Threading;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Design;
using System.Windows.Forms;

namespace PallaControls.Windows.Forms
{
	[System.ComponentModel.ToolboxItem(true)]
	public class ListBox : PallaControls.Windows.Forms.ControlBase, IFlashabledControl
	{
		private PallaControls.Windows.Forms.ListBoxBase mListBox;
		private System.ComponentModel.IContainer components = null;
		//Style Neo, default!!
		private Color m_TextColor = Color.Black;
		private Color m_EditDisabledColor = Color.FromArgb(238, 238, 225);
		private Color m_EditReadOnlyColor = Color.FromArgb(238, 238, 225);
		private Color m_EditFocusedColor = Color.White;
		private Color m_EditColor = Color.FromArgb(242, 242, 228);
		private Color m_FlashColor = Color.FromArgb(170, 170, 221);

		[Category("Property Changed")]
		public event EventHandler SelectedValueChanged;

		[Category("Behavior")]
		public event EventHandler SelectedIndexChanged;

		[Category("Property Changed")]
		public event EventHandler ValueMemberChanged;

		[Category("Property Changed")]
		public event EventHandler DataSourceChanged;

		[Category("Property Changed")]
		public event EventHandler DisplayMemberChanged;

		#region Constructors

		public ListBox()
		{
			InitializeComponent();
			mListBox.LostFocus  += new System.EventHandler(this.mListBox_OnLostFocus);
			mListBox.GotFocus   += new System.EventHandler(this.mListBox_OnGotFocus);
		}

		#endregion

		#region Dispose

		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				mListBox.LostFocus  -= new System.EventHandler(this.mListBox_OnLostFocus);
				mListBox.GotFocus   -= new System.EventHandler(this.mListBox_OnGotFocus);

				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#endregion

		#region Designer generated code
		private void InitializeComponent()
		{
			this.mListBox = new PallaControls.Windows.Forms.ListBoxBase();
			this.SuspendLayout();
			// 
			// mListBox
			// 
			this.mListBox.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(242)), ((System.Byte)(242)), ((System.Byte)(228)));
			this.mListBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.mListBox.Dock = System.Windows.Forms.DockStyle.Fill;
			this.mListBox.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
			this.mListBox.Location = new System.Drawing.Point(1, 1);
			this.mListBox.Name = "mListBox";
			this.mListBox.SelectionColor = System.Drawing.Color.FromArgb(((System.Byte)(187)), ((System.Byte)(194)), ((System.Byte)(214)));
			this.mListBox.Size = new System.Drawing.Size(148, 195);
			this.mListBox.TabIndex = 0;
			this.mListBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.mListBox_KeyDown);
			this.mListBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.mListBox_KeyPress);
			this.mListBox.DataSourceChanged += new System.EventHandler(this.mListBox_DataSourceChanged);
			this.mListBox.KeyUp += new System.Windows.Forms.KeyEventHandler(this.mListBox_KeyUp);
			this.mListBox.SelectedValueChanged += new System.EventHandler(this.mListBox_SelectedValueChanged);
			this.mListBox.DisplayMemberChanged += new System.EventHandler(this.mListBox_DisplayMemberChanged);
			this.mListBox.SelectedIndexChanged += new System.EventHandler(this.mListBox_SelectedIndexChanged);
			this.mListBox.ValueMemberChanged += new System.EventHandler(this.mListBox_ValueMemberChanged);
			// 
			// ListBox
			// 
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.mListBox});
			this.DockPadding.All = 1;
			this.Name = "ListBox";
			this.Size = new System.Drawing.Size(150, 200);
			this.ResumeLayout(false);

		}
		#endregion

		#region Events handlers
				
		private void mListBox_OnGotFocus(object sender, System.EventArgs e)
		{
			this.BackColor = this.EditFocusedColor;			
		}

		private void mListBox_OnLostFocus(object sender, System.EventArgs e)
		{
			this.BackColor = this.Style!=null? 
				this.Style.InteliEditColor(false,this.Enabled):
				StyleGuide.InteliEditColor(false,this.Enabled,this.m_EditColor, 
				this.m_EditReadOnlyColor, this.m_EditDisabledColor);
			//
			DrawControl(this.ContainsFocus);
		}

		private void mListBox_SelectedValueChanged(object sender, System.EventArgs e)
		{
			if (SelectedValueChanged != null)
				SelectedValueChanged(sender,e);
		}

		private void mListBox_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			if (SelectedIndexChanged != null)
				SelectedIndexChanged(sender,e);
		}

		private void mListBox_ValueMemberChanged(object sender, System.EventArgs e)
		{
			if (ValueMemberChanged != null)
				ValueMemberChanged(sender,e);
		}

		private void mListBox_DataSourceChanged(object sender, System.EventArgs e)
		{
			if (DataSourceChanged != null)
				DataSourceChanged(sender,e);
		}
	
		private void mListBox_DisplayMemberChanged(object sender, System.EventArgs e)
		{
			if (DisplayMemberChanged != null)
				DisplayMemberChanged(sender,e);
		}

		private void mListBox_KeyDown(object sender, System.Windows.Forms.KeyEventArgs e)
		{
			this.OnKeyDown(e);
		}

		private void mListBox_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
		{
			this.OnKeyPress(e);
		}

		private void mListBox_KeyUp(object sender, System.Windows.Forms.KeyEventArgs e)
		{
			this.OnKeyUp(e);
		}

		#endregion

		#region Overrides

		protected override void OnStyleChanged(object sender, StyleEventArgs args)
		{
			base.OnStyleChanged(sender, args);

			if (args.PropertyName == "FlashColor") {this.FlashColor = (Color)args.PropertyValue;}
			else if (args.PropertyName == "TextColor") {this.TextColor = (Color)args.PropertyValue;}
			else if (args.PropertyName == "EditColor") {this.EditColor = (Color)args.PropertyValue;}
			else if (args.PropertyName == "EditFocusedColor") {this.EditFocusedColor = (Color)args.PropertyValue;}
			else if (args.PropertyName == "EditReadOnlyColor") {this.EditReadOnlyColor = (Color)args.PropertyValue;}
			else if (args.PropertyName == "EditDisabledColor") {this.EditDisabledColor = (Color)args.PropertyValue;}

			this.BackColor = this.Style!=null? 
				this.Style.InteliEditColor(false,this.Enabled):
				StyleGuide.InteliEditColor(false,this.Enabled,this.m_EditColor, 
				this.m_EditReadOnlyColor, this.m_EditDisabledColor);

			this.Invalidate(true);
		}

		protected override void OnPlansOfColorsChanged(object sender, PlansOfColorsChangedEventArgs args)
		{
			base.OnPlansOfColorsChanged(sender, args);

			if (this.Style!=null)
			{
				this.FlashColor = this.Style.FlashColor;
				this.EditColor = this.Style.EditColor;
				this.EditFocusedColor = this.Style.EditFocusedColor;
				this.EditReadOnlyColor = this.Style.EditReadOnlyColor;
				this.EditDisabledColor = this.Style.EditDisabledColor;
				this.TextColor = this.Style.TextColor;
				this.mListBox.SelectionColor = StyleGuide.InteliSelectionColor(args.NewPlan);

				this.BackColor = this.Style!=null? 
					this.Style.InteliEditColor(false,this.Enabled):
					StyleGuide.InteliEditColor(false,this.Enabled,this.m_EditColor, 
					this.m_EditReadOnlyColor, this.m_EditDisabledColor);
			}

			this.Invalidate(true);
		}

		protected override void OnEnabledChanged(EventArgs e)
		{
			base.OnEnabledChanged(e);
			this.BackColor = this.Style!=null? 
				this.Style.InteliEditColor(false,this.Enabled):
				StyleGuide.InteliEditColor(false,this.Enabled,this.m_EditColor, 
				this.m_EditReadOnlyColor, this.m_EditDisabledColor);
		}

		#endregion

		#region Internal helpers

		private void ThreadFlashControl()
		{
			for (int i=1; i<=8;i++)
			{
				if(this.mListBox.BackColor == this.EditColor)
				{
					this.mListBox.BackColor = this.FlashColor;
				}
				else
				{
					this.mListBox.BackColor = this.EditColor;
				}
				Thread.Sleep(150);
			}

			this.mListBox.BackColor = this.EditColor;
		}

		#endregion

		#region Methods
		
		public int FindString(string s, int startIndex)
		{
			return mListBox.FindString(s,startIndex);
		}
		
		public int FindString(string s)
		{
			return mListBox.FindString(s);
		}

		public int FindStringExact(string s, int startIndex)
		{
			return mListBox.FindStringExact(s,startIndex);
		}
		
		public int FindStringExact(string s)
		{
			return mListBox.FindStringExact(s);
		}

		public bool GetSelected(int index)
		{
			return mListBox.GetSelected(index);
		}

		public void ClearSelected()
		{
			mListBox.ClearSelected();
		}

		public void SetSelected(int index, bool value)
		{
			mListBox.SetSelected(index, value);
		}

		public void PostMessage(Message m)
		{
			base.WndProc(ref m);
		}
		
		#endregion

		#region Properties
		
		public System.Windows.Forms.ListBox InternalListBox
		{
			get {return mListBox;}
		}

		[Browsable(false),
		DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		public new Color BackColor
		{
			get{ return base.BackColor; }

			set
			{
				base.BackColor      = value;
				if (mListBox!=null) mListBox.BackColor = value;
			}
		}

		[Browsable(false)]
		public override Color ForeColor
		{
			get{ return base.ForeColor; }

			set
			{
				base.ForeColor      = value;
				mListBox.ForeColor = value;
			}
		}

		[Category("Style")]
		public Color TextColor
		{
			get {return m_TextColor;}
			set 
			{
				m_TextColor = value;
				this.mListBox.ForeColor = value;
				this.Invalidate();
			}
		}

		[Category("Style")]
		public Color FlashColor
		{
			get {return m_FlashColor;}
			set 
			{
				m_FlashColor = value;
				this.Invalidate();
			}
		}

		[Category("Style")]
		public Color EditColor
		{
			get {return m_EditColor;}
			set 
			{
				m_EditColor = value;
				this.mListBox.BackColor = value;
				this.Invalidate();
			}
		}

		[Category("Style")]
		public Color EditFocusedColor
		{
			get {return m_EditFocusedColor;}
			set 
			{
				m_EditFocusedColor = value;
				this.Invalidate();
			}
		}

		[Category("Style")]
		public Color EditReadOnlyColor
		{
			get {return m_EditReadOnlyColor;}
			set 
			{
				m_EditReadOnlyColor = value;
				this.Invalidate();
			}
		}

		[Category("Style")]
		public Color EditDisabledColor
		{
			get {return m_EditDisabledColor;}
			set 
			{
				m_EditDisabledColor = value;
				this.Invalidate();
			}
		}

		[Category("Data"),
		Editor("System.Windows.Forms.Design.StringCollectionEditor,System.Design", 
               "System.Drawing.Design.UITypeEditor,System.Drawing"),
		DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
		public System.Windows.Forms.ListBox.ObjectCollection Items
		{
			get {return mListBox.Items;}
			//set{ mListBox.Items.AddRange(value); }
		}

		[Category("Behavior")]
		public int ColumnWidth
		{
			get{ return mListBox.ColumnWidth; }
			set{ mListBox.ColumnWidth = value; }
		}

		[Category("Behavior")]
		public bool MultiColumn
		{
			get{ return mListBox.MultiColumn; }
			set{ mListBox.MultiColumn = value; }
		}

		[Category("Behavior")]
		public System.Windows.Forms.SelectionMode SelectionMode
		{
			get{ return mListBox.SelectionMode; }
			set{ mListBox.SelectionMode = value; }
		}

		[Category("Behavior")]
		public bool Sorted
		{
			get{ return mListBox.Sorted; }
			set{ mListBox.Sorted = value; }
		}

		[Category("Data"), 
		Browsable(true),
		DefaultValue(null),
		RefreshProperties(RefreshProperties.Repaint),
		TypeConverter("System.Windows.Forms.Design.DataSourceConverter, System.Design")]
		public object DataSource
		{
			get{ return mListBox.DataSource; }
			set{ mListBox.DataSource = value; }
		}
			
		[Category("Data"),
		Browsable(true),
		DefaultValue("")]
		public string DisplayMember
		{
			get{ return mListBox.DisplayMember; }
			set{ mListBox.DisplayMember = value; }
		}

		[Category("Data"),
		Browsable(true)]
		public string ValueMember
		{
			get{ return mListBox.ValueMember; }
			set{ mListBox.ValueMember = value; }
		}

		[Bindable(true),
		Browsable(false)]
		public int SelectedIndex
		{
			get{ return mListBox.SelectedIndex; }
			set{ mListBox.SelectedIndex = value; }
		}

		[Bindable(true),
		Browsable(false)]
		public object SelectedItem
		{
			get{ return mListBox.SelectedItem; }
			set{ mListBox.SelectedItem = value; }
		}

		[Bindable(true),
		Browsable(false)]
		public object SelectedValue
		{
			get{ return mListBox.SelectedValue; }
			set{ mListBox.SelectedValue = value; }
		}

		[Browsable(false)]
		public System.Windows.Forms.ListBox.SelectedIndexCollection SelectedIndices
		{
			get
			{
				return mListBox.SelectedIndices;
			}
		}

		[Browsable(false)]
		public System.Windows.Forms.ListBox.SelectedObjectCollection SelectedItems
		{
			get
			{
				return mListBox.SelectedItems;
			}
		}

		public override string Text 
		{
			get
			{
				return mListBox.Text;
			} 
			set
			{
				mListBox.Text = value;
			}
		}

		[Browsable(false)]
		public int TopIndex
		{
			get{ return mListBox.TopIndex; }
			set{ mListBox.TopIndex = value; }
		}

		#endregion

		#region IFlashabledControl

		public void FlashControl()
		{
			Thread m_Thread = new Thread(new ThreadStart(ThreadFlashControl));
			m_Thread.Start();
		}
		
		#endregion
	}
}


