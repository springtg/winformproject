using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;
using PallaControls.Utilities.Win32;

namespace PallaControls.Windows.Forms
{
	[ToolboxItem(false)]
	public class PanelBase : System.Windows.Forms.Panel, IHasStyleControl
	{
		protected bool Initing = false;

		private System.ComponentModel.Container components = null;
		private StyleGuide m_enterpriseStyle = null;
		private bool parentStyle = false;

		#region Contructors
		
		public PanelBase()
		{
			InitializeComponent();

			SetStyle(ControlStyles.ResizeRedraw,true);
			SetStyle(ControlStyles.DoubleBuffer  | ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint,true);
		}

		#endregion

		#region Dispose

		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#endregion

		#region Component Designer generated code
		private void InitializeComponent()
		{
			components = new System.ComponentModel.Container();
		}
		#endregion

		#region Overrides

		protected override void OnPaint(System.Windows.Forms.PaintEventArgs e)
		{
			base.OnPaint(e);
		}

		protected override void OnMouseEnter(System.EventArgs e)
		{
			base.OnMouseEnter(e);
		}

		protected override void OnMouseLeave(System.EventArgs e)
		{
			base.OnMouseLeave(e);
		}

		protected override void OnGotFocus(System.EventArgs e)
		{
			base.OnLostFocus(e);
		}

		protected override void OnLostFocus(System.EventArgs e)
		{
			base.OnLostFocus(e);
		}

		protected override void OnControlAdded(ControlEventArgs e)
		{
			base.OnControlAdded(e);
		}

		protected override void OnControlRemoved(ControlEventArgs e)
		{
			base.OnControlRemoved(e);
		}

		#endregion

		#region Virtuals

		protected virtual void OnStyleChanged(object sender, StyleEventArgs args)
		{
		}

		protected virtual  void OnPlansOfColorsChanged(object sender, PlansOfColorsChangedEventArgs args)
		{
		}

		#endregion

		#region Properties

		[Category("Style")]
		public StyleGuide Style
		{
			get {return m_enterpriseStyle;}
			set 
			{
				m_enterpriseStyle = value;

				if (m_enterpriseStyle != null)
				{
					PlansOfColorsChangedEventArgs oArgs = new PlansOfColorsChangedEventArgs(m_enterpriseStyle.PlansOfColors);
					OnPlansOfColorsChanged(this, oArgs);

					m_enterpriseStyle.StyleChanged += new StyleChangedEventHandler(this.OnStyleChanged);
					m_enterpriseStyle.PlansOfColorsChanged += new PlansOfColorsChangedEventHandler(this.OnPlansOfColorsChanged);
				}
				
				foreach(Control m_Control in this.Controls)
				{
					if (m_Control is IHasStyleControl && ((IHasStyleControl)m_Control).GetParentStyle()) 
					{
						((IHasStyleControl)m_Control).SetStyle(value);
					}
				}
				
				this.Invalidate(true);
			}
		}

		[Category("Behavior")]
		public bool ParentStyle
		{
			get {return parentStyle;}
			set {parentStyle = value;}
		}

		#endregion

		#region IHasStyleControl

		public StyleGuide GetStyle()
		{
			return this.m_enterpriseStyle;
		}

		public void SetStyle(StyleGuide style)
		{
			this.Style = style;
		}

		public bool GetParentStyle()
		{
			return this.parentStyle;
		}

		#endregion
	}
}
