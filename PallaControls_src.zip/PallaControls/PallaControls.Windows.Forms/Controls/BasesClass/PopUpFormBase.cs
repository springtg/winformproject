using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Security.Permissions;
using System.Windows.Forms;
using PallaControls.Utilities;
using PallaControls.Utilities.Win32;

namespace PallaControls.Windows.Forms
{
	public class PopUpFormBase : System.Windows.Forms.Form
	{
		private System.ComponentModel.IContainer components = null;
		private bool m_Start = false;
		private Control m_Parent = null;
		private Form m_ParentForm = null;
		private Form m_MdiParent = null;
		
		#region Constructors
		
		public PopUpFormBase()
		{
			InitializeComponent();
		}

		public PopUpFormBase(Control parent)
		{
			InitializeComponent();

			m_Parent = parent;
			m_ParentForm = m_Parent.FindForm();
			
			if(Form.ActiveForm != null && Form.ActiveForm.IsMdiContainer)
			{
				m_MdiParent = Form.ActiveForm;

				m_MdiParent.LostFocus += new System.EventHandler(this.ParentLostFocus);
				m_MdiParent.MouseDown += new System.Windows.Forms.MouseEventHandler(this.ParentFormMouseClick);
				m_MdiParent.Move      += new System.EventHandler(this.ParentFormMoved);
			}
						
			m_ParentForm.LostFocus += new System.EventHandler(this.ParentLostFocus);
			m_ParentForm.MouseDown += new System.Windows.Forms.MouseEventHandler(this.ParentFormMouseClick);
			m_ParentForm.Move      += new System.EventHandler(this.ParentFormMoved);

			if(!object.ReferenceEquals(m_Parent.Parent,m_ParentForm))
			{
				m_Parent.Parent.MouseDown += new System.Windows.Forms.MouseEventHandler(this.ParentFormMouseClick);
			}
		}

		#endregion

		#region Dispose

		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				m_Parent.LostFocus -= new System.EventHandler(this.ParentLostFocus);
				m_ParentForm.MouseDown -= new System.Windows.Forms.MouseEventHandler(this.ParentFormMouseClick);
				m_ParentForm.Move -= new System.EventHandler(this.ParentFormMoved);

				if(!object.ReferenceEquals(m_Parent.Parent,m_ParentForm))
				{
					m_Parent.Parent.MouseDown -= new System.Windows.Forms.MouseEventHandler(this.ParentFormMouseClick);
				}

				if(m_MdiParent != null)
				{
					m_MdiParent.LostFocus -= new System.EventHandler(this.ParentLostFocus);
					m_MdiParent.MouseDown -= new System.Windows.Forms.MouseEventHandler(this.ParentFormMouseClick);
					m_MdiParent.Move      -= new System.EventHandler(this.ParentFormMoved);
				}

				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#endregion

		#region Windows Form Designer generated code

		private void InitializeComponent()
		{
			this.AutoScale = false;
			this.ClientSize = new System.Drawing.Size(176, 96);
			this.ControlBox = false;
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "PopUpFormBase";
			this.ShowInTaskbar = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
			this.Text = "PopUpFormBase";

		}

		#endregion

		#region Events handles

		private void ParentFormMouseClick(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			this.Close();
		}

		private void ParentLostFocus(object sender, System.EventArgs e)
		{
			if(m_Start){
				this.Close();
			}
		}

		private void ParentFormMoved(object sender, System.EventArgs e)
		{
			if(m_Start){
				this.Close();
			}
		}

		#endregion

		#region Overrides

		[SecurityPermission(SecurityAction.LinkDemand)]
		[UseApiElements("Msgs.WM_MOUSEACTIVATE, MouseActivateFlags.MA_NOACTIVATE")]
		protected override void WndProc(ref Message m)
		{				
			if(m.Msg == (int)Msgs.WM_MOUSEACTIVATE)
			{
				m.Result = (IntPtr)MouseActivateFlags.MA_NOACTIVATE;
				return;
			}

			base.WndProc(ref m);
		}

		[UseApiElements("WindowExStyles.WS_EX_TOPMOST")]
		protected override CreateParams CreateParams 
		{
			[SecurityPermission(SecurityAction.LinkDemand)]
			get
			{
				CreateParams cp = base.CreateParams;

				cp.ExStyle |= (int)WindowExStyles.WS_EX_TOPMOST; 

				return cp;
			}
		}

		#endregion

		#region Virtuals

		public virtual void PostMessage(ref Message m)
		{
		}

		#endregion		

		#region Properties

		public bool Start
		{
			get{return m_Start;}
			set{m_Start = value;}
		}

		#endregion
	}
}
