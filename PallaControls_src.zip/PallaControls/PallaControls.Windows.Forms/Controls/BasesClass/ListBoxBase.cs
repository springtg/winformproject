using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Reflection;
using System.Windows.Forms;
using PallaControls.Utilities;
using PallaControls.Utilities.Win32;

namespace PallaControls.Windows.Forms
{
	[System.ComponentModel.ToolboxItem(false)]
	public class ListBoxBase : System.Windows.Forms.ListBox
	{
		private System.ComponentModel.IContainer components = null;
		private Color m_SelectionColor = StyleGuide.InteliSelectionColor(null);

		#region Constructors

		public ListBoxBase()
		{
			InitializeComponent();
			this.DrawMode    = DrawMode.OwnerDrawFixed;
			this.BorderStyle = BorderStyle.None;
		}

		#endregion

		#region Dispose

		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#endregion

		#region Designer generated code
		private void InitializeComponent()
		{
			components = new System.ComponentModel.Container();
		}
		#endregion

		#region Overrides

		[UseApiElements("ShowScrollBar")]
		protected override void OnDrawItem(DrawItemEventArgs e)
		{
			if (this.DrawMode == DrawMode.OwnerDrawFixed ||
				this.DrawMode == DrawMode.Normal) 
			{
				User32.ShowScrollBar(this.Handle, (int)ScrollBarTypes.SB_BOTH, 0);

				using(Graphics g = e.Graphics)
				{
					Rectangle bounds = e.Bounds;
					bool selected = (e.State & DrawItemState.Selected) > 0;
					if ( e.Index != -1 && this.Items.Count > 0)
						DrawListBoxItem(g, bounds, e.Index, selected);
				}
			}
			else
			{
				base.OnDrawItem(e);
			}
		}

		#endregion

		#region Virtuals

		protected virtual void DrawListBoxItem(Graphics g, Rectangle bounds, int index, bool selected)
		{
			if (index != -1)
			{
				if ( selected && Enabled )
				{
					using ( Brush b = new SolidBrush(m_SelectionColor) )
					{
						g.FillRectangle(b, bounds.Left, bounds.Top, bounds.Width, bounds.Height);
					}
					using ( Pen p = new Pen(Color.Transparent) )
					{
						g.DrawRectangle(p, bounds.Left, bounds.Top, bounds.Width-1, bounds.Height-1);
					}
				}
				else
				{
					using (Brush b = new SolidBrush(this.BackColor))
					{
						g.FillRectangle(b, bounds.Left, bounds.Top, bounds.Width, bounds.Height);
					}
				}

				object pitem = null;
				if (this.Items[index] is DataRowView) 
				{pitem = ((DataRowView)this.Items[index]).Row[this.DisplayMember.Substring(this.DisplayMember.IndexOf(".")+1)];}
				else if (this.Items[index] is string) 
				{pitem = (string)this.Items[index];}
				else //Custom objects
				{
					if (this.Items[index] != null && this.DisplayMember == String.Empty && this.ValueMember == String.Empty)
						pitem = this.Items[index].ToString();
				}
								
				if ( pitem != null )
				{
					if ( Enabled )
					{
						using (Brush brush1=new SolidBrush(this.ForeColor))
						{
							g.DrawString((string)pitem, SystemInformation.MenuFont,
								brush1, new RectangleF(bounds.Left+2, bounds.Top, 
								bounds.Width-20, bounds.Height));

							//g.DrawString((string)pitem, SystemInformation.MenuFont, 
							//	brush1, new Point(bounds.Left+2, bounds.Top));
						}
					}
					else
					{
						g.DrawString((string)pitem, SystemInformation.MenuFont,
							SystemBrushes.ControlDark, new RectangleF(bounds.Left+2, bounds.Top, 
							bounds.Width-20, bounds.Height));

						//g.DrawString((string)pitem, SystemInformation.MenuFont, 
						//	SystemBrushes.ControlDark, new Point(bounds.Left+2, bounds.Top));
					}
				}
				
			}
		}

		#endregion

		#region Properties

		public Color SelectionColor
		{
			get{return m_SelectionColor;}
			set{m_SelectionColor = value;}
		}

		#endregion
	}
}

