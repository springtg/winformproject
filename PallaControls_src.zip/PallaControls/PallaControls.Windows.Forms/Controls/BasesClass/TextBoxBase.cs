using System;
using System.IO;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Collections;
using System.Diagnostics;
using System.ComponentModel;
using System.Windows.Forms;
using System.Text;
using System.Text.RegularExpressions;
using System.Security.Permissions;
using PallaControls.Resources;
using PallaControls.Resources.Keys;
using PallaControls.Utilities.CoreHelpers;
using PallaControls.Utilities.Win32;

namespace PallaControls.Windows.Forms
{
	[System.ComponentModel.ToolboxItem(false)]
	public class TextBoxBase : System.Windows.Forms.TextBox
	{
		private System.ComponentModel.Container components = null;

		protected EditMask mMask = EditMask.Custom;
		protected int mDecPlaces = 2;
		protected int mDecMinValue = -999999999;
		protected int mDecMaxValue =  999999999;
		protected bool mRequired = false;
		protected string mNotAcceptsChars = String.Empty;
		protected bool mValidWithMask = false;
		protected string mRegExp = string.Empty;
		private string m_ErrorMessage = string.Empty;

		public event MessageEventHandler ProccessMessage;
		public event NumberOcurredEventHandler NumberOcurred = null;
		public event ErrorOcurredEventHandler ErrorOcurred  = null;
		
		#region Constructors

		public TextBoxBase()
		{
			InitializeComponent();
		}

		#endregion

		#region Dispose

		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#endregion

		#region Component Designer generated code
		
		private void InitializeComponent()
		{

		}

		#endregion

		#region Overrides

		[SecurityPermission(SecurityAction.LinkDemand)]
		protected override void WndProc(ref Message m)
		{	
			if(!OnWndProc(ref m))
			{				
				base.WndProc(ref m);
			}
		}

		protected override void OnKeyPress(KeyPressEventArgs e)
		{
			switch(mMask)
			{
				case EditMask.Numeric:
					e.Handled = !HandleNumeric(e.KeyChar);
					break;

				case EditMask.Date:
					e.Handled = HandleDate(e.KeyChar);
					break;
				
				case EditMask.Ip:
					e.Handled = HandleIp(e.KeyChar);
					break;

				case EditMask.Phone:
					e.Handled = HandlePhone(e.KeyChar);
					break;

				case EditMask.PhoneWithArea:
					e.Handled = HandlePhoneWithArea(e.KeyChar);
					break;

				case EditMask.Identity:
					e.Handled = HandleRg(e.KeyChar);
					break;

				case EditMask.PersonIdentity:
					e.Handled = HandleCpf(e.KeyChar);
					break;

				case EditMask.EnterpriseIdentity:
					e.Handled = HandleCnpj(e.KeyChar);
					break;
					
				case EditMask.Zip:
					e.Handled = HandleCep(e.KeyChar);
					break;

				case EditMask.Email:
					e.Handled = HandleEmail(e.KeyChar);
					break;

				case EditMask.Diretory:
					e.Handled = HandleDirectory(e.KeyChar);
					break;

				case EditMask.FileName:
					e.Handled = HandleDirectory(e.KeyChar);
					break;

				case EditMask.Time:
					e.Handled = HandleTime(e.KeyChar);
					break;
				
				case EditMask.TextWithNotAcceptChars:
					e.Handled = HandleTextWithNotAcceptChars(e.KeyChar);
					break;

				case EditMask.StateRegistration:
					e.Handled = HandleInscricaoEstadual(e.KeyChar);
					break;

				case EditMask.PhoneCodeArea:
					e.Handled = HandlePhoneCodeArea(e.KeyChar);
					break;
			
				default:
					break;
			}

			base.OnKeyPress(e);
		}

		protected override void OnValidating(System.ComponentModel.CancelEventArgs e)
		{
			base.OnValidating(e);
			switch(mMask)
			{
				case EditMask.Date:
					e.Cancel = ValidateDate();
					break;

				case EditMask.Email:
					e.Cancel = ValidateMail();
					break;

				case EditMask.Ip:
					e.Cancel = ValidateIp();
					break;
					
				case EditMask.Phone:
					e.Cancel = ValidatePhone();
					break;

				case EditMask.PhoneWithArea:
					e.Cancel = ValidatePhoneWithArea();
					break;

				case EditMask.Identity:
					e.Cancel = ValidateRg();
					break;

				case EditMask.PersonIdentity:
					e.Cancel = ValidateCpf();
					break;

				case EditMask.Diretory:
					e.Cancel = ValidateDiretory();
					break;

				case EditMask.FileName:
					e.Cancel = ValidateFileName();
					break;

				case EditMask.EnterpriseIdentity:
					e.Cancel = ValidateCnpj();
					break;

				case EditMask.Zip:
					e.Cancel = ValidateText();
					break;

				case EditMask.Time:
					e.Cancel = ValidateTime();
					break;

				case EditMask.Text:
					e.Cancel = ValidateText();
					break;

				case EditMask.TextWithNotAcceptChars:
					e.Cancel = ValidateText();
					break;

				case EditMask.Numeric:
					e.Cancel = ValidateNumber();
					break;

				case EditMask.StateRegistration:
					e.Cancel = ValidateText();
					break;

				case EditMask.PhoneCodeArea:
					e.Cancel = ValidatePhoneCodeArea();
					break;

				case EditMask.CustomWithRegularExpressions:
					e.Cancel = ValidateRegularExpression();
					break;

				case EditMask.Custom:
					e.Cancel = false;
					break;

				default:
					break;
			}

			this.mValidWithMask = !e.Cancel;
		}

		protected override void OnValidated(EventArgs e)
		{
			if (this.ErrorOcurred != null)
			{
				ErrorOcurredEventArgs oArg = new ErrorOcurredEventArgs("");
				ErrorOcurred(this, oArg); 
			}
			//
			base.OnValidated(e);
		}

		protected override void OnTextChanged(System.EventArgs e)
		{
			if(mMask == EditMask.Numeric)
			{
				NumberOcurredEventArgs oArg = null;

				if (this.NumberOcurred != null)
				{
					oArg = new NumberOcurredEventArgs();
					NumberOcurred(this, oArg); 
				}

				if(this.Text.StartsWith("-"))
				{
					if (oArg != null)
					{
						this.ForeColor = oArg.NegativeNumberColor;
					}
					else {this.ForeColor = Color.Red;}
				}
				else
				{
					if (oArg != null)
					{
						this.ForeColor = oArg.PositiveNumberColor;
					}
					else {this.ForeColor = Color.Black;}
				}
			}

			base.OnTextChanged(e);
		}

		/*protected override void OnEnter(System.EventArgs e)
		{
			base.OnEnter(e);
			if (this.Parent is Panel)
			{
				((Panel)this.Parent).ScrollControlIntoView(this);
			}
		}*/
		
		#endregion

		#region Virtuals

		public virtual bool OnWndProc(ref Message m)
		{
			if(ProccessMessage != null)
			{
				MessageEventArgs evtArgs = new MessageEventArgs(m, false);
				ProccessMessage(this, evtArgs);
				
				return evtArgs.Result;
			}

			return false;
		}

		protected virtual bool HandleDate(char keyChar)		
		{			
			if (!this.ReadOnly) 			
			{				
				if (Char.IsDigit(keyChar) || 					
					keyChar == CultureInfo.CurrentCulture.DateTimeFormat.DateSeparator[0] || 
					keyChar == 8 ||					
					keyChar == 22 || keyChar == 3 || 					
					keyChar == 26 || keyChar == 24 || keyChar == 27)				
				{ 					
					if (this.ErrorOcurred != null)					
					{						
						ErrorOcurredEventArgs oArg = new ErrorOcurredEventArgs("");						
						ErrorOcurred(this, oArg); 					
					}					
					if (keyChar != 8 && keyChar != 22 && 						
						keyChar != 3 && keyChar != 26 && keyChar != 24 && keyChar != 27)					
					{						
						if (this.SelectedText == this.Text) this.Clear();						
						//						
						if (keyChar != CultureInfo.CurrentCulture.DateTimeFormat.DateSeparator[0] )						
						{							
							if (this.Text.Length == 2 || this.Text.Length == 5) 								
								this.AppendText(CultureInfo.CurrentCulture.DateTimeFormat.DateSeparator);						
						}						
						//						
						if(this.Text.Length == 10)							
							return true;					
					}				
				}				
				else				
				{					
					ErrorOcurredEventArgs oArg = null;					
					if (this.ErrorOcurred != null)					
					{						
						oArg = new ErrorOcurredEventArgs(this.m_ErrorMessage != string.Empty ? this.m_ErrorMessage : ResourceLibrary.GetString(WindowsControlsResourceKeys.OnlyDigitsBarAccepted,WindowsControlsResourceKeys.Root));						
						ErrorOcurred(this, oArg); 					
					}					
					return true;				
				}			
			}			
			return false;	    
		}
		
		protected virtual bool HandleEmail(char keyChar)
		{
			if (!this.ReadOnly) 
			{
				if (this.ErrorOcurred != null)
				{
					ErrorOcurredEventArgs oArg = new ErrorOcurredEventArgs("");
					ErrorOcurred(this, oArg); 
				}
			}
			return false;
		}

		protected virtual bool HandleDirectory(char keyChar)
		{
			if (!this.ReadOnly) 
			{
				if (this.ErrorOcurred != null)
				{
					ErrorOcurredEventArgs oArg = new ErrorOcurredEventArgs("");
					ErrorOcurred(this, oArg); 
				}
			}
			return false;
		}

		protected virtual bool HandleIp(char keyChar)
		{
			if (!this.ReadOnly)
			{
				if(Char.IsDigit(keyChar) || 
					keyChar == '.' || keyChar == 8 ||
					keyChar == 22  || keyChar == 3 || 
					keyChar == 26  || keyChar == 24)
				{
					if (this.ErrorOcurred != null)
					{
						ErrorOcurredEventArgs oArg = new ErrorOcurredEventArgs("");
						ErrorOcurred(this, oArg); 
					}
				}
				else
				{
					if (this.ErrorOcurred != null)
					{
						ErrorOcurredEventArgs oArg = new ErrorOcurredEventArgs(this.m_ErrorMessage != string.Empty ? this.m_ErrorMessage : ResourceLibrary.GetString(WindowsControlsResourceKeys.OnlyDigitsPointsAccepted,WindowsControlsResourceKeys.Root));
						ErrorOcurred(this, oArg); 
					}
					return true;
				}
			}
			return false;
		}

		protected virtual bool HandlePhone(char keyChar)
		{
			if (!this.ReadOnly) 
			{
				if(Char.IsDigit(keyChar) || keyChar == '-' || 
					keyChar == 8  || keyChar == 32 ||
					keyChar == 22 || keyChar == 3  || 
					keyChar == 26 || keyChar == 24) 
				{ 
					if (this.ErrorOcurred != null)
					{
						ErrorOcurredEventArgs oArg = new ErrorOcurredEventArgs("");
						ErrorOcurred(this, oArg); 
					}
					
					if (keyChar != 8 && keyChar != 22 && 
						keyChar != 3 && keyChar != 26 && 
						keyChar != 24)
					{
						if (keyChar != '-' )
						{
							if (this.Text.Length == 4 && this.Text.LastIndexOf('-') == -1) 
								this.AppendText("-");
							//
							if (this.Text.Length == 9)
								return true;
						}
					}
				}
				else
				{
					if (this.ErrorOcurred != null)
					{
						ErrorOcurredEventArgs oArg = new ErrorOcurredEventArgs(this.m_ErrorMessage != string.Empty ? this.m_ErrorMessage : ResourceLibrary.GetString(WindowsControlsResourceKeys.OnlyDigitsMinusSpaceAccepted,WindowsControlsResourceKeys.Root));
						ErrorOcurred(this, oArg); 
					}
					return true;
				}
			}
			return false;
		}

		protected virtual bool HandlePhoneWithArea(char keyChar)
		{
			if (!this.ReadOnly) 
			{
				if(Char.IsDigit(keyChar) || 
					keyChar == '-' || keyChar == '(' || 
					keyChar == ')' || keyChar == 8   || 
					keyChar == 32  || keyChar == 22  || 
					keyChar == 3   || keyChar == 26  || keyChar == 24) 
				{ 
					if (this.ErrorOcurred != null)
					{
						ErrorOcurredEventArgs oArg = new ErrorOcurredEventArgs("");
						ErrorOcurred(this, oArg); 
					}

					if (keyChar != 8 && keyChar != 22 && 
						keyChar != 3 && keyChar != 26 && 
						keyChar != 24)
					{
						if (keyChar != '(' )
						{
							if (this.Text.Length == 0 && this.Text.LastIndexOf('(') == -1) 
								this.AppendText("(");
						}

						if (keyChar != ')' )
						{
							if (this.Text.Length == 4 && this.Text.LastIndexOf(')') == -1) 
								this.AppendText(")");
						}

						if (keyChar != '-' )
						{
							if (this.Text.Length == 9 && this.Text.LastIndexOf('-') == -1) 
								this.AppendText("-");
						}
						//
						if(this.Text.Length == 14)
							return true;
					}
				}
				else
				{
					if (this.ErrorOcurred != null)
					{
						ErrorOcurredEventArgs oArg = new ErrorOcurredEventArgs(this.m_ErrorMessage != string.Empty ? this.m_ErrorMessage : ResourceLibrary.GetString(WindowsControlsResourceKeys.OnlyDigitsMinusParenthesesAccepted,WindowsControlsResourceKeys.Root));
						ErrorOcurred(this, oArg); 
					}
					return true;
				}
			}
			return false;
		}

		protected virtual bool HandleRg(char keyChar)
		{
			if (!this.ReadOnly) 
			{
				if (CultureInfo.CurrentCulture.Name == "pt-BR")
				{
					if(Char.IsLetterOrDigit(keyChar) || 
						keyChar == '.' || keyChar == '-' || keyChar == 8  ||
						keyChar == 22  || keyChar == 3   || keyChar == 26 || 
						keyChar == 24) 
					{ 
						if (this.ErrorOcurred != null)
						{
							ErrorOcurredEventArgs oArg = new ErrorOcurredEventArgs("");
							ErrorOcurred(this, oArg); 
						}
						if (keyChar != 8 && keyChar != 22 && 
							keyChar != 3 && keyChar != 26 && 
							keyChar != 24)
						{
							if (keyChar != '.' )
							{
								if (this.Text.Length == 2 || this.Text.Length == 6)
									this.AppendText(".");
							}
							if (keyChar != '-' )
							{
								if (this.Text.Length == 10 && this.Text.LastIndexOf('-') == -1) 
									this.AppendText("-");
							}
							//
							if(this.Text.Length == 12)
								return true;
						}
					}
					else
					{
						if (this.ErrorOcurred != null)
						{
							ErrorOcurredEventArgs oArg = new ErrorOcurredEventArgs(this.m_ErrorMessage != string.Empty ? this.m_ErrorMessage : ResourceLibrary.GetString(WindowsControlsResourceKeys.OnlyDigitsMinusPointsAccepted,WindowsControlsResourceKeys.Root));
							ErrorOcurred(this, oArg); 
						}
						return true;
					}
				}
				else if (CultureInfo.CurrentCulture.Name == "es-DO")
				{
					if(Char.IsDigit(keyChar)||
						keyChar == 8 || keyChar == 22 || 
						keyChar == 3 || keyChar == 26 || 
						keyChar == 24) 
					{ 
						if (this.ErrorOcurred != null)
						{
							ErrorOcurredEventArgs oArg = new ErrorOcurredEventArgs("");
							ErrorOcurred(this, oArg); 
						}
						//
						if(this.Text.Length == 12)
							return true;
					}
					else
					{
						if (this.ErrorOcurred != null)
						{
							ErrorOcurredEventArgs oArg = new ErrorOcurredEventArgs(this.m_ErrorMessage != string.Empty ? this.m_ErrorMessage : ResourceLibrary.GetString(WindowsControlsResourceKeys.OnlyDigitsAccepted,WindowsControlsResourceKeys.Root));
							ErrorOcurred(this, oArg); 
						}
						return true;
					}
				}
			}
			return false;
		}
		
		protected virtual bool HandleCpf(char keyChar)
		{
			if (!this.ReadOnly) 
			{
				if (CultureInfo.CurrentCulture.Name == "pt-BR")
				{
					if(Char.IsDigit(keyChar) || 
						keyChar == '-' || keyChar == 8 ||
						keyChar == 22  || keyChar == 3 || 
						keyChar == 26  || keyChar == 24)
					{ 
						if (this.ErrorOcurred != null)
						{
							ErrorOcurredEventArgs oArg = new ErrorOcurredEventArgs("");
							ErrorOcurred(this, oArg); 
						}

						if (keyChar != 8 && keyChar != 22 && 
							keyChar != 3 && keyChar != 26 && 
							keyChar != 24)
						{
							if (keyChar != '-' )
							{
								if (this.Text.Length == 9)
									this.AppendText("-");
							}
							//
							if(this.Text.Length == 12)
								return true;
						}
					}
					else
					{
						if (this.ErrorOcurred != null)
						{
							ErrorOcurredEventArgs oArg = new ErrorOcurredEventArgs(this.m_ErrorMessage != string.Empty ? this.m_ErrorMessage : ResourceLibrary.GetString(WindowsControlsResourceKeys.OnlyDigitsMinusAccepted,WindowsControlsResourceKeys.Root));
							ErrorOcurred(this, oArg); 
						}
						return true;
					}
				}
				else if (CultureInfo.CurrentCulture.Name == "es-DO")
				{
					if(Char.IsDigit(keyChar)||
						keyChar == 8 || keyChar == 22 || 
						keyChar == 3 || keyChar == 26 || 
						keyChar == 24)  
					{ 
						if (this.ErrorOcurred != null)
						{
							ErrorOcurredEventArgs oArg = new ErrorOcurredEventArgs("");
							ErrorOcurred(this, oArg); 
						}

						if(this.Text.Length == 12)
							return true;
					}
					else
					{
						if (this.ErrorOcurred != null)
						{
							ErrorOcurredEventArgs oArg = new ErrorOcurredEventArgs(this.m_ErrorMessage != string.Empty ? this.m_ErrorMessage : ResourceLibrary.GetString(WindowsControlsResourceKeys.OnlyDigitsAccepted,WindowsControlsResourceKeys.Root));
							ErrorOcurred(this, oArg); 
						}
						return true;
					}
				}
			}
			return false;
		}

		protected virtual bool HandleCnpj(char keyChar)
		{
			if (!this.ReadOnly) 
			{
				if (CultureInfo.CurrentCulture.Name == "pt-BR")
				{
					if(Char.IsDigit(keyChar) || 
						keyChar == '-' || keyChar == '.' || 
						keyChar == '/' || keyChar == 8   ||
						keyChar == 22  || keyChar == 3   || 
						keyChar == 26  || keyChar == 24) 
					{ 
						if (this.ErrorOcurred != null)
						{
							ErrorOcurredEventArgs oArg = new ErrorOcurredEventArgs("");
							ErrorOcurred(this, oArg); 
						}

						if (keyChar != 8 && keyChar != 22 && 
							keyChar != 3 && keyChar != 26 && 
							keyChar != 24)
						{
							if (keyChar != '.' )
							{
								if (this.Text.Length == 2 || this.Text.Length == 6) 
									this.AppendText(".");
							}

							if (keyChar != '/' )
							{
								if (this.Text.Length == 10 && this.Text.LastIndexOf('/') == -1) 
									this.AppendText("/");
							}

							if (keyChar != '-' )
							{
								if (this.Text.Length == 15 && this.Text.LastIndexOf('-') == -1) 
									this.AppendText("-");
							}
							//
							if(this.Text.Length == 18)
								return true;
						}
					}
					else
					{
						if (this.ErrorOcurred != null)
						{
							ErrorOcurredEventArgs oArg = new ErrorOcurredEventArgs(this.m_ErrorMessage != string.Empty ? this.m_ErrorMessage : ResourceLibrary.GetString(WindowsControlsResourceKeys.OnlyDigitsMinusPointsBarsAccepted,WindowsControlsResourceKeys.Root));
							ErrorOcurred(this, oArg); 
						}
						return true;
					}
				}
				else if (CultureInfo.CurrentCulture.Name == "es-DO")
				{
					if(Char.IsDigit(keyChar)||
						keyChar == 8 || keyChar == 22 || 
						keyChar == 3 || keyChar == 26 || 
						keyChar == 24) 
					{ 
						if (this.ErrorOcurred != null)
						{
							ErrorOcurredEventArgs oArg = new ErrorOcurredEventArgs("");
							ErrorOcurred(this, oArg); 
						}

						if(this.Text.Length == 20)
							return true;
					}
					else
					{
						if (this.ErrorOcurred != null)
						{
							ErrorOcurredEventArgs oArg = new ErrorOcurredEventArgs(this.m_ErrorMessage != string.Empty ? this.m_ErrorMessage : ResourceLibrary.GetString(WindowsControlsResourceKeys.OnlyDigitsAccepted,WindowsControlsResourceKeys.Root));
							ErrorOcurred(this, oArg); 
						}
						return true;
					}
				}
			}
			return false;
		}

		protected virtual bool HandleCep(char keyChar)
		{
			if (!this.ReadOnly) 
			{
				if (CultureInfo.CurrentCulture.Name == "pt-BR")
				{
					if(Char.IsDigit(keyChar) || keyChar == '-' || 
						keyChar == 8 || keyChar == 22 || 
						keyChar == 3 || keyChar == 26 || 
						keyChar == 24) 
					{ 

						if (this.ErrorOcurred != null)
						{
							ErrorOcurredEventArgs oArg = new ErrorOcurredEventArgs("");
							ErrorOcurred(this, oArg); 
						}

						if (keyChar != 8 && keyChar != 22 && 
							keyChar != 3 && keyChar != 26 && 
							keyChar != 24)
						{
							if (keyChar != '-' )
							{
								if (this.Text.Length == 5 && this.Text.LastIndexOf('-') == -1) 
								{
									this.AppendText("-");
								}
								//
								if(this.Text.Length == 9)
									return true;
							}
						}
					}
					else
					{
						if (this.ErrorOcurred != null)
						{
							ErrorOcurredEventArgs oArg = new ErrorOcurredEventArgs(this.m_ErrorMessage != string.Empty ? this.m_ErrorMessage : ResourceLibrary.GetString(WindowsControlsResourceKeys.OnlyDigitsMinusAccepted,WindowsControlsResourceKeys.Root));
							ErrorOcurred(this, oArg); 
						}
						return true;
					}
				}
				else if (CultureInfo.CurrentCulture.Name == "es-DO")
				{
					if(Char.IsDigit(keyChar) ||
						keyChar == 8 || keyChar == 22 || 
						keyChar == 3 || keyChar == 26 || 
						keyChar == 24) 
					{ 
						if (this.ErrorOcurred != null)
						{
							ErrorOcurredEventArgs oArg = new ErrorOcurredEventArgs("");
							ErrorOcurred(this, oArg); 
						}

						if(this.Text.Length == 9)
							return true;
					}
					else
					{
						if (this.ErrorOcurred != null)
						{
							ErrorOcurredEventArgs oArg = new ErrorOcurredEventArgs(this.m_ErrorMessage != string.Empty ? this.m_ErrorMessage : ResourceLibrary.GetString(WindowsControlsResourceKeys.OnlyDigitsAccepted,WindowsControlsResourceKeys.Root));
							ErrorOcurred(this, oArg); 
						}
						return true;
					}
				}
			}
			return false;
		}

		//THANK�S "Geri Wolters" (CODEPROJECT)
		protected virtual bool HandleTime(char keyChar)		
		{			
			if (!this.ReadOnly) 			
			{				
				if (Char.IsDigit(keyChar) || 					
					keyChar == CultureInfo.CurrentCulture.DateTimeFormat.TimeSeparator[0] || 
					keyChar == 8 ||					
					keyChar == 22 || 
					keyChar == 3 || 					
					keyChar == 26 || 
					keyChar == 24)				
				{ 					
					if (this.ErrorOcurred != null)					
					{						
						ErrorOcurredEventArgs oArg = new ErrorOcurredEventArgs("");						
						ErrorOcurred(this, oArg); 					
					}					
					if (keyChar != 8 && keyChar != 22 && 						
						keyChar != 3 && keyChar != 26 && keyChar != 24)					
					{						
						if (this.SelectedText == this.Text) this.Clear();						
						//						
						if (keyChar != CultureInfo.CurrentCulture.DateTimeFormat.TimeSeparator[0] )						
						{							
							if (this.Text.Length == 2 || this.Text.Length == 5) 								
								this.AppendText(CultureInfo.CurrentCulture.DateTimeFormat.TimeSeparator);
						}						
						//						
						if(this.Text.Length == 8)							
							return true;					
					}				
				}				
				else				
				{					
					ErrorOcurredEventArgs oArg = null;					
					if (this.ErrorOcurred != null)					
					{						
						oArg = new ErrorOcurredEventArgs(this.m_ErrorMessage != string.Empty ? this.m_ErrorMessage : ResourceLibrary.GetString(WindowsControlsResourceKeys.OnlyDigitsTwoPointsAccepted,WindowsControlsResourceKeys.Root));						
						ErrorOcurred(this, oArg); 					
					}					
					return true;				
				}			
			}			
			return false;		
		}
		
		protected virtual bool HandleTextWithNotAcceptChars(char keyChar)
		{
			if (!this.ReadOnly) 
			{
				if (this.ErrorOcurred != null)
				{
					ErrorOcurredEventArgs oArg = new ErrorOcurredEventArgs("");
					ErrorOcurred(this, oArg); 
				}
				//
				if (mNotAcceptsChars.IndexOf(keyChar) > -1) 
				{
					if (this.ErrorOcurred != null)
					{
						ErrorOcurredEventArgs oArg = new ErrorOcurredEventArgs(this.m_ErrorMessage != string.Empty ? this.m_ErrorMessage : ResourceLibrary.GetString(CommonResourceKeys.IlegalChar,CommonResourceKeys.Root));
						ErrorOcurred(this, oArg); 
					}
					return true;
				}
			}
			return false;
		}

		protected virtual bool HandleInscricaoEstadual(char keyChar)
		{
			if (!this.ReadOnly) 
			{
				if(Char.IsLetterOrDigit(keyChar) || 
					keyChar == '.' || keyChar == '-' || keyChar == 8 ||
					keyChar == '/' || keyChar == 22  || keyChar == 3 || 
					keyChar == 26  || keyChar == 24) 
				{ 
					if (this.ErrorOcurred != null)
					{
						ErrorOcurredEventArgs oArg = new ErrorOcurredEventArgs("");
						ErrorOcurred(this, oArg); 
					}
					if(this.Text.Length == 20)
						return true;
				}
				else
				{
					if (this.ErrorOcurred != null)
					{
						ErrorOcurredEventArgs oArg = new ErrorOcurredEventArgs(this.m_ErrorMessage != string.Empty ? this.m_ErrorMessage : ResourceLibrary.GetString(CommonResourceKeys.IlegalChar,CommonResourceKeys.Root));
						ErrorOcurred(this, oArg); 
					}
					return true;
				}
			}
			return false;
		}

		protected virtual bool HandleNumeric(char pressedChar)
		{
			if(this.ReadOnly)
			{
				return true;
			}

			if (this.ErrorOcurred != null)
			{
				ErrorOcurredEventArgs oArg = new ErrorOcurredEventArgs("");
				ErrorOcurred(this, oArg); 
			}

			char decSep = Convert.ToChar(System.Globalization.NumberFormatInfo.CurrentInfo.NumberDecimalSeparator, CultureInfo.CurrentCulture);
			string val         = this.Text;
			bool   isSeparator = val.IndexOf(decSep) > -1;
			int    length      = val.Length;
			int    curPos      = this.SelectionStart;
			int    sepPos      = val.IndexOf(decSep);

			if(this.SelectionLength > 0)
			{
				val = val.Remove(this.SelectionStart,this.SelectionLength);
				length = val.Length;
			}
			
			if(char.IsDigit(pressedChar))
			{
                
				if(val.IndexOf("-") > -1 && val.IndexOf("-") > curPos-1)
				{
					return false;
				}
								
				if(((val.StartsWith("0") && curPos == 1) || (val.StartsWith("-0") && curPos == 2)))
				{
					return false;
				}
					
				if(isSeparator)
				{
					if(curPos > sepPos)
					{
						if((curPos - sepPos) > mDecPlaces)
						{
							return false;
						}

						if((length - sepPos) > mDecPlaces)
						{
							string newVal = val.Remove(curPos,1);
							newVal = newVal.Insert(curPos,pressedChar.ToString(CultureInfo.CurrentCulture));

							this.Text = newVal;
							this.SelectionStart = curPos + 1; 
							return false;
						}
					}
				}

				if(pressedChar == '0')
				{					
					if(val.StartsWith("-") && length > 1 && curPos == 1)
					{
						return false;					
					}

					if(length > 0 && curPos == 0)
					{
						return false;	
					}
				}

				return true;
			}
			else
			{
				if(pressedChar == decSep && !isSeparator && mDecPlaces > 0)
				{
					if(length - curPos > mDecPlaces)
					{
						return false;
					}

					return true;
				}
				if(pressedChar == '-')
				{
					if(!val.StartsWith("-") && curPos == 0)
					{
						return true;
					}
				}
				if(pressedChar == '\b')
				{
					return true;
				}

				return false;
			}
		}

		protected virtual bool HandlePhoneCodeArea(char keyChar)
		{
			if (!this.ReadOnly) 
			{
				if (CultureInfo.CurrentCulture.Name == "pt-BR" || 
					CultureInfo.CurrentCulture.Name == "es-DO")
				{
					if(Char.IsDigit(keyChar) || keyChar == 8 || 
						keyChar == 22 || keyChar == 3 || 
						keyChar == 26 || keyChar == 24) 
					{ 
						if (this.ErrorOcurred != null)
						{
							ErrorOcurredEventArgs oArg = new ErrorOcurredEventArgs("");
							ErrorOcurred(this, oArg); 
						}

						if (keyChar != 8 && keyChar != 22 && 
							keyChar != 3 && keyChar != 26 && 
							keyChar != 24)
						{
							if(this.Text.Length == 3)
								return true;
						}
					}
					else
					{
						if (this.ErrorOcurred != null)
						{
							ErrorOcurredEventArgs oArg = new ErrorOcurredEventArgs(this.m_ErrorMessage != string.Empty ? this.m_ErrorMessage : ResourceLibrary.GetString(WindowsControlsResourceKeys.OnlyDigitsAccepted,WindowsControlsResourceKeys.Root));
							ErrorOcurred(this, oArg); 
						}
						return true;
					}
				}
			}
			return false;
		}

		protected virtual bool ValidateText()
		{
			if (this.Required && this.TextLength == 0)
			{
				if (this.ErrorOcurred != null)
				{
					ErrorOcurredEventArgs oArg = new ErrorOcurredEventArgs(this.m_ErrorMessage != string.Empty ? this.m_ErrorMessage : ResourceLibrary.GetString(CommonResourceKeys.RequiredField,CommonResourceKeys.Root));
					ErrorOcurred(this, oArg); 
				}
				return true;
			}
			return false;
		}

		protected virtual bool ValidateMail()
		{
			if (this.Required || this.TextLength > 0)
			{
				Regex regularExpr = new Regex(@"^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$");
				//
				if(!regularExpr.IsMatch(this.Text))
				{
					if (this.ErrorOcurred != null)
					{
						ErrorOcurredEventArgs oArg = new ErrorOcurredEventArgs(this.m_ErrorMessage != string.Empty ? this.m_ErrorMessage : ResourceLibrary.GetString(WindowsControlsResourceKeys.InvalidEmail,WindowsControlsResourceKeys.Root));
						ErrorOcurred(this, oArg); 
					}
					return true;
				}
			}
			return false;
		}

		protected virtual bool ValidateDiretory()
		{
			if (this.Required || this.TextLength > 0)
			{
				if(!Directory.Exists(this.Text))
				{
					if (this.ErrorOcurred != null)
					{
						ErrorOcurredEventArgs oArg = new ErrorOcurredEventArgs(this.m_ErrorMessage != string.Empty ? this.m_ErrorMessage : ResourceLibrary.GetString(WindowsControlsResourceKeys.InvalidDirectory,WindowsControlsResourceKeys.Root));
						ErrorOcurred(this, oArg); 
					}
					return true;
				}
			}
			return false;
		}

		protected virtual bool ValidateFileName()
		{
			if (this.Required || this.TextLength > 0)
			{
				if(!File.Exists(this.Text))
				{
					if (this.ErrorOcurred != null)
					{
						ErrorOcurredEventArgs oArg = new ErrorOcurredEventArgs(String.Format(CultureInfo.CurrentCulture, this.m_ErrorMessage != string.Empty ? this.m_ErrorMessage : ResourceLibrary.GetString(CommonResourceKeys.FileNotFound, CommonResourceKeys.Root), this.Text));
						ErrorOcurred(this, oArg); 
					}
					return true;
				}
			}
			return false;
		}

		protected virtual bool ValidatePhone()
		{
			if (this.Required || this.TextLength > 0)
			{
				Regex regularExpr = new Regex(@"\s{1}\d{3}-\d{4}|\d{4}-\d{4}|\d{3}-\d{4}");
				//
				if(!regularExpr.IsMatch(this.Text))
				{
					if (this.ErrorOcurred != null)
					{
						ErrorOcurredEventArgs oArg = new ErrorOcurredEventArgs(this.m_ErrorMessage != string.Empty ? this.m_ErrorMessage : ResourceLibrary.GetString(WindowsControlsResourceKeys.InvalidTelephoneFormat,WindowsControlsResourceKeys.Root));
						ErrorOcurred(this, oArg); 
					}
					return true;
				}
			}
			return false;
		}

		protected virtual bool ValidatePhoneWithArea()
		{
			if (this.Required || this.TextLength > 0)
			{
				Regex regularExpr = new Regex(@"[(]\d{3}[)]\d{4}-\d{4}|[(]\d{3}[)]\s{1}\d{3}-\d{4}|[(]\d{3}[)]\d{3}-\d{4}");
				//
				if(!regularExpr.IsMatch(this.Text))
				{
					if (this.ErrorOcurred != null)
					{
						ErrorOcurredEventArgs oArg = new ErrorOcurredEventArgs(this.m_ErrorMessage != string.Empty ? this.m_ErrorMessage : ResourceLibrary.GetString(WindowsControlsResourceKeys.InvalidTelephoneAreaFormat,WindowsControlsResourceKeys.Root));
						ErrorOcurred(this, oArg); 
					}
					return true;
				}
			}
			return false;
		}

		protected virtual bool ValidatePhoneCodeArea()
		{
			if (CultureInfo.CurrentCulture.Name == "pt-BR")  
			{
				if (this.Required || this.TextLength > 0)
				{
					Regex regularExpr = new Regex(@"011|012|013|014|015|016|017|018|019|021|" +
						"022|024|027|028|031|032|033|034|035|037|038|041|042|043|044|045|046|047|048|049" +
						"051|053|054|055|061|062|063|064|065|066|067|068|069|071|073|074|075|077|079|081" +
						"082|083|084|085|086|087|088|089|091|092|093|094|095|096|097|098|099");
					//
					if(!regularExpr.IsMatch(this.Text))
					{
						if (this.ErrorOcurred != null)
						{
							ErrorOcurredEventArgs oArg = new ErrorOcurredEventArgs(this.m_ErrorMessage != string.Empty ? this.m_ErrorMessage : ResourceLibrary.GetString(WindowsControlsResourceKeys.InvalidAreaCode,WindowsControlsResourceKeys.Root));
							ErrorOcurred(this, oArg); 
						}
						return true;
					}
				}
			}
			else if (CultureInfo.CurrentCulture.Name == "es-DO")
			{
				return this.ValidateText();
			}
			else if (CultureInfo.CurrentCulture.TwoLetterISOLanguageName == "en")
			{
				return this.ValidateText();
			}

			return false;
		}

		//2002-08-07 - GWO - Added to accept regular expressions.
		protected bool ValidateRegularExpression()
		{
			if (this.Required || this.TextLength > 0)
			{
				if (mRegExp != string.Empty)
				{

					Regex regularExpr = new Regex(mRegExp);
					//
					if(!regularExpr.IsMatch(this.Text))
					{
						if (this.ErrorOcurred != null)
						{
							ErrorOcurredEventArgs oArg = new ErrorOcurredEventArgs(this.m_ErrorMessage != string.Empty ? this.m_ErrorMessage : ResourceLibrary.GetString(WindowsControlsResourceKeys.InvalidRegExp,WindowsControlsResourceKeys.Root));
							ErrorOcurred(this, oArg); 
						}
						return true;
					}
				}
			}

			return false;
		}

		protected virtual bool ValidateRg()
		{
			if (CultureInfo.CurrentCulture.Name == "pt-BR")
			{
				if (this.Required || this.TextLength > 0)
				{
					Regex regularExpr = new Regex(@"\d{2}.\d{3}.\d{3}-\w{1}");
					//
					if(!regularExpr.IsMatch(this.Text))
					{
						if (this.ErrorOcurred != null)
						{
							ErrorOcurredEventArgs oArg = new ErrorOcurredEventArgs(this.m_ErrorMessage != string.Empty ? this.m_ErrorMessage : ResourceLibrary.GetString(WindowsControlsResourceKeys.InvalidRgFormat,WindowsControlsResourceKeys.Root));
							ErrorOcurred(this, oArg); 
						}
						return true;
					}
				}
			}
			else if (CultureInfo.CurrentCulture.Name == "es-DO")
			{
				return this.ValidateText();
			}

			return false;
		}

		protected virtual bool ValidateCpf()
		{
			if (CultureInfo.CurrentCulture.Name == "pt-BR")
			{
				if (this.Required || this.TextLength > 0)
				{
					Regex regularExpr = new Regex(@"\d{9}-\d{2}");
					//
					if(!regularExpr.IsMatch(this.Text))
					{
						if (this.ErrorOcurred != null)
						{
							ErrorOcurredEventArgs oArg = new ErrorOcurredEventArgs(this.m_ErrorMessage != string.Empty ? this.m_ErrorMessage : ResourceLibrary.GetString(WindowsControlsResourceKeys.InvalidCpfFormat,WindowsControlsResourceKeys.Root));
							ErrorOcurred(this, oArg); 
						}
						return true;
					}
					else
					{
						if (!ValidationDigits.IsCpfOk(this.Text))
						{
							if (this.ErrorOcurred != null)
							{
								ErrorOcurredEventArgs oArg = new ErrorOcurredEventArgs(this.m_ErrorMessage != string.Empty ? this.m_ErrorMessage : ResourceLibrary.GetString(WindowsControlsResourceKeys.InvalidCpf,WindowsControlsResourceKeys.Root));
								ErrorOcurred(this, oArg); 
							}
							return true;
						}
					}
				}
			}
			else if (CultureInfo.CurrentCulture.Name == "es-DO")
			{
				return this.ValidateText();
			}

			return false;
		}

		protected virtual bool ValidateCnpj()
		{
			if (CultureInfo.CurrentCulture.Name == "pt-BR")
			{
				if (this.Required || this.TextLength > 0)
				{
					Regex regularExpr = new Regex(@"\d{2}.\d{3}.\d{3}[/]\d{4}-\d{2}");
					//
					if(!regularExpr.IsMatch(this.Text))
					{
						if (this.ErrorOcurred != null)
						{
							ErrorOcurredEventArgs oArg = new ErrorOcurredEventArgs(this.m_ErrorMessage != string.Empty ? this.m_ErrorMessage : ResourceLibrary.GetString(WindowsControlsResourceKeys.InvalidCnpjFormat,WindowsControlsResourceKeys.Root));
							ErrorOcurred(this, oArg); 
						}
						return true;
					}
					else
					{
						if (!ValidationDigits.IsCnpjOk(this.Text))
						{
							if (this.ErrorOcurred != null)
							{
								ErrorOcurredEventArgs oArg = new ErrorOcurredEventArgs(this.m_ErrorMessage != string.Empty ? this.m_ErrorMessage : ResourceLibrary.GetString(WindowsControlsResourceKeys.InvalidCnpj,WindowsControlsResourceKeys.Root));
								ErrorOcurred(this, oArg); 
							}
							return true;
						}
					}
				}
			}
			else if (CultureInfo.CurrentCulture.Name == "es-DO")
			{
				return this.ValidateText();
			}

			return false;
		}

		protected virtual bool ValidateTime()		
		{			
			if (this.Required || this.TextLength > 0)			
			{				
				DateTimeFormatInfo format = CultureInfo.CurrentCulture.DateTimeFormat;				
				//08-06-2003 - Geri Wolters: Code replaced. Made it more culture aware and let validation be handled by the DateTime class.
				try				
				{					
					DateTime.Parse(this.Text, format);					
					if (!CommonHelpers.IsDateOk(this.Text))					
					{						
						if (this.ErrorOcurred != null)						
						{							
							ErrorOcurredEventArgs oArg = new ErrorOcurredEventArgs(string.Format(this.m_ErrorMessage != string.Empty ? this.m_ErrorMessage : ResourceLibrary.GetString(WindowsControlsResourceKeys.InvalidTime,WindowsControlsResourceKeys.Root), format.ShortTimePattern));
							ErrorOcurred(this, oArg); 						
						}						
						return true;					
					}				
				}				
				catch				
				{					
					if (this.ErrorOcurred != null)					
					{						
						ErrorOcurredEventArgs oArg = new ErrorOcurredEventArgs(this.m_ErrorMessage != string.Empty ? this.m_ErrorMessage : ResourceLibrary.GetString(WindowsControlsResourceKeys.InvalidTimeFormat,WindowsControlsResourceKeys.Root));						
						ErrorOcurred(this, oArg); 					
					}					
					return true;				
				}			
			}			
			return false;		
		}
		
		protected virtual bool ValidateNumber()
		{
			if (this.Required && this.TextLength == 0)
			{
				if (this.ErrorOcurred != null)
				{
					ErrorOcurredEventArgs oArg = new ErrorOcurredEventArgs(this.m_ErrorMessage != string.Empty ? this.m_ErrorMessage : ResourceLibrary.GetString(CommonResourceKeys.RequiredField,CommonResourceKeys.Root));
					ErrorOcurred(this, oArg); 
				}
				return true;
			}
			else if (this.TextLength > 0)
			{
				if (!CommonHelpers.IsNumberOk(this.Text))
				{
					if (this.ErrorOcurred != null)
					{
						ErrorOcurredEventArgs oArg = new ErrorOcurredEventArgs(this.m_ErrorMessage != string.Empty ? this.m_ErrorMessage : ResourceLibrary.GetString(WindowsControlsResourceKeys.InvalidNumber,WindowsControlsResourceKeys.Root));
						ErrorOcurred(this, oArg); 
					}

					return true;
				}

				double decVal = CommonHelpers.StringToDouble(this.Text);
				if(decVal > this.mDecMaxValue || decVal < this.mDecMinValue)
				{
					if (this.ErrorOcurred != null)
					{
						ErrorOcurredEventArgs oArg = new ErrorOcurredEventArgs(String.Format(CultureInfo.CurrentCulture,
							                                                   this.m_ErrorMessage != string.Empty ? this.m_ErrorMessage : ResourceLibrary.GetString(WindowsControlsResourceKeys.InvalidNumberStrip,
							                                                   WindowsControlsResourceKeys.Root), 
							                                                   this.mDecMinValue.ToString(CultureInfo.CurrentCulture), 
							                                                   this.mDecMaxValue.ToString(CultureInfo.CurrentCulture)));
						ErrorOcurred(this, oArg); 
					}
					
					return true;
				}
			}

			if (this.TextLength > 0) 
			{
				this.Text = Convert.ToDecimal(this.Text, CultureInfo.CurrentCulture).ToString("N"+this.mDecPlaces.ToString(), CultureInfo.CurrentCulture);
			}
			return false;
		}

		protected virtual bool ValidateSr9Digits(string state)
		{
			Regex regularExpr = new Regex(@"\d{2}.\d{2}.\d{4}-\d{1}");
			//
			if(!regularExpr.IsMatch(this.Text))
			{
				if (this.ErrorOcurred != null)
				{
					ErrorOcurredEventArgs oArg = new ErrorOcurredEventArgs(String.Format(CultureInfo.CurrentCulture, 
						this.m_ErrorMessage != string.Empty ? this.m_ErrorMessage : ResourceLibrary.GetString(WindowsControlsResourceKeys.InvalidInscriptionFormat,WindowsControlsResourceKeys.Root), "00.00.0000-0."));
					ErrorOcurred(this, oArg); 
				}
				return true;
			}
			else
			{
				if (!ValidationDigits.IsSrOk(this.Text, state))
				{
					if (this.ErrorOcurred != null)
					{
						ErrorOcurredEventArgs oArg = new ErrorOcurredEventArgs(this.m_ErrorMessage != string.Empty ? this.m_ErrorMessage : ResourceLibrary.GetString(WindowsControlsResourceKeys.InvalidInscription,WindowsControlsResourceKeys.Root));
						ErrorOcurred(this, oArg); 
					}
					return true;
				}
			}
			return false;
		}

		protected virtual bool ValidateSr11Digits(string state)
		{
			Regex regularExpr = new Regex(@"\d{5}.\d{5}-\d{1}");
			//
			if(!regularExpr.IsMatch(this.Text))
			{
				if (this.ErrorOcurred != null)
				{
					ErrorOcurredEventArgs oArg = new ErrorOcurredEventArgs(String.Format(CultureInfo.CurrentCulture, 
						this.m_ErrorMessage != string.Empty ? this.m_ErrorMessage : ResourceLibrary.GetString(WindowsControlsResourceKeys.InvalidInscriptionFormat,WindowsControlsResourceKeys.Root), "00000.00000-0"));
					ErrorOcurred(this, oArg); 
				}
				return true;
			}
			else
			{
				if (!ValidationDigits.IsSrOk(this.Text, state))
				{
					if (this.ErrorOcurred != null)
					{
						ErrorOcurredEventArgs oArg = new ErrorOcurredEventArgs(this.m_ErrorMessage != string.Empty ? this.m_ErrorMessage : ResourceLibrary.GetString(WindowsControlsResourceKeys.InvalidInscription,WindowsControlsResourceKeys.Root));
						ErrorOcurred(this, oArg); 
					}
					return true;
				}
			}
			return false;
		}

		protected virtual bool ValidateSrDistritoFederal(string state)
		{
			Regex regularExpr = new Regex(@"\d{3}.\d{5}.\d{3}-\d{2}");
			//
			if(!regularExpr.IsMatch(this.Text))
			{
				if (this.ErrorOcurred != null)
				{
					ErrorOcurredEventArgs oArg = new ErrorOcurredEventArgs(String.Format(CultureInfo.CurrentCulture, 
						this.m_ErrorMessage != string.Empty ? this.m_ErrorMessage : ResourceLibrary.GetString(WindowsControlsResourceKeys.InvalidInscriptionFormat,WindowsControlsResourceKeys.Root), "000.00000.000-00"));
				}
				return true;
			}
			else
			{
				if (!ValidationDigits.IsSrOk(this.Text, state))
				{
					if (this.ErrorOcurred != null)
					{
						ErrorOcurredEventArgs oArg = new ErrorOcurredEventArgs(this.m_ErrorMessage != string.Empty ? this.m_ErrorMessage : ResourceLibrary.GetString(WindowsControlsResourceKeys.InvalidInscription,WindowsControlsResourceKeys.Root));
						ErrorOcurred(this, oArg); 
					}
					return true;
				}
			}
			return false;
		}
		
		protected virtual bool ValidateSrBahia(string state)
		{
			Regex regularExpr = new Regex(@"\d{3}.\d{3}-\d{2}");
			//
			if(!regularExpr.IsMatch(this.Text))
			{
				if (this.ErrorOcurred != null)
				{
					ErrorOcurredEventArgs oArg = new ErrorOcurredEventArgs(String.Format(CultureInfo.CurrentCulture, 
						this.m_ErrorMessage != string.Empty ? this.m_ErrorMessage : ResourceLibrary.GetString(WindowsControlsResourceKeys.InvalidInscriptionFormat,WindowsControlsResourceKeys.Root), "000.000-00"));
				}
				return true;
			}
			else
			{
				if (!ValidationDigits.IsSrOk(this.Text, state))
				{
					if (this.ErrorOcurred != null)
					{
						ErrorOcurredEventArgs oArg = new ErrorOcurredEventArgs(this.m_ErrorMessage != string.Empty ? this.m_ErrorMessage : ResourceLibrary.GetString(WindowsControlsResourceKeys.InvalidInscription,WindowsControlsResourceKeys.Root));
						ErrorOcurred(this, oArg); 
					}
					return true;
				}
			}
			return false;
		}

		protected virtual bool ValidateSrMinasGerais(string state)
		{
			Regex regularExpr = new Regex(@"\d{3}.\d{3}.\d{3}[/]\d{4}");
			//
			if(!regularExpr.IsMatch(this.Text))
			{
				if (this.ErrorOcurred != null)
				{
					ErrorOcurredEventArgs oArg = new ErrorOcurredEventArgs(String.Format(CultureInfo.CurrentCulture, 
						this.m_ErrorMessage != string.Empty ? this.m_ErrorMessage : ResourceLibrary.GetString(WindowsControlsResourceKeys.InvalidInscriptionFormat,WindowsControlsResourceKeys.Root), "000.000.000/0000"));
					ErrorOcurred(this, oArg); 
				}
				return true;
			}
			else
			{
				if (!ValidationDigits.IsSrOk(this.Text, state))
				{
					if (this.ErrorOcurred != null)
					{
						ErrorOcurredEventArgs oArg = new ErrorOcurredEventArgs(this.m_ErrorMessage != string.Empty ? this.m_ErrorMessage : ResourceLibrary.GetString(WindowsControlsResourceKeys.InvalidInscription,WindowsControlsResourceKeys.Root));
						ErrorOcurred(this, oArg); 
					}
					return true;
				}
			}
			return false;
		}

		protected virtual bool ValidateSrParana(string state)
		{
			Regex regularExpr = new Regex(@"\d{3}.\d{4}-\d{2}");
			//
			if(!regularExpr.IsMatch(this.Text))
			{
				if (this.ErrorOcurred != null)
				{
					ErrorOcurredEventArgs oArg = new ErrorOcurredEventArgs(String.Format(CultureInfo.CurrentCulture, 
						this.m_ErrorMessage != string.Empty ? this.m_ErrorMessage : ResourceLibrary.GetString(WindowsControlsResourceKeys.InvalidInscriptionFormat,WindowsControlsResourceKeys.Root), "000.0000-00"));
					ErrorOcurred(this, oArg); 
				}
				return true;
			}
			else
			{
				if (!ValidationDigits.IsSrOk(this.Text, state))
				{
					if (this.ErrorOcurred != null)
					{
						ErrorOcurredEventArgs oArg = new ErrorOcurredEventArgs(this.m_ErrorMessage != string.Empty ? this.m_ErrorMessage : ResourceLibrary.GetString(WindowsControlsResourceKeys.InvalidInscription,WindowsControlsResourceKeys.Root));
						ErrorOcurred(this, oArg); 
					}
					return true;
				}
			}
			return false;
		}

		protected virtual bool ValidateSrPernambuco(string state)
		{
			Regex regularExpr = new Regex(@"\d{2}.\d{1}.\d{3}.\d{7}-\d{1}");
			//
			if(!regularExpr.IsMatch(this.Text))
			{
				if (this.ErrorOcurred != null)
				{
					ErrorOcurredEventArgs oArg = new ErrorOcurredEventArgs(String.Format(CultureInfo.CurrentCulture, 
						this.m_ErrorMessage != string.Empty ? this.m_ErrorMessage : ResourceLibrary.GetString(WindowsControlsResourceKeys.InvalidInscriptionFormat,WindowsControlsResourceKeys.Root), "00.0.000.0000000-0"));
					ErrorOcurred(this, oArg); 
				}
				return true;
			}
			else
			{
				if (!ValidationDigits.IsSrOk(this.Text, state))
				{
					if (this.ErrorOcurred != null)
					{
						ErrorOcurredEventArgs oArg = new ErrorOcurredEventArgs(this.m_ErrorMessage != string.Empty ? this.m_ErrorMessage : ResourceLibrary.GetString(WindowsControlsResourceKeys.InvalidInscription,WindowsControlsResourceKeys.Root));
						ErrorOcurred(this, oArg); 
					}
					return true;
				}
			}
			return false;
		}

		protected virtual bool ValidateSrRioDeJaneiro(string state)
		{
			Regex regularExpr = new Regex(@"\d{2}.\d{3}.\d{2}-\d{1}");
			//
			if(!regularExpr.IsMatch(this.Text))
			{
				if (this.ErrorOcurred != null)
				{
					ErrorOcurredEventArgs oArg = new ErrorOcurredEventArgs(String.Format(CultureInfo.CurrentCulture, 
						this.m_ErrorMessage != string.Empty ? this.m_ErrorMessage : ResourceLibrary.GetString(WindowsControlsResourceKeys.InvalidInscriptionFormat,WindowsControlsResourceKeys.Root), "00.000.00-0"));
					ErrorOcurred(this, oArg); 
				}
				return true;
			}
			else
			{
				if (!ValidationDigits.IsSrOk(this.Text, state))
				{
					if (this.ErrorOcurred != null)
					{
						ErrorOcurredEventArgs oArg = new ErrorOcurredEventArgs(this.m_ErrorMessage != string.Empty ? this.m_ErrorMessage : ResourceLibrary.GetString(WindowsControlsResourceKeys.InvalidInscription,WindowsControlsResourceKeys.Root));
						ErrorOcurred(this, oArg); 
					}
					return true;
				}
			}
			return false;
		}

		protected virtual bool ValidateSrRioGrandeDoSul(string state)
		{
			Regex regularExpr = new Regex(@"\d{3}.\d{6}-\d{1}");
			//
			if(!regularExpr.IsMatch(this.Text))
			{
				if (this.ErrorOcurred != null)
				{
					ErrorOcurredEventArgs oArg = new ErrorOcurredEventArgs(String.Format(CultureInfo.CurrentCulture, 
						this.m_ErrorMessage != string.Empty ? this.m_ErrorMessage : ResourceLibrary.GetString(WindowsControlsResourceKeys.InvalidInscriptionFormat,WindowsControlsResourceKeys.Root), "000.000000-0"));
					ErrorOcurred(this, oArg); 
				}
				return true;
			}
			else
			{
				if (!ValidationDigits.IsSrOk(this.Text, state))
				{
					if (this.ErrorOcurred != null)
					{
						ErrorOcurredEventArgs oArg = new ErrorOcurredEventArgs(this.m_ErrorMessage != string.Empty ? this.m_ErrorMessage : ResourceLibrary.GetString(WindowsControlsResourceKeys.InvalidInscription,WindowsControlsResourceKeys.Root));
						ErrorOcurred(this, oArg); 
					}
					return true;
				}
			}
			return false;
		}

		protected virtual bool ValidateSrSaoPaulo(string state)
		{
			Regex regularExpr = new Regex(@"\d{3}.\d{3}.\d{3}.\d{3}|[P]-\d{8}.\d{1}[/]\d{3}");
			//
			if(!regularExpr.IsMatch(this.Text))
			{
				if (this.ErrorOcurred != null)
				{
					ErrorOcurredEventArgs oArg = new ErrorOcurredEventArgs(String.Format(CultureInfo.CurrentCulture, 
						this.m_ErrorMessage != string.Empty ? this.m_ErrorMessage : ResourceLibrary.GetString(WindowsControlsResourceKeys.InvalidInscriptionFormat,WindowsControlsResourceKeys.Root), "000.000.000.000 ; P-00000000.0/000"));
					ErrorOcurred(this, oArg); 
				}
				return true;
			}
			else
			{
				if (!ValidationDigits.IsSrOk(this.Text, state))
				{
					if (this.ErrorOcurred != null)
					{
						ErrorOcurredEventArgs oArg = new ErrorOcurredEventArgs(this.m_ErrorMessage != string.Empty ? this.m_ErrorMessage : ResourceLibrary.GetString(WindowsControlsResourceKeys.InvalidInscription,WindowsControlsResourceKeys.Root));
						ErrorOcurred(this, oArg); 
					}
					return true;
				}
			}
			return false;
		}

		#endregion

		#region Internal helpers

		private bool ValidateDate()		
		{			
			if (this.Required || this.TextLength > 0)			
			{								
				DateTimeFormatInfo format = CultureInfo.CurrentCulture.DateTimeFormat;				
				//08-06-2003 - Geri Wolters: Code replaced. Made it more culture aware and let validation be handled by the DateTime class.
				try				{					
					DateTime.Parse(this.Text, format);				
				}				
				catch				
				{					
					if (this.ErrorOcurred != null)					
					{						
						string sDateFormat = format.ShortDatePattern;													
						ErrorOcurredEventArgs oArg = new ErrorOcurredEventArgs(string.Format(this.m_ErrorMessage != string.Empty ? this.m_ErrorMessage : ResourceLibrary.GetString(WindowsControlsResourceKeys.InvalidDateFormat,WindowsControlsResourceKeys.Root), sDateFormat));						
						ErrorOcurred(this, oArg); 					
					}					
					return true;				
				}			
			}			
			return false;		
		}
		
		private bool ValidateIp()
		{
			if (this.Required || this.TextLength > 0)
			{
				Regex regularExpr = new Regex(@"^(25[0-5]|2[0-4][0-9]|[0-1]{1}[0-9]{2}|[1-9]{1}[0-9]{1}|[1-9])\.(25[0-5]|2[0-4][0-9]|[0-1]{1}[0-9]{2}|[1-9]{1}[0-9]{1}|[1-9]|0)\.(25[0-5]|2[0-4][0-9]|[0-1]{1}[0-9]{2}|[1-9]{1}[0-9]{1}|[1-9]|0)\.(25[0-5]|2[0-4][0-9]|[0-1]{1}[0-9]{2}|[1-9]{1}[0-9]{1}|[0-9])$");
				//
				if(!regularExpr.IsMatch(this.Text))
				{
					if (this.ErrorOcurred != null)
					{
						ErrorOcurredEventArgs oArg = new ErrorOcurredEventArgs(this.m_ErrorMessage != string.Empty ? this.m_ErrorMessage : ResourceLibrary.GetString(WindowsControlsResourceKeys.InvalidIp,WindowsControlsResourceKeys.Root));
						ErrorOcurred(this, oArg); 
					}
					return true;
				}
			}
			return false;
		}

		#endregion

		#region Methods

		public bool ValidateCep(string state)
		{
			if (CultureInfo.CurrentCulture.Name == "pt-BR")
			{
				if (this.Required || this.TextLength > 0)
				{
					Regex regularExpr = new Regex(@"\d{5}-\d{3}");
					//
					if(!regularExpr.IsMatch(this.Text))
					{
						if (this.ErrorOcurred != null)
						{
							ErrorOcurredEventArgs oArg = new ErrorOcurredEventArgs(this.m_ErrorMessage != string.Empty ? this.m_ErrorMessage : ResourceLibrary.GetString(WindowsControlsResourceKeys.InvalidZipFormat,WindowsControlsResourceKeys.Root));
							ErrorOcurred(this, oArg); 
						}
						return true;
					}
					else
					{
						if (state.Length == 0 ||
							!ValidationDigits.IsCepOk(this.Text, state))
						{
							if (this.ErrorOcurred != null)
							{
								ErrorOcurredEventArgs oArg = new ErrorOcurredEventArgs(this.m_ErrorMessage != string.Empty ? this.m_ErrorMessage : ResourceLibrary.GetString(WindowsControlsResourceKeys.InvalidZip,WindowsControlsResourceKeys.Root));
								ErrorOcurred(this, oArg); 
							}
							return true;
						}
					}
				}
			}
			else if (CultureInfo.CurrentCulture.Name == "es-DO")
			{
				return this.ValidateText();
			}

			return false;
		}

		public bool ValidateInscricaoEstadual(string state)
		{
			if (CultureInfo.CurrentCulture.Name == "pt-BR")
			{
				if (this.Required || this.TextLength > 0)
				{
					if (state == BrazilStates.AC.ToString(CultureInfo.CurrentCulture) ||
						state == BrazilStates.AP.ToString(CultureInfo.CurrentCulture) ||
						state == BrazilStates.AL.ToString(CultureInfo.CurrentCulture) ||
						state == BrazilStates.AM.ToString(CultureInfo.CurrentCulture) ||
						state == BrazilStates.CE.ToString(CultureInfo.CurrentCulture) ||
						state == BrazilStates.PA.ToString(CultureInfo.CurrentCulture) ||
						state == BrazilStates.PB.ToString(CultureInfo.CurrentCulture) ||
						state == BrazilStates.PI.ToString(CultureInfo.CurrentCulture) ||
						state == BrazilStates.RN.ToString(CultureInfo.CurrentCulture) ||
						state == BrazilStates.RR.ToString(CultureInfo.CurrentCulture) ||
						state == BrazilStates.RO.ToString(CultureInfo.CurrentCulture) ||
						state == BrazilStates.SC.ToString(CultureInfo.CurrentCulture) ||
						state == BrazilStates.ES.ToString(CultureInfo.CurrentCulture) ||
						state == BrazilStates.GO.ToString(CultureInfo.CurrentCulture) ||
						state == BrazilStates.MA.ToString(CultureInfo.CurrentCulture) ||
						state == BrazilStates.MS.ToString(CultureInfo.CurrentCulture) ||
						state == BrazilStates.SE.ToString(CultureInfo.CurrentCulture)) return  ValidateSr9Digits(state);
					else if (state == BrazilStates.DF.ToString(CultureInfo.CurrentCulture)) return ValidateSrDistritoFederal(state);
					else if (state == BrazilStates.BA.ToString(CultureInfo.CurrentCulture)) return ValidateSrBahia(state);
					else if (state == BrazilStates.MT.ToString(CultureInfo.CurrentCulture) ||
						state == BrazilStates.TO.ToString(CultureInfo.CurrentCulture)) return  ValidateSr11Digits(state);
					else if (state == BrazilStates.MG.ToString(CultureInfo.CurrentCulture)) return ValidateSrMinasGerais(state);
					else if (state == BrazilStates.PR.ToString(CultureInfo.CurrentCulture)) return ValidateSrParana(state);
					else if (state == BrazilStates.PE.ToString(CultureInfo.CurrentCulture)) return ValidateSrPernambuco(state);
					else if (state == BrazilStates.RJ.ToString(CultureInfo.CurrentCulture)) return ValidateSrRioDeJaneiro(state);
					else if (state == BrazilStates.RS.ToString(CultureInfo.CurrentCulture)) return ValidateSrRioGrandeDoSul(state);
					else if (state == BrazilStates.SP.ToString(CultureInfo.CurrentCulture)) return ValidateSrSaoPaulo(state);
				}
			}
			else if (CultureInfo.CurrentCulture.Name == "es-DO")
			{
				return this.ValidateText();
			}

			return false;
		}

		#endregion

		#region Properties

		//2002-08-07 - GWO - Added to accept regular expressions.
		public string RegularExpression
		{
			get {return this.mRegExp;}
			set {this.mRegExp = value;}
		}

		//2002-08-24 - GWO - Added to accept custom messages.
		public string ErrorMessage
		{
			get {return this.m_ErrorMessage;}
			set {this.m_ErrorMessage = value;}
		}

		[Browsable(false)]
		public bool ValidWithMask
		{
			get
			{
				if (!this.mValidWithMask)
					this.OnValidating(new CancelEventArgs());

				return this.mValidWithMask;
			}
		}
	
		public EditMask Mask
		{
			get {return mMask;}

			set
			{ 
				mMask = value;
				this.Text = String.Empty;
			}
		}

		public int DecimalPlaces
		{
			get {return mDecPlaces;}
			set {mDecPlaces = value;}
		}
		
		[Browsable(true),
		DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		public DateTime DateValue
		{
			get
			{
				if(this.Mask == EditMask.Date && CommonHelpers.IsDateOk(this.Text))
				{
					return Convert.ToDateTime(this.Text, CultureInfo.CurrentCulture);
				}
				else 
				{
					return DateTime.Today;
				}
			}
			set
			{
				if(this.Mask == EditMask.Date)
					this.Text = CommonHelpers.DateToString(value);
			}
		}

		[Browsable(false),
		DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		public double DoubleValue
		{
			get
			{ 
				if(this.Mask == EditMask.Numeric && CommonHelpers.IsNumberOk(this.Text))
				{
					return Convert.ToDouble(this.Text, CultureInfo.CurrentCulture);
				}
				else
				{
					return 0;
				}
			}

			set
			{
				if(this.Mask == EditMask.Numeric)
				{
					this.Text = value.ToString("N"+this.mDecPlaces.ToString(), CultureInfo.CurrentCulture);
				}
			}
		}

		[Browsable(true),
		DesignerSerializationVisibility(DesignerSerializationVisibility.Visible)]
		public override string Text
		{
			get	{return base.Text;}
			set	{base.Text = value;}
		}

		public int DecMinValue
		{
			get {return mDecMinValue;}
			set {mDecMinValue = value;}
		}

		public int DecMaxValue
		{
			get {return mDecMaxValue;}
			set {mDecMaxValue = value;}
		}

		public bool Required
		{
			get	{return mRequired;}
			set	{mRequired = value;}
		}

		public string NotAcceptsChars
		{
			get {return mNotAcceptsChars;}
			set {mNotAcceptsChars = value;}
		}

		#endregion
	}
}