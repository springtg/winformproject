using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;

namespace PallaControls.Windows.Forms
{
	[ToolboxItem(true)]
	public class LineFrame : System.Windows.Forms.Control
	{
		#region Constructors
		
		public LineFrame()
		{
		}

		#endregion

		#region Overrides
		
		protected override void OnPaint(PaintEventArgs pe)
		{
			Graphics g = pe.Graphics;
			using(Pen p = new Pen(Color.FromArgb(128, 128, 128)))
			{
				g.DrawLine(p, new Point(0, 0), new Point(Width, 0));
			}
			g.DrawLine(Pens.White, new Point(0, 1), new Point(Width, 1));

			base.OnPaint(pe);
		}

		#endregion

		#region Properties
		
		[DefaultValue(typeof(Size), "75, 2")]
		protected new Size Size
		{
			get
			{
				return base.Size;
			}
			set
			{
				base.Size = value;
			}
		}

		[Browsable(true)]
		[Category("Layout")]
		public new int Width
		{
			get
			{
				return Size.Width;
			}
			set
			{
				Size = new Size(value, 2);
			}
		}

		#endregion
	}
}
