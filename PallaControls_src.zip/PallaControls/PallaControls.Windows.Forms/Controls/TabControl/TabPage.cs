using System;
using System.IO;
using System.Drawing;
using System.Resources;
using System.Reflection;
using System.Collections;
using System.Windows.Forms;
using System.ComponentModel;
using PallaControls.Windows.Forms.Collections;

namespace PallaControls.Windows.Forms
{
    [ToolboxItem(false)]
    [DefaultProperty("Title")]
    [DefaultEvent("PropertyChanged")]
    public class TabPage : PanelBase
    {
		#region PropChangeEventArgs

		public class PropChangeEventArgs : EventArgs
		{
			private TabPage item = null;
			private string prop = String.Empty;
			private object oldValue = null;

			public PropChangeEventArgs(TabPage item, string prop, object oldValue)
			{
				this.item = item;
				this.prop = prop;
				this.oldValue = oldValue;
			}

			public TabPage Page
			{
				get {return this.item;}
			}

			public string PropertyName
			{
				get {return this.prop;}
			}
		
			public object OldValue
			{
				get {return this.oldValue;}
			}
		}

		#endregion

		public delegate void PropChangeEventHandler(object sender, PropChangeEventArgs e);
		public event PropChangeEventHandler PropertyChanged;

		protected string mtitle;
        protected Control mcontrol;
        protected int mimageIndex;
        protected ImageList mimageList;
        protected Icon micon;
        protected bool mselected;
		protected Control mstartFocus;
		protected bool mshown;

		#region Constructors

		public TabPage()
        {
            InternalConstruct("Page", null, null, -1, null);
        }

        public TabPage(string title)
        {
            InternalConstruct(title, null, null, -1, null);
        }

        public TabPage(string title, Control control)
        {
            InternalConstruct(title, control, null, -1, null);
        }
			
        public TabPage(string title, Control control, int imageIndex)
        {
            InternalConstruct(title, control, null, imageIndex, null);
        }

        public TabPage(string title, Control control, ImageList imageList, int imageIndex)
        {
            InternalConstruct(title, control, imageList, imageIndex, null);
        }

        public TabPage(string title, Control control, Icon icon)
        {
            InternalConstruct(title, control, null, -1, icon);
        }

        protected void InternalConstruct(string title, 
                                         Control control, 
                                         ImageList imageList, 
                                         int imageIndex,
                                         Icon icon)
        {
            mtitle = title;
            mcontrol = control;
            mimageIndex = imageIndex;
            mimageList = imageList;
            micon = icon;

            mselected = false;
			mstartFocus = null;
        }

		#endregion

		#region Virtual

		public virtual void OnPropertyChanged(PropChangeEventArgs e)
		{
			if (PropertyChanged != null)
				PropertyChanged(this, e);
		}

		#endregion

		#region Properties

		[DefaultValue("Page")]
        [Localizable(true)]
        public string Title
        {
            get { return mtitle; }
		   
            set 
            { 
                if (mtitle != value)
                {
                    string oldValue = mtitle;
                    mtitle = value; 

                    OnPropertyChanged(new PropChangeEventArgs(this, "Title", oldValue));
                }
            }
        }

        [DefaultValue(null)]
        public Control Control
        {
            get { return mcontrol; }

            set 
            { 
                if (mcontrol != value)
                {
                    Control oldValue = mcontrol;
                    mcontrol = value; 

                    OnPropertyChanged(new PropChangeEventArgs(this, "Control", oldValue));
                }
            }
        }

        [DefaultValue(-1)]
        public int ImageIndex
        {
            get { return mimageIndex; }
		
            set 
            { 
                if (mimageIndex != value)
                {
                    int oldValue = mimageIndex;
                    mimageIndex = value; 

                    OnPropertyChanged(new PropChangeEventArgs(this, "ImageIndex", oldValue));
                }
            }
        }

        [DefaultValue(null)]
        public ImageList ImageList
        {
            get { return mimageList; }
		
            set 
            { 
                if (mimageList != value)
                {
                    ImageList oldValue = mimageList;
                    mimageList = value; 

					OnPropertyChanged(new PropChangeEventArgs(this, "ImageList", oldValue));
                }
            }
        }

        [DefaultValue(null)]
        public Icon Icon
        {
            get { return micon; }
		
            set 
            { 
                if (micon != value)
                {
                    Icon oldValue = micon;
                    micon = value; 

					OnPropertyChanged(new PropChangeEventArgs(this, "Icon", oldValue));
                }
            }
        }

        [DefaultValue(true)]
        public bool Selected
        {
            get { return mselected; }

            set
            {
                if (mselected != value)
                {
                    bool oldValue = mselected;
                    mselected = value;

                    OnPropertyChanged(new PropChangeEventArgs(this, "Selected", oldValue));
                }
            }
        }

        [DefaultValue(null)]
        public Control StartFocus
        {
            get { return mstartFocus; }
            set { mstartFocus = value; }
        }

		internal bool Shown
		{
			get { return mshown; }
			set { mshown = value; }
		}

		#endregion
    }
}
