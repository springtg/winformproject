using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Security.Permissions;
using System.Windows.Forms;
using System.Windows.Forms.Design;
using PallaControls.Windows.Forms.Collections; 
using PallaControls.Utilities.Win32;
using PallaControls.Utilities;

namespace PallaControls.Windows.Forms
{
    public class TabControlDesigner :  System.Windows.Forms.Design.ParentControlDesigner
    {
        private ISelectionService _selectionService = null;

		#region Properties

		public ISelectionService SelectionService
        {
            get
            {
                if (_selectionService == null)
                {
                    _selectionService = (ISelectionService)GetService(typeof(ISelectionService));
                }

                return _selectionService;
            }
        }

        protected override bool DrawGrid
        {
            get { return false; }
        }

		#endregion

		#region Overrides

		public override ICollection AssociatedComponents
		{
			get 
			{
				if (base.Control is TabControl)
					return ((TabControl)base.Control).TabPages;
				else
					return base.AssociatedComponents;
			}
		}

        [UseApiElements("WM_LBUTTONDOWN, WM_LBUTTONDBLCLK")]
		[SecurityPermission(SecurityAction.LinkDemand)]
		protected override void WndProc(ref Message msg)
        {
            if (msg.Msg == (int)Msgs.WM_LBUTTONDOWN)
            {
                TabControl tabControl = this.SelectionService.PrimarySelection as TabControl;

                if (tabControl != null)
                {
                    int xPos = (short)((uint)msg.LParam & 0x0000FFFFU);
                    int yPos = (short)(((uint)msg.LParam & 0xFFFF0000U) >> 16);

                    tabControl.ExternalMouseTest(msg.HWnd, new Point(xPos, yPos));
                }
            }
            else
            {
                if (msg.Msg == (int)Msgs.WM_LBUTTONDBLCLK)
                {
                    TabControl tabControl = this.SelectionService.PrimarySelection as TabControl;

                    if (tabControl != null)
                    {
                        int xPos = (short)((uint)msg.LParam & 0x0000FFFFU);
                        int yPos = (short)(((uint)msg.LParam & 0xFFFF0000U) >> 16);

                        if (tabControl.WantDoubleClick(msg.HWnd, new Point(xPos, yPos)))
                            return;
                    }
                }
            }

            base.WndProc(ref msg);
        }

		#endregion
    }
}
