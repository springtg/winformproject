using System;
using System.Data;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Text;
using System.Drawing.Drawing2D;
using System.Windows.Forms;
using PallaControls.Utilities.Drawing;
using PallaControls.Windows.Forms.Helpers;

namespace PallaControls.Windows.Forms
{
	[System.ComponentModel.ToolboxItem(true)]
	public class GroupBox : PallaControls.Windows.Forms.PanelBase, PallaControls.Windows.Forms.IFlashabledControl
	{
		private System.ComponentModel.Container components = null;
		private Single m_Radius = 0;
		private string m_Text = String.Empty;
		private int m_TextOffSet = 6; 
		//Style Neo, default!
		private Color m_PanelClientAreaColor = Color.FromArgb(242, 242, 228);
		private Color m_BorderColor = Color.FromArgb(222, 217, 207);
		private Color m_BorderHotColor = Color.FromArgb(222, 217, 207);
		private Color m_TextColor = Color.Black;

		#region Constructors
		
		public GroupBox()
		{
			InitializeComponent();
		}

		#endregion

		#region Dispose

		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#endregion

		#region Component Designer generated code

		private void InitializeComponent()
		{
			components = new System.ComponentModel.Container();
		}

		#endregion

		#region Overrides
		
		protected override void OnStyleChanged(object sender, StyleEventArgs args)
		{
			base.OnStyleChanged(sender, args);

			if (args.PropertyName == "TextColor") {this.m_TextColor = (Color)args.PropertyValue;}
			else if (args.PropertyName == "PanelClientAreaColor") {this.m_PanelClientAreaColor = (Color)args.PropertyValue;}
			else if (args.PropertyName == "BorderColor") {this.BorderColor = (Color)args.PropertyValue;}
			else if (args.PropertyName == "BorderHotColor") {this.BorderHotColor = (Color)args.PropertyValue;}

			this.Invalidate(true);
		}

		protected override void OnPlansOfColorsChanged(object sender, PlansOfColorsChangedEventArgs args)
		{
			base.OnPlansOfColorsChanged(sender, args);

			if (this.Style!=null)
			{
				this.m_TextColor = this.Style.TextColor;
				this.m_PanelClientAreaColor = this.Style.PanelClientAreaColor;
				this.m_BorderColor = this.Style.BorderColor;
				this.m_BorderHotColor = this.Style.BorderHotColor;
			}

			this.Invalidate(true);
		}
		
		protected override void OnPaint(System.Windows.Forms.PaintEventArgs e)
		{
			StringFormat format  = new StringFormat();
			format.LineAlignment = StringAlignment.Center;
			format.Alignment     = StringAlignment.Near;
			format.HotkeyPrefix  = HotkeyPrefix.Show;

			float textWidth = e.Graphics.MeasureString(this.m_Text, this.Font, this.Width-10, format).Width;
			float textHeight = e.Graphics.MeasureString(this.m_Text, this.Font, this.Width-10, format).Height;

			using (Pen pen1 = new Pen(this.Style!=null?this.Style.InteliBorderColor(false):StyleGuide.InteliBorderColor(false, this.BorderHotColor, this.BorderColor)))
			{
				this.BackColor = this.Parent.BackColor;

				Rectangle groupRect = this.ClientRectangle;
			
				if (m_Text.Length > 0) 
				{
					groupRect.Y      = this.ClientRectangle.Y + ((int)textHeight/2);
					groupRect.X      = 5;
					groupRect.Height = this.ClientRectangle.Height - (int)textHeight;
					groupRect.Width  = this.ClientRectangle.Width  - 10;
				}
				else 
				{
					groupRect.Offset(5,5);
					groupRect.Height -= 10;
					groupRect.Width  -= 10;
				}
			
				GraphicsPath path = DrawHelpers.GetRoundedRect(groupRect, m_Radius);
				e.Graphics.DrawPath(pen1, path);
			
				if (this.PanelClientAreaColor != this.Parent.BackColor)
					e.Graphics.FillPath(new SolidBrush(this.PanelClientAreaColor),path);

				RectangleF txtRect = new RectangleF(3+this.Radius,0, textWidth, textHeight);
				using (SolidBrush brushText = new SolidBrush(this.ForeColor),
					brushTextRect = new SolidBrush(this.Parent.BackColor))
				{
					e.Graphics.FillRectangle(brushTextRect, 10+this.Radius,0, textWidth-6, textHeight);
					e.Graphics.DrawString(m_Text,this.Font,brushText,txtRect,format);
				}
			}
		}		

		#endregion

		#region Properties

		[Category("Style")]
		public Color BorderColor
		{
			get {return m_BorderColor;}
			set 
			{
				m_BorderColor = value;
				this.Invalidate(true);
			}
		}

		[Category("Style")]
		public Color BorderHotColor
		{
			get {return m_BorderHotColor;}
			set 
			{
				m_BorderHotColor = value;
				this.Invalidate(true);
			}
		}

		[Category("Style")]
		public Color TextColor
		{
			get {return m_TextColor;}
			set 
			{
				m_TextColor = value;
				this.Invalidate();
			}
		}

		[Category("Style")]
		public Color PanelClientAreaColor
		{
			get {return m_PanelClientAreaColor;}
			set 
			{
				m_PanelClientAreaColor = value;
				this.Invalidate();
			}
		}

		[Category("Appearance")]
		public Single Radius
		{
			get
			{ 
				return m_Radius; 
			}
			set
			{
				m_Radius = value;
				this.Invalidate(false);
			}
		}

		[Category("Appearance")]
		public int TextOffSet
		{
			get
			{ 
				return m_TextOffSet; 
			}
			set
			{
				m_TextOffSet = value;
				this.Invalidate(false);
			}
		}

		[Browsable(true),
		Bindable(true),
		Category("Appearance")]
		public override string Text
		{
			get
			{ 
				return m_Text; 
			}
			set
			{
				m_Text = value;
				this.Invalidate(false);
			}
		}

		#endregion

		#region IFlashabledControl

		public void FlashControl()
		{
			foreach(Control m_Control in this.Controls)
			{
				if (m_Control is IFlashabledControl) 
				{
					((IFlashabledControl)m_Control).FlashControl();
				}
			}
		}
		
		#endregion
	}
}
