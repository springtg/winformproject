using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;


namespace PallaControls.Windows.Forms
{
	[ToolboxItem(true)]
	public class DataGrid : System.Windows.Forms.DataGrid, IHasStyleControl
	{
		private StyleGuide m_enterpriseStyle = null;
		private bool parentStyle = false;
		
		#region Constructors

		public DataGrid()
		{
			this.FlatMode = true;
			this.BorderStyle = BorderStyle.None;
		}

		#endregion

		#region Virtuals

		protected virtual void OnStyleChanged(object sender, StyleEventArgs args)
		{
			if (args.PropertyName == "DataGridAlternatingBackColor") {this.AlternatingBackColor = (Color)args.PropertyValue;}
			else if (args.PropertyName == "DataGridBackColor") {this.BackColor = (Color)args.PropertyValue;}
			else if (args.PropertyName == "DataGridBackgroundColor") {this.BackgroundColor = (Color)args.PropertyValue;}
			else if (args.PropertyName == "DataGridCaptionBackColor") {this.CaptionBackColor = (Color)args.PropertyValue;}
			else if (args.PropertyName == "DataGridCaptionForeColor") {this.CaptionForeColor = (Color)args.PropertyValue;}
			else if (args.PropertyName == "DataGridForeColor") {this.ForeColor = (Color)args.PropertyValue;}
			else if (args.PropertyName == "DataGridLineColor") {this.GridLineColor = (Color)args.PropertyValue;}
			else if (args.PropertyName == "DataGridHeaderBackColor") {this.HeaderBackColor = (Color)args.PropertyValue;}
			else if (args.PropertyName == "DataGridHeaderForeColor") {this.HeaderForeColor = (Color)args.PropertyValue;}
			else if (args.PropertyName == "DataGridLinkColor") {this.LinkColor = (Color)args.PropertyValue;}
			else if (args.PropertyName == "DataGridParentRowsBackColor") {this.ParentRowsBackColor = (Color)args.PropertyValue;}
			else if (args.PropertyName == "DataGridParentRowsForeColor") {this.ParentRowsForeColor = (Color)args.PropertyValue;}
			else if (args.PropertyName == "DataGridSelectionBackColor") {this.SelectionBackColor = (Color)args.PropertyValue;}
			else if (args.PropertyName == "DataGridSelectionForeColor") {this.SelectionForeColor = (Color)args.PropertyValue;}
		}

		protected virtual  void OnPlansOfColorsChanged(object sender, PlansOfColorsChangedEventArgs args)
		{
			if (m_enterpriseStyle !=null) 
			{
				this.AlternatingBackColor = m_enterpriseStyle.DataGridAlternatingBackColor;
				this.BackColor = m_enterpriseStyle.DataGridBackColor;
				this.BackgroundColor = m_enterpriseStyle.DataGridBackgroundColor;
				this.CaptionBackColor = m_enterpriseStyle.DataGridCaptionBackColor;
				this.CaptionForeColor = m_enterpriseStyle.DataGridCaptionForeColor;
				this.ForeColor = m_enterpriseStyle.DataGridForeColor;
				this.GridLineColor = m_enterpriseStyle.DataGridLineColor;
				this.HeaderBackColor = m_enterpriseStyle.DataGridHeaderBackColor;
				this.HeaderForeColor = m_enterpriseStyle.DataGridHeaderForeColor;
				this.LinkColor = m_enterpriseStyle.DataGridLinkColor;
				this.ParentRowsBackColor = m_enterpriseStyle.DataGridParentRowsBackColor;
				this.ParentRowsForeColor = m_enterpriseStyle.DataGridParentRowsForeColor;
				this.SelectionBackColor = m_enterpriseStyle.DataGridSelectionBackColor;
				this.SelectionForeColor = m_enterpriseStyle.DataGridSelectionForeColor;
			}
		}

		#endregion

		#region Properties

		[Category("Style")]
		public StyleGuide Style
		{
			get {return m_enterpriseStyle;}
			set 
			{
				m_enterpriseStyle = value;

				if (m_enterpriseStyle != null)
				{
					PlansOfColorsChangedEventArgs oArgs = new PlansOfColorsChangedEventArgs(m_enterpriseStyle.PlansOfColors);
					OnPlansOfColorsChanged(this, oArgs);

					m_enterpriseStyle.StyleChanged += new StyleChangedEventHandler(this.OnStyleChanged);
					m_enterpriseStyle.PlansOfColorsChanged += new PlansOfColorsChangedEventHandler(this.OnPlansOfColorsChanged);
				}
			}
		}

		[Category("Behavior")]
		public bool ParentStyle
		{
			get {return parentStyle;}
			set {parentStyle = value;}
		}

		#endregion

		#region IHasStyleControl

		public StyleGuide GetStyle()
		{
			return this.m_enterpriseStyle;
		}

		public void SetStyle(StyleGuide style)
		{
			this.m_enterpriseStyle = style;
		}

		public bool GetParentStyle()
		{
			return this.parentStyle;
		}

		#endregion
	}
}

