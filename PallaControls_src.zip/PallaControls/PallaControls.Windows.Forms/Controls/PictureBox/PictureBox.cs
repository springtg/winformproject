using System;
using System.Data;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace PallaControls.Windows.Forms
{
	[System.ComponentModel.ToolboxItem(true)]
	public class PictureBox : PallaControls.Windows.Forms.ControlBase
	{
		private System.Windows.Forms.PictureBox pb_Figure;
		private System.ComponentModel.Container components = null;
		//Style default, neo
		private Color m_TextColor = Color.Black;
		private Color m_PictureBoxColor = Color.FromArgb(242, 242, 228);

		#region Constructors

		public PictureBox()
		{
			InitializeComponent();
		}

		#endregion

		#region Dispose

		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#endregion

		#region Component Designer generated code
		private void InitializeComponent()
		{
			this.pb_Figure = new System.Windows.Forms.PictureBox();
			this.SuspendLayout();
			// 
			// pb_Figure
			// 
			this.pb_Figure.Anchor = (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right);
			this.pb_Figure.Location = new System.Drawing.Point(1, 1);
			this.pb_Figure.Name = "pb_Figure";
			this.pb_Figure.Size = new System.Drawing.Size(98, 98);
			this.pb_Figure.TabIndex = 0;
			this.pb_Figure.TabStop = false;
			// 
			// EnterprisePictureBox
			// 
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.pb_Figure});
			this.Name = "PictureBox";
			this.Size = new System.Drawing.Size(100, 100);
			this.ResumeLayout(false);
		}
		#endregion

		#region Overrides

		protected override void OnStyleChanged(object sender, StyleEventArgs args)
		{
			base.OnStyleChanged(sender, args);

			if (args.PropertyName == "PictureBoxColor") {this.PictureBoxColor = (Color)args.PropertyValue;}
			else if (args.PropertyName == "TextColor") {this.TextColor = (Color)args.PropertyValue;}

			this.Invalidate(true);
		}

		protected override void OnPlansOfColorsChanged(object sender, PlansOfColorsChangedEventArgs args)
		{
			base.OnPlansOfColorsChanged(sender, args);

			if (this.Style != null)
			{
				this.TextColor = this.Style.TextColor;
				this.PictureBoxColor = this.Style.PictureBoxColor;
			}

			this.Invalidate(true);
		}

		#endregion

		#region Properties

		[Category("Style")]
		public Color TextColor
		{
			get {return m_TextColor;}
			set 
			{
				m_TextColor = value;
				this.ForeColor = value;
				this.Invalidate();
			}
		}

		[Category("Style")]
		public Color PictureBoxColor
		{
			get {return this.m_PictureBoxColor;}
			set 
			{
				this.m_PictureBoxColor = value;
				this.BackColor = value;
				this.Invalidate();
			}
		}

		[Browsable(false)]
		public override Color BackColor
		{
			get {return m_PictureBoxColor;}
			set 
			{
				m_PictureBoxColor = value;
			}
		}

		[Browsable(false)]
		public override Color ForeColor
		{
			get {return m_TextColor;}
			set 
			{
				m_TextColor = value;
			}
		}
		
		[Category("Appearance")]
		public Image Image
		{
			get { return pb_Figure.Image; }

			set
			{ 
				pb_Figure.Image = value; 

				if(pb_Figure.SizeMode == PictureBoxSizeMode.AutoSize)
				{
					base.Size = new Size(pb_Figure.Width + 2,pb_Figure.Height + 2);
				}
			}
		}

		[Category("Layout")]
		public PictureBoxSizeMode SizeMode
		{
			get{ return pb_Figure.SizeMode; }

			set
			{ 
				pb_Figure.SizeMode = value; 

				if(value == PictureBoxSizeMode.AutoSize)
				{
					base.Size = new Size(pb_Figure.Width + 2,pb_Figure.Height + 2);
				}
			}
		}

		[Category("Layout")]
		public new Size Size
		{
			get {return base.Size;}

			set
			{
				if(pb_Figure.SizeMode == PictureBoxSizeMode.AutoSize)
				{
					base.Size = new Size(pb_Figure.Width + 2,pb_Figure.Height + 2);
				}
				else
				{                    
					base.Size = value;
				}
			}
		}

		[Category("Layout")]
		public new int Width
		{
			get {return base.Width;}

			set
			{
				if(pb_Figure.SizeMode == PictureBoxSizeMode.AutoSize)
				{
					base.Width = pb_Figure.Width + 2;
				}
				else
				{
					base.Width = value;
				}
			}
		}

		[Category("Layout")]
		public new int Height
		{
			get {return base.Height;}

			set
			{
				if(pb_Figure.SizeMode == PictureBoxSizeMode.AutoSize)
				{
					base.Height = pb_Figure.Height + 2;
				}
				else
				{
					base.Height = value;
				}
			}
		}

		#endregion
	}
}
