using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Data;
using System.Windows.Forms;

namespace PallaControls.Windows.Forms
{
	public class InfiniteProgress : System.Windows.Forms.Control, IHasStyleControl
	{
		private Timer mtimer;
		private float mposition;
		private float mstep;

		//Default, neo
		private Color mcolor1 = Color.FromArgb(170, 170, 221);
		private Color mcolor2 = Color.White;

		private StyleGuide m_enterpriseStyle;
		private bool parentStyle = false;

		#region Constructors

		public InfiniteProgress()
		{
			this.SetStyle(ControlStyles.DoubleBuffer,true);
			mcolor1 = Color.White;
			mcolor2 = Color.Blue;
			mposition = 0;
			mstep = 5;
		}

		#endregion

		#region Overrides
		
		protected override void OnPaint(PaintEventArgs pe)
		{
			LinearGradientBrush b = new LinearGradientBrush(this.Bounds, mcolor1, mcolor2, 0, false);
			try
			{
				b.WrapMode = WrapMode.TileFlipX;
				b.TranslateTransform(Position, 0, MatrixOrder.Append);
				pe.Graphics.FillRectangle(b, 0, 0, this.Width, this.Height);      
			}
			finally
			{
				b.Dispose();
			}

			base.OnPaint(pe);
		}

		protected override void OnVisibleChanged(EventArgs e)
		{
			if (this.Visible) 
			{
				if (mtimer == null) 
				{
					mtimer = new System.Windows.Forms.Timer();
					mtimer.Interval = 20;
					mtimer.Tick += new EventHandler(OnTick);          
				}
				mtimer.Start();
			} 
			else 
			{
				if (mtimer != null) 
				{
					mtimer.Stop();
				}
			}

			base.OnVisibleChanged(e);
		}

		#endregion

		#region Virtuals

		protected virtual void OnTick(object sender, EventArgs args) 
		{    
			mposition += Step;
			if (mposition>this.Width) 
				mposition =- this.Width;

			this.Invalidate();
		}

		protected virtual void OnStyleChanged(object sender, StyleEventArgs args)
		{
			if (args.PropertyName == "InfiniteProgressStartColor") {this.StartColor = (Color)args.PropertyValue;}
			else if (args.PropertyName == "InfiniteProgressEndColor") {this.EndColor = (Color)args.PropertyValue;}
		}

		protected virtual  void OnPlansOfColorsChanged(object sender, PlansOfColorsChangedEventArgs args)
		{
			if (m_enterpriseStyle !=null) 
			{
				this.StartColor = m_enterpriseStyle.InfiniteProgressStartColor;
				this.EndColor = m_enterpriseStyle.InfiniteProgressEndColor;
			}
		}

		#endregion

		#region Properties

		[Category("Style")]
		public Color StartColor
		{
			get{return mcolor1;}
			set{mcolor1 = value;}
		}

		[Category("Style")]
		public Color EndColor
		{
			get{return mcolor2;}
			set{mcolor2 = value;}
		}

		[Category("Behavior")]
		public float Position
		{
			get{return mposition;}
			set{mposition = value;}
		}

		[Category("Behavior")]
		public float Step
		{
			get{return mstep;}
			set{mstep = value;}
		}

		[Category("Style")]
		public StyleGuide Style
		{
			get {return m_enterpriseStyle;}
			set 
			{
				m_enterpriseStyle = value;

				if (m_enterpriseStyle != null)
				{
					PlansOfColorsChangedEventArgs oArgs = new PlansOfColorsChangedEventArgs(m_enterpriseStyle.PlansOfColors);
					OnPlansOfColorsChanged(this, oArgs);

					m_enterpriseStyle.StyleChanged += new StyleChangedEventHandler(this.OnStyleChanged);
					m_enterpriseStyle.PlansOfColorsChanged += new PlansOfColorsChangedEventHandler(this.OnPlansOfColorsChanged);
				}
			}
		}

		[Category("Behavior")]
		public bool ParentStyle
		{
			get {return parentStyle;}
			set {parentStyle = value;}
		}

		#endregion

		#region IHasStyleControl

		public StyleGuide GetStyle()
		{
			return this.m_enterpriseStyle;
		}

		public void SetStyle(StyleGuide style)
		{
			this.Style = style;
		}

		public bool GetParentStyle()
		{
			return this.parentStyle;
		}

		#endregion
	}
}
