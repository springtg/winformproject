using System;
using System.Collections;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using System.Threading;
using PallaControls.Utilities.Drawing;
using PallaControls.Windows.Forms.Helpers;
using PallaControls.Windows.Forms.Collections;

namespace PallaControls.Windows.Forms
{
	[System.ComponentModel.ToolboxItem(false)]
	public class TaskPanel : PallaControls.Windows.Forms.PanelBase
	{
		private const int minTitleHeight = 19;
		private const int gripWidth = 14;
		private const int iconBorder = 2;
		private const int expandBorder = 3;

		private System.ComponentModel.IContainer components;
		private System.Windows.Forms.Label labelTitle;

		//Style neo, default
		private Color m_TaskPanelBackColor = Color.FromArgb(242, 242, 228);
		private Color m_TaskPanelTitleBackColor = Color.FromArgb(231, 231, 214);
		private Color m_TaskPanelTitleForeColor = Color.White;

		#region Constructors
		public TaskPanel() : base()
		{
			this.components = new System.ComponentModel.Container();
			InitializeComponent();
		}
		#endregion
		
		#region Windows Form Designer generated code
		private void InitializeComponent()
		{
			this.labelTitle = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// labelTitle
			// 
			this.labelTitle.Cursor = System.Windows.Forms.Cursors.Default;
			this.labelTitle.Dock = System.Windows.Forms.DockStyle.Top;
			this.labelTitle.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.labelTitle.ForeColor = System.Drawing.Color.Navy;
			this.labelTitle.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
			this.labelTitle.Location = new System.Drawing.Point(17, 17);
			this.labelTitle.Name = "labelTitle";
			this.labelTitle.Size = new System.Drawing.Size(200, 19);
			this.labelTitle.TabIndex = 0;
			this.labelTitle.Text = "Title";
			this.labelTitle.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.labelTitle.Paint += new System.Windows.Forms.PaintEventHandler(this.labelTitle_Paint);
			// 
			// TaskPanel
			// 
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.labelTitle});
			this.ResumeLayout(false);

		}
		#endregion
	
		#region Event handlers

		private void labelTitle_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
		{
			Rectangle bounds = labelTitle.Bounds;

			e.Graphics.Clear(this.Parent.BackColor);
			GraphicsPath path = new GraphicsPath();

			path.AddRectangle(bounds);
			
			using (SolidBrush brush = new SolidBrush(this.m_TaskPanelTitleBackColor))
			{

				e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
				e.Graphics.FillPath(brush, path);
			}

			using (SolidBrush textBrush = new SolidBrush(this.m_TaskPanelTitleForeColor))
			{

				float left = 2;
				float top = (float)TaskPanel.expandBorder;
				float width = (float)this.labelTitle.Width - left - TaskPanel.expandBorder;
				float height = (float)TaskPanel.minTitleHeight - (2f * (float)TaskPanel.expandBorder);
			
				RectangleF textRectF = new RectangleF(left, top, width, height);
			
				StringFormat format = new StringFormat();
				format.Trimming = StringTrimming.EllipsisWord;
				e.Graphics.DrawString(labelTitle.Text, labelTitle.Font, textBrush, 
					textRectF, format);
			}
		}

		#endregion

		#region Overrides

		protected override void OnStyleChanged(object sender, StyleEventArgs args)
		{
			base.OnStyleChanged(sender, args);

			if (args.PropertyName == "TaskPanelBackColor") {this.m_TaskPanelBackColor = (Color)args.PropertyValue;}
			else if (args.PropertyName == "TaskPanelTitleForeColor") {this.m_TaskPanelTitleForeColor = (Color)args.PropertyValue;}
			else if (args.PropertyName == "TaskPanelTitleBackColor") {this.m_TaskPanelTitleBackColor = (Color)args.PropertyValue;}
			
			this.Invalidate(true);
		}

		protected override void OnPlansOfColorsChanged(object sender, PlansOfColorsChangedEventArgs args)
		{
			base.OnPlansOfColorsChanged(sender, args);

			if (this.Style!=null)
			{
				this.m_TaskPanelBackColor = this.Style.TaskPanelBackColor;
				this.m_TaskPanelTitleForeColor = this.Style.TaskPanelTitleForeColor;
				this.m_TaskPanelTitleBackColor = this.Style.TaskPanelTitleBackColor;
			}

			this.Invalidate(true);
		}

		protected override void OnPaint(System.Windows.Forms.PaintEventArgs e)
		{
			this.labelTitle.Invalidate();
			base.OnPaint(e);
		}		

		#endregion

		#region Properties

		[Browsable(false)]
		public override Color BackColor
		{
			get {return m_TaskPanelBackColor;}
			set {m_TaskPanelBackColor = value;}
		}

		[Browsable(false)]
		public override Color ForeColor
		{
			get {return m_TaskPanelTitleForeColor;}
			set {m_TaskPanelTitleForeColor = value;}
		}

		[Category("Style")]
		public Color TaskPanelTitleForeColor
		{
			get {return m_TaskPanelTitleForeColor;}
			set 
			{
				m_TaskPanelTitleForeColor = value;
				this.Invalidate(true);
			}
		}
		
		[Category("Style")]
		public Color TaskPanelTitleBackColor
		{
			get {return m_TaskPanelTitleBackColor;}
			set 
			{
				m_TaskPanelTitleBackColor = value;
				this.Invalidate(true);
			}
		}

		[Category("Style")]
		public Color TaskPanelBackColor
		{
			get {return m_TaskPanelBackColor;}
			set 
			{
				m_TaskPanelBackColor = value;
				this.BackColor = value;
				this.Invalidate(true);
			}
		}
		
		[Category("Title")]
		public string TitleText
		{
			get
			{
				return this.labelTitle.Text;
			}
			set
			{
				this.labelTitle.Text = value;
			}
		}

		[Category("Title")]
		public Font TitleFont
		{
			get
			{
				return this.labelTitle.Font;
			}
			set
			{
				this.labelTitle.Font = value;
			}
		}

		#endregion
	}
}
