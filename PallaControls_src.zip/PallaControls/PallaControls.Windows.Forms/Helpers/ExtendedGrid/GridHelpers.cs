using System;
using System.Drawing;
using System.Collections;
using System.Windows.Forms;

namespace ControlWare.Windows.Controls.Helpers
{
	#region Selection
	
	public class Selection : ICollection
	{
		private Grid m_Grid;
		public Grid Grid
		{
			get{return m_Grid;}
		}
		public Selection(Grid pGrid)
		{
			m_Grid = pGrid;
			m_Grid.CellSelectionChange += new CellEventHandler(GridCellSelectionChange);

			m_iImageCut = GetImage("cut.ico");
			m_iImageCopy = GetImage("copy.ico");
			m_iImagePaste = GetImage("paste.ico");
			m_iImageClear = GetImage("clear.ico");
			m_iImageFormatCells = GetImage("properties.ico");
		}

		private int GetImage(string pImage)
		{
			System.Reflection.Assembly l_as = System.Reflection.Assembly.GetExecutingAssembly();
			return m_Grid.AddMenuImage(Image.FromStream(l_as.GetManifestResourceStream("ControlWare.Windows.Controls.res." + pImage)));
		}

		private int m_iImageCut;
		private int m_iImageCopy;
		private int m_iImagePaste;
		private int m_iImageClear;
		private int m_iImageFormatCells;

		public void Clear()
		{
			int l_Count = Count;
			for (int i = 0; i < l_Count; i++)
				this[0].Select = false;
		}

		public void Clear(Cell paramCellLeaveThisCellSelected)
		{
			int l_Count = Count;
			int indexToDel = 0;
			for (int i = 0; i < l_Count; i++)
			{
				if (this[indexToDel] != paramCellLeaveThisCellSelected)
					this[indexToDel].Select = false;
				else
					indexToDel++; 
			}
		}

		public virtual void CopyTo ( System.Array array , int index )
		{
			mList.CopyTo(array,index);
		}
		public int Count
		{
			get{return mList.Count;}
		}
		public bool IsSynchronized
		{
			get{return mList.IsSynchronized;}
		}
		public object SyncRoot
		{
			get{return mList.SyncRoot;}
		}

		public IEnumerator GetEnumerator()
		{
			return mList.GetEnumerator();
		}

		protected void GridCellSelectionChange(object sender, CellEventArgs e)
		{
			if (e.Cell.Select == true)
			{
				mList.Add(e.Cell);

				if (m_RightBottomCell == null ||
					e.Cell.Row > m_RightBottomCell.Row ||
					e.Cell.Col > m_RightBottomCell.Col)
				{
					if (m_RightBottomCell != null)
						m_RightBottomCell.RaiseInvalidate();
					m_RightBottomCell = e.Cell;
				}
			}
			else
			{
				mList.Remove(e.Cell);

				if (e.Cell == m_RightBottomCell)
				{
					m_RightBottomCell.RaiseInvalidate();
					m_RightBottomCell = null;
				}
			}
		}

		protected ArrayList mList = new ArrayList();

		public Cell this[int index]
		{
			get{return (Cell)mList[index];}
		}

		public bool Contains(Cell paramCell)
		{
			return mList.Contains(paramCell);
		}

		public int IndexOf(Cell paramCell)
		{
			return mList.IndexOf(paramCell);
		}

		protected Cell m_RightBottomCell = null;
		public Cell RightBottomCell
		{
			get{return m_RightBottomCell;}
		}

		public virtual void ContextMenuPopup(EventArgs e)
		{
			ArrayList l_Array = new ArrayList();
			
			if (Count > 0)
			{
				if (EnableCopyPasteSelection)
				{
					MenuItem l_mnCut = new MenuItem("Cut", new EventHandler(Selection_Cut));
					m_Grid.SetMenuImage(l_mnCut,m_iImageCut);
					l_mnCut.Enabled = false;
					l_Array.Add(l_mnCut);

					MenuItem l_mnCopy = new MenuItem("Copy", new EventHandler(Selection_Copy));
					m_Grid.SetMenuImage(l_mnCopy,m_iImageCopy);
					l_Array.Add(l_mnCopy);

					MenuItem l_mnPaste = new MenuItem("Paste", new EventHandler(Selection_Paste));
					l_mnPaste.Enabled = AllowClipboardPaste();
					m_Grid.SetMenuImage(l_mnPaste,m_iImagePaste);
					l_Array.Add(l_mnPaste);
				}
				if (EnableCopyPasteSelection && EnablePropertyCell)
					l_Array.Add(new MenuItem("-"));

				if (EnableClearSelection)
				{
					MenuItem l_mnClear = new MenuItem("Clear", new EventHandler(Selection_Clear));
					m_Grid.SetMenuImage(l_mnClear,m_iImageClear);
					l_Array.Add(l_mnClear);
				}
				if (EnablePropertyCell)
				{
					MenuItem l_mnFormatCells = new MenuItem("Format Cells ...", new EventHandler(Selection_FormatCells));
					m_Grid.SetMenuImage(l_mnFormatCells,m_iImageFormatCells);
					l_Array.Add(l_mnFormatCells);
				}

				MenuItem[] l_menus = new MenuItem[l_Array.Count];
				l_Array.CopyTo(l_menus);
				ContextMenuItems = l_menus;
			}
			else
				ContextMenuItems = null;
		}

		protected bool m_EnableClearSelection = true;
		public virtual bool EnableClearSelection
		{
			get{return m_EnableClearSelection;}
			set{m_EnableClearSelection = value;}
		}
		protected bool m_EnableCopyPasteSelection = true;
		public virtual bool EnableCopyPasteSelection
		{
			get{return m_EnableCopyPasteSelection;}
			set{m_EnableCopyPasteSelection = value;}
		}
		protected bool m_EnablePropertyCell = true;
		public virtual bool EnablePropertyCell
		{
			get{return m_EnablePropertyCell;}
			set{m_EnablePropertyCell = value;}
		}

		protected MenuItem[] m_ContextMenuItems = null;
		public MenuItem[] ContextMenuItems
		{
			get{return m_ContextMenuItems;}
			set{m_ContextMenuItems = value;}
		}

		public void ClipboardCut()
		{
		}
		public void FindSelectionCorner(out int row1,out int col1, out int row2,out  int col2)
		{
			row1 = int.MaxValue;
			col1 = int.MaxValue;
			row2 = int.MinValue;
			col2 = int.MinValue;
			foreach ( Cell c in this)
			{
				if (row1 > c.Row)
					row1 = c.Row;
				if (col1 > c.Col)
					col1 = c.Col;
				if (row2 < c.Row)
					row2 = c.Row;
				if (col2 < c.Col)
					col2 = c.Col;
			}
		}
		public void ClipboardCopy()
		{
			try
			{
				int row1,col2,row2,col1;
				if (Count>0)
				{
				
					FindSelectionCorner(out row1,out col1, out row2,out col2);
					System.Text.StringBuilder l_TabBuffer = new System.Text.StringBuilder();
					for (int r = row1; r <= row2; r++)
					{
						for (int c = col1;c <= col2; c++)
						{
							if (m_Grid[r,c] != null && m_Grid[r,c].Select == true)
							{
								l_TabBuffer.Append(m_Grid[r,c].CellFormatter.ExportValue(m_Grid[r,c].Value));
							}

							if (c<col2)
							{
								l_TabBuffer.Append("\t");
							}
						}
						if (r<row2)
						{
							l_TabBuffer.Append("\x0D\x0A");
						}
					}
					DataObject l_dataObj = new DataObject();
					l_dataObj.SetData(DataFormats.Text,l_TabBuffer.ToString());

					Clipboard.SetDataObject(l_dataObj,true);
				}
			}
			catch(Exception err)
			{
				MessageBox.Show(err.Message,"Clipboard copy error");
			}
		}
		public void ClipboardPaste()
		{
			try
			{
				if (AllowClipboardPaste() && Count > 0)
				{
					IDataObject l_dtObj = Clipboard.GetDataObject();
					string l_buffer = (string)l_dtObj.GetData(DataFormats.Text,true);
					l_buffer = l_buffer.Replace("\x0D\x0A","\x0A");
					string[] l_buffRows = l_buffer.Split('\x0A','\x0D');

					int row1,col2,row2,col1;
					FindSelectionCorner(out row1,out col1, out row2,out col2);
					for (int r = row1; r < Math.Min(row1+l_buffRows.Length,m_Grid.Rows); r++)
					{
						if (l_buffRows[r-row1].Length>0)
						{
							string[] l_buffCols = l_buffRows[r-row1].Split('\t');
							for (int c = col1; c < Math.Min(col1+l_buffCols.Length,m_Grid.Cols); c++)
							{
								if (m_Grid[r,c] != null && m_Grid[r,c].CellEditor != null)
								{
									m_Grid[r,c].CellEditor.ChangeCellValue(l_buffCols[c-col1]);
								}
							}
						}
					}
				}
			}
			catch(Exception err)
			{
				MessageBox.Show(err.Message,"Clipboard paste error");
			}
		}

		public bool AllowClipboardPaste()
		{
			IDataObject l_dtObj = Clipboard.GetDataObject();
			return l_dtObj.GetDataPresent(DataFormats.Text,true);
		}

		protected virtual void Selection_FormatCells(object sender, EventArgs e)
		{
			frmPropertyGridCell l_frmProperty = new frmPropertyGridCell();
			Cell[] l_Cells = new Cell[Count];
			this.CopyTo(l_Cells,0);
			l_frmProperty.LoadCellFormat(m_Grid.FocusCell,l_Cells);
			l_frmProperty.ShowDialog(m_Grid);
		}
		protected virtual void Selection_Clear(object sender, EventArgs e)
		{
			CellEditorClear();
		}
		protected virtual void Selection_Cut(object sender, EventArgs e)
		{
			ClipboardCut();
		}
		protected virtual void Selection_Paste(object sender, EventArgs e)
		{
			ClipboardPaste();
		}
		protected virtual void Selection_Copy(object sender, EventArgs e)
		{
			ClipboardCopy();
		}

		public void CellEditorClear()
		{
			try
			{
				foreach(Cell c in this)
				{
					if (c.CellEditor != null)
						c.CellEditor.ClearCell();
				}
			}
			catch(Exception err)
			{
				MessageBox.Show(err.Message,"Clear error");
			}
		}
	}

	#endregion 

	#region Border

	public class Border : ICloneable
	{
		public virtual object Clone()
		{
			return new Border(Color,Width);
		}
		public Border(Color pColor)
		{
			m_Color = pColor;
		}
		public Border(Color pColor, float pWidth)
		{
			m_Width = pWidth;
			m_Color = pColor;
		}
		public Border()
		{
		}
		protected float m_Width = 1;
		public float Width
		{
			get{return m_Width;}
			set{m_Width=value;OnChange();}
		}

		protected Color m_Color = Color.LightGray;
		public Color Color
		{
			get{return m_Color;}
			set{m_Color = value;OnChange();}
		}

		private void OnChange()
		{
			OnChange(new EventArgs());
		}
		protected void OnChange(EventArgs e)
		{
			if (Change!=null)
				Change(this,e);
		}

		public event EventHandler Change;

		public override string ToString()
		{
			return m_Color.ToString() + ", Width= " + m_Width.ToString();
		}
	}

	#endregion

	#region RowInfo

	public class RowInfo
	{
		public RowInfo(int pHeight, int pTop)
		{
			Height = pHeight;
			Top = pTop;
		}
		public int Height;
		public int Top;
	}

	#endregion

	#region ColInfo

	public class ColInfo
	{
		public ColInfo(int pWidth, int pLeft)
		{
			Width =	pWidth;
			Left = pLeft;
		}

		public int Width;
		public int Left;
	}

	#endregion

	#region SelectionExpander

	public class SelectionExpander
	{
		protected Cell m_Cell;
		public SelectionExpander(Cell paramCell)
		{
			m_Cell = paramCell;
		}
		protected Size m_Size = new Size(4,4);
		public Size Size
		{
			get{return m_Size;}
			set{m_Size = value;}
		}

		public void Draw(PaintEventArgs e, Point pLocation)
		{
			e.Graphics.FillRectangle(new SolidBrush(m_BackColor),pLocation.X,pLocation.Y,m_Size.Width,m_Size.Height);
		}
		protected Color m_BackColor = Color.DarkBlue;
		public Color BackColor
		{
			get{return m_BackColor;}
			set{m_BackColor = value;}
		}

		protected Cursor m_Cursor = Cursors.Cross;
		public Cursor Cursor
		{
			get{return m_Cursor;}
			set{m_Cursor = value;}
		}

		protected Cursor m_OldCursor = null;

		public virtual void MouseEnter(EventArgs e)
		{
			if (m_Cursor != null && m_Cell.Grid.Cursor != m_Cursor)
			{
				m_OldCursor = m_Cell.Grid.Cursor;
				m_Cell.Grid.Cursor = m_Cursor;
			}
		}
		public virtual void MouseLeave(EventArgs e)
		{
			if (m_OldCursor != null)
			{
				m_Cell.Grid.Cursor = m_OldCursor;
				m_OldCursor = null;
			}
		}
	}

	#endregion

	#region CellFormat

	public class CellFormat
	{
		private ContentAlignment m_TextAlignment = ContentAlignment.MiddleLeft;
		public ContentAlignment TextAlignment
		{
			get{return m_TextAlignment;}
			set{m_TextAlignment = value;}
		}

		private Font m_Font;
		public Font Font
		{
			get{return m_Font;}
			set{m_Font = value;}
		}

		private Color m_BackColor; 
		public Color BackColor
		{
			get{return m_BackColor;}
			set{m_BackColor = value;}
		}
		private Color m_ForeColor; 
		public Color ForeColor
		{
			get{return m_ForeColor;}
			set{m_ForeColor = value;}
		}

		private Color m_SelectionForeColor; 
		public Color SelectionForeColor
		{
			get{return m_SelectionForeColor;}
			set{m_SelectionForeColor = value;}
		}

		private Color m_SelectionBackColor; 
		public Color SelectionBackColor
		{
			get{return m_SelectionBackColor;}
			set{m_SelectionBackColor = value;}
		}

		private Cursor m_Cursor = null;
		public Cursor Cursor
		{
			get{return m_Cursor;}
			set{m_Cursor = value;}
		}

		private Image m_Image = null;
		public Image Image
		{
			get{return m_Image;}
			set
			{
				m_Image = value;
			}
		}
		private bool m_imgStretch = false;
		public bool ImageStretch
		{
			get{return m_imgStretch;}
			set{m_imgStretch = value;}
		}
		private ContentAlignment m_ImageAlignment = ContentAlignment.MiddleLeft;
		public ContentAlignment ImageAlignment
		{
			get{return m_ImageAlignment;}
			set
			{
				m_ImageAlignment = value;
			}
		}


		private Border m_FocusBorder = null;
		public Border FocusBorder
		{
			get{return m_FocusBorder;}
			set{m_FocusBorder = value;}		
		}

		private Border m_TopBorder = null;
		public Border TopBorder
		{
			get{return m_TopBorder;}
			set{m_TopBorder = value;}
		}

		private Border m_BottomBorder = null;
		public Border BottomBorder
		{
			get{return m_BottomBorder;}
			set{m_BottomBorder = value;}
		}
		
		private Border m_LeftBorder = null;
		public Border LeftBorder
		{
			get{return m_LeftBorder;}
			set{m_LeftBorder = value;}
		}

		private Border m_RightBorder = null;
		public Border RightBorder
		{
			get{return m_RightBorder;}
			set{m_RightBorder = value;}
		}
	}

	#endregion
}
