using System;
using System.Drawing;
using System.Globalization;
using PallaControls.Utilities;
using PallaControls.Utilities.Win32;

namespace PallaControls.Windows.Forms.Helpers
{
	internal class ColorUtilities
	{
		private static Color backgroundColor = Color.Empty;
		private static Color selectionColor  = Color.Empty;
		private static Color controlColor    = Color.Empty;
		private static Color pressedColor    = Color.Empty;
		private static Color checkedColor    = Color.Empty;
		private static Color borderColor     = Color.Empty;
		private static bool useCustomColor   = false;

		static public string[] KnownColorNames = 
		{
			"Transparent", "Black", "DimGray", "Gray", "DarkGray", "Silver", "LightGray", "Gainsboro", "WhiteSmoke", "White",
			"RosyBrown", "IndianRed", "Brown", "Firebrick", "LightCoral", "Maroon", "DarkRed", "Red", "Snow", "MistyRose",
			"Salmon", "Tomato", "DarkSalmon", "Coral", "OrangeRed", "LightSalmon", "Sienna", "SeaShell", "Chocalate",
			"SaddleBrown", "SandyBrown", "PeachPuff", "Peru", "Linen", "Bisque", "DarkOrange", "BurlyWood", "Tan", "AntiqueWhite",
			"NavajoWhite", "BlanchedAlmond", "PapayaWhip", "Mocassin", "Orange", "Wheat", "OldLace", "FloralWhite", "DarkGoldenrod",
			"Cornsilk", "Gold", "Khaki", "LemonChiffon", "PaleGoldenrod", "DarkKhaki", "Beige", "LightGoldenrod", "Olive",
			"Yellow", "LightYellow", "Ivory", "OliveDrab", "YellowGreen", "DarkOliveGreen", "GreenYellow", "Chartreuse", "LawnGreen",
			"DarkSeaGreen", "ForestGreen", "LimeGreen", "PaleGreen", "DarkGreen", "Green", "Lime", "Honeydew", "SeaGreen", "MediumSeaGreen",
			"SpringGreen", "MintCream", "MediumSpringGreen", "MediumAquaMarine", "YellowAquaMarine", "Turquoise", "LightSeaGreen",
			"MediumTurquoise", "DarkSlateGray", "PaleTurquoise", "Teal", "DarkCyan", "Aqua", "Cyan", "LightCyan", "Azure", "DarkTurquoise",
			"CadetBlue", "PowderBlue", "LightBlue", "DeepSkyBlue", "SkyBlue", "LightSkyBlue", "SteelBlue", "AliceBlue", "DodgerBlue",
			"SlateGray", "LightSlateGray", "LightSteelBlue", "CornflowerBlue", "RoyalBlue", "MidnightBlue", "Lavender", "Navy",
			"DarkBlue", "MediumBlue", "Blue", "GhostWhite", "SlateBlue", "DarkSlateBlue", "MediumSlateBlue", "MediumPurple",
			"BlueViolet", "Indigo", "DarkOrchid", "DarkViolet", "MediumOrchid", "Thistle", "Plum", "Violet", "Purple", "DarkMagenta",
			"Magenta", "Fuchsia", "Orchid", "MediumVioletRed", "DeepPink", "HotPink", "LavenderBlush", "PaleVioletRed", "Crimson",
			"Pink", "LightPink" 
		};

		static public string[] SystemColorNames = 
		{
			"ActiveBorder", "ActiveCaption", "ActiveCaptionText", "AppWorkspace", "Control", "ControlDark", "ControlDarkDark",
			"ControlLight", "ControlLightLight", "ControlText", "Desktop", "GrayText", "HighLight", "HighLightText", 
			"HotTrack", "InactiveBorder", "InactiveCaption", "InactiveCaptionText", "Info", "InfoText", "Menu", "MenuText",
			"ScrollBar", "Window", "WindowFrame", "WindowText" 
		};
		
		#region Constructors

		private ColorUtilities()
		{
		}

		#endregion

		#region Methods

		static private float GetRgbValue(float n1, float n2, float hue)
		{
			if (hue>360.0f) 
			{
				hue-=360.0f;
			} 
			else if (hue<0.0f) 
			{
				hue+=360.0f;
			}
		
			if (hue<60.0) 
			{
				return n1+(n2-n1)*hue/60.0f;
			} 
			else if (hue<180.0f) 
			{
				return n2;
			} 
			else if (hue<240.0f) 
			{
				return n1+(n2-n1)*(240.0f-hue)/60.0f;
			} 
			else 
			{
				return n1;
			}
		}

		public static Color CalculateColor(Color front, Color back, int alpha)
		{
			
			Color frontColor = Color.FromArgb(255, front);
			Color backColor = Color.FromArgb(255, back);
									
			float frontRed = frontColor.R;
			float frontGreen = frontColor.G;
			float frontBlue = frontColor.B;
			float backRed = backColor.R;
			float backGreen = backColor.G;
			float backBlue = backColor.B;
			
			float fRed = frontRed*alpha/255 + backRed*((float)(255-alpha)/255);
			byte newRed = (byte)fRed;
			float fGreen = frontGreen*alpha/255 + backGreen*((float)(255-alpha)/255);
			byte newGreen = (byte)fGreen;
			float fBlue = frontBlue*alpha/255 + backBlue*((float)(255-alpha)/255);
			byte newBlue = (byte)fBlue;

			return  Color.FromArgb(255, newRed, newGreen, newBlue);

		}

		static public bool UsingCustomColor
		{
			get { return useCustomColor;}
		}

		static public void HslToRgb(float h, float s, float l, ref float r, ref float g, ref float b)
		{
			h=(h/240)*360;
			s /= 240;
			l /= 240;
			r /= 255;
			g /= 255;
			b /= 255;
					
			// Begin Foley
			float m1,m2;
			
			// Calc m2
			if (l<=0.5f) 
			{
				m2=(l*(1+s));				
			} 
			else 
			{
				m2=(l+s-l*s);
			}
			
			//calc m1
			m1=2.0f*l-m2;
			
			if (s==0.0f) 
			{	
				r=g=b=l;
			} 
			else 
			{	
				r= GetRgbValue(m1,m2,h+120.0f);
				g= GetRgbValue(m1,m2,h);
				b= GetRgbValue(m1,m2,h-120.0f);
			}
						
			r*=255;
			g*=255;
			b*=255;
		}

		static public void RgbToHsl(int r, int g, int b, ref float h, ref float s, ref float l)
		{
			float delta;
			float fr = (float)r/255;
			float fg = (float)g/255;
			float fb = (float)b/255;
			float max = Math.Max(fr,Math.Max(fg,fb));
			float min = Math.Min(fr,Math.Min(fg,fb));
			
			l = (max+min)/2;
			
			if (max==min)
			{
				s = 0;
				h = 240.0f;		
			} 
			else 
			{
			
				delta = max-min;						
			
				if (l < 0.5) 
				{
					s = delta/(max+min);
				} 
				else 
				{
					s = delta/(2.0f-(max+min));
				}
				
				if (fr==max) 
				{
					h = (fg-fb)/delta;
				} 
				else if (fg==max) 
				{
					h = 2.0f + (fb-fr)/delta;
				} 
				else if (fb==max) 
				{
					h = 4.0f + (fr-fg)/delta;
				}
				
				//convert hue to degrees
				h*=60.0f;
				if (h<0.0f) 
				{
					h+=360.0f;
				}
			}

			l*=240;
			s*=240;
			h=(h/360)*240;
            
		}

		static public Color VsNetBackgroundColor
		{
			get 
			{
				if ( useCustomColor && backgroundColor != Color.Empty )
					return backgroundColor;
				else
					return CalculateColor(SystemColors.Window, SystemColors.Control, 220);
			}
			set
			{
				useCustomColor = true;
				backgroundColor = value;
			}
		}

		static public Color VsNetSelectionColor
		{
			get 
			{
				if ( useCustomColor && selectionColor != Color.Empty )
					return selectionColor;
				else
					return CalculateColor(SystemColors.Highlight, SystemColors.Window, 70);
			}
			set
			{
				useCustomColor = true;
				selectionColor = value;
			}
		}

		static public Color VsNetControlColor
		{
			get 
			{
					if (useCustomColor && controlColor != Color.Empty )
					return controlColor;
				else
					return CalculateColor(SystemColors.Control, VsNetBackgroundColor, 195);
			}
			set
			{
				useCustomColor = true;
				controlColor = value;
			}

		}

		static public Color VsNetPressedColor
		{
			get 
			{
				if (useCustomColor && pressedColor != Color.Empty )
					return pressedColor;
				else
					return CalculateColor(SystemColors.Highlight, ColorUtilities.VsNetSelectionColor, 70);
			}
			set
			{
				useCustomColor = true;
				pressedColor = value;
			}
		}

		static public Color VsNetCheckedColor
		{
			get 
			{
				if ( useCustomColor && pressedColor != Color.Empty )
					return checkedColor;
				else
					return CalculateColor(SystemColors.Highlight,  SystemColors.Window, 30);
			}
			set
			{
				useCustomColor = true;
				checkedColor = value;
			}
		}

		static public Color VsNetBorderColor
		{
			get 
			{
				if ( useCustomColor && borderColor != Color.Empty )
					return borderColor;
				else
				{
					return SystemColors.Highlight;
				}
			}
			set
			{
				useCustomColor = true;
				borderColor = value;
			}
		}

		[UseApiElements("GetPixel")]
		static public Color ColorFromPoint(Graphics g, int x, int y)
		{
			IntPtr hDC = g.GetHdc();

			int colorref = (int)User32.GetPixel(hDC, x, y);

			byte Red = GetrValue(colorref);
			byte Green = GetgValue(colorref);
			byte Blue = GetbValue(colorref);
			g.ReleaseHdc(hDC);
			return  Color.FromArgb(Red, Green, Blue);
		}

		static public bool IsKnownColor(Color color, ref Color knownColor, bool useTransparent)
		{

			Color currentColor = Color.Empty;
			bool badColor = false;
			for (KnownColor enumValue = 0; enumValue <= KnownColor.YellowGreen; enumValue++)
			{
				currentColor = Color.FromKnownColor(enumValue);
				string colorName = currentColor.Name;
				if ( !useTransparent ) 
					badColor = (colorName == "Transparent");
				if ( color.A == currentColor.A && color.R == currentColor.R && color.G == currentColor.G 
					&& color.B == currentColor.B && !currentColor.IsSystemColor
					&& !badColor )
				{
					knownColor = currentColor;
					return true;
				}
				
			}
			return false;

		}

		static public bool IsSystemColor(Color color, ref Color knownColor)
		{
			Color currentColor = Color.Empty;
			for (KnownColor enumValue = 0; enumValue <= KnownColor.YellowGreen; enumValue++)
			{
				currentColor = Color.FromKnownColor(enumValue);
				string colorName = currentColor.Name;
				if ( color.R == currentColor.R && color.G == currentColor.G 
					&& color.B == currentColor.B && currentColor.IsSystemColor )
				{
					knownColor = currentColor;
					return true;
				}
				
			}
			return false;
		}

		static public int GetColorRef(Color color)
		{
			return Rgb(color.R, color.G, color.B);
		}

		static public Color ColorFromRgbString(string text)
		{
			
			Color rgbColor = Color.Empty;
			string[] RGBs = text.Split(','); 
			if ( RGBs.Length != 3 ) 
			{
				throw new Exception("RGB color string is not well formed");
			}
		
			string stringR = RGBs[0];
			string stringG = RGBs[1];
			string stringB = RGBs[2];
			int R, G, B;
				
			try 
			{
				R = Convert.ToInt32(stringR, CultureInfo.CurrentCulture);
				G = Convert.ToInt32(stringG, CultureInfo.CurrentCulture);
				B = Convert.ToInt32(stringB, CultureInfo.CurrentCulture);
				if ( ( R < 0 || R > 255 ) || ( G < 0 || G > 255 ) || ( B < 0 || B > 255 ) ) 
				{
					throw new Exception("Out of bounds RGB value");
				}
				else 
				{
					rgbColor = Color.FromArgb(R, G, B);

					Color knownColor = Color.Empty;
					bool isKnown = ColorUtilities.IsKnownColor( rgbColor, ref knownColor, true);
					if ( !isKnown )
						isKnown = ColorUtilities.IsSystemColor(rgbColor, ref knownColor);
					if ( isKnown )
						rgbColor = knownColor;
				}
			}
			catch ( InvalidCastException )
			{
				throw new Exception("Invalid RGB value");
			}

			return rgbColor;
		}

		static public byte GetrValue(int color)
		{
			return (byte)color;
		}

		static public byte GetgValue(int color)
		{
			return ((byte)(((short)(color)) >> 8));
		}

		static public byte GetbValue(int color)
		{
			return ((byte)((color)>>16));
		}

		static public int Rgb(int r, int g, int b)
		{
			return ((int)(((byte)(r)|((short)((byte)(g))<<8))|(((short)(byte)(b))<<16)));

		}

		public static Color TabBackgroundFromBaseColor(Color backColor)
		{
			Color backIDE;

			if ((backColor.R == 212) &&
				(backColor.G == 208) &&
				(backColor.B == 200))
			{
				backIDE = Color.FromArgb(247, 243, 233);
			}
			else
			{
				if ((backColor.R == 236) &&
					(backColor.G == 233) &&
					(backColor.B == 216))
				{
					backIDE = Color.FromArgb(255, 251, 233);
				}
				else
				{
					int red = 255 - ((255 - backColor.R) / 2);
					int green = 255 - ((255 - backColor.G) / 2);
					int blue = 255 - ((255 - backColor.B) / 2);
					backIDE = Color.FromArgb(red, green, blue);
				}
			}
                        
			return backIDE;
		}

		#endregion
	}
}
