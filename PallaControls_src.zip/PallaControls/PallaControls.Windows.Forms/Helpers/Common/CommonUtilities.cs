using System;

namespace PallaControls.Windows.Forms.Helpers
{
	internal class CommonUtilities
	{
		#region Consrucors

		private CommonUtilities()
		{
		}

		#endregion

		#region Methods

		static public  int HiWord(int number) 
		{ 
			return (number >> 16) & 0xffff; 
		} 
 
		static public int LoWord(int number) 
		{ 
			return number & 0xffff; 
		} 

		#endregion
	}
}
