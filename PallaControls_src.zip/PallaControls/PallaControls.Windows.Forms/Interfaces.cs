using System;
using System.Drawing;
using System.Windows.Forms;
using PallaControls.Windows.Forms.Collections;

namespace PallaControls.Windows.Forms
{
	public interface IFlashabledControl
	{
		void FlashControl();
	}

	public interface IHasStyleControl
	{
		StyleGuide GetStyle();
		void SetStyle(StyleGuide style);
		bool GetParentStyle();
	}

	public interface IHookedControl
	{
		object HookControl();
	}

	public interface IHookedPopupControl
	{
		object HookPopupControl();
	}
}

namespace PallaControls.Windows.Docking
{
	public interface IHotZoneSource
	{
		void AddHotZones(Redocker redock, HotZoneCollection collection);
	}

	public interface IZoneMaximizeWindow
	{
		PallaControls.Windows.Forms.Direction Direction { get; }
		bool IsMaximizeAvailable();
		bool IsWindowMaximized(Window w);
		void MaximizeWindow(Window w);
		void RestoreWindow();
		event EventHandler RefreshMaximize;
	}
}