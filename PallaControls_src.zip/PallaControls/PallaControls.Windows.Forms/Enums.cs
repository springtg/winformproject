using System;

namespace PallaControls.Windows.Forms
{
	public enum AllowClose
	{
		Ask,
		AskIfNotFinish,
		AlwaysAllow
	}

	public enum PanelItemStyle
	{
		Item = 1,
		Separator = 2,
		Option
	}
	
	public enum Direction
	{
		Vertical,
		Horizontal
	}
    
	public enum Edge
	{
		Top,
		Left,
		Bottom,
		Right,
		None
	}

	public enum LineDirection
	{
		Horizontal  = 1,
		Vertical = 2,
	}
	
	public enum LeftRight
	{
		Left  = 1,
		Right = 2,
	}

	public enum PlansColors
	{
		Morpheus          = 1,
		Cypher            = 2,
		Apoc              = 3,
		AgentSmith        = 4,
		Trinity           = 5,
		Mouse             = 6,
		NeoTheOne         = 7,
		AssGreen          = 9,         
		CustomGoodLuckman = 8,
		TweakGreen        = 10 //2003-08-10 create by Stray Bullet
	}

	public enum PanelTypes
	{
		TopOptions   = 1,
		LeftOptions  = 2,
		BottomArea   = 3,
		ClientArea   = 4,
		AssLeftTitle = 5,
		AssRightTitle = 6,
		AssLeftOptions = 7,
		AssClientArea = 8,
		AssBottomArea = 9
	}

	public enum OptionTypes
	{
		TopOption    = 1,
		LeftOption   = 2,
		ClientOption = 3,
	}

	public enum OptionHighLight
	{
		Rectangle = 1,
		Font = 2
	}

	public enum ComboAutoFill
	{
		States       = 1,
		CivilStatus  = 2,
		Sex          = 3,
		Months       = 4,
		None         = 5,
	}

	public enum BrazilStates
	{
		AC=1,
		AL=2,
		AP=3,
		AM=4,
		BA=5,
		CE=6,
		DF=7,
		ES=8,
		GO=9,
		MA=10,
		MT=11,
		MS=12,
		MG=13,
		PA=14,
		PB=15,
		PR=16,
		PE=17,
		PI=18,
		RJ=19,
		RN=20,
		RS=21,
		RO=22,
		RR=23,
		SC=24,
		SP=25,
		SE=26,
		TO=27,
	}

	public enum EditMask
	{
		Custom                  = 0,
		Text                    = 1,
		TextWithNotAcceptChars  = 2,
		Numeric                 = 3,
		Date                    = 4,
		Diretory                = 5,
		Email                   = 6,
		Ip                      = 7,
		Phone                   = 8,
		PhoneWithArea           = 9,
		PhoneCodeArea           = 10,
		Identity                = 11,
		PersonIdentity          = 12,
		EnterpriseIdentity      = 13,
		StateRegistration       = 14,
		Zip                     = 15,
		Time                    = 16,
		FileName                = 17,
		CustomWithRegularExpressions = 18 //2002-08-07 - GWO - Added to accept regular expressions.
	}

	public enum ThumbDraggedFireFrequency
	{
		MouseMove,
		MouseUp
	}

	public enum DrawState
	{
		Normal,
		Hot,
		Pressed,
		Disable
	}

	public enum ScrollBarEvent
	{
		LineUp,
		LineDown,
		PageUp,
		PageDown,
		ThumbUp,
		ThumbDown
	}

	public enum ArrowGlyph
	{
		Up,
		Down,
		Left,
		Right
	}

	public enum ScrollBarHit
	{
		UpArrow,
		DownArrow,
		PageUp,
		PageDown,
		Thumb,
		LeftArrow,
		RightArrow,
		PageLeft,
		PageRight,
		None
	}

	public enum PanelState
	{
		Expanded,
		Collapsed
	}

	public enum VisualStyle
	{
		Ide,
		Plain
	}

	public enum GridSelectionMode
	{
		Cell = 1,
		Row = 2,
		Col = 3
	}

	[Flags]
	public enum EditableModes
	{
		None = 0,
		F2Key = 1,
		DoubleClick = 2,
		SingleClick = 4,
		AnyKey = 9
	}

	public enum CommonBorderStyle
	{
		Normal = 1,
		Raised = 2,
		Inset = 3
	}
}

namespace PallaControls.Windows.Docking
{
	public enum State
	{
		Floating,
		DockTop,
		DockBottom,
		DockLeft,
		DockRight
	}

	public enum PropogateName
	{
		BackColor,
		ActiveColor,
		ActiveTextColor,
		InactiveTextColor,
		ResizeBarColor,
		ResizeBarVector,
		CaptionFont,
		TabControlFont,
		ZoneMinMax,
		PlainTabBorder
	}
}