using System;
using System.IO;
using System.Xml;
using System.Text;
using System.Drawing;
using System.Collections;
using System.Globalization;
using System.Windows.Forms;
using System.ComponentModel;
using System.Xml.Serialization;
using Microsoft.Win32;
using PallaControls.Utilities.Drawing;
using PallaControls.Windows.Forms;
using PallaControls.Resources;
using PallaControls.Resources.Keys;
using PallaControls.Windows.Forms.Collections;
using PallaControls.Windows.Forms.Helpers;

namespace PallaControls.Windows.Docking
{
	public class DockingManager
    {
		#region Nested types

		public class XmlTextWriterEventArgs : EventArgs
		{
			private XmlTextWriter xmlOut;

			public XmlTextWriterEventArgs(XmlTextWriter xmlOut)
			{
				this.xmlOut = xmlOut;
			}

			public XmlTextWriter XmlOut
			{
				get{return this.xmlOut;}
				set{this.xmlOut = value;}
			}
		}

		public class XmlTextReaderEventArgs : EventArgs
		{
			private XmlTextReader xmlIn;

			public XmlTextReaderEventArgs(XmlTextReader xmlIn)
			{
				this.xmlIn = xmlIn;
			}

			public XmlTextReader XmlIn
			{
				get{return this.xmlIn;}
				set{this.xmlIn = value;}
			}
		}
		
		#endregion
		
		protected Hashtable mTagsMenu = null;
		protected bool mzoneMinMax;
        protected bool minsideFill;
        protected bool mautoResize;
        protected bool mfirstHalfWidth;
        protected bool mfirstHalfHeight;
        protected int msurpressVisibleEvents;
        protected int mresizeBarVector;
        protected Size minnerMinimum;
        protected Color mbackColor;
        protected Color mactiveColor;
        protected Color mactiveTextColor;
        protected Color minactiveTextColor;
        protected Color mresizeBarColor;
        protected Font mcaptionFont;
		protected Font mtabControlFont;
        protected bool mdefaultBackColor;
        protected bool mdefaultActiveColor;
        protected bool mdefaultActiveTextColor;
        protected bool mdefaultInactiveTextColor;
        protected bool mdefaultResizeBarColor;
        protected bool mdefaultCaptionFont;
		protected bool mdefaultTabControlFont;
        protected bool mplainTabBorder;
        protected Control minnerControl;
        protected Control mouterControl;
        protected AutoHidePanel mahpTop;
        protected AutoHidePanel mahpLeft;
        protected AutoHidePanel mahpBottom;
        protected AutoHidePanel mahpRight;
        protected ContainerControl mcontainer;
        protected ManagerContentCollection mcontents;
		protected StyleGuide menterpriseStyle = null;

        public delegate void ContentEventHandler(object sender, EventArgs e);
        public delegate void ContentHidingEventHandler(object sender, CancelEventArgs e);
        public delegate void ContextMenuEventHandler(object sender, CancelEventArgs e);
		public delegate void TabControlCreatedEventHandler(object sender, EventArgs e);
		public delegate void SaveCustomConfigEventHandler(object sender, XmlTextWriterEventArgs e);
        public delegate void LoadCustomConfigEventHandler(object sender, XmlTextReaderEventArgs e);

        public event ContentEventHandler ContentShown;
        public event ContentEventHandler ContentHidden;
        public event ContentHidingEventHandler ContentHiding;
        public event ContextMenuEventHandler ContextMenu;
		public event TabControlCreatedEventHandler TabControlCreated;
		public event SaveCustomConfigEventHandler SaveCustomConfig;
        public event LoadCustomConfigEventHandler LoadCustomConfig;

		#region Constructors

		public DockingManager(ContainerControl container, PallaControls.Windows.Forms.StyleGuide style)
        {
            if (container == null)
                throw new ArgumentNullException("Container");

            mcontainer = container;
            minnerControl = null;
			mzoneMinMax = true;
			minsideFill = false;
			mautoResize = true;
			mfirstHalfWidth = true;
			mfirstHalfHeight = true;
			mplainTabBorder = false;
			msurpressVisibleEvents = 0;
			minnerMinimum = new Size(20, 20);
			mTagsMenu = new Hashtable();
	
			mresizeBarVector = -1;
			mcaptionFont = SystemInformation.MenuFont;
			mtabControlFont = SystemInformation.MenuFont;
			mdefaultCaptionFont = true;
			mdefaultTabControlFont = true;

			AddAutoHidePanels();

            ResetColors();

            mcontents = new ManagerContentCollection(this);

            mcontents.Clearing += new CollectionClearEventHandler(OnContentsClearing);
            mcontents.Removed += new PallaControls.Windows.Forms.Collections.CollectionChangeEventHandler(OnContentRemoved);

			mcontainer.Resize += new EventHandler(OnContainerResized);
			
			if (mcontainer is Form)
			{   
			    Form formContainer = mcontainer as Form;			    
			    formContainer.Load += new EventHandler(OnFormLoaded);
			}

            Microsoft.Win32.SystemEvents.UserPreferenceChanged += new UserPreferenceChangedEventHandler(OnPreferenceChanged);

			this.Style = style;
        }

		#endregion

		#region Virtuals

		protected virtual void OnStyleChanged(object sender, StyleEventArgs args)
		{
			if (args.PropertyName == "DockingBackColor") {this.mbackColor = (Color)args.PropertyValue;}
			else if (args.PropertyName == "DockingResizeBarColor") {this.mresizeBarColor = (Color)args.PropertyValue;}
			else if (args.PropertyName == "DockingActiveTextColor") {this.mactiveTextColor = (Color)args.PropertyValue;}
			else if (args.PropertyName == "DockingActiveColor") {this.mactiveColor = (Color)args.PropertyValue;}
			else if (args.PropertyName == "DockingInactiveColor") {this.minactiveTextColor = (Color)args.PropertyValue;}
		}

		protected virtual  void OnPlansOfColorsChanged(object sender, PlansOfColorsChangedEventArgs args)
		{
			if (this.Style!=null)
			{
				this.mbackColor = this.Style.DockingBackColor;
				this.mresizeBarColor = this.Style.DockingResizeBarColor;
				this.mactiveTextColor = this.Style.DockingActiveTextColor;
				this.mactiveColor = this.Style.DockingActiveColor;
				this.minactiveTextColor = this.Style.DockingInactiveTextColor;
			}
		}

		public virtual bool ToggleContentAutoHide(Content c)
		{
			if (!c.Visible)
				return false;

			if (c.ParentWindowContent.State == State.Floating)
				return false;

			if (c.ParentWindowContent.ParentZone == null)
			{
				AutoHidePanel ahp = AutoHidePanelForState(c.ParentWindowContent.State);
				
				ahp.InvertAutoHideWindowContent(c.ParentWindowContent as WindowContentTabbed);
			}
			else
			{
				InvertAutoHideWindowContent(c.ParentWindowContent);
			}

			return true;
		}

		public virtual bool ShowContent(Content c)
		{
			if ((c == null) || !mcontents.Contains(c))
				return false;
		
			if (!c.Visible)
			{
				msurpressVisibleEvents++;

				RemoveShowingAutoHideWindows();
                               
				if (c.Docked)
				{
					if (c.AutoHidden)
						c.AutoHideRestore.PerformRestore(this);
					else
						c.DockingRestore.PerformRestore(this);
				}
				else
					c.FloatingRestore.PerformRestore(this);

				msurpressVisibleEvents--;

				OnContentShown(c);

				return true;
			}
			else
				return false;
		}

		public virtual void ShowAllContents()
		{
			mcontainer.SuspendLayout();

			foreach(Content c in mcontents)
				ShowContent(c);

			UpdateInsideFill();

			mcontainer.ResumeLayout();
		}

		public virtual void HideContent(Content c)
		{
			HideContent(c, true, true);
		}

		public virtual void HideContent(Content c, bool record, bool reorder)
		{
			if (c.Visible)
			{
				msurpressVisibleEvents++;

				RemoveShowingAutoHideWindows();
                
				if (record)
				{
					c.RecordRestore();
				}

				if (c.AutoHidden)
				{
					c.AutoHidePanel.RemoveContent(c);
				}
				else
				{
					c.ParentWindowContent.Contents.Remove(c);
				}
                
				if (reorder)
				{
					mcontents.SetIndex(0, c); 
				}

				UpdateInsideFill();

				msurpressVisibleEvents--;
                
				OnContentHidden(c);
			}
		}

		public virtual void HideAllContents()
		{
			mcontainer.SuspendLayout();

			int count = mcontents.Count;

			for(int index=count-1; index>=0; index--)
			{
				if (mcontents[index].Visible)
				{
					if (!OnContentHiding(mcontents[index]))
					{
						HideContent(mcontents[index], true, false);
					}
				}
			}

			UpdateInsideFill();

			mcontainer.ResumeLayout();
		}

		public virtual Window CreateWindowForContent(Content c)
		{
			return CreateWindowForContent(c, new EventHandler(OnContentClose), 
				new EventHandler(OnRestore),
				new EventHandler(OnInvertAutoHide),
				new ContextEventHandler(OnShowContextMenu));
		}

		public virtual Window CreateWindowForContent(Content c,
			EventHandler contentClose,
			EventHandler restore,
			EventHandler invertAutoHide,
			ContextEventHandler showContextMenu)
		{
			WindowContent wc = new WindowContentTabbed(this);

			WindowDetailCaption wdc;

			wdc = new WindowDetailCaptionIde(this, contentClose, restore,
				invertAutoHide, showContextMenu);

			wc.WindowDetails.Add(wdc);

			if (c != null)
			{
				wc.Contents.Add(c);
			}

			return wc;
		}    
            
		public virtual Zone CreateZoneForContent(State zoneState)
		{
			return CreateZoneForContent(zoneState, mcontainer);
		}

		protected virtual Zone CreateZoneForContent(State zoneState, ContainerControl destination)
		{
			DockStyle ds;
			Direction direction;

			ValuesFromState(zoneState, out ds, out direction);

			ZoneSequence zs = new ZoneSequence(this, zoneState, direction, mzoneMinMax);

			zs.Dock = ds;

			if (destination != null)
			{
				destination.Controls.Add(zs);
			}

			return zs;
		}

		public virtual bool OnContentHiding(Content sender)
		{
			CancelEventArgs cea = new CancelEventArgs();

			if (msurpressVisibleEvents == 0)
			{
				if (ContentHiding != null)
					ContentHiding(sender, cea);
			}
            
			return cea.Cancel;
		}

		public virtual void OnContentHidden(Content sender)
		{
			if (msurpressVisibleEvents == 0)
			{
				if (ContentHidden != null)
					ContentHidden(sender, EventArgs.Empty);
			}
		}

		public virtual void OnContentShown(Content sender)
		{
			if (msurpressVisibleEvents == 0)
			{
				if (ContentShown != null)
					ContentShown(sender, EventArgs.Empty);
			}
		}

		public virtual void OnTabControlCreated(PallaControls.Windows.Forms.TabControl sender)
		{ 
			if (TabControlCreated != null)
				TabControlCreated(sender, EventArgs.Empty);
		}
		
		public virtual void OnSaveCustomConfig(XmlTextWriter xmlOut)
		{
			if (SaveCustomConfig != null)
				SaveCustomConfig(this, new XmlTextWriterEventArgs(xmlOut));
		}

		public virtual void OnLoadCustomConfig(XmlTextReader xmlIn)
		{
			if (LoadCustomConfig != null)
				LoadCustomConfig(this, new XmlTextReaderEventArgs(xmlIn));
		}
        
		protected virtual void OnContentsClearing(object sender, EventArgs e)
		{
			mcontainer.SuspendLayout();

			HideAllContents();

			mcontainer.ResumeLayout();
		}

		protected virtual void OnContentRemoved(object value, PallaControls.Windows.Forms.Collections.CollectionChangeEventArgs e)
		{
			mcontainer.SuspendLayout();

			Content c = value as Content;

			if (c != null)
				HideContent(c, true, false);

			mcontainer.ResumeLayout();
		}

		protected virtual void OnContentClose(object sender, EventArgs e)
		{
			WindowDetailCaption wdc = sender as WindowDetailCaption;
            
			if (wdc != null)
			{
				WindowContentTabbed wct = wdc.ParentWindow as WindowContentTabbed;
                
				if (wct != null)
				{
					Content c = wct.CurrentContent;
                    
					if (c != null)
					{
						if (!OnContentHiding(c))
							wct.HideCurrentContent();
					}
				}
			}
		}
        
		protected virtual void OnInvertAutoHide(object sender, EventArgs e)
		{
			WindowDetail detail = sender as WindowDetail;

			WindowContent wc = detail.ParentWindow as WindowContent;
                        
			InvertAutoHideWindowContent(wc);
		}

		protected virtual void InvertAutoHideWindowContent(WindowContent wc)
		{
			msurpressVisibleEvents++;

			ContentCollection cc = new ContentCollection();
	            
			foreach(Content c in wc.Contents)
				cc.Add(c);

			AutoHideContents(cc, wc.State);

			msurpressVisibleEvents--;
		}

		protected void AddAutoHidePanels()
		{
			mahpTop = new AutoHidePanel(this, DockStyle.Top);
			mahpLeft = new AutoHidePanel(this, DockStyle.Left);
			mahpBottom = new AutoHidePanel(this, DockStyle.Bottom);
			mahpRight = new AutoHidePanel(this, DockStyle.Right);
        
			mahpTop.Name = "Top";
			mahpLeft.Name = "Left";
			mahpBottom.Name = "Bottom";
			mahpRight.Name = "Right";
		    
			mcontainer.Controls.AddRange(new Control[]{mahpBottom, mahpTop, mahpRight, mahpLeft});
		}
		            
		protected void RepositionControlBefore(Control target, Control source)
		{
			int targetPos = mcontainer.Controls.IndexOf(target);
			int sourcePos = mcontainer.Controls.IndexOf(source);

			if (targetPos >= sourcePos)
				targetPos--;

			mcontainer.Controls.SetChildIndex(source, targetPos);			
		}

		protected virtual void OnRestore(object sender, EventArgs e)
		{
			WindowDetailCaption wdc = sender as WindowDetailCaption;

			if (wdc != null)
			{
				RemoveAnyFillStyle();

				WindowContent wc = wdc.ParentWindow as WindowContent;

				if (wc != null)
				{
					ContentCollection copy = new ContentCollection();

					foreach(Content c in wc.Contents)
					{
						c.RecordRestore();

						c.Docked = (c.Docked == false);

						copy.Add(c);
					}

					int copyCount = copy.Count;

					if (copyCount >= 1)
					{
						HideContent(copy[0], false, true);
						ShowContent(copy[0]);

						if (copyCount >= 2)
						{
							WindowContent newWC = copy[0].ParentWindowContent;

							if (newWC != null)
							{
								for(int index=1; index<copyCount; index++)
								{
									HideContent(copy[index], false, true);
									newWC.Contents.Add(copy[index]);
								}
							}
						}
					}
				}

				AddInnerFillStyle();
			}
		}

		protected void AddInnerFillStyle()
		{
			if (minsideFill)
			{
				foreach(Control c in mcontainer.Controls)
				{
					Zone z = c as Zone;

					if (z != null)
					{
						z.Dock = DockStyle.Fill;

						break;
					}
				}
			}
		}

		protected void RemoveAnyFillStyle()
		{
			foreach(Control c in mcontainer.Controls)
			{
				Zone z = c as Zone;

				if (z != null)
				{
					if (z.Dock == DockStyle.Fill)
					{
						DockStyle ds;
						Direction direction;

						ValuesFromState(z.State, out ds, out direction);
			
						z.Dock = ds;
					}
				}
			}
		}

		protected void OnFormLoaded(object sender, EventArgs e)
		{
			ReorderAutoHidePanels();
		}

		protected void ReorderAutoHidePanels()
		{
			if (mouterControl == null)
			{
				int count = mcontainer.Controls.Count;

				mcontainer.Controls.SetChildIndex(mahpLeft, count - 1);
				mcontainer.Controls.SetChildIndex(mahpRight, count - 1);
				mcontainer.Controls.SetChildIndex(mahpTop, count - 1);
				mcontainer.Controls.SetChildIndex(mahpBottom, count - 1);
			}
			else
			{
				RepositionControlBefore(mouterControl, mahpBottom);
				RepositionControlBefore(mouterControl, mahpTop);
				RepositionControlBefore(mouterControl, mahpRight);
				RepositionControlBefore(mouterControl, mahpLeft);
			}
		}
        
		protected void OnContainerResized(object sender, EventArgs e)
		{
			if (mautoResize)
			{
				Rectangle inner = InnerResizeRectangle(null);			

				inner.Width -= minnerMinimum.Width;
				inner.Height -= minnerMinimum.Height;
    			
				Form f = mcontainer as Form;

				if ((f == null) || ((f != null) && (f.WindowState != FormWindowState.Minimized)))
				{
					if ((inner.Width < 0) || (inner.Height < 0))
					{
						mcontainer.SuspendLayout();

						ZoneCollection zcLeft = new ZoneCollection();
						ZoneCollection zcRight = new ZoneCollection();
						ZoneCollection zcTop = new ZoneCollection();
						ZoneCollection zcBottom = new ZoneCollection();

						foreach(Control c in mcontainer.Controls)
						{
							Zone z = c as Zone;

							if (z != null)
							{
								switch(z.State)
								{
									case State.DockLeft:
										zcLeft.Add(z);
										break;
									case State.DockRight:
										zcRight.Add(z);
										break;
									case State.DockTop:
										zcTop.Add(z);
										break;
									case State.DockBottom:
										zcBottom.Add(z);
										break;
								}
							}
						}

						if (inner.Width < 0)
							ResizeDirection(-inner.Width, zcLeft, zcRight, Direction.Horizontal);

						if (inner.Height < 0)
							ResizeDirection(-inner.Height, zcTop, zcBottom, Direction.Vertical);

						mcontainer.ResumeLayout();
					}
				}
			}
		}

		protected void ResizeDirection(int remainder, ZoneCollection zcAlpha, ZoneCollection zcBeta, Direction dir)
		{
			bool alter;
			int available;
			int half1, half2;

			while((remainder > 0) && ((zcAlpha.Count > 0) || (zcBeta.Count > 0)))
			{
				if (dir == Direction.Horizontal)
				{
					mfirstHalfWidth = (mfirstHalfWidth != true);
					alter = mfirstHalfWidth;
				}
				else
				{
					mfirstHalfHeight = (mfirstHalfHeight != true);
					alter = mfirstHalfHeight;
				}

				if (alter)
				{
					half1 = (remainder / 2) + 1;
					half2 = remainder - half1;
				}
				else
				{
					half2 = (remainder / 2) + 1;
					half1 = remainder - half2;
				}

				if (zcAlpha.Count > 0)
				{
					Zone z = zcAlpha[0];

					if (dir == Direction.Horizontal)
						available = z.Width - z.MinimumWidth;
					else
						available = z.Height - z.MinimumHeight;

					if (available > 0)
					{
						if (available > half1)
							available = half1;
						else
							zcAlpha.Remove(z);

						if (dir == Direction.Horizontal)
							z.Width = z.Width - available;
						else
							z.Height = z.Height - available;

						remainder -= available;
					}
					else
						zcAlpha.Remove(z);
				}

				if (zcBeta.Count > 0)
				{
					Zone z = zcBeta[0];

					if (dir == Direction.Horizontal)
						available = z.Width - z.MinimumWidth;
					else
						available = z.Height - z.MinimumHeight;

					if (available > 0)
					{
						if (available > half2)
							available = half2;
						else
							zcBeta.Remove(z);

						if (dir == Direction.Horizontal)
							z.Width = z.Width - available;
						else
							z.Height = z.Height - available;

						remainder -= available;
					}
					else
						zcBeta.Remove(z);
				}
			}
		}

		protected void OnPreferenceChanged(object sender, UserPreferenceChangedEventArgs e)
		{
			if (mdefaultBackColor)
			{
				mbackColor = SystemColors.Control;
				PropogateNameValue(PropogateName.BackColor, (object)SystemColors.Control);
			}

			if (mdefaultActiveColor)
			{
				mactiveColor = SystemColors.ActiveCaption;
				PropogateNameValue(PropogateName.ActiveColor, (object)SystemColors.ActiveCaption);
			}
            
			if (mdefaultActiveTextColor)
			{
				mactiveTextColor = SystemColors.ActiveCaptionText;
				PropogateNameValue(PropogateName.ActiveTextColor, (object)SystemColors.ActiveCaptionText);
			}

			if (mdefaultInactiveTextColor)
			{
				minactiveTextColor = SystemColors.ControlText;
				PropogateNameValue(PropogateName.InactiveTextColor, (object)SystemColors.ControlText);
			}

			if (mdefaultResizeBarColor)
			{
				mresizeBarColor = SystemColors.Control;
				PropogateNameValue(PropogateName.ResizeBarColor, (object)SystemColors.Control);
			}

			if (mdefaultCaptionFont)
			{
				mcaptionFont = SystemInformation.MenuFont;
				PropogateNameValue(PropogateName.CaptionFont, (object)SystemInformation.MenuFont);
			}

			if (mdefaultTabControlFont)
			{
				mtabControlFont = SystemInformation.MenuFont;
				PropogateNameValue(PropogateName.TabControlFont, (object)SystemInformation.MenuFont);
			}
		}

		public virtual void OnShowContextMenu(object sender, ContextEventArgs e)
		{
			ContextMenu context = new ContextMenu();

			ContentCollection temp = new ContentCollection();

			foreach(Content c in mcontents)
			{
				int count = temp.Count;
				int index = 0;

				for(; index<count; index++)
				{
					if (c.Order < temp[index].Order)
						break;
				}

				temp.Insert(index, c);
			}

			foreach(Content t in temp)
			{
				MenuItem mc = new MenuItem(t.Title, new EventHandler(OnToggleContentVisibility));
				mc.Checked = t.Visible;
				
				this.mTagsMenu.Add(t.Title, t);
				
				context.MenuItems.Add(mc);
			}

			context.MenuItems.Add(new MenuItem("-"));

			context.MenuItems.Add(new MenuItem(ResourceLibrary.GetString(WindowsControlsResourceKeys.ShowAll, WindowsControlsResourceKeys.Root), new EventHandler(OnShowAll)));
			context.MenuItems.Add(new MenuItem(ResourceLibrary.GetString(WindowsControlsResourceKeys.HideAll, WindowsControlsResourceKeys.Root), new EventHandler(OnHideAll)));

			if (OnContextMenu(context))
			{
				context.Show(this.InnerControl, e.ScreenPos);
			}
		}

		protected bool OnContextMenu(System.Windows.Forms.ContextMenu context)
		{
			CancelEventArgs cea = new CancelEventArgs();
        
			if (ContextMenu != null)
				ContextMenu(context, cea);
                
			return !cea.Cancel;
		}

		protected void OnToggleContentVisibility(object sender, EventArgs e)
		{
			MenuItem mc = sender as MenuItem;

			if (mc != null)
			{
				Content c = this.mTagsMenu[mc.Text] as Content;

				if (c != null)
				{
					if (c.Visible)
						HideContent(c);
					else
						ShowContent(c);
				}
			}
		}

		protected void OnShowAll(object sender, EventArgs e)
		{
			ShowAllContents();
		}

		protected void OnHideAll(object sender, EventArgs e)
		{
			HideAllContents();
		}

		#endregion

		#region Methods

        public void ResetColors()
        {
            mbackColor = SystemColors.Control;
            minactiveTextColor = SystemColors.ControlText;
            mactiveColor = SystemColors.ActiveCaption;
            mactiveTextColor = SystemColors.ActiveCaptionText;
            mresizeBarColor = SystemColors.Control;
            mdefaultBackColor = true;
            mdefaultActiveColor = true;
            mdefaultActiveTextColor = true;
            mdefaultInactiveTextColor = true;
            mdefaultResizeBarColor = true;

            PropogateNameValue(PropogateName.BackColor, (object)mbackColor);
            PropogateNameValue(PropogateName.ActiveColor, (object)mactiveColor);
            PropogateNameValue(PropogateName.ActiveTextColor, (object)mactiveTextColor);
            PropogateNameValue(PropogateName.InactiveTextColor, (object)minactiveTextColor);
            PropogateNameValue(PropogateName.ResizeBarColor, (object)mresizeBarColor);
        }

        public void UpdateInsideFill()
		{
			if (minsideFill)
			{
				mcontainer.SuspendLayout();
				
				RemoveAnyFillStyle();
				AddInnerFillStyle();

				mcontainer.ResumeLayout();
			}
		}

		public WindowContent AddContentWithState(Content c, State newState)
		{
			if ((c == null) || !mcontents.Contains(c))
				return null;
		
			msurpressVisibleEvents++;

			RemoveShowingAutoHideWindows();
                
			if (c.ParentWindowContent != null)
			{
				if (c.ParentWindowContent.ParentZone.State == State.Floating)
					c.ContentLeavesFloating();

				c.ParentWindowContent.Contents.Remove(c);
			}

			Window w = CreateWindowForContent(c);

			ContainerControl destination = null;

			if (newState != State.Floating)
			{
				destination = mcontainer;
				destination.SuspendLayout();
			}

			Zone z = CreateZoneForContent(newState, destination);

			if (newState == State.Floating)
			{
				c.Docked = false;
			
				destination = new FloatingForm(this, z, new ContextEventHandler(OnShowContextMenu));

				destination.Location = c.DisplayLocation;
				
				destination.Size = new Size(c.FloatingSize.Width, 
					c.FloatingSize.Height + SystemInformation.ToolWindowCaptionHeight);
			}
			
			z.Windows.Add(w);

			if (newState != State.Floating)
			{
				ReorderZoneToInnerMost(z);

				UpdateInsideFill();

				destination.ResumeLayout();
			}
			else
				destination.Show();

			msurpressVisibleEvents--;

			OnContentShown(c);

			return w as WindowContent;
		}

		public WindowContent AddContentToWindowContent(Content c, WindowContent wc)
		{
			if ((c == null) || !mcontents.Contains(c))
				return null;

			if (wc == null)
				return null;

			if (c.ParentWindowContent == wc)
				return wc;
			else
			{
				bool valid = true;

				msurpressVisibleEvents++;

				RemoveShowingAutoHideWindows();
                
				if (c.ParentWindowContent != null)
				{
					if (c.ParentWindowContent.ParentZone.State != wc.ParentZone.State)
					{
						if (c.ParentWindowContent.ParentZone.State == State.Floating)
							c.ContentLeavesFloating();
						else
							c.ContentBecomesFloating();
					}

					c.ParentWindowContent.Contents.Remove(c);
				}
				else
				{
					if (wc.ParentZone != null)
					{
						if (wc.ParentZone.State == State.Floating)
							c.Docked = false;
					}
					else
					{
						valid = false;
					}
				}

				if (valid)
				{
					wc.Contents.Add(c);
				}

				msurpressVisibleEvents--;

				if (valid)
				{
					OnContentShown(c);
				}

				return wc;
			}
		}

		public Window AddContentToZone(Content c, Zone z, int index)
		{
			if ((c == null) || !mcontents.Contains(c))
				return null;

			if (z == null) 
				return null;

			msurpressVisibleEvents++;

			RemoveShowingAutoHideWindows();
                
			if (c.ParentWindowContent != null)
			{
				if (c.ParentWindowContent.ParentZone.State != z.State)
				{
					if (c.ParentWindowContent.ParentZone.State == State.Floating)
						c.ContentLeavesFloating();
					else
						c.ContentBecomesFloating();
				}

				c.ParentWindowContent.Contents.Remove(c);
			}
			else
			{
				if (z.State == State.Floating)
					c.Docked = false;
			}

			Window w = CreateWindowForContent(c);

			z.Windows.Insert(index, w);

			msurpressVisibleEvents--;
			OnContentShown(c);

			return w;
		}

		public Rectangle InnerResizeRectangle(Control source)
		{
			Rectangle client = mcontainer.ClientRectangle;

			int count = mcontainer.Controls.Count;
			int inner = mcontainer.Controls.IndexOf(minnerControl);
			int sourceIndex = mcontainer.Controls.IndexOf(source);

			for(int index=count-1; index>inner; index--)
			{
				Control item = mcontainer.Controls[index];

				bool insideSource = (index < sourceIndex);

				switch(item.Dock)
				{
					case DockStyle.Left:
						client.Width -= item.Width;
						client.X += item.Width;

						if (insideSource)
							client.Width -= item.Width;
						break;
					case DockStyle.Right:
						client.Width -= item.Width;

						if (insideSource)
						{
							client.Width -= item.Width;
							client.X += item.Width;
						}
						break;
					case DockStyle.Top:
						client.Height -= item.Height;
						client.Y += item.Height;

						if (insideSource)
							client.Height -= item.Height;
						break;
					case DockStyle.Bottom:
						client.Height -= item.Height;

						if (insideSource)
						{
							client.Height -= item.Height;
							client.Y += item.Height;
						}
						break;
					case DockStyle.Fill:
					case DockStyle.None:
						break;
				}
			}

			return client;
		}

		public void ReorderZoneToInnerMost(Zone zone)
		{
			int index = 0;

			if (minnerControl != null)
			{
				index = mcontainer.Controls.IndexOf(minnerControl) + 1;
			}

			int current = mcontainer.Controls.IndexOf(zone);

			if (current < index)
				index--;

			mcontainer.Controls.SetChildIndex(zone, index);
            
			RemoveShowingAutoHideWindows();
		}

		public void ReorderZoneToOuterMost(Zone zone)
		{
			int index = OuterControlIndex();

			int current = mcontainer.Controls.IndexOf(zone);

			if (current < index)
				index--;

			mcontainer.Controls.SetChildIndex(zone, index);

			RemoveShowingAutoHideWindows();
		}
        
		public int OuterControlIndex()
		{
			int index = mcontainer.Controls.Count;

			if (mouterControl != null)
			{
				index = mcontainer.Controls.IndexOf(mouterControl);
			}

			for(; index>0; index--)
				if (!(mcontainer.Controls[index-1] is AutoHidePanel))
					break;
                    
			return index;
		}

		public void RemoveShowingAutoHideWindows()
		{
			mahpLeft.RemoveShowingWindow();
			mahpRight.RemoveShowingWindow();
			mahpTop.RemoveShowingWindow();
			mahpBottom.RemoveShowingWindow();
		}
        
		internal void RemoveShowingAutoHideWindowsExcept(AutoHidePanel except)
		{
			if (except != mahpLeft)
				mahpLeft.RemoveShowingWindow();

			if (except != mahpRight)
				mahpRight.RemoveShowingWindow();
            
			if (except != mahpTop)
				mahpTop.RemoveShowingWindow();
            
			if (except != mahpBottom)
				mahpBottom.RemoveShowingWindow();
		}

		public void BringAutoHideIntoView(Content c)
		{
			if (mahpLeft.ContainsContent(c))
				mahpLeft.BringContentIntoView(c);     

			if (mahpRight.ContainsContent(c))
				mahpRight.BringContentIntoView(c);     

			if (mahpTop.ContainsContent(c))
				mahpTop.BringContentIntoView(c);     

			if (mahpBottom.ContainsContent(c))
				mahpBottom.BringContentIntoView(c);     
		}            
        
		public void ValuesFromState(State newState, out DockStyle dockState, out Direction direction)
		{
			switch(newState)
			{
				case State.Floating:
					dockState = DockStyle.Fill;
					direction = Direction.Vertical;
					break;
				case State.DockTop:
					dockState = DockStyle.Top;
					direction = Direction.Horizontal;
					break;
				case State.DockBottom:
					dockState = DockStyle.Bottom;
					direction = Direction.Horizontal;
					break;
				case State.DockRight:
					dockState = DockStyle.Right;
					direction = Direction.Vertical;
					break;
				case State.DockLeft:
				default:
					dockState = DockStyle.Left;
					direction = Direction.Vertical;
					break;
			}
		}

		public byte[] SaveConfigToArray()
		{
			return SaveConfigToArray(Encoding.Unicode);	
		}

		public byte[] SaveConfigToArray(Encoding encoding)
		{
			MemoryStream ms = new MemoryStream();
			
			SaveConfigToStream(ms, encoding);

			ms.Close();

			return ms.GetBuffer();
		}

		public void SaveConfigToFile(string filename)
		{
			SaveConfigToFile(filename, Encoding.Unicode);
		}

		public void SaveConfigToFile(string filename, Encoding encoding)
		{
			FileStream fs = new FileStream(filename, FileMode.Create);
			
			SaveConfigToStream(fs, encoding);		

			fs.Close();
		}

		public void SaveConfigToStream(Stream stream, Encoding encoding)
		{
			XmlTextWriter xmlOut = new XmlTextWriter(stream, encoding); 

			xmlOut.Formatting = Formatting.Indented;
			
			xmlOut.WriteStartDocument();
			xmlOut.WriteComment(" PallaControls Sistemas de Automa��o ");
			xmlOut.WriteComment(" Modificar este arquivo pode causar dados no momento da leitura ");

			xmlOut.WriteStartElement("DockingConfig");
			xmlOut.WriteAttributeString("FormatVersion", "5");
			xmlOut.WriteAttributeString("InsideFill", minsideFill.ToString(CultureInfo.CurrentCulture));
			xmlOut.WriteAttributeString("InnerMinimum", DrawHelpers.SizeToString(minnerMinimum));

			mcontainer.SuspendLayout();

			ContentCollection hideContent = new ContentCollection();

			ContentCollection origContents = mcontents.Copy();

			msurpressVisibleEvents++;
            
			int count = origContents.Count;

			for(int index=count-1; index>=0; index--)
			{
				Content c = origContents[index];
            
				c.RecordRestore();
				c.SaveToXml(xmlOut);

				if (c.Visible)
				{
					hideContent.Insert(0, c);
					HideContent(c);
				}
			}
			
			OnSaveCustomConfig(xmlOut);

			foreach(Content c in hideContent)
				ShowContent(c);

			msurpressVisibleEvents--;
            
			AddInnerFillStyle();

			mcontainer.ResumeLayout();

			xmlOut.WriteEndElement();
			xmlOut.WriteEndDocument();

			xmlOut.Close();			
		}

		public void LoadConfigFromArray(byte[] buffer)
		{
			MemoryStream ms = new MemoryStream(buffer);
			
			LoadConfigFromStream(ms);

			ms.Close();
		}

		public void LoadConfigFromFile(string filename)
		{
			FileStream fs = new FileStream(filename, FileMode.Open);
			
			LoadConfigFromStream(fs);		

			fs.Close();
		}

		public void LoadConfigFromStream(Stream stream)
		{
			XmlTextReader xmlIn = new XmlTextReader(stream); 

			xmlIn.WhitespaceHandling = WhitespaceHandling.None;

			xmlIn.MoveToContent();

			if (xmlIn.Name != "DockingConfig")
				throw new ArgumentException(String.Format(CultureInfo.CurrentCulture, ResourceLibrary.GetString(WindowsControlsResourceKeys.ElementNotFound, WindowsControlsResourceKeys.Root), "DockingConfig"));

			string version = xmlIn.GetAttribute(0);
			string insideFill = xmlIn.GetAttribute(1);
			string innerSize = xmlIn.GetAttribute(2);

			int formatVersion = (int)Convert.ToDouble(version, CultureInfo.CurrentCulture);
            
			if (formatVersion < 3)
				throw new ArgumentException("Invalid version");

			minsideFill = (bool)Convert.ToBoolean(insideFill, CultureInfo.CurrentCulture);
			minnerMinimum = DrawHelpers.StringToSize(innerSize);

			ContentCollection cc = new ContentCollection();

			do
			{
				if (!xmlIn.Read())
					throw new ArgumentException(ResourceLibrary.GetString(WindowsControlsResourceKeys.InaccessibleNode, WindowsControlsResourceKeys.Root));

				if ((xmlIn.NodeType == XmlNodeType.EndElement) && (xmlIn.Name == "DockingConfig"))
					break;

				if (xmlIn.Name == "Content")
				{
					cc.Insert(0, new Content(xmlIn, formatVersion));
				}
				else
				{
					OnLoadCustomConfig(xmlIn);

					xmlIn.Close();			
                   
					break;
				}

			} while(!xmlIn.EOF);

			xmlIn.Close();			

			mcontainer.SuspendLayout();

			HideAllContents();

			foreach(Content loaded in cc)
			{
				Content c = mcontents[loaded.Title];

				if (c != null)
				{
					c.Docked = loaded.Docked;
					c.AutoHidden = loaded.AutoHidden;
					c.CaptionBar = loaded.CaptionBar;
					c.CloseButton = loaded.CloseButton;
					c.DisplaySize = loaded.DisplaySize;
					c.DisplayLocation = loaded.DisplayLocation;
					c.AutoHideSize = loaded.AutoHideSize;
					c.FloatingSize = loaded.FloatingSize;
					c.DefaultRestore = loaded.DefaultRestore;
					c.AutoHideRestore = loaded.AutoHideRestore;
					c.DockingRestore = loaded.DockingRestore;
					c.FloatingRestore = loaded.FloatingRestore;

					c.ReconnectRestore();					

					if (loaded.Visible)
					{
						ShowContent(c);
					}
				}
			}

			AddInnerFillStyle();

			mcontainer.ResumeLayout();
			
			mahpLeft.Invalidate();
			mahpRight.Invalidate();
			mahpTop.Invalidate();
			mahpBottom.Invalidate();
		}
        
		public void PropogateNameValue(PropogateName name, object value)
		{
			foreach(Control c in mcontainer.Controls)
			{
				Zone z = c as Zone;

				if (z != null)
					z.PropogateNameValue(name, value);
			}

			if (mcontainer.FindForm() != null)
			{
				foreach(Form f in mcontainer.FindForm().OwnedForms)
				{
					FloatingForm ff = f as FloatingForm;
                    
					if (ff != null)
						ff.PropogateNameValue(name, value);
				}
			}
            
			mahpTop.PropogateNameValue(name, value);
			mahpLeft.PropogateNameValue(name, value);
			mahpRight.PropogateNameValue(name, value);
			mahpBottom.PropogateNameValue(name, value);
		}

		internal AutoHidePanel AutoHidePanelForState(State state)
		{
			AutoHidePanel ahp = null;

			switch(state)
			{
				case State.DockLeft:
					ahp = mahpLeft;
					break;
				case State.DockRight:
					ahp = mahpRight;
					break;
				case State.DockTop:
					ahp = mahpTop;
					break;
				case State.DockBottom:
					ahp = mahpBottom;
					break;
			}

			return ahp;
		}
        
		internal void AutoHideContents(ContentCollection cc, State state)
		{
			foreach(Content c in cc)
				HideContent(c);

			AutoHidePanel ahp = AutoHidePanelForState(state);

			ahp.AddContentsAsGroup(cc);
		}

		internal AutoHidePanel AutoHidePanelForContent(Content c)
		{
			if (mahpLeft.ContainsContent(c))
				return mahpLeft;     

			if (mahpRight.ContainsContent(c))
				return mahpRight;     

			if (mahpTop.ContainsContent(c))
				return mahpTop;     

			if (mahpBottom.ContainsContent(c))
				return mahpBottom;     
                
			return null;
		}

		#endregion

		#region Properties
        
		public StyleGuide Style
		{
			get {return menterpriseStyle;}
			set 
			{
				menterpriseStyle = value;

				if (menterpriseStyle != null)
				{
					PlansOfColorsChangedEventArgs oArgs = new PlansOfColorsChangedEventArgs(menterpriseStyle.PlansOfColors);
					OnPlansOfColorsChanged(this, oArgs);

					menterpriseStyle.StyleChanged += new StyleChangedEventHandler(this.OnStyleChanged);
					menterpriseStyle.PlansOfColorsChanged += new PlansOfColorsChangedEventHandler(this.OnPlansOfColorsChanged);
				}
			}
		}
		
		public ContainerControl Container
		{
			get { return mcontainer; }
		}

		public Control InnerControl
		{
			get { return minnerControl; }
			set { minnerControl = value; }
		}

		public Control OuterControl
		{
			get { return mouterControl; }
			set 
			{
				if (mouterControl != value)
				{
					mouterControl = value;
				    
					ReorderAutoHidePanels();
				}
			}
		}

		public ManagerContentCollection Contents
		{
			get { return mcontents; }
			/*set 
			{
				mcontents.Clear();
				mcontents = value;	
			}*/
		}

		public bool ZoneMinMax
		{
			get { return mzoneMinMax; }

			set 
			{ 
				if (value != mzoneMinMax)
				{
					mzoneMinMax = value;
                
					PropogateNameValue(PropogateName.ZoneMinMax, (object)mzoneMinMax);
				} 
			}
		}

		public bool InsideFill
		{
			get { return minsideFill; }

			set
			{
				if (minsideFill != value)
				{
					minsideFill = value;

					if (minsideFill)
					{
						AddInnerFillStyle();
					}
					else
					{
						RemoveAnyFillStyle();
						
						OnContainerResized(null, EventArgs.Empty);
					}
				}
			}
		}

		public bool AutoResize
		{
			get { return mautoResize; }
			set { mautoResize = value; }
		}

		public Size InnerMinimum
		{
			get { return minnerMinimum; }
			set { minnerMinimum = value; }
		}

		public int ResizeBarVector
		{
			get { return mresizeBarVector; }
            
			set 
			{
				if (value != mresizeBarVector)
				{
					mresizeBarVector = value;
                    
					PropogateNameValue(PropogateName.ResizeBarVector, (object)mresizeBarVector);
				}
			}
		}

		public Color BackColor
		{
			get { return mbackColor; }
            
			set 
			{
				if (value != mbackColor)
				{
					mbackColor = value;
					mdefaultBackColor = (mbackColor == SystemColors.Control);
                    
					PropogateNameValue(PropogateName.BackColor, (object)mbackColor);
				}
			}
		}
    
		public Color ActiveColor
		{
			get { return mactiveColor; }
            
			set 
			{
				if (value != mactiveColor)
				{
					mactiveColor = value;
					mdefaultActiveColor = (mactiveColor == SystemColors.ActiveCaption);
                    
					PropogateNameValue(PropogateName.ActiveColor, (object)mactiveColor);
				}
			}
		}
        
		public Color ActiveTextColor
		{
			get { return mactiveTextColor; }
            
			set 
			{
				if (value != mactiveTextColor)
				{
					mactiveTextColor = value;
					mdefaultActiveTextColor = (mactiveTextColor == SystemColors.ActiveCaptionText);
                    
					PropogateNameValue(PropogateName.ActiveTextColor, (object)mactiveTextColor);
				}
			}
		}

		public Color InactiveTextColor
		{
			get { return minactiveTextColor; }
            
			set 
			{
				if (value != minactiveTextColor)
				{
					minactiveTextColor = value;
					mdefaultInactiveTextColor = (minactiveTextColor == SystemColors.ControlText);
                    
					PropogateNameValue(PropogateName.InactiveTextColor, (object)minactiveTextColor);
				}
			}
		}

		public Color ResizeBarColor
		{
			get { return mresizeBarColor; }
            
			set 
			{
				if (value != mresizeBarColor)
				{
					mresizeBarColor = value;
					mdefaultResizeBarColor = (mresizeBarColor == SystemColors.Control);
                    
					PropogateNameValue(PropogateName.ResizeBarColor, (object)mresizeBarColor);
				}
			}
		}
        
		public Font CaptionFont
		{
			get { return mcaptionFont; }
            
			set 
			{
				if (value != mcaptionFont)
				{
					mcaptionFont = value;
					mdefaultCaptionFont = (mcaptionFont == SystemInformation.MenuFont);
                    
					PropogateNameValue(PropogateName.CaptionFont, (object)mcaptionFont);
				}
			}
		}

		public Font TabControlFont
		{
			get { return mtabControlFont; }
            
			set 
			{
				if (value != mtabControlFont)
				{
					mtabControlFont = value;
					mdefaultTabControlFont = (mcaptionFont == SystemInformation.MenuFont);
                    
					PropogateNameValue(PropogateName.TabControlFont, (object)mtabControlFont);
				}
			}
		}

		public bool PlainTabBorder
		{
			get { return mplainTabBorder; }
            
			set 
			{
				if (value != mplainTabBorder)
				{
					mplainTabBorder = value;
                    
					PropogateNameValue(PropogateName.PlainTabBorder, (object)mplainTabBorder);
				}
			}
		}

		internal int SurpressVisibleEvents
		{
			get { return msurpressVisibleEvents; }
			set { msurpressVisibleEvents = value; }
		}

		#endregion
    }
}