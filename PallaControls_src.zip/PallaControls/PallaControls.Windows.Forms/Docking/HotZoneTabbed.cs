using System;
using System.Drawing;
using System.Windows.Forms;
using PallaControls.Windows.Forms.Helpers;

namespace PallaControls.Windows.Docking
{
    public class HotZoneTabbed : HotZone
    {
        protected static int mtabPageLeft = 9;
        protected static int mtabPageHeight = 25;
        protected static int mtabPageWidth= 45;

        protected bool mitself;
        protected Rectangle mtabRect;
        protected Rectangle mtabRectTL;
        protected Rectangle mtabRectTR;
        protected WindowContentTabbed mwct;

		#region Constructors
		
		public HotZoneTabbed(Rectangle hotArea, Rectangle newSize, WindowContentTabbed wct, bool itself) : base(hotArea, newSize)
        {
            mwct = wct;
            mitself = itself;

            int tabHeight = mtabPageHeight;

            if (newSize.Height < (tabHeight + mdragWidth))
                tabHeight = newSize.Height -  mdragWidth * 3;

            mtabRect = new Rectangle(newSize.X + mtabPageLeft,
                                     newSize.Bottom - tabHeight,
                                     mtabPageWidth,
                                     tabHeight);

            if (mtabRect.Right > newSize.Right)
                mtabRect.Width -= mtabRect.Right - newSize.Right;

            mtabRectTL = new Rectangle(mtabRect.X, mtabRect.Y, mdragWidth, mdragWidth);
            mtabRectTR = new Rectangle(mtabRect.Right - mdragWidth, mtabRect.Y, mdragWidth, mdragWidth);

            mnewSize.Height -= tabHeight - mdragWidth;
        }

		#endregion

		#region Overrides

        public override bool ApplyChange(Point screenPos, Redocker parent)
        {
            if (mitself)
                return false;

            RedockerContent redock = parent as RedockerContent;

            DockingManager dockingManager = redock.DockingManager;

			bool becomeFloating = (mwct.ParentZone.State == State.Floating);

            dockingManager.Container.SuspendLayout();

            dockingManager.RemoveShowingAutoHideWindows();

            switch(redock.DockingSource)
            {
                case RedockerContent.Source.RawContent:
					{
						if (becomeFloating)
							redock.Content.ContentBecomesFloating();

						mwct.Contents.Add(redock.Content);
					}
                    break;
                case RedockerContent.Source.WindowContent:
					{
						if (becomeFloating)
						{
							foreach(Content c in redock.WindowContent.Contents)
								c.ContentBecomesFloating();
						}
                        else
                        {
                            if (redock.WindowContent.State == State.Floating)
                            {
                                foreach(Content c in redock.WindowContent.Contents)
                                    c.ContentLeavesFloating();
                            }
                        }

						int count = redock.WindowContent.Contents.Count;

						for(int index=0; index<count; index++)
						{
							Content c = redock.WindowContent.Contents[0];

							redock.WindowContent.Contents.RemoveAt(0);

							mwct.Contents.Add(c);
						}
					}
                    break;
                case RedockerContent.Source.ContentInsideWindow:
					{
						if (becomeFloating)
							redock.Content.ContentBecomesFloating();
                        else
                        {
                            if (redock.Content.ParentWindowContent.State == State.Floating)
                                redock.Content.ContentLeavesFloating();
                        }

						if (redock.Content.ParentWindowContent != null)
							redock.Content.ParentWindowContent.Contents.Remove(redock.Content);

						mwct.Contents.Add(redock.Content);
					}
                    break;
                case RedockerContent.Source.FloatingForm:
					{
						if (!becomeFloating)
						{
							redock.FloatingForm.ExitFloating();
						}

						int wCount = redock.FloatingForm.Zone.Windows.Count;
                    
						for(int wIndex=0; wIndex<wCount; wIndex++)
						{
							WindowContent wc = redock.FloatingForm.Zone.Windows[0] as WindowContent;

							if (wc != null)
							{
								int cCount = wc.Contents.Count;
                            
								for(int cIndex=0; cIndex<cCount; cIndex++)
								{
									Content c = wc.Contents[0];

									wc.Contents.RemoveAt(0);

									mwct.Contents.Add(c);
								}
							}
						}
					}
                    break;
            }

			dockingManager.UpdateInsideFill();

            dockingManager.Container.ResumeLayout();

            return true;
        }

        public override void DrawReversible(Rectangle rect)
        {
            GraphicsUtils.DrawDragRectangles(new Rectangle[]{rect, mtabRect, mtabRectTL, mtabRectTR}, mdragWidth);
        }

		#endregion
    }
}