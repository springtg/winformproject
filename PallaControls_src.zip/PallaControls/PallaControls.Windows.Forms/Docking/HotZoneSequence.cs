using System;
using System.Drawing;
using System.Windows.Forms;

namespace PallaControls.Windows.Docking
{
    public class HotZoneSequence : HotZone
    {
        protected int mindex;
        protected ZoneSequence mzs;

		#region Constructors

		public HotZoneSequence(Rectangle hotArea, Rectangle newSize, ZoneSequence zs, int index) : base(hotArea, newSize)
        {
            mindex = index;
            mzs = zs;
        }

		#endregion

		#region Overrides

        public override bool ApplyChange(Point screenPos, Redocker parent)
        {
            RedockerContent redock = parent as RedockerContent;

            DockingManager dockingManager = redock.DockingManager;

			bool becomeFloating = (mzs.State == State.Floating);

            dockingManager.Container.SuspendLayout();

            dockingManager.RemoveShowingAutoHideWindows();

            switch(redock.DockingSource)
            {
                case RedockerContent.Source.RawContent:
                    {
						if (becomeFloating)
							redock.Content.ContentBecomesFloating();

                        Window w = dockingManager.CreateWindowForContent(redock.Content);

                        mzs.Windows.Insert(mindex, w);
                    }
                    break;
                case RedockerContent.Source.WindowContent:
                    {
						if (becomeFloating)
						{
							foreach(Content c in redock.WindowContent.Contents)
								c.ContentBecomesFloating();
						}
						else
						{
						    if (redock.WindowContent.State == State.Floating)
						    {
                                foreach(Content c in redock.WindowContent.Contents)
                                    c.ContentLeavesFloating();
                            }
						}

                        if (redock.WindowContent.ParentZone == mzs)
                        {
                            int currPos = mzs.Windows.IndexOf(redock.WindowContent);
                            
                            if (currPos < mindex)
                                mindex--;
                        }

                        WindowContent wc = dockingManager.CreateWindowForContent(null) as WindowContent;

                        int count = redock.WindowContent.Contents.Count;
                        
                        for(int index=0; index<count; index++)
                        {
                            Content c = redock.WindowContent.Contents[0];

                            redock.WindowContent.Contents.RemoveAt(0);

                            wc.Contents.Add(c);  
                        }

                        mzs.Windows.Insert(mindex, wc);
                    }
                    break;
                case RedockerContent.Source.ContentInsideWindow:
                    {
						if (becomeFloating)
							redock.Content.ContentBecomesFloating();
						else
						{
						    if (redock.Content.ParentWindowContent.State == State.Floating)
                                redock.Content.ContentLeavesFloating();
                        }

                        if (redock.Content.ParentWindowContent != null)
                        {
                            if (redock.Content.ParentWindowContent.Contents.Count == 1)
                            {
                                if (redock.Content.ParentWindowContent.ParentZone == mzs)
                                {
                                    int currPos = mzs.Windows.IndexOf(redock.Content.ParentWindowContent);
                            
                                    if (currPos < mindex)
                                        mindex--;
                                }
                            }

                            redock.Content.ParentWindowContent.Contents.Remove(redock.Content);
                        }
    				
                        Window w = dockingManager.CreateWindowForContent(redock.Content);

                        mzs.Windows.Insert(mindex, w);
                    }
                    break;
                case RedockerContent.Source.FloatingForm:
                    {
						if (!becomeFloating)
						{
							redock.FloatingForm.ExitFloating();
						}

                        int count = redock.FloatingForm.Zone.Windows.Count;
                        
                        for(int index=count-1; index>=0; index--)
                        {
                            Window w = redock.FloatingForm.Zone.Windows[index];
                        
                            redock.FloatingForm.Zone.Windows.RemoveAt(index);

                            mzs.Windows.Insert(mindex, w);
                        }
                    }
                    break;
            }

			dockingManager.UpdateInsideFill();

            dockingManager.Container.ResumeLayout();

            return true;
        }

		#endregion
    }
}