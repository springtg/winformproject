using System;
using System.Drawing;
using System.Windows.Forms;
using System.ComponentModel;
using PallaControls.Windows.Forms.Helpers;

namespace PallaControls.Windows.Docking
{
    [ToolboxItem(false)]
    public class WindowDetail : Control
    {
        protected Zone mparentZone;
        protected Window mparentWindow;
        protected DockingManager mmanager;

		#region Constructors
		
		public WindowDetail(DockingManager manager)
        {
            mparentZone = null;
            mparentWindow = null;
            mmanager = manager;
            
            this.BackColor = mmanager.BackColor;            
            this.ForeColor = mmanager.InactiveTextColor;
        }

		#endregion
		
		#region Overrides

        protected override void OnGotFocus(EventArgs e)
        {
            if (mparentWindow != null)
                mparentWindow.WindowDetailGotFocus(this);

            base.OnGotFocus(e);
        }

        protected override void OnLostFocus(EventArgs e)
        {
            if (mparentWindow != null)
                mparentWindow.WindowDetailLostFocus(this);

            base.OnLostFocus(e);
        }

		#endregion

		#region Virtuals

		public virtual void WindowGotFocus() {}
		public virtual void WindowLostFocus() {}
		public virtual void NotifyRedockAllowed(bool redockAllowed) {}
		public virtual void NotifyAutoHideImage(bool autoHidden) {}
		public virtual void NotifyCloseButton(bool show) {}
		public virtual void NotifyHideButton(bool show) {}
		public virtual void NotifyShowCaptionBar(bool show) {}
		public virtual void NotifyFullTitleText(string title) {}
		public virtual void ParentStateChanged(State newState) {}
		public virtual void RemovedFromParent(Window parent) {}
		public virtual void AddedToParent(Window parent) {}

		public virtual void PropogateNameValue(PropogateName name, object value)
		{
			if (name == PropogateName.BackColor)
			{
				this.BackColor = (Color)value;
				Invalidate();
			}
		}

		#endregion

		#region Properties

		public virtual Zone ParentZone
		{ 
			get { return mparentZone; }
			set { mparentZone = value; }
		}

		public Window ParentWindow
		{ 
			get { return mparentWindow; }
			
			set 
			{
				RemovedFromParent(mparentWindow);

				if (value == null)
				{
					if (mparentWindow != null)
					{
						ControlUtilities.Remove(mparentWindow.Controls, this);
					}
				}
				else
				{
					if ((mparentWindow != null) && (mparentWindow != value))
					{
						RemovedFromParent(mparentWindow);
						ControlUtilities.Remove(mparentWindow.Controls, this);
					}
	
					value.Controls.Add(this);
				}

				mparentWindow = value;

				AddedToParent(mparentWindow);

				if (mparentWindow != null)
				{
					ParentStateChanged(mparentWindow.State);
				}
			}
		}

		#endregion
    }
}