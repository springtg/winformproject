using System;
using System.Drawing;
using System.Windows.Forms;
using System.ComponentModel;
using PallaControls.Windows.Forms.Collections;

namespace PallaControls.Windows.Docking
{
    [ToolboxItem(false)]
    public class Zone : Panel
    {
        protected State mstate;
        protected bool mautoDispose;
        protected DockingManager mmanager;
        protected WindowCollection mwindows;

		#region Constructors

		public Zone(DockingManager manager)
        {
            InternalConstruct(manager, State.DockLeft);
        }

        public Zone(DockingManager manager, State state)
        {
            InternalConstruct(manager, state);
        }

        protected void InternalConstruct(DockingManager manager, State state)
        {
            if (manager == null)
                throw new ArgumentNullException("DockingManager");

            mstate = state;
            mmanager = manager;
            mautoDispose = true;

            this.BackColor = mmanager.BackColor;
            this.ForeColor = mmanager.InactiveTextColor;

            mwindows = new WindowCollection();

            mwindows.Clearing += new CollectionClearEventHandler(OnWindowsClearing);
            mwindows.Inserted += new PallaControls.Windows.Forms.Collections.CollectionChangeEventHandler(OnWindowInserted);
            mwindows.Removing += new PallaControls.Windows.Forms.Collections.CollectionChangeEventHandler(OnWindowRemoving);
            mwindows.Removed += new PallaControls.Windows.Forms.Collections.CollectionChangeEventHandler(OnWindowRemoved);
        }

		#endregion

		#region Properties

		public virtual State State
        {
            get { return mstate; }
            set { mstate = value; }
        }

        public bool AutoDispose
        {
            get { return mautoDispose; }
            set { mautoDispose = value; }
        }

        public DockingManager DockingManager
        {
            get { return mmanager; }
        }

        public WindowCollection Windows
        {
            get { return mwindows; }

            /*set
            {
                mwindows.Clear();
                mwindows = value;
            }*/
        }

		#endregion

		#region Virtuals

		public virtual Restore RecordRestore(Window w, object child, Restore childRestore) { return null; }
		public virtual int MinimumWidth { get { return 0; } }
		public virtual int MinimumHeight { get { return 0; } }

        public virtual void PropogateNameValue(PropogateName name, object value)
        {
            if (name == PropogateName.BackColor)
            {
                this.BackColor = (Color)value;
                Invalidate();
            }

            foreach(Window w in mwindows)
                w.PropogateNameValue(name, value);
        }

        protected virtual void OnWindowsClearing(object sender, EventArgs e)
        {
            foreach(Control c in Controls)
            {
                Window w = c as Window;

                if (w != null)
                    w.ParentZone = null;
            }

            if (this.AutoDispose)
            {
                mwindows.Clearing -= new CollectionClearEventHandler(OnWindowsClearing);
                mwindows.Inserted -= new PallaControls.Windows.Forms.Collections.CollectionChangeEventHandler(OnWindowInserted);
                mwindows.Removing -= new PallaControls.Windows.Forms.Collections.CollectionChangeEventHandler(OnWindowRemoving);
                mwindows.Removed -= new PallaControls.Windows.Forms.Collections.CollectionChangeEventHandler(OnWindowRemoved);

                this.Dispose();
            }
        }

        protected virtual void OnWindowInserted(object sender, PallaControls.Windows.Forms.Collections.CollectionChangeEventArgs e)
        {
            Window w = sender as Window;

            w.ParentZone = this;

            w.State = mstate;
        }

        protected virtual void OnWindowRemoving(object sender, PallaControls.Windows.Forms.Collections.CollectionChangeEventArgs e)
        {
            Window w = sender as Window;
            w.ParentZone = null;
        }

        protected virtual void OnWindowRemoved(object sender, PallaControls.Windows.Forms.Collections.CollectionChangeEventArgs e)
        {
            if (mwindows.Count == 0)
            {
                if (this.AutoDispose)
                    this.Dispose();
            }
        }

		#endregion
    }
}
