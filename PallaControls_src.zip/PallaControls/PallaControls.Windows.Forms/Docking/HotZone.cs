using System;
using System.Drawing;
using System.Windows.Forms;
using PallaControls.Windows.Forms.Helpers;

namespace PallaControls.Windows.Docking
{
    public class HotZone
    {
        protected static int mdragWidth = 4;
        protected Rectangle mhotArea;
        protected Rectangle mnewSize;

		#region Constructors

		public HotZone(Rectangle hotArea, Rectangle newSize)
        {
            mhotArea = hotArea;
            mnewSize = newSize;
        }

		#endregion

		#region Virtuals

		public virtual bool ApplyChange(Point screenPos, Redocker parent) { return false; }
		public virtual void UpdateForMousePosition(Point screenPos, Redocker parent) {}

		public virtual void DrawIndicator(Point mousePos) 
		{
			DrawReversible(mnewSize);
		}
		
		public virtual void RemoveIndicator(Point mousePos) 
		{
			DrawReversible(mnewSize);
		}

		public virtual void DrawReversible(Rectangle rect)
		{
			GraphicsUtils.DrawDragRectangle(rect, mdragWidth);
		}

		#endregion

		#region Properties

        public Rectangle HotArea
        {
            get { return mhotArea; }
        }

        public Rectangle NewSize
        {
            get { return mnewSize; }
        }

		#endregion

    }
}