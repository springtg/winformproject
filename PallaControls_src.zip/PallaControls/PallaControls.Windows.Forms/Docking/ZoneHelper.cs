using System;
using System.Drawing;
using System.Windows.Forms;
using PallaControls.Windows.Docking;
using PallaControls.Windows.Forms.Collections;

namespace PallaControls.Windows.Docking
{
    public class ZoneHelper
    {
		#region Constructors

		private ZoneHelper()
		{
		}

		#endregion
		
		#region Methods
		
		public static ContentCollection Contents(Zone z)
		{
			ContentCollection cc = new ContentCollection();

			foreach(Window w in z.Windows)
			{
				WindowContent wc = w as WindowContent;

				if (wc != null)
				{
					foreach(Content c in wc.Contents)
						cc.Add(c);
				}
			}

			return cc;
		}

		public static StringCollection ContentNames(Zone z)
		{
			StringCollection sc = new StringCollection();

			foreach(Window w in z.Windows)
			{
				WindowContent wc = w as WindowContent;

				if (wc != null)
				{
					foreach(Content c in wc.Contents)
						sc.Add(c.Title);
				}
			}

			return sc;
		}

		public static StringCollection ContentNamesInPriority(Zone z, Content c)
		{
			StringCollection sc = new StringCollection();

			foreach(Window w in z.Windows)
			{
				WindowContent wc = w as WindowContent;

				if (wc != null)
				{
					if (wc.Contents.Contains(c))
					{
						foreach(Content content in wc.Contents)
							sc.Insert(0, content.Title);
					}
					else
					{
						foreach(Content content in wc.Contents)
							sc.Add(content.Title);
					}
				}
			}

			return sc;
		}

		#endregion
    }
}