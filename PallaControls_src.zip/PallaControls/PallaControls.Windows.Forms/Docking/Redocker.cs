using System;
using System.Windows.Forms;
using PallaControls.Windows.Docking;

namespace PallaControls.Windows.Docking
{
    public class Redocker
    {
        protected bool mtracking;

		#region Constructors

		public Redocker()
        {
            mtracking = false;
        }

		#endregion

		#region Virtual

		public virtual void EnterTrackingMode()
		{
			if (!mtracking)
				mtracking = true;
		}

		public virtual bool ExitTrackingMode(MouseEventArgs e)
		{
			if (mtracking)
				mtracking = false;

			return false;
		}

		public virtual void QuitTrackingMode(MouseEventArgs e)
		{
			if (mtracking)
				mtracking = false;
		}

		public virtual void OnMouseMove(MouseEventArgs e) {}

		public virtual bool OnMouseUp(MouseEventArgs e)
		{
			if (mtracking)
			{
				if (e.Button == MouseButtons.Left)
					return ExitTrackingMode(e);
				else
					QuitTrackingMode(e);
			}

			return false;
		}

		#endregion

		#region Properties

		public bool Tracking
        {
            get { return mtracking; }
        }

		#endregion
    }
}
