using System;
using System.Drawing;
using System.Windows.Forms;
using System.ComponentModel;
using PallaControls.Windows.Forms;
using PallaControls.Windows.Forms.Collections;

namespace PallaControls.Windows.Docking
{
    [ToolboxItem(false)]
    public class WindowContent : Window
    {
        protected ContentCollection mcontents;

		#region Constructors

		public WindowContent(DockingManager manager) : base(manager)
        {
        
            mcontents = new ContentCollection();

            mcontents.Clearing += new CollectionClearEventHandler(OnContentsClearing);
            mcontents.Inserted += new PallaControls.Windows.Forms.Collections.CollectionChangeEventHandler(OnContentInserted);
            mcontents.Removing += new PallaControls.Windows.Forms.Collections.CollectionChangeEventHandler(OnContentRemoving);
            mcontents.Removed += new PallaControls.Windows.Forms.Collections.CollectionChangeEventHandler(OnContentRemoved);
        }

		#endregion

		#region Virtuals

		public virtual void BringContentToFront(Content c) {}

        protected virtual void OnContentsClearing(object sender, EventArgs e)
        {
            foreach(Content c in mcontents)
            {
                c.ParentWindowContent = null;

                c.PropertyChanged -= new Content.PropChangeEventHandler(OnContentChanged);
            }

            if (this.AutoDispose)
                Suicide();
        }

        protected virtual void OnContentInserted(object sender, PallaControls.Windows.Forms.Collections.CollectionChangeEventArgs e)
        {
            Content content = sender as Content;

            if (mcontents.Count == 1)
            {
                this.Size = content.DisplaySize;
            }

            content.ParentWindowContent = this;

            content.PropertyChanged += new Content.PropChangeEventHandler(OnContentChanged);
        }

        protected virtual void OnContentRemoving(object sender, PallaControls.Windows.Forms.Collections.CollectionChangeEventArgs e)
        {
            Content content = sender as Content;

            content.ParentWindowContent = null;

            content.PropertyChanged -= new Content.PropChangeEventHandler(OnContentChanged);
        }

        protected virtual void OnContentRemoved(object sender, PallaControls.Windows.Forms.Collections.CollectionChangeEventArgs e)
        {
            if (mcontents.Count == 0)
            {
                if (this.AutoDispose)
                    Suicide();
            }
        }

        protected virtual void OnContentChanged(object obj, Content.PropChangeEventArgs e) {}

        protected void Suicide()
        {
            if (this.ParentZone != null)
                this.ParentZone.Windows.Remove(this);

            mcontents.Clearing -= new CollectionClearEventHandler(OnContentsClearing);
            mcontents.Inserted -= new PallaControls.Windows.Forms.Collections.CollectionChangeEventHandler(OnContentInserted);
            mcontents.Removing -= new PallaControls.Windows.Forms.Collections.CollectionChangeEventHandler(OnContentRemoving);
            mcontents.Removed -= new PallaControls.Windows.Forms.Collections.CollectionChangeEventHandler(OnContentRemoved);

            this.Dispose();
        }

		#endregion

		#region Properties

		public ContentCollection Contents
		{
			get { return mcontents; }
			
			/*set
			{
				mcontents.Clear();
				mcontents = value;
			}*/
		}

		#endregion
    }
}