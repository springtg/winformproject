using System;
using System.Drawing;
using System.ComponentModel;
using System.Windows.Forms;

namespace PallaControls.Windows.Forms
{
	#region NumberOcurredEventArgs

	public class NumberOcurredEventArgs : EventArgs
	{
		private Color m_NegativeColor = Color.Red;
		private Color m_PositiveColor = Color.Black;

		#region Constructors

		public NumberOcurredEventArgs()
		{
		}

		public NumberOcurredEventArgs(Color negativeColor, Color positiveColor)
		{
			m_NegativeColor = negativeColor;
			m_PositiveColor = positiveColor;
		}

		#endregion

		#region Properties

		public Color NegativeNumberColor
		{
			get {return m_NegativeColor;}
			set {m_NegativeColor = value;}
		}

		public Color PositiveNumberColor
		{
			get {return m_PositiveColor;}
			set {m_PositiveColor = value;}
		}

		#endregion
	}

	#endregion

	#region ErrorOcurredEventArgs

	public class ErrorOcurredEventArgs : EventArgs
	{
		private string m_Message = "";

		#region Constructors

		public ErrorOcurredEventArgs(string message)
		{
			m_Message = message;
		}

		#endregion

		#region Properties

		public string Message
		{
			get {return m_Message;}
			set {m_Message = value;}
		}

		#endregion
	}

	#endregion

	#region PlansOfColorsChangedEventArgs

	public class PlansOfColorsChangedEventArgs : EventArgs
	{
		private PlansColors m_NewPlan;

		#region Constructors

		public PlansOfColorsChangedEventArgs(PlansColors newPlan)
		{
			m_NewPlan = newPlan;
		}

		#endregion

		#region Properties

		public PlansColors NewPlan
		{
			get {return m_NewPlan;}
			set {m_NewPlan = value;}
		}

		#endregion
	}

	#endregion

	#region ComboSelChangedEventArgs

	public class ComboSelChangedEventArgs : EventArgs
	{
		private string m_SelectedValue;

		#region Constructors
		
		public ComboSelChangedEventArgs(string selectedValue)
		{
			m_SelectedValue = selectedValue;
		}

		#endregion

		#region Properties

		public string Value
		{
			get{ return m_SelectedValue; }
		}

		#endregion
	}

	#endregion

	#region StyleEventArgs

	public class StyleEventArgs : EventArgs
	{
		private string m_PropertyName  = "";
		private object m_PropertyValue = null;

		public StyleEventArgs(string propertyName,object popertyValue)
		{
			m_PropertyName  = propertyName;
			m_PropertyValue = popertyValue;
		}

		public string PropertyName
		{
			get{ return m_PropertyName; }
		}

		public object PropertyValue
		{
			get{ return m_PropertyValue; }
		}
	}

	#endregion

	#region DateChangedEventArgs

	public class DateChangedEventArgs : EventArgs
	{
		private DateTime m_SelectedDate;

		public DateChangedEventArgs(DateTime selectedDate)
		{
			m_SelectedDate = selectedDate;
		}

		#region Properties Implementation
		
		public DateTime Date
		{
			get{ return m_SelectedDate; }
		}

		#endregion

	}

	#endregion

	#region MessageEventsArgs

	public class MessageEventArgs : EventArgs
	{
		private Message men;
		private bool result = false;

		public MessageEventArgs(Message message, bool result)
		{
			this.men = message;
			this.result = result;
		}

		#region Properties Implementation
		
		public Message WindowsMessage
		{
			get {return this.men;}
		}

		public bool Result
		{
			get {return this.result;}
			set {this.result = value;}
		}

		#endregion

	}

	#endregion

	#region ValidatingEventArgs

	public class ValidatingEventArgs : System.ComponentModel.CancelEventArgs
	{
		private object m_NewValue = null;
		public ValidatingEventArgs(object newValue):base(false)
		{
			m_NewValue = newValue;
		}
		public object NewValue
		{
			get{return m_NewValue;}
			set{m_NewValue = value;}
		}
	}

	#endregion

	#region RowEventArgs

	public class RowEventArgs : EventArgs
	{
		protected int m_Row;
		public int Row
		{
			get{return m_Row;}
			set{m_Row = value;}
		}
		public RowEventArgs(int pRow)
		{
			m_Row = pRow;
		}
	}

	#endregion

	#region ColumnEventArgs

	public class ColumnEventArgs : EventArgs
	{
		protected int m_Column;
		public int Column
		{
			get{return m_Column;}
			set{m_Column = value;}
		}
		public ColumnEventArgs(int pColumn)
		{
			m_Column = pColumn;
		}
	}

	#endregion*/

	public delegate void MessageEventHandler(object sender, MessageEventArgs e);
	public delegate void StyleChangedEventHandler(object sender,StyleEventArgs e);
	public delegate void NumberOcurredEventHandler(object sender,NumberOcurredEventArgs e);
	public delegate void ErrorOcurredEventHandler(object sender,ErrorOcurredEventArgs e);
	public delegate void PlansOfColorsChangedEventHandler(object sender,PlansOfColorsChangedEventArgs e);
	public delegate void ButtonPressedEventHandler(object sender,System.EventArgs e);
	public delegate void ComboSelectionChangedEventHandler(object sender,ComboSelChangedEventArgs e);
	public delegate void DateSelectionChangedEventHandler(object sender,DateChangedEventArgs e);
}

namespace PallaControls.Windows.Forms.Collections
{
	#region CollectionChangeEventArgs

	public class CollectionChangeEventArgs : EventArgs
	{
		private int index = -1;

		public CollectionChangeEventArgs(int index)
		{
			this.index = index;
		}

		public int Index
		{
			get {return this.index;}
		}
	}

	#endregion
		
	public delegate void CollectionClearEventHandler(object sender, EventArgs e);
	public delegate void CollectionChangeEventHandler(object sender, PallaControls.Windows.Forms.Collections.CollectionChangeEventArgs e);
}

namespace PallaControls.Windows.Docking
{
	#region ContextEventArgs

	public class ContextEventArgs : EventArgs
	{
		private Point m_screenPos;

		#region Constructors

		public ContextEventArgs()
		{
		}

		public ContextEventArgs(Point screenPos)
		{
			this.m_screenPos = screenPos;
		}

		#endregion

		#region Properties

		public Point ScreenPos
		{
			get {return m_screenPos;}
			set {m_screenPos = value;}
		}

		#endregion
	}

	#endregion

	public delegate void ContextEventHandler(object sender, ContextEventArgs e);
}


