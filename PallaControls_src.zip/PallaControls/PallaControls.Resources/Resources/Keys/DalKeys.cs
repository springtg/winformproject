using System;

namespace CeltaWare.Resources.Keys
{
	/// <summary>
	/// Chaves para mensagens da camada CeltaWare.Dal.
	/// </summary>
	public sealed class DalResourceKeys
	{
		/// <summary>
		/// Origem dos erros gerados em CeltaWare.Dal
		/// </summary>
		public const string Source = "CeltaWare.Dal";
		
		/// <summary>
		/// Raiz das mensagens usadas pela camada de abstra��o do acesso � dados.
		/// </summary>
		public const string Root = "Dal";

		/// <summary>
		/// Erro em CeltaWare.Dal.Engine: ExecSPDataReader, na procedure de banco de dados '{0}'.
		/// </summary>
		public const string DataTableNotFound = Root + ".DataTableNotFound";

		/// <summary>
		/// Erro em CeltaWare.Dal.Engine: ExecSPScalar, na procedure de banco de dados '{0}'.
		/// </summary>
		public const string ErrorExecSPScalar = Root + ".ErrorExecSPScalar";

		/// <summary>
		/// Erro em CeltaWare.Dal.Engine: ExecSPNonQuery, na procedure de banco de dados '{0}'.
		/// </summary>
		public const string ErrorExecSPNonQuery = Root + ".ErrorExecSPNonQuery";

		/// <summary>
		/// Erro em CeltaWare.Dal.Engine: ExecSPDataReader, na procedure de banco de dados '{0}'.
		/// </summary>
		public const string ErrorExecSPDataReader = Root + ".ErrorExecSPDataReader";

		/// <summary>
		/// Erro em CeltaWare.Dal.Engine: ExecQueryDataReader, com a cl�usula '{0}'.
		/// </summary>
		public const string ErrorExecQueryDataReader = Root + ".ErrorExecQueryDataReader";

		/// <summary>
		/// Erro em CeltaWare.Dal.Engine: ExecQueryScalar, com a cl�usula '{0}'.
		/// </summary>
		public const string ErrorExecQueryScalar = Root + ".ErrorExecQueryScalar";

		/// <summary>
		/// Erro em CeltaWare.Dal.Engine: ExecQueryNonQuery, com a cl�usula '{0}'.
		/// </summary>
		public const string ErrorExecQueryNonQuery = Root + ".ErrorExecQueryNonQuery";

		/// <summary>
		/// Erro em CeltaWare.Dal.Engine: Falha ao recuperar o objeto ['{0}'] com a cl�usula sql '{1}'.
		/// </summary>
		public const string FlawToRecoverObject = Root + ".FlawToRecoverObject";

		/// <summary>
		/// Erro em CeltaWare.Dal.Engine: O objeto [' {0} '] n�o possue campos que definem o relacionamento.
		/// </summary>
		public const string WaitingChildFields = Root + ".WaitingChildFields";

		/// <summary>
		/// Erro em CeltaWare.Dal.Engine: Falha ao recuperar objetos filhos [' {0} '] com a cl�usula sql '{1}'.
		/// </summary>
		public const string FlawRecoverChildObjects = Root + ".FlawRecoverChildObjects";

		/// <summary>
		/// O usu�rio atual n�o tem permiss�o para executar a opera��o.
		/// </summary>
		public const string RestrictionSafety = Root + ".RestrictionSafety";

		/// <summary>
		/// Tipo da cl�usula inv�lido para o contexto. Somente 'Insert' ou 'Update' s�o aceitos neste caso.
		/// </summary>
		public const string TypeQueryInvalidate = Root + ".TypeQueryInvalidate";

		/// <summary>
		/// Erro em CeltaWare.Dal.SqlEngine: ExecSPDataSet, na procedure de banco de dados '{0}'.
		/// </summary>
		public const string ErrorExecSPDataSet = Root + ".ErrorExecSPDataSet";

		/// <summary>
		/// Erro em CeltaWare.Dal.SqlEngine: ExecQueryDataSet, na cl�usula '{0}'.
		/// </summary>
		public const string ErrorExecQueryDataSet = Root + ".ErrorExecQueryDataSet";

		/// <summary>
		/// Por favor forne�a um nome de par�metro v�lido em {0}, a propriedade de ParameterName tem o valor seguinte: '{1}'.
		/// </summary>
		public const string NameParamInvalidate = Root + ".NameParamInvalidate";

		/// <summary>
		/// N�mero de par�metros n�o � igual ao n�mero de valores.
		/// </summary>
		public const string InvalidNumberParam = Root + ".InvalidNumberParam";

		/// <summary>
		/// A transa��o est� como 'rollbacked' ou 'commited', por favor informe uma transa��o aberta.
		/// </summary>
		public const string InvalidTransaction = Root + ".InvalidTransaction";

		/// <summary>
		/// :Inclua o par�metro ReturnValue
		/// </summary>
		public const string IncludeParam = Root + ".IncludeParam";

		/// <summary>
		/// O par�metro 'tableNames' deve conter uma lista de tabelas, ao menos um valor foi fornecido como uma string vazia ou nula.
		/// </summary>
		public const string InvalidTablesNames = Root + ".InvalidTablesNames";
	}
}
