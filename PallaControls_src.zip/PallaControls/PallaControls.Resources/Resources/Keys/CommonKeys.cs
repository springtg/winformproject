using System;

namespace PallaControls.Resources.Keys
{
	/// <summary>
	/// Chaves para mensagens comuns 'a todas as camadas.
	/// </summary>
	public sealed class CommonResourceKeys
	{
		/// <summary>
		/// Raiz das mensagens comuns.
		/// </summary>
		public const string Root = "Common";

		/// <summary>
		/// Caracter ilegal.
		/// </summary>
		public const string IlegalChar = Root + ".IlegalChar";

		/// <summary>
		/// Campo de preenchimento obrigat�rio.
		/// </summary>
		public const string RequiredField = Root + ".RequiredField";

		/// <summary>
		/// O �ndice solicitado est� fora do alcance.
		/// </summary>
		public const string IndexOutBounds = Root + ".IndexOutBounds";

		/// <summary>
		/// Sim
		/// </summary>
		public const string Yes = Root + ".Yes";

		/// <summary>
		/// N�o
		/// </summary>
		public const string No = Root + ".No";
	
		/// <summary>
		/// OK
		/// </summary>
		public const string OK = Root + ".OK";
	
		/// <summary>
		/// Cancelar
		/// </summary>
		public const string Cancel = Root + ".Cancel";
	
		/// <summary>
		/// Repetir
		/// </summary>
		public const string Retry = Root + ".Retry";

		/// <summary>
		/// Abortar
		/// </summary>
		public const string Abort = Root + ".Abort";

		/// <summary>
		/// Ignorar
		/// </summary>
		public const string Ignore = Root + ".Ignore";

		/// <summary>
		/// Informa��o
		/// </summary>
		public const string Information = Root + ".Information";
	
		/// <summary>
		/// Erro
		/// </summary>
		public const string Error = Root + ".Error";

		/// <summary>
		/// Confirma��o
		/// </summary>
		public const string Confirmation = Root + ".Confirmation";

		/// <summary>
		/// Um erro n�o esperado aconteceu. Reporte a seguinte mensagem ao nosso depto. de suporte: {0}
		/// </summary>
		public const string ErrorNotExpected = Root + ".ErrorNotExpected";

		/// <summary>
		/// �ndice deve ser maior que zero.
		/// </summary>
		public const string LargerIndexThanZero = Root + ".LargerIndexThanZero";

		/// <summary>
		/// Argumento � nulo ou est� vazio.
		/// </summary>
		public const string NullArgument = Root + ".NullArgument";

		/// <summary>
		/// Chave para criptografia n�o configurada.
		/// </summary>
		public const string KeyNotConfigured = Root + ".KeyNotConfigured";

		/// <summary>
		/// Chave para criptografia deve ter ao menos {0} caracteres.
		/// </summary>
		public const string SizeOfKeyInvalidates = Root + ".SizeOfKeyInvalidates";

		/// <summary>
		/// Arquivo {0} n�o p�de ser encontrado.
		/// </summary>
		public const string FileNotFound = Root + ".FileNotFound";

		/// <summary>
		/// Progresso
		/// </summary>
		public const string Progress = Root + ".Progress";

		/// <summary>
		/// Ocorreu um erro inesperado durante a carga de um componente da aplica��o. 
		/// Normalmente este tipo de erro � causado por falhas de configura��o. 
		/// Por favor, entre em contato com nosso suporte t�cnico informando as 
		/// palavras a seguir e local em que o erro ocorreu. "{0}"
		/// </summary>
		public const string MistakeConfigRemoting = Root + ".MistakeConfigRemoting";
	}
}
