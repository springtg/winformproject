using System;

namespace CeltaWare.Resources.Keys
{
	/// <summary>
	/// Chaves para mensagens da camada CeltaWare.Utilities.Plugins.
	/// </summary>
	public sealed class PluginsResourceKeys
	{
		/// <summary>
		/// Raiz das mensagens usadas pela camada de abstra��o do acesso � dados.
		/// </summary>
		public const string Root = "Plugins";

		/// <summary>
		/// Nomes de plugins duplicados, no mesmo contrato. O nome repedido � \"{0}\" e o arquivo que gerou este problema: \"{1}\"
		/// </summary>
		public const string DuplicatedPlugins = Root + ".DuplicatedPlugins";

		/// <summary>
		/// O tipo definido para o plugin n�o implementa o contrato correto para este contexto.
		/// </summary>
		public const string IncorrectContract = Root + ".IncorrectContract";
	
		/// <summary>
		/// \"CeltaWare.Utilities.Plugins.Loader\" n�o p�de ser encontrado
		/// </summary>
		public const string PluginLoaderNotFound = Root + ".PluginLoaderNotFound";
	
		/// <summary>
		/// O tipo definido para o plugin n�o p�de ser encontrado no arquivo: \"{0}\"
		/// </summary>
		public const string TypePluginNotFound = Root + ".TypePluginNotFound";

		/// <summary>
		/// Este arquivo n�o cont�m um plugin v�lido para CW-Framework: \"{0}\"
		/// </summary>
		public const string PluginInvalidate = Root + ".PluginInvalidate";
	
		/// <summary>
		/// Origem inv�lida para o arquivo: \"{0}\"
		/// </summary>
		public const string OriginPluginInvalidates = Root + ".OriginPluginInvalidates";
	}
}
