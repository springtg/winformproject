using System;

namespace CeltaWare.Resources.Keys
{
	/// <summary>
	/// Chaves para mensagens referentes aos servi�os de atualiza��o.
	/// </summary>
	public sealed class UpdateServicesResourceKeys 
	{
		/// <summary>
		/// Raiz das mensagens comuns.
		/// </summary>
		public const string Root = "UpdateServices";

		/// <summary>
		/// Origem dos erros gerados em CeltaWare.Update.Services
		/// </summary>
		public const string Source = "CeltaWare update services";

		/// <summary>
		/// Atualiza��o n�o autorizada. {0}
		/// </summary>
		public const string UpdatingNonAuthorized = Root + ".UpdatingNonAuthorized";

		/// <summary>
		/// Arquivo de autoriza��o n�o foi encontrado ou n�o � v�lido.
		/// </summary>
		public const string FileAuthorizationInvalidates = Root + ".FileAuthorizationInvalidates";

		/// <summary>
		/// Arquivos de configura��o n�o encontrados.
		/// </summary>
		public const string FilesConfigurationNotFound = Root + ".FilesConfigurationNotFound";

		/// <summary>
		/// String de identifica��o do cliente n�o encontrada.
		/// </summary>
		public const string ClientIdNotFound = Root + ".ClientIdNotFound";

		/// <summary>
		/// Caminho do diret�rio principal da aplica��o n�o encontrado.
		/// </summary>
		public const string RootPathNotFound = Root + ".RootPathNotFound";
	
		/// <summary>
		/// Caminho do diret�rio de plugins n�o encontrado.
		/// </summary>
		public const string PluginsPathNotFound = Root + ".PluginsPathNotFound";

		/// <summary>
		/// A conex�o com o banco de dados n�o p�de ser realizada. Provavelmente o arquivo de configura��o est� inv�lido.
		/// </summary>
		public const string ConnectionWithBaseInvalidates = Root + ".ConnectionWithBaseInvalidates";

		/// <summary>
		/// A origem do arquivo {0} n�o � v�lida ou o arquivo est� corrompido. Favor informar este problema ao departamento de suporte da CeltaWare.
		/// </summary>
		public const string OriginFileInvalidates = Root + ".OriginFileInvalidates";

		/// <summary>
		/// CeltaWare.Update.Loader n�o encontrado.
		/// </summary>
		public const string UpdateLoaderNotFound = Root + ".UpdateLoaderNotFound";

		/// <summary>
		/// O arquivo {0} n�o p�de ser atualizado. Feche todas as aplica��es da CeltaWare e tente novamente.
		/// </summary>
		public const string FileLocked = Root + ".FileLocked";

		/// <summary>
		/// Selecione ao menos um item para atualiza��o.
		/// </summary>
		public const string ThereAreNotSelectedItems = Root + ".ThereAreNotSelectedItems";

		/// <summary>
		/// GacUtil n�o encontrado.
		/// </summary>
		public const string GacUtilNotFound = Root + ".GacUtilNotFound";

		/// <summary>
		/// CeltaWare Update Service n�o est� dispon�vel no momento. Entre em contato com nosso suporte t�cnico para maiores detalhes.
		/// </summary>
		public const string WebServiceOffLine = Root + ".WebServiceOffLine";

		/// <summary>
		/// Seu sistema est� 100% atualizado com nossas bases de instala��o.
		/// </summary>
		public const string SystemUpToDate = Root + ".SystemUpToDate";

		/// <summary>
		/// Baixa
		/// </summary>
		public const string Low = Root + ".Low";

		/// <summary>
		/// M�dia
		/// </summary>
		public const string Medium = Root + ".Medium";

		/// <summary>
		/// Alta
		/// </summary>
		public const string High = Root + ".High";

		/// <summary>
		/// NaoHaVersao
		/// </summary>
		public const string ThereIsNotVersion = Root + ".ThereIsNotVersion";

		/// <summary>
		/// Vers�o
		/// </summary>
		public const string Version = Root + ".Version";

		/// <summary>
		/// Prioridade
		/// </summary>
		public const string Priority = Root + ".Priority";

		/// <summary>
		/// Sum�rio
		/// </summary>
		public const string Summary = Root + ".Summary";

		/// <summary>
		/// Fazendo download dos arquivos para atualiza��o. Isso pode demorar alguns minutos...
		/// </summary>
		public const string MakingDownload = Root + ".MakingDownload";

		/// <summary>
		/// N�o foi poss�vel fazer o download do arquivo {0}
		/// </summary>
		public const string ErrorDownload = Root + ".ErrorDownload";

		/// <summary>
		/// Atualizando arquivos...
		/// </summary>
		public const string UpdatingFiles = Root + ".UpdatingFiles";

		/// <summary>
		/// Descompactando arquivos...
		/// </summary>
		public const string DecompressFiles = Root + ".DecompressFiles";
	}
}