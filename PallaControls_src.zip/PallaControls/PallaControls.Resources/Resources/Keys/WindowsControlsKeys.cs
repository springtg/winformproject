using System;

namespace PallaControls.Resources.Keys
{
	/// <summary>
	/// Chaves para mensagens da camada PallaControls.Windows.Controls.
	/// </summary>
	public sealed class WindowsControlsResourceKeys
	{
		/// <summary>
		/// Origem dos erros gerados em PallaControls.Windows.Controls
		/// </summary>
		public const string Source = "PallaControls.Windows.Controls";
		
		/// <summary>
		/// Raiz das mensagens usadas pela camada de controles para Windows.
		/// </summary>
		public const string Root = "WindowsControls";

		/// <summary>
		/// Somente d�gitos e barras s�o aceitos.
		/// </summary>
		public const string OnlyDigitsBarAccepted = Root + ".OnlyDigitsBarAccepted";

		/// <summary>
		/// Somente d�gitos e pontos s�o aceitos.
		/// </summary>
		public const string OnlyDigitsPointsAccepted = Root + ".OnlyDigitsPointsAccepted";

		/// <summary>
		/// Somente d�gitos, h�fens e espa�os s�o aceitos.
		/// </summary>
		public const string OnlyDigitsMinusSpaceAccepted = Root + ".OnlyDigitsMinusSpaceAccepted";

		/// <summary>
		/// Somente d�gitos, h�fens, par�nteses e espa�os s�o aceitos.
		/// </summary>
		public const string OnlyDigitsMinusParenthesesAccepted = Root + ".OnlyDigitsMinusParenthesesAccepted";

		/// <summary>
		/// Somente d�gitos, h�fens e pontos s�o aceitos.
		/// </summary>
		public const string OnlyDigitsMinusPointsAccepted = Root + ".OnlyDigitsMinusPointsAccepted";

		/// <summary>
		/// Somente d�gitos e h�fens s�o aceitos.
		/// </summary>
		public const string OnlyDigitsMinusAccepted = Root + ".OnlyDigitsMinusAccepted";
       
		/// <summary>
		/// Somente d�gitos, pontos, h�fens e barras s�o aceitos.
		/// </summary>
		public const string OnlyDigitsMinusPointsBarsAccepted = Root + ".OnlyDigitsMinusPointsBarsAccepted";

		/// <summary>
		/// Somente d�gitos e dois pontos s�o aceitos.
		/// </summary>
		public const string OnlyDigitsTwoPointsAccepted = Root + ".OnlyDigitsTwoPointsAccepted";
		
		/// <summary>
		/// Somente d�gitos pontos e barras s�o aceitos.
		/// </summary>
		public const string OnlyDigitsPointsBarsAccepted = Root + ".OnlyDigitsPointsBarsAccepted";
		
		/// <summary>
		/// Somente d�gitos hifens e barras s�o aceitos.
		/// </summary>
		public const string OnlyDigitsMinusBarsAccepted = Root + ".OnlyDigitsMinusBarsAccepted";

		/// <summary>
		/// Formato data inv�lido: {0} .
		/// </summary>
		public const string InvalidDateFormat = Root + ".InvalidDateFormat";

		/// <summary>
		/// Data inv�lida.
		/// </summary>
		public const string InvalidDate = Root + ".InvalidDate";

		/// <summary>
		/// CPF inv�lido.
		/// </summary>
		public const string InvalidCpf = Root + ".InvalidCpf";

		/// <summary>
		/// CNPJ inv�lido.
		/// </summary>
		public const string InvalidCnpj = Root + ".InvalidCnpj";

		/// <summary>
		/// e-mail inv�lido.
		/// </summary>
		public const string InvalidEmail = Root + ".InvalidEmail";

		/// <summary>
		/// N�mero de IP inv�lido.
		/// </summary>
		public const string InvalidIp = Root + ".InvalidIp";

		/// <summary>
		/// Formato do telefone n�o � v�lido; 0000-0000 ou 000-0000.
		/// </summary>
		public const string InvalidTelephoneFormat = Root + ".InvalidTelephoneFormat";
		
		/// <summary>
		/// Formato do telefone n�o � v�lido; (000)0000-0000.
		/// </summary>
		public const string InvalidTelephoneAreaFormat = Root + ".InvalidTelephoneAreaFormat";

		/// <summary>
		/// Formato do RG n�o � v�lido; 00.000.000-0.
		/// </summary>
		public const string InvalidRgFormat = Root + ".InvalidRgFormat";

		/// <summary>
		/// Formato do CPF n�o � v�lido; 000000000-00.
		/// </summary>
		public const string InvalidCpfFormat = Root + ".InvalidCpfFormat";

		/// <summary>
		/// Formato do CNPJ n�o � v�lido; 00.000.000/0000-00.
		/// </summary>
		public const string InvalidCnpjFormat = Root + ".InvalidCnpjFormat";

		/// <summary>
		/// Formato do CEP n�o � v�lido; 00000-000.
		/// </summary>
		public const string InvalidZipFormat = Root + ".InvalidZipFormat";

		/// <summary>
		/// Formato de hora inv�lido; 00:00:00.
		/// </summary>
		public const string InvalidTimeFormat = Root + ".InvalidTimeFormat";
		
		/// <summary>
		/// Hora inv�lida.
		/// </summary>
		public const string InvalidTime = Root + ".InvalidTime";

		/// <summary>
		/// N�mero inv�lido.
		/// </summary>
		public const string InvalidNumber = Root + ".InvalidNumber";
		
		/// <summary>
		/// Formato da inscri��o estadual n�o � v�lido;\n{0}.
		/// </summary>
		public const string InvalidInscriptionFormat = Root + ".InvalidInscriptionFormat";

		/// <summary>
		/// Inscri��o estadual inv�lida.
		/// </summary>
		public const string InvalidInscription = Root + ".InvalidInscription";

		/// <summary>
		/// Inscri��o estadual inv�lida.
		/// </summary>
		public const string OnlyDigitsAccepted = Root + ".OnlyDigitsAccepted";

		/// <summary>
		/// Inscri��o estadual inv�lida.
		/// </summary>
		public const string InvalidZip = Root + ".InvalidZip";

		/// <summary>
		/// C�digo de �rea inv�lido.
		/// </summary>
		public const string InvalidAreaCode = Root + ".InvalidAreaCode";

		/// <summary>
		/// Conte�do informado no campo n�o est� na lista.
		/// </summary>
		public const string ContentNotExistInList = Root + ".ContentNotExistInList";

		/// <summary>
		/// N�o foi poss�vel ler o pr�ximo n� esperado. 
		/// </summary>
		/// <remarks>Usada em ger��o e leitura de documentos XML</remarks>
		public const string InaccessibleNode = Root + ".InaccessibleNode";

		/// <summary>
		/// Nome de n� incorreto foi encontrado.
		/// </summary>
		/// <remarks>Usada em ger��o e leitura de documentos XML</remarks>
		public const string IncorrectNodeName = Root + ".IncorrectNodeName";

		/// <summary>
		/// 'EndElement' esperado mas n�o encontrado.
		/// </summary>
		/// <remarks>Usada em ger��o e leitura de documentos XML</remarks>
		public const string FinalElementNotFound = Root + ".FinalElementNotFound";

		/// <summary>
		/// Mostrar todos
		/// </summary>
		public const string ShowAll = Root + ".ShowAll";
	
		/// <summary>
		/// Esconder todos 
		/// </summary>
		public const string HideAll = Root + ".HideAll";
	
		/// <summary>
		/// Elemento '{0}' esperado e n�o encontrado.
		/// </summary>
		/// <remarks>Usada em ger��o e leitura de documentos XML</remarks>
		public const string ElementNotFound = Root + ".ElementNotFound";
	
		/// <summary>
		/// N� '{0}' esperado e n�o encontrado.
		/// </summary>
		/// <remarks>Usada em ger��o e leitura de documentos XML</remarks>
		public const string NodeNotFound = Root + ".NodeNotFound";
	
		/// <summary>
		/// N�o posso inserir depois das entradas atual.
		/// </summary>
		public const string CantInsert = Root + ".CantInsert";
	
		/// <summary>
		/// N�o posso remover depois das entradas atual.
		/// </summary>
		public const string CantRemove = Root + ".CantRemove";

		/// <summary>
		/// Fechar
		/// </summary>
		public const string Close = Root + ".Close";

		/// <summary>
		/// Proeminente
		/// </summary>
		public const string Prominent = Root + ".Prominent";
	
		/// <summary>
		/// Recalcular
		/// </summary>
		public const string CalculateAgain = Root + ".CalculateAgain";

		/// <summary>
		/// Mover para p�gina anterior
		/// </summary>
		public const string PreviousPage = Root + ".PreviousPage";

		/// <summary>
		/// Mover para pr�xima p�gina
		/// </summary>
		public const string NextPage = Root + ".NextPage";
	
		/// <summary>
		/// Nova p�gina vertical
		/// </summary>
		public const string NewPageVertical = Root + ".NewPageVertical";

		/// <summary>
		/// Nova p�gina horizontal
		/// </summary>
		public const string NewPageHorizontal = Root + ".NewPageHorizontal";

		/// <summary>
		/// Diret�rio inv�lido
		/// </summary>
		public const string InvalidDirectory = Root + ".InvalidDirectory";

		/// <summary>
		/// Anterior
		/// </summary>
		public const string Previous = Root + ".Previous";

		/// <summary>
		/// Pr�ximo
		/// </summary>
		public const string Next = Root + ".Next";

		/// <summary>
		/// Terminar
		/// </summary>
		public const string Finish = Root + ".Finish";

		/// <summary>
		/// Passo n�o existe no assistente.
		/// </summary>
		public const string StepNotFound = Root + ".StepNotFound";

		/// <summary>
		/// Primeiro passo n�o pode ser nulo ou estar em branco.
		/// </summary>
		public const string FirstStepCannotBeNull = Root + ".FirstStepCannotBeNull";

		/// <summary>
		/// Sair do assistente?
		/// </summary>
		public const string CloseWizard = Root + ".CloseWizard";
	
		/// <summary>
		/// Voc� deseja deixar o assistente agora?\r\nSuas mudan�as n�o ser�o salvadas.
		/// </summary>
		public const string MessageToLeaveAssistant = Root + ".MessageToLeaveAssistant";

		/// <summary>
		/// N�o h� nenhum painel de tarefas instalado em seu sistema
		/// </summary>
		public const string NoExistTaskPanels = Root + ".NoExistTaskPanels";

		/// <summary>
		/// N�mero fora da faixa permitida; {0} - {1}
		/// </summary>
		public const string InvalidNumberStrip = Root + ".InvalidNumberStrip";

		/// <summary>
		/// Invalid regular expression.
		/// </summary>
		public const string InvalidRegExp = Root + ".InvalidRegExp"; //2002-08-07 - GWO - Added message
	}
}