using System;
using System.Globalization;
using System.Reflection;
using System.Resources;
using System.Collections;

namespace PallaControls.Resources
{
	public class ResourceLibrary
	{  
		private static Hashtable resourceManagers = new Hashtable();  

		#region Methods
		
		public static string GetString(string key, string modname)  
		{  
			ResourceManager rm = (ResourceManager)resourceManagers[modname];  
   
			if (rm == null)  
			{  
				rm = new ResourceManager("PallaControls.Resources.Resources.Files."  
					+ modname + "." 
					+ modname + "Resources",
					Assembly.GetExecutingAssembly());  
   
				resourceManagers.Add(modname,rm);  
			} 
 
			return rm.GetString(key, CultureInfo.CurrentCulture);  
		}  

		#endregion
	}
}
