using System;
using System.Globalization;
using System.Threading;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace PallaControlsStyeSamples
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class frmStyleSamples : System.Windows.Forms.Form
	{
		private PallaControls.Windows.Forms.Panel panel2;
		private PallaControls.Windows.Forms.Panel panel3;
		private PallaControls.Windows.Forms.Panel panel1;
		private PallaControls.Windows.Forms.GroupBox groupBox1;
		private PallaControls.Windows.Forms.RadioButton radioButton1;
		private PallaControls.Windows.Forms.RadioButton radioButton2;
		private PallaControls.Windows.Forms.RadioButton radioButton3;
		private PallaControls.Windows.Forms.RadioButton radioButton4;
		private PallaControls.Windows.Forms.RadioButton radioButton5;
		private PallaControls.Windows.Forms.RadioButton radioButton6;
		private PallaControls.Windows.Forms.RadioButton radioButton7;
		private PallaControls.Windows.Forms.RadioButton radioButton8;
		private PallaControls.Windows.Forms.StyleGuide styleGuide1;
		private PallaControls.Windows.Forms.Button button1;
		private PallaControls.Windows.Forms.Button button2;
		private PallaControls.Windows.Forms.Button button3;
		private PallaControls.Windows.Forms.Button button4;
		private PallaControls.Windows.Forms.Button button5;
		private PallaControls.Windows.Forms.Button button6;
		private PallaControls.Windows.Forms.RadioButton radioButton9;
		private System.ComponentModel.IContainer components;

		public frmStyleSamples()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			this.panel2 = new PallaControls.Windows.Forms.Panel();
			this.button6 = new PallaControls.Windows.Forms.Button();
			this.styleGuide1 = new PallaControls.Windows.Forms.StyleGuide(this.components);
			this.button5 = new PallaControls.Windows.Forms.Button();
			this.button4 = new PallaControls.Windows.Forms.Button();
			this.button3 = new PallaControls.Windows.Forms.Button();
			this.button2 = new PallaControls.Windows.Forms.Button();
			this.button1 = new PallaControls.Windows.Forms.Button();
			this.groupBox1 = new PallaControls.Windows.Forms.GroupBox();
			this.radioButton8 = new PallaControls.Windows.Forms.RadioButton();
			this.radioButton7 = new PallaControls.Windows.Forms.RadioButton();
			this.radioButton6 = new PallaControls.Windows.Forms.RadioButton();
			this.radioButton5 = new PallaControls.Windows.Forms.RadioButton();
			this.radioButton4 = new PallaControls.Windows.Forms.RadioButton();
			this.radioButton3 = new PallaControls.Windows.Forms.RadioButton();
			this.radioButton2 = new PallaControls.Windows.Forms.RadioButton();
			this.radioButton1 = new PallaControls.Windows.Forms.RadioButton();
			this.panel3 = new PallaControls.Windows.Forms.Panel();
			this.panel1 = new PallaControls.Windows.Forms.Panel();
			this.radioButton9 = new PallaControls.Windows.Forms.RadioButton();
			this.panel2.SuspendLayout();
			this.groupBox1.SuspendLayout();
			this.SuspendLayout();
			// 
			// panel2
			// 
			this.panel2.BackColor = System.Drawing.Color.Empty;
			this.panel2.Controls.AddRange(new System.Windows.Forms.Control[] {
																				 this.button6,
																				 this.button5,
																				 this.button4,
																				 this.button3,
																				 this.button2,
																				 this.button1,
																				 this.groupBox1,
																				 this.panel3});
			this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
			this.panel2.Location = new System.Drawing.Point(81, 0);
			this.panel2.Name = "panel2";
			this.panel2.PanelAssBottomAreaColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(230)), ((System.Byte)(210)));
			this.panel2.PanelAssClientAreaColor = System.Drawing.Color.FromArgb(((System.Byte)(232)), ((System.Byte)(237)), ((System.Byte)(223)));
			this.panel2.PanelAssLeftOptionsColor = System.Drawing.Color.FromArgb(((System.Byte)(147)), ((System.Byte)(167)), ((System.Byte)(159)));
			this.panel2.PanelAssLeftTitleColor = System.Drawing.Color.FromArgb(((System.Byte)(232)), ((System.Byte)(237)), ((System.Byte)(223)));
			this.panel2.PanelAssRightTitleColor = System.Drawing.Color.FromArgb(((System.Byte)(147)), ((System.Byte)(167)), ((System.Byte)(159)));
			this.panel2.PanelBottomAreaColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(230)), ((System.Byte)(210)));
			this.panel2.PanelClientAreaColor = System.Drawing.Color.FromArgb(((System.Byte)(232)), ((System.Byte)(237)), ((System.Byte)(223)));
			this.panel2.PanelLeftOptionsColor = System.Drawing.Color.FromArgb(((System.Byte)(147)), ((System.Byte)(167)), ((System.Byte)(159)));
			this.panel2.PanelTopOptionsColor = System.Drawing.Color.FromArgb(((System.Byte)(119)), ((System.Byte)(145)), ((System.Byte)(135)));
			this.panel2.PanelType = PallaControls.Windows.Forms.PanelTypes.ClientArea;
			this.panel2.ParentStyle = true;
			this.panel2.Size = new System.Drawing.Size(377, 303);
			this.panel2.Style = this.styleGuide1;
			this.panel2.TabIndex = 1;
			// 
			// button6
			// 
			this.button6.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(232)), ((System.Byte)(237)), ((System.Byte)(223)));
			this.button6.BorderColor = System.Drawing.Color.FromArgb(((System.Byte)(123)), ((System.Byte)(156)), ((System.Byte)(159)));
			this.button6.BorderHotColor = System.Drawing.Color.FromArgb(((System.Byte)(123)), ((System.Byte)(156)), ((System.Byte)(159)));
			this.button6.ButtonColor = System.Drawing.Color.FromArgb(((System.Byte)(123)), ((System.Byte)(156)), ((System.Byte)(159)));
			this.button6.ButtonHotColor = System.Drawing.Color.FromArgb(((System.Byte)(131)), ((System.Byte)(171)), ((System.Byte)(170)));
			this.button6.ButtonPressedColor = System.Drawing.Color.FromArgb(((System.Byte)(99)), ((System.Byte)(133)), ((System.Byte)(137)));
			this.button6.FlashColor = System.Drawing.Color.FromArgb(((System.Byte)(109)), ((System.Byte)(135)), ((System.Byte)(125)));
			this.button6.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(224)), ((System.Byte)(231)), ((System.Byte)(213)));
			this.button6.Location = new System.Drawing.Point(232, 130);
			this.button6.Name = "button6";
			this.button6.ParentStyle = false;
			this.button6.Radius = 8F;
			this.button6.Size = new System.Drawing.Size(136, 21);
			this.button6.Style = this.styleGuide1;
			this.button6.TabIndex = 7;
			this.button6.Text = "I&FlashableControl";
			this.button6.TextColor = System.Drawing.Color.FromArgb(((System.Byte)(224)), ((System.Byte)(231)), ((System.Byte)(213)));
			this.button6.ButtonPressed += new PallaControls.Windows.Forms.ButtonPressedEventHandler(this.button5_ButtonPressed);
			// 
			// styleGuide1
			// 
			this.styleGuide1.BorderColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(217)), ((System.Byte)(207)));
			this.styleGuide1.BorderHotColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(217)), ((System.Byte)(207)));
			this.styleGuide1.ButtonBorderColor = System.Drawing.Color.FromArgb(((System.Byte)(123)), ((System.Byte)(156)), ((System.Byte)(159)));
			this.styleGuide1.ButtonBorderHotColor = System.Drawing.Color.FromArgb(((System.Byte)(123)), ((System.Byte)(156)), ((System.Byte)(159)));
			this.styleGuide1.ButtonColor = System.Drawing.Color.FromArgb(((System.Byte)(123)), ((System.Byte)(156)), ((System.Byte)(159)));
			this.styleGuide1.ButtonFlashColor = System.Drawing.Color.FromArgb(((System.Byte)(109)), ((System.Byte)(135)), ((System.Byte)(125)));
			this.styleGuide1.ButtonHotColor = System.Drawing.Color.FromArgb(((System.Byte)(131)), ((System.Byte)(171)), ((System.Byte)(170)));
			this.styleGuide1.ButtonPressedColor = System.Drawing.Color.FromArgb(((System.Byte)(99)), ((System.Byte)(133)), ((System.Byte)(137)));
			this.styleGuide1.ButtonTextColor = System.Drawing.Color.FromArgb(((System.Byte)(224)), ((System.Byte)(231)), ((System.Byte)(213)));
			this.styleGuide1.CalendarBackColor = System.Drawing.Color.FromArgb(((System.Byte)(232)), ((System.Byte)(237)), ((System.Byte)(223)));
			this.styleGuide1.CalendarForeColor = System.Drawing.Color.Black;
			this.styleGuide1.CalendarTitleBackColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(217)), ((System.Byte)(207)));
			this.styleGuide1.CalendarTitleForeColor = System.Drawing.Color.White;
			this.styleGuide1.CalendarTrailingForeColor = System.Drawing.Color.FromArgb(((System.Byte)(147)), ((System.Byte)(167)), ((System.Byte)(159)));
			this.styleGuide1.CheckBoxColor = System.Drawing.Color.FromArgb(((System.Byte)(232)), ((System.Byte)(237)), ((System.Byte)(223)));
			this.styleGuide1.CheckColor = System.Drawing.Color.FromArgb(((System.Byte)(147)), ((System.Byte)(167)), ((System.Byte)(159)));
			this.styleGuide1.CollapsiblePanelBackColor = System.Drawing.Color.FromArgb(((System.Byte)(183)), ((System.Byte)(196)), ((System.Byte)(190)));
			this.styleGuide1.CollapsiblePanelBarBackColor = System.Drawing.Color.FromArgb(((System.Byte)(147)), ((System.Byte)(167)), ((System.Byte)(159)));
			this.styleGuide1.CollapsiblePanelEndColor = System.Drawing.Color.White;
			this.styleGuide1.CollapsiblePanelLineEndColor = System.Drawing.Color.White;
			this.styleGuide1.CollapsiblePanelLineStartColor = System.Drawing.Color.White;
			this.styleGuide1.CollapsiblePanelLinkColor = System.Drawing.Color.White;
			this.styleGuide1.CollapsiblePanelStartColor = System.Drawing.Color.FromArgb(((System.Byte)(114)), ((System.Byte)(139)), ((System.Byte)(129)));
			this.styleGuide1.CollapsiblePanelTitleFontColor = System.Drawing.Color.White;
			this.styleGuide1.DataGridAlternatingBackColor = System.Drawing.Color.FromArgb(((System.Byte)(224)), ((System.Byte)(231)), ((System.Byte)(214)));
			this.styleGuide1.DataGridBackColor = System.Drawing.Color.FromArgb(((System.Byte)(240)), ((System.Byte)(240)), ((System.Byte)(240)));
			this.styleGuide1.DataGridBackgroundColor = System.Drawing.Color.FromArgb(((System.Byte)(232)), ((System.Byte)(237)), ((System.Byte)(223)));
			this.styleGuide1.DataGridCaptionBackColor = System.Drawing.Color.FromArgb(((System.Byte)(109)), ((System.Byte)(135)), ((System.Byte)(125)));
			this.styleGuide1.DataGridCaptionForeColor = System.Drawing.Color.White;
			this.styleGuide1.DataGridForeColor = System.Drawing.Color.Black;
			this.styleGuide1.DataGridHeaderBackColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(217)), ((System.Byte)(207)));
			this.styleGuide1.DataGridHeaderForeColor = System.Drawing.Color.Black;
			this.styleGuide1.DataGridLineColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(217)), ((System.Byte)(207)));
			this.styleGuide1.DataGridLinkColor = System.Drawing.Color.LightSteelBlue;
			this.styleGuide1.DataGridParentRowsBackColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(217)), ((System.Byte)(207)));
			this.styleGuide1.DataGridParentRowsForeColor = System.Drawing.Color.Black;
			this.styleGuide1.DataGridSelectionBackColor = System.Drawing.Color.Navy;
			this.styleGuide1.DataGridSelectionForeColor = System.Drawing.Color.White;
			this.styleGuide1.DisabledTextColor = System.Drawing.SystemColors.GrayText;
			this.styleGuide1.DockingActiveColor = System.Drawing.Color.FromArgb(((System.Byte)(224)), ((System.Byte)(231)), ((System.Byte)(214)));
			this.styleGuide1.DockingActiveTextColor = System.Drawing.Color.White;
			this.styleGuide1.DockingBackColor = System.Drawing.Color.FromArgb(((System.Byte)(232)), ((System.Byte)(237)), ((System.Byte)(223)));
			this.styleGuide1.DockingInactiveTextColor = System.Drawing.Color.Black;
			this.styleGuide1.DockingResizeBarColor = System.Drawing.Color.FromArgb(((System.Byte)(231)), ((System.Byte)(231)), ((System.Byte)(214)));
			this.styleGuide1.EditButtonColor = System.Drawing.Color.FromArgb(((System.Byte)(224)), ((System.Byte)(231)), ((System.Byte)(214)));
			this.styleGuide1.EditButtonHotColor = System.Drawing.Color.FromArgb(((System.Byte)(231)), ((System.Byte)(231)), ((System.Byte)(214)));
			this.styleGuide1.EditButtonPressedColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(217)), ((System.Byte)(207)));
			this.styleGuide1.EditColor = System.Drawing.Color.FromArgb(((System.Byte)(232)), ((System.Byte)(237)), ((System.Byte)(223)));
			this.styleGuide1.EditDisabledColor = System.Drawing.Color.FromArgb(((System.Byte)(238)), ((System.Byte)(238)), ((System.Byte)(225)));
			this.styleGuide1.EditFocusedColor = System.Drawing.Color.FromArgb(((System.Byte)(240)), ((System.Byte)(240)), ((System.Byte)(240)));
			this.styleGuide1.EditReadOnlyColor = System.Drawing.Color.FromArgb(((System.Byte)(238)), ((System.Byte)(238)), ((System.Byte)(225)));
			this.styleGuide1.FlashColor = System.Drawing.Color.FromArgb(((System.Byte)(147)), ((System.Byte)(167)), ((System.Byte)(159)));
			this.styleGuide1.InfiniteProgressEndColor = System.Drawing.Color.FromArgb(((System.Byte)(240)), ((System.Byte)(240)), ((System.Byte)(240)));
			this.styleGuide1.InfiniteProgressStartColor = System.Drawing.Color.FromArgb(((System.Byte)(147)), ((System.Byte)(167)), ((System.Byte)(159)));
			this.styleGuide1.LabelColor = System.Drawing.Color.FromArgb(((System.Byte)(224)), ((System.Byte)(231)), ((System.Byte)(214)));
			this.styleGuide1.NegativeNumberColor = System.Drawing.Color.Black;
			this.styleGuide1.PanelAssBottomAreaColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(230)), ((System.Byte)(210)));
			this.styleGuide1.PanelAssClientAreaColor = System.Drawing.Color.FromArgb(((System.Byte)(232)), ((System.Byte)(237)), ((System.Byte)(223)));
			this.styleGuide1.PanelAssLeftOptionsColor = System.Drawing.Color.FromArgb(((System.Byte)(147)), ((System.Byte)(167)), ((System.Byte)(159)));
			this.styleGuide1.PanelAssLeftTitleColor = System.Drawing.Color.FromArgb(((System.Byte)(232)), ((System.Byte)(237)), ((System.Byte)(223)));
			this.styleGuide1.PanelAssRightTitleColor = System.Drawing.Color.FromArgb(((System.Byte)(147)), ((System.Byte)(167)), ((System.Byte)(159)));
			this.styleGuide1.PanelBottomAreaColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(230)), ((System.Byte)(210)));
			this.styleGuide1.PanelClientAreaColor = System.Drawing.Color.FromArgb(((System.Byte)(232)), ((System.Byte)(237)), ((System.Byte)(223)));
			this.styleGuide1.PanelItemAssBackColor = System.Drawing.Color.FromArgb(((System.Byte)(147)), ((System.Byte)(167)), ((System.Byte)(159)));
			this.styleGuide1.PanelItemBackColor = System.Drawing.Color.FromArgb(((System.Byte)(183)), ((System.Byte)(196)), ((System.Byte)(190)));
			this.styleGuide1.PanelItemFlashColor = System.Drawing.Color.FromArgb(((System.Byte)(108)), ((System.Byte)(108)), ((System.Byte)(108)));
			this.styleGuide1.PanelItemForeColor = System.Drawing.Color.FromArgb(((System.Byte)(228)), ((System.Byte)(234)), ((System.Byte)(218)));
			this.styleGuide1.PanelLeftOptionsColor = System.Drawing.Color.FromArgb(((System.Byte)(147)), ((System.Byte)(167)), ((System.Byte)(159)));
			this.styleGuide1.PanelTopOptionsColor = System.Drawing.Color.FromArgb(((System.Byte)(119)), ((System.Byte)(145)), ((System.Byte)(135)));
			this.styleGuide1.PictureBoxColor = System.Drawing.Color.FromArgb(((System.Byte)(232)), ((System.Byte)(237)), ((System.Byte)(223)));
			this.styleGuide1.PlansOfColors = PallaControls.Windows.Forms.PlansColors.AssGreen;
			this.styleGuide1.RadioButtonColor = System.Drawing.Color.FromArgb(((System.Byte)(232)), ((System.Byte)(237)), ((System.Byte)(223)));
			this.styleGuide1.SelectionColor = System.Drawing.Color.FromArgb(((System.Byte)(224)), ((System.Byte)(231)), ((System.Byte)(214)));
			this.styleGuide1.TabControlBackColor = System.Drawing.Color.FromArgb(((System.Byte)(232)), ((System.Byte)(237)), ((System.Byte)(223)));
			this.styleGuide1.TaskPanelBackColor = System.Drawing.Color.FromArgb(((System.Byte)(232)), ((System.Byte)(237)), ((System.Byte)(223)));
			this.styleGuide1.TaskPanelBarBackColor = System.Drawing.Color.FromArgb(((System.Byte)(232)), ((System.Byte)(237)), ((System.Byte)(223)));
			this.styleGuide1.TaskPanelTitleBackColor = System.Drawing.Color.FromArgb(((System.Byte)(147)), ((System.Byte)(167)), ((System.Byte)(159)));
			this.styleGuide1.TaskPanelTitleForeColor = System.Drawing.Color.White;
			this.styleGuide1.TextColor = System.Drawing.Color.Black;
			// 
			// button5
			// 
			this.button5.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(232)), ((System.Byte)(237)), ((System.Byte)(223)));
			this.button5.BorderColor = System.Drawing.Color.FromArgb(((System.Byte)(123)), ((System.Byte)(156)), ((System.Byte)(159)));
			this.button5.BorderHotColor = System.Drawing.Color.FromArgb(((System.Byte)(123)), ((System.Byte)(156)), ((System.Byte)(159)));
			this.button5.ButtonColor = System.Drawing.Color.FromArgb(((System.Byte)(123)), ((System.Byte)(156)), ((System.Byte)(159)));
			this.button5.ButtonHotColor = System.Drawing.Color.FromArgb(((System.Byte)(131)), ((System.Byte)(171)), ((System.Byte)(170)));
			this.button5.ButtonPressedColor = System.Drawing.Color.FromArgb(((System.Byte)(99)), ((System.Byte)(133)), ((System.Byte)(137)));
			this.button5.FlashColor = System.Drawing.Color.FromArgb(((System.Byte)(109)), ((System.Byte)(135)), ((System.Byte)(125)));
			this.button5.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(224)), ((System.Byte)(231)), ((System.Byte)(213)));
			this.button5.Location = new System.Drawing.Point(232, 106);
			this.button5.Name = "button5";
			this.button5.ParentStyle = false;
			this.button5.Radius = 8F;
			this.button5.Size = new System.Drawing.Size(136, 21);
			this.button5.Style = this.styleGuide1;
			this.button5.TabIndex = 6;
			this.button5.Text = "&XPLine";
			this.button5.TextColor = System.Drawing.Color.FromArgb(((System.Byte)(224)), ((System.Byte)(231)), ((System.Byte)(213)));
			this.button5.ButtonPressed += new PallaControls.Windows.Forms.ButtonPressedEventHandler(this.button6_ButtonPressed);
			// 
			// button4
			// 
			this.button4.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(232)), ((System.Byte)(237)), ((System.Byte)(223)));
			this.button4.BorderColor = System.Drawing.Color.FromArgb(((System.Byte)(123)), ((System.Byte)(156)), ((System.Byte)(159)));
			this.button4.BorderHotColor = System.Drawing.Color.FromArgb(((System.Byte)(123)), ((System.Byte)(156)), ((System.Byte)(159)));
			this.button4.ButtonColor = System.Drawing.Color.FromArgb(((System.Byte)(123)), ((System.Byte)(156)), ((System.Byte)(159)));
			this.button4.ButtonHotColor = System.Drawing.Color.FromArgb(((System.Byte)(131)), ((System.Byte)(171)), ((System.Byte)(170)));
			this.button4.ButtonPressedColor = System.Drawing.Color.FromArgb(((System.Byte)(99)), ((System.Byte)(133)), ((System.Byte)(137)));
			this.button4.FlashColor = System.Drawing.Color.FromArgb(((System.Byte)(109)), ((System.Byte)(135)), ((System.Byte)(125)));
			this.button4.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(224)), ((System.Byte)(231)), ((System.Byte)(213)));
			this.button4.Location = new System.Drawing.Point(232, 82);
			this.button4.Name = "button4";
			this.button4.ParentStyle = false;
			this.button4.Radius = 8F;
			this.button4.Size = new System.Drawing.Size(136, 21);
			this.button4.Style = this.styleGuide1;
			this.button4.TabIndex = 5;
			this.button4.Text = "M&enuListBox";
			this.button4.TextColor = System.Drawing.Color.FromArgb(((System.Byte)(224)), ((System.Byte)(231)), ((System.Byte)(213)));
			this.button4.ButtonPressed += new PallaControls.Windows.Forms.ButtonPressedEventHandler(this.button1_ButtonPressed);
			// 
			// button3
			// 
			this.button3.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(232)), ((System.Byte)(237)), ((System.Byte)(223)));
			this.button3.BorderColor = System.Drawing.Color.FromArgb(((System.Byte)(123)), ((System.Byte)(156)), ((System.Byte)(159)));
			this.button3.BorderHotColor = System.Drawing.Color.FromArgb(((System.Byte)(123)), ((System.Byte)(156)), ((System.Byte)(159)));
			this.button3.ButtonColor = System.Drawing.Color.FromArgb(((System.Byte)(123)), ((System.Byte)(156)), ((System.Byte)(159)));
			this.button3.ButtonHotColor = System.Drawing.Color.FromArgb(((System.Byte)(131)), ((System.Byte)(171)), ((System.Byte)(170)));
			this.button3.ButtonPressedColor = System.Drawing.Color.FromArgb(((System.Byte)(99)), ((System.Byte)(133)), ((System.Byte)(137)));
			this.button3.FlashColor = System.Drawing.Color.FromArgb(((System.Byte)(109)), ((System.Byte)(135)), ((System.Byte)(125)));
			this.button3.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(224)), ((System.Byte)(231)), ((System.Byte)(213)));
			this.button3.Location = new System.Drawing.Point(232, 58);
			this.button3.Name = "button3";
			this.button3.ParentStyle = false;
			this.button3.Radius = 8F;
			this.button3.Size = new System.Drawing.Size(136, 21);
			this.button3.Style = this.styleGuide1;
			this.button3.TabIndex = 4;
			this.button3.Text = "&ProgressDialog";
			this.button3.TextColor = System.Drawing.Color.FromArgb(((System.Byte)(224)), ((System.Byte)(231)), ((System.Byte)(213)));
			this.button3.ButtonPressed += new PallaControls.Windows.Forms.ButtonPressedEventHandler(this.button4_ButtonPressed);
			// 
			// button2
			// 
			this.button2.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(232)), ((System.Byte)(237)), ((System.Byte)(223)));
			this.button2.BorderColor = System.Drawing.Color.FromArgb(((System.Byte)(123)), ((System.Byte)(156)), ((System.Byte)(159)));
			this.button2.BorderHotColor = System.Drawing.Color.FromArgb(((System.Byte)(123)), ((System.Byte)(156)), ((System.Byte)(159)));
			this.button2.ButtonColor = System.Drawing.Color.FromArgb(((System.Byte)(123)), ((System.Byte)(156)), ((System.Byte)(159)));
			this.button2.ButtonHotColor = System.Drawing.Color.FromArgb(((System.Byte)(131)), ((System.Byte)(171)), ((System.Byte)(170)));
			this.button2.ButtonPressedColor = System.Drawing.Color.FromArgb(((System.Byte)(99)), ((System.Byte)(133)), ((System.Byte)(137)));
			this.button2.FlashColor = System.Drawing.Color.FromArgb(((System.Byte)(109)), ((System.Byte)(135)), ((System.Byte)(125)));
			this.button2.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(224)), ((System.Byte)(231)), ((System.Byte)(213)));
			this.button2.Location = new System.Drawing.Point(232, 34);
			this.button2.Name = "button2";
			this.button2.ParentStyle = false;
			this.button2.Radius = 8F;
			this.button2.Size = new System.Drawing.Size(136, 21);
			this.button2.Style = this.styleGuide1;
			this.button2.TabIndex = 3;
			this.button2.Text = "&MessageBox";
			this.button2.TextColor = System.Drawing.Color.FromArgb(((System.Byte)(224)), ((System.Byte)(231)), ((System.Byte)(213)));
			this.button2.ButtonPressed += new PallaControls.Windows.Forms.ButtonPressedEventHandler(this.button3_ButtonPressed);
			// 
			// button1
			// 
			this.button1.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(232)), ((System.Byte)(237)), ((System.Byte)(223)));
			this.button1.BorderColor = System.Drawing.Color.FromArgb(((System.Byte)(123)), ((System.Byte)(156)), ((System.Byte)(159)));
			this.button1.BorderHotColor = System.Drawing.Color.FromArgb(((System.Byte)(123)), ((System.Byte)(156)), ((System.Byte)(159)));
			this.button1.ButtonColor = System.Drawing.Color.FromArgb(((System.Byte)(123)), ((System.Byte)(156)), ((System.Byte)(159)));
			this.button1.ButtonHotColor = System.Drawing.Color.FromArgb(((System.Byte)(131)), ((System.Byte)(171)), ((System.Byte)(170)));
			this.button1.ButtonPressedColor = System.Drawing.Color.FromArgb(((System.Byte)(99)), ((System.Byte)(133)), ((System.Byte)(137)));
			this.button1.FlashColor = System.Drawing.Color.FromArgb(((System.Byte)(109)), ((System.Byte)(135)), ((System.Byte)(125)));
			this.button1.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(224)), ((System.Byte)(231)), ((System.Byte)(213)));
			this.button1.Location = new System.Drawing.Point(232, 10);
			this.button1.Name = "button1";
			this.button1.ParentStyle = false;
			this.button1.Radius = 8F;
			this.button1.Size = new System.Drawing.Size(136, 21);
			this.button1.Style = this.styleGuide1;
			this.button1.TabIndex = 2;
			this.button1.Text = "&Input controls";
			this.button1.TextColor = System.Drawing.Color.FromArgb(((System.Byte)(224)), ((System.Byte)(231)), ((System.Byte)(213)));
			this.button1.ButtonPressed += new PallaControls.Windows.Forms.ButtonPressedEventHandler(this.button2_ButtonPressed);
			// 
			// groupBox1
			// 
			this.groupBox1.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(232)), ((System.Byte)(237)), ((System.Byte)(223)));
			this.groupBox1.BorderColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(217)), ((System.Byte)(207)));
			this.groupBox1.BorderHotColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(217)), ((System.Byte)(207)));
			this.groupBox1.Controls.AddRange(new System.Windows.Forms.Control[] {
																					this.radioButton9,
																					this.radioButton8,
																					this.radioButton7,
																					this.radioButton6,
																					this.radioButton5,
																					this.radioButton4,
																					this.radioButton3,
																					this.radioButton2,
																					this.radioButton1});
			this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.groupBox1.Location = new System.Drawing.Point(8, 8);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.PanelClientAreaColor = System.Drawing.Color.FromArgb(((System.Byte)(232)), ((System.Byte)(237)), ((System.Byte)(223)));
			this.groupBox1.ParentStyle = false;
			this.groupBox1.Radius = 20F;
			this.groupBox1.Size = new System.Drawing.Size(216, 264);
			this.groupBox1.Style = this.styleGuide1;
			this.groupBox1.TabIndex = 1;
			this.groupBox1.Text = "Styles";
			this.groupBox1.TextColor = System.Drawing.Color.Black;
			this.groupBox1.TextOffSet = 6;
			// 
			// radioButton8
			// 
			this.radioButton8.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(232)), ((System.Byte)(237)), ((System.Byte)(223)));
			this.radioButton8.BorderColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(217)), ((System.Byte)(207)));
			this.radioButton8.BorderHotColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(217)), ((System.Byte)(207)));
			this.radioButton8.ButtonColor = System.Drawing.Color.FromArgb(((System.Byte)(232)), ((System.Byte)(237)), ((System.Byte)(223)));
			this.radioButton8.CheckColor = System.Drawing.Color.FromArgb(((System.Byte)(147)), ((System.Byte)(167)), ((System.Byte)(159)));
			this.radioButton8.Checked = false;
			this.radioButton8.EditColor = System.Drawing.Color.FromArgb(((System.Byte)(232)), ((System.Byte)(237)), ((System.Byte)(223)));
			this.radioButton8.EditDisabledColor = System.Drawing.Color.FromArgb(((System.Byte)(238)), ((System.Byte)(238)), ((System.Byte)(225)));
			this.radioButton8.EditFocusedColor = System.Drawing.Color.FromArgb(((System.Byte)(240)), ((System.Byte)(240)), ((System.Byte)(240)));
			this.radioButton8.EditReadOnlyColor = System.Drawing.Color.FromArgb(((System.Byte)(238)), ((System.Byte)(238)), ((System.Byte)(225)));
			this.radioButton8.FlashColor = System.Drawing.Color.FromArgb(((System.Byte)(147)), ((System.Byte)(167)), ((System.Byte)(159)));
			this.radioButton8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.radioButton8.GroupIndex = -1;
			this.radioButton8.Location = new System.Drawing.Point(16, 200);
			this.radioButton8.Name = "radioButton8";
			this.radioButton8.ParentStyle = false;
			this.radioButton8.ReadOnly = false;
			this.radioButton8.Size = new System.Drawing.Size(168, 19);
			this.radioButton8.Style = this.styleGuide1;
			this.radioButton8.TabIndex = 7;
			this.radioButton8.Text = "Mouse";
			this.radioButton8.TextColor = System.Drawing.Color.Black;
			this.radioButton8.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
			// 
			// radioButton7
			// 
			this.radioButton7.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(232)), ((System.Byte)(237)), ((System.Byte)(223)));
			this.radioButton7.BorderColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(217)), ((System.Byte)(207)));
			this.radioButton7.BorderHotColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(217)), ((System.Byte)(207)));
			this.radioButton7.ButtonColor = System.Drawing.Color.FromArgb(((System.Byte)(232)), ((System.Byte)(237)), ((System.Byte)(223)));
			this.radioButton7.CheckColor = System.Drawing.Color.FromArgb(((System.Byte)(147)), ((System.Byte)(167)), ((System.Byte)(159)));
			this.radioButton7.Checked = false;
			this.radioButton7.EditColor = System.Drawing.Color.FromArgb(((System.Byte)(232)), ((System.Byte)(237)), ((System.Byte)(223)));
			this.radioButton7.EditDisabledColor = System.Drawing.Color.FromArgb(((System.Byte)(238)), ((System.Byte)(238)), ((System.Byte)(225)));
			this.radioButton7.EditFocusedColor = System.Drawing.Color.FromArgb(((System.Byte)(240)), ((System.Byte)(240)), ((System.Byte)(240)));
			this.radioButton7.EditReadOnlyColor = System.Drawing.Color.FromArgb(((System.Byte)(238)), ((System.Byte)(238)), ((System.Byte)(225)));
			this.radioButton7.FlashColor = System.Drawing.Color.FromArgb(((System.Byte)(147)), ((System.Byte)(167)), ((System.Byte)(159)));
			this.radioButton7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.radioButton7.GroupIndex = -1;
			this.radioButton7.Location = new System.Drawing.Point(16, 176);
			this.radioButton7.Name = "radioButton7";
			this.radioButton7.ParentStyle = false;
			this.radioButton7.ReadOnly = false;
			this.radioButton7.Size = new System.Drawing.Size(168, 19);
			this.radioButton7.Style = this.styleGuide1;
			this.radioButton7.TabIndex = 6;
			this.radioButton7.Text = "Trinity";
			this.radioButton7.TextColor = System.Drawing.Color.Black;
			this.radioButton7.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
			// 
			// radioButton6
			// 
			this.radioButton6.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(232)), ((System.Byte)(237)), ((System.Byte)(223)));
			this.radioButton6.BorderColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(217)), ((System.Byte)(207)));
			this.radioButton6.BorderHotColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(217)), ((System.Byte)(207)));
			this.radioButton6.ButtonColor = System.Drawing.Color.FromArgb(((System.Byte)(232)), ((System.Byte)(237)), ((System.Byte)(223)));
			this.radioButton6.CheckColor = System.Drawing.Color.FromArgb(((System.Byte)(147)), ((System.Byte)(167)), ((System.Byte)(159)));
			this.radioButton6.Checked = false;
			this.radioButton6.EditColor = System.Drawing.Color.FromArgb(((System.Byte)(232)), ((System.Byte)(237)), ((System.Byte)(223)));
			this.radioButton6.EditDisabledColor = System.Drawing.Color.FromArgb(((System.Byte)(238)), ((System.Byte)(238)), ((System.Byte)(225)));
			this.radioButton6.EditFocusedColor = System.Drawing.Color.FromArgb(((System.Byte)(240)), ((System.Byte)(240)), ((System.Byte)(240)));
			this.radioButton6.EditReadOnlyColor = System.Drawing.Color.FromArgb(((System.Byte)(238)), ((System.Byte)(238)), ((System.Byte)(225)));
			this.radioButton6.FlashColor = System.Drawing.Color.FromArgb(((System.Byte)(147)), ((System.Byte)(167)), ((System.Byte)(159)));
			this.radioButton6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.radioButton6.GroupIndex = -1;
			this.radioButton6.Location = new System.Drawing.Point(16, 152);
			this.radioButton6.Name = "radioButton6";
			this.radioButton6.ParentStyle = false;
			this.radioButton6.ReadOnly = false;
			this.radioButton6.Size = new System.Drawing.Size(168, 19);
			this.radioButton6.Style = this.styleGuide1;
			this.radioButton6.TabIndex = 5;
			this.radioButton6.Text = "AgentSmith";
			this.radioButton6.TextColor = System.Drawing.Color.Black;
			this.radioButton6.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
			// 
			// radioButton5
			// 
			this.radioButton5.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(232)), ((System.Byte)(237)), ((System.Byte)(223)));
			this.radioButton5.BorderColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(217)), ((System.Byte)(207)));
			this.radioButton5.BorderHotColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(217)), ((System.Byte)(207)));
			this.radioButton5.ButtonColor = System.Drawing.Color.FromArgb(((System.Byte)(232)), ((System.Byte)(237)), ((System.Byte)(223)));
			this.radioButton5.CheckColor = System.Drawing.Color.FromArgb(((System.Byte)(147)), ((System.Byte)(167)), ((System.Byte)(159)));
			this.radioButton5.Checked = false;
			this.radioButton5.EditColor = System.Drawing.Color.FromArgb(((System.Byte)(232)), ((System.Byte)(237)), ((System.Byte)(223)));
			this.radioButton5.EditDisabledColor = System.Drawing.Color.FromArgb(((System.Byte)(238)), ((System.Byte)(238)), ((System.Byte)(225)));
			this.radioButton5.EditFocusedColor = System.Drawing.Color.FromArgb(((System.Byte)(240)), ((System.Byte)(240)), ((System.Byte)(240)));
			this.radioButton5.EditReadOnlyColor = System.Drawing.Color.FromArgb(((System.Byte)(238)), ((System.Byte)(238)), ((System.Byte)(225)));
			this.radioButton5.FlashColor = System.Drawing.Color.FromArgb(((System.Byte)(147)), ((System.Byte)(167)), ((System.Byte)(159)));
			this.radioButton5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.radioButton5.GroupIndex = -1;
			this.radioButton5.Location = new System.Drawing.Point(16, 128);
			this.radioButton5.Name = "radioButton5";
			this.radioButton5.ParentStyle = false;
			this.radioButton5.ReadOnly = false;
			this.radioButton5.Size = new System.Drawing.Size(168, 19);
			this.radioButton5.Style = this.styleGuide1;
			this.radioButton5.TabIndex = 4;
			this.radioButton5.Text = "Apoc";
			this.radioButton5.TextColor = System.Drawing.Color.Black;
			this.radioButton5.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
			// 
			// radioButton4
			// 
			this.radioButton4.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(232)), ((System.Byte)(237)), ((System.Byte)(223)));
			this.radioButton4.BorderColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(217)), ((System.Byte)(207)));
			this.radioButton4.BorderHotColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(217)), ((System.Byte)(207)));
			this.radioButton4.ButtonColor = System.Drawing.Color.FromArgb(((System.Byte)(232)), ((System.Byte)(237)), ((System.Byte)(223)));
			this.radioButton4.CheckColor = System.Drawing.Color.FromArgb(((System.Byte)(147)), ((System.Byte)(167)), ((System.Byte)(159)));
			this.radioButton4.Checked = false;
			this.radioButton4.EditColor = System.Drawing.Color.FromArgb(((System.Byte)(232)), ((System.Byte)(237)), ((System.Byte)(223)));
			this.radioButton4.EditDisabledColor = System.Drawing.Color.FromArgb(((System.Byte)(238)), ((System.Byte)(238)), ((System.Byte)(225)));
			this.radioButton4.EditFocusedColor = System.Drawing.Color.FromArgb(((System.Byte)(240)), ((System.Byte)(240)), ((System.Byte)(240)));
			this.radioButton4.EditReadOnlyColor = System.Drawing.Color.FromArgb(((System.Byte)(238)), ((System.Byte)(238)), ((System.Byte)(225)));
			this.radioButton4.FlashColor = System.Drawing.Color.FromArgb(((System.Byte)(147)), ((System.Byte)(167)), ((System.Byte)(159)));
			this.radioButton4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.radioButton4.GroupIndex = -1;
			this.radioButton4.Location = new System.Drawing.Point(16, 80);
			this.radioButton4.Name = "radioButton4";
			this.radioButton4.ParentStyle = false;
			this.radioButton4.ReadOnly = false;
			this.radioButton4.Size = new System.Drawing.Size(168, 19);
			this.radioButton4.Style = this.styleGuide1;
			this.radioButton4.TabIndex = 2;
			this.radioButton4.Text = "Cypher";
			this.radioButton4.TextColor = System.Drawing.Color.Black;
			this.radioButton4.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
			// 
			// radioButton3
			// 
			this.radioButton3.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(232)), ((System.Byte)(237)), ((System.Byte)(223)));
			this.radioButton3.BorderColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(217)), ((System.Byte)(207)));
			this.radioButton3.BorderHotColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(217)), ((System.Byte)(207)));
			this.radioButton3.ButtonColor = System.Drawing.Color.FromArgb(((System.Byte)(232)), ((System.Byte)(237)), ((System.Byte)(223)));
			this.radioButton3.CheckColor = System.Drawing.Color.FromArgb(((System.Byte)(147)), ((System.Byte)(167)), ((System.Byte)(159)));
			this.radioButton3.Checked = false;
			this.radioButton3.EditColor = System.Drawing.Color.FromArgb(((System.Byte)(232)), ((System.Byte)(237)), ((System.Byte)(223)));
			this.radioButton3.EditDisabledColor = System.Drawing.Color.FromArgb(((System.Byte)(238)), ((System.Byte)(238)), ((System.Byte)(225)));
			this.radioButton3.EditFocusedColor = System.Drawing.Color.FromArgb(((System.Byte)(240)), ((System.Byte)(240)), ((System.Byte)(240)));
			this.radioButton3.EditReadOnlyColor = System.Drawing.Color.FromArgb(((System.Byte)(238)), ((System.Byte)(238)), ((System.Byte)(225)));
			this.radioButton3.FlashColor = System.Drawing.Color.FromArgb(((System.Byte)(147)), ((System.Byte)(167)), ((System.Byte)(159)));
			this.radioButton3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.radioButton3.GroupIndex = -1;
			this.radioButton3.Location = new System.Drawing.Point(16, 104);
			this.radioButton3.Name = "radioButton3";
			this.radioButton3.ParentStyle = false;
			this.radioButton3.ReadOnly = false;
			this.radioButton3.Size = new System.Drawing.Size(168, 19);
			this.radioButton3.Style = this.styleGuide1;
			this.radioButton3.TabIndex = 3;
			this.radioButton3.Text = "Morpheus";
			this.radioButton3.TextColor = System.Drawing.Color.Black;
			this.radioButton3.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
			// 
			// radioButton2
			// 
			this.radioButton2.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(232)), ((System.Byte)(237)), ((System.Byte)(223)));
			this.radioButton2.BorderColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(217)), ((System.Byte)(207)));
			this.radioButton2.BorderHotColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(217)), ((System.Byte)(207)));
			this.radioButton2.ButtonColor = System.Drawing.Color.FromArgb(((System.Byte)(232)), ((System.Byte)(237)), ((System.Byte)(223)));
			this.radioButton2.CheckColor = System.Drawing.Color.FromArgb(((System.Byte)(147)), ((System.Byte)(167)), ((System.Byte)(159)));
			this.radioButton2.Checked = true;
			this.radioButton2.EditColor = System.Drawing.Color.FromArgb(((System.Byte)(232)), ((System.Byte)(237)), ((System.Byte)(223)));
			this.radioButton2.EditDisabledColor = System.Drawing.Color.FromArgb(((System.Byte)(238)), ((System.Byte)(238)), ((System.Byte)(225)));
			this.radioButton2.EditFocusedColor = System.Drawing.Color.FromArgb(((System.Byte)(240)), ((System.Byte)(240)), ((System.Byte)(240)));
			this.radioButton2.EditReadOnlyColor = System.Drawing.Color.FromArgb(((System.Byte)(238)), ((System.Byte)(238)), ((System.Byte)(225)));
			this.radioButton2.FlashColor = System.Drawing.Color.FromArgb(((System.Byte)(147)), ((System.Byte)(167)), ((System.Byte)(159)));
			this.radioButton2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.radioButton2.GroupIndex = -1;
			this.radioButton2.Location = new System.Drawing.Point(16, 56);
			this.radioButton2.Name = "radioButton2";
			this.radioButton2.ParentStyle = false;
			this.radioButton2.ReadOnly = false;
			this.radioButton2.Size = new System.Drawing.Size(168, 19);
			this.radioButton2.Style = this.styleGuide1;
			this.radioButton2.TabIndex = 1;
			this.radioButton2.Text = "AssGreen";
			this.radioButton2.TextColor = System.Drawing.Color.Black;
			this.radioButton2.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
			// 
			// radioButton1
			// 
			this.radioButton1.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(232)), ((System.Byte)(237)), ((System.Byte)(223)));
			this.radioButton1.BorderColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(217)), ((System.Byte)(207)));
			this.radioButton1.BorderHotColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(217)), ((System.Byte)(207)));
			this.radioButton1.ButtonColor = System.Drawing.Color.FromArgb(((System.Byte)(232)), ((System.Byte)(237)), ((System.Byte)(223)));
			this.radioButton1.CheckColor = System.Drawing.Color.FromArgb(((System.Byte)(147)), ((System.Byte)(167)), ((System.Byte)(159)));
			this.radioButton1.Checked = false;
			this.radioButton1.EditColor = System.Drawing.Color.FromArgb(((System.Byte)(232)), ((System.Byte)(237)), ((System.Byte)(223)));
			this.radioButton1.EditDisabledColor = System.Drawing.Color.FromArgb(((System.Byte)(238)), ((System.Byte)(238)), ((System.Byte)(225)));
			this.radioButton1.EditFocusedColor = System.Drawing.Color.FromArgb(((System.Byte)(240)), ((System.Byte)(240)), ((System.Byte)(240)));
			this.radioButton1.EditReadOnlyColor = System.Drawing.Color.FromArgb(((System.Byte)(238)), ((System.Byte)(238)), ((System.Byte)(225)));
			this.radioButton1.FlashColor = System.Drawing.Color.FromArgb(((System.Byte)(147)), ((System.Byte)(167)), ((System.Byte)(159)));
			this.radioButton1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.radioButton1.GroupIndex = -1;
			this.radioButton1.Location = new System.Drawing.Point(16, 32);
			this.radioButton1.Name = "radioButton1";
			this.radioButton1.ParentStyle = false;
			this.radioButton1.ReadOnly = false;
			this.radioButton1.Size = new System.Drawing.Size(168, 19);
			this.radioButton1.Style = this.styleGuide1;
			this.radioButton1.TabIndex = 0;
			this.radioButton1.Text = "Neo";
			this.radioButton1.TextColor = System.Drawing.Color.Black;
			this.radioButton1.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
			// 
			// panel3
			// 
			this.panel3.BackColor = System.Drawing.Color.Empty;
			this.panel3.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.panel3.Location = new System.Drawing.Point(0, 278);
			this.panel3.Name = "panel3";
			this.panel3.PanelAssBottomAreaColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(230)), ((System.Byte)(210)));
			this.panel3.PanelAssClientAreaColor = System.Drawing.Color.FromArgb(((System.Byte)(232)), ((System.Byte)(237)), ((System.Byte)(223)));
			this.panel3.PanelAssLeftOptionsColor = System.Drawing.Color.FromArgb(((System.Byte)(147)), ((System.Byte)(167)), ((System.Byte)(159)));
			this.panel3.PanelAssLeftTitleColor = System.Drawing.Color.FromArgb(((System.Byte)(232)), ((System.Byte)(237)), ((System.Byte)(223)));
			this.panel3.PanelAssRightTitleColor = System.Drawing.Color.FromArgb(((System.Byte)(147)), ((System.Byte)(167)), ((System.Byte)(159)));
			this.panel3.PanelBottomAreaColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(230)), ((System.Byte)(210)));
			this.panel3.PanelClientAreaColor = System.Drawing.Color.FromArgb(((System.Byte)(232)), ((System.Byte)(237)), ((System.Byte)(223)));
			this.panel3.PanelLeftOptionsColor = System.Drawing.Color.FromArgb(((System.Byte)(147)), ((System.Byte)(167)), ((System.Byte)(159)));
			this.panel3.PanelTopOptionsColor = System.Drawing.Color.FromArgb(((System.Byte)(119)), ((System.Byte)(145)), ((System.Byte)(135)));
			this.panel3.PanelType = PallaControls.Windows.Forms.PanelTypes.BottomArea;
			this.panel3.ParentStyle = true;
			this.panel3.Size = new System.Drawing.Size(377, 25);
			this.panel3.Style = this.styleGuide1;
			this.panel3.TabIndex = 0;
			// 
			// panel1
			// 
			this.panel1.BackColor = System.Drawing.Color.Empty;
			this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
			this.panel1.Name = "panel1";
			this.panel1.PanelAssBottomAreaColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(230)), ((System.Byte)(210)));
			this.panel1.PanelAssClientAreaColor = System.Drawing.Color.FromArgb(((System.Byte)(232)), ((System.Byte)(237)), ((System.Byte)(223)));
			this.panel1.PanelAssLeftOptionsColor = System.Drawing.Color.FromArgb(((System.Byte)(147)), ((System.Byte)(167)), ((System.Byte)(159)));
			this.panel1.PanelAssLeftTitleColor = System.Drawing.Color.FromArgb(((System.Byte)(232)), ((System.Byte)(237)), ((System.Byte)(223)));
			this.panel1.PanelAssRightTitleColor = System.Drawing.Color.FromArgb(((System.Byte)(147)), ((System.Byte)(167)), ((System.Byte)(159)));
			this.panel1.PanelBottomAreaColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(230)), ((System.Byte)(210)));
			this.panel1.PanelClientAreaColor = System.Drawing.Color.FromArgb(((System.Byte)(232)), ((System.Byte)(237)), ((System.Byte)(223)));
			this.panel1.PanelLeftOptionsColor = System.Drawing.Color.FromArgb(((System.Byte)(147)), ((System.Byte)(167)), ((System.Byte)(159)));
			this.panel1.PanelTopOptionsColor = System.Drawing.Color.FromArgb(((System.Byte)(119)), ((System.Byte)(145)), ((System.Byte)(135)));
			this.panel1.PanelType = PallaControls.Windows.Forms.PanelTypes.LeftOptions;
			this.panel1.ParentStyle = true;
			this.panel1.Size = new System.Drawing.Size(81, 303);
			this.panel1.Style = this.styleGuide1;
			this.panel1.TabIndex = 0;
			// 
			// radioButton9
			// 
			this.radioButton9.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(232)), ((System.Byte)(237)), ((System.Byte)(223)));
			this.radioButton9.BorderColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(217)), ((System.Byte)(207)));
			this.radioButton9.BorderHotColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(217)), ((System.Byte)(207)));
			this.radioButton9.ButtonColor = System.Drawing.Color.FromArgb(((System.Byte)(232)), ((System.Byte)(237)), ((System.Byte)(223)));
			this.radioButton9.CheckColor = System.Drawing.Color.FromArgb(((System.Byte)(147)), ((System.Byte)(167)), ((System.Byte)(159)));
			this.radioButton9.Checked = false;
			this.radioButton9.EditColor = System.Drawing.Color.FromArgb(((System.Byte)(232)), ((System.Byte)(237)), ((System.Byte)(223)));
			this.radioButton9.EditDisabledColor = System.Drawing.Color.FromArgb(((System.Byte)(238)), ((System.Byte)(238)), ((System.Byte)(225)));
			this.radioButton9.EditFocusedColor = System.Drawing.Color.FromArgb(((System.Byte)(240)), ((System.Byte)(240)), ((System.Byte)(240)));
			this.radioButton9.EditReadOnlyColor = System.Drawing.Color.FromArgb(((System.Byte)(238)), ((System.Byte)(238)), ((System.Byte)(225)));
			this.radioButton9.FlashColor = System.Drawing.Color.FromArgb(((System.Byte)(147)), ((System.Byte)(167)), ((System.Byte)(159)));
			this.radioButton9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.radioButton9.GroupIndex = -1;
			this.radioButton9.Location = new System.Drawing.Point(16, 224);
			this.radioButton9.Name = "radioButton9";
			this.radioButton9.ParentStyle = false;
			this.radioButton9.ReadOnly = false;
			this.radioButton9.Size = new System.Drawing.Size(168, 19);
			this.radioButton9.Style = this.styleGuide1;
			this.radioButton9.TabIndex = 8;
			this.radioButton9.Text = "TweakGreen";
			this.radioButton9.TextColor = System.Drawing.Color.Black;
			this.radioButton9.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
			// 
			// frmStyleSamples
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(458, 303);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.panel2,
																		  this.panel1});
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.MaximizeBox = false;
			this.Name = "frmStyleSamples";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "PallaControls style samples";
			this.panel2.ResumeLayout(false);
			this.groupBox1.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new frmStyleSamples());
		}

		private void radioButton1_CheckedChanged(object sender, System.EventArgs e)
		{
			if (this.radioButton1.Checked)  
				this.styleGuide1.PlansOfColors = PallaControls.Windows.Forms.PlansColors.NeoTheOne;
			else if (this.radioButton2.Checked)
				this.styleGuide1.PlansOfColors = PallaControls.Windows.Forms.PlansColors.AssGreen;
		    else if (this.radioButton3.Checked)
				this.styleGuide1.PlansOfColors = PallaControls.Windows.Forms.PlansColors.Cypher;
		    else if (this.radioButton4.Checked)
				this.styleGuide1.PlansOfColors = PallaControls.Windows.Forms.PlansColors.Morpheus;
		    else if (this.radioButton5.Checked)
				this.styleGuide1.PlansOfColors = PallaControls.Windows.Forms.PlansColors.Apoc;
		    else if (this.radioButton6.Checked)
				this.styleGuide1.PlansOfColors = PallaControls.Windows.Forms.PlansColors.AgentSmith;
		    else if (this.radioButton7.Checked)
				this.styleGuide1.PlansOfColors = PallaControls.Windows.Forms.PlansColors.Trinity;
			else if (this.radioButton8.Checked)
				this.styleGuide1.PlansOfColors = PallaControls.Windows.Forms.PlansColors.Mouse;
			else if (this.radioButton9.Checked)
				this.styleGuide1.PlansOfColors = PallaControls.Windows.Forms.PlansColors.TweakGreen;
		}

		private void button2_ButtonPressed(object sender, System.EventArgs e)
		{
			frmInputControls form = new frmInputControls(this.styleGuide1);
			try
			{
				form.ShowDialog(this);
			}
			finally
			{
				form.Dispose();
			}
		}

		private void button3_ButtonPressed(object sender, System.EventArgs e)
		{
			bool checkValue = false;

			PallaControls.Windows.Forms.MessageBox.Show("Message", MessageBoxButtons.OKCancel, 
					MessageBoxIcon.Information,MessageBoxDefaultButton.Button1, this.styleGuide1, "Show again?", ref checkValue);
		}

		private void button4_ButtonPressed(object sender, System.EventArgs e)
		{
			PallaControls.Windows.Forms.MessageBox.ShowProgressDialog("Wait...", true, this.styleGuide1, null);
		}

		private void button5_ButtonPressed(object sender, System.EventArgs e)
		{
			groupBox1.FlashControl();
		}

		private void button1_ButtonPressed(object sender, System.EventArgs e)
		{
			frmMenuListBoxSample form = new frmMenuListBoxSample(this.styleGuide1);
			try
			{
				form.ShowDialog(this);
			}
			finally
			{
				form.Dispose();
			}
		}

		private void button6_ButtonPressed(object sender, System.EventArgs e)
		{
			frmXpline form = new frmXpline(this.styleGuide1);
			try
			{
				form.ShowDialog(this);
			}
			finally
			{
				form.Dispose();
			}
		}
	}
}
