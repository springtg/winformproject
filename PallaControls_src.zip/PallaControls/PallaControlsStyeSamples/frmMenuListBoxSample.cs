using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace PallaControlsStyeSamples
{
	/// <summary>
	/// Summary description for frmMenuListBoxSample.
	/// </summary>
	public class frmMenuListBoxSample : System.Windows.Forms.Form
	{
		private PallaControls.Windows.Forms.Panel panel1;
		private PallaControls.Windows.Forms.OptionPanel optionPanel1;
		private PallaControls.Windows.Forms.Panel panel2;
		private PallaControls.Windows.Forms.Panel panel3;
		private PallaControls.Windows.Forms.StyleGuide styleGuide1;
		private PallaControls.Windows.Forms.MenuListBox menuListBox1;
		private PallaControls.Windows.Forms.PanelItem panelItem1;
		private PallaControls.Windows.Forms.PanelItem panelItem2;
		private PallaControls.Windows.Forms.PanelItem panelItem3;
		private PallaControls.Windows.Forms.PanelItem panelItem4;
		private PallaControls.Windows.Forms.PanelItem panelItem5;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.ComponentModel.IContainer components;

		public frmMenuListBoxSample(PallaControls.Windows.Forms.StyleGuide style)
		{
			InitializeComponent();

			optionPanel1.Style = style;
			panel1.Style = style;
			panel2.Style = style;
			panel3.Style = style;

			panelItem1.Style = style;
			panelItem2.Style = style;
			panelItem3.Style = style;
			panelItem4.Style = style;
			panelItem5.Style = style;

			menuListBox1.Style = style;
			menuListBox1.Style = null;
			menuListBox1.EditFocusedColor = menuListBox1.EditColor;
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmMenuListBoxSample));
			this.panel1 = new PallaControls.Windows.Forms.Panel();
			this.menuListBox1 = new PallaControls.Windows.Forms.MenuListBox();
			this.styleGuide1 = new PallaControls.Windows.Forms.StyleGuide(this.components);
			this.panel2 = new PallaControls.Windows.Forms.Panel();
			this.label1 = new System.Windows.Forms.Label();
			this.optionPanel1 = new PallaControls.Windows.Forms.OptionPanel();
			this.panel3 = new PallaControls.Windows.Forms.Panel();
			this.label2 = new System.Windows.Forms.Label();
			this.panelItem1 = new PallaControls.Windows.Forms.PanelItem();
			this.panelItem2 = new PallaControls.Windows.Forms.PanelItem();
			this.panelItem3 = new PallaControls.Windows.Forms.PanelItem();
			this.panelItem4 = new PallaControls.Windows.Forms.PanelItem();
			this.panelItem5 = new PallaControls.Windows.Forms.PanelItem();
			this.panel1.SuspendLayout();
			this.panel2.SuspendLayout();
			this.optionPanel1.SuspendLayout();
			this.panel3.SuspendLayout();
			this.SuspendLayout();
			// 
			// panel1
			// 
			this.panel1.BackColor = System.Drawing.Color.Empty;
			this.panel1.Controls.AddRange(new System.Windows.Forms.Control[] {
																				 this.menuListBox1,
																				 this.panel2});
			this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.panel1.Name = "panel1";
			this.panel1.PanelAssBottomAreaColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(230)), ((System.Byte)(210)));
			this.panel1.PanelAssClientAreaColor = System.Drawing.Color.FromArgb(((System.Byte)(232)), ((System.Byte)(237)), ((System.Byte)(223)));
			this.panel1.PanelAssLeftOptionsColor = System.Drawing.Color.FromArgb(((System.Byte)(147)), ((System.Byte)(167)), ((System.Byte)(159)));
			this.panel1.PanelAssLeftTitleColor = System.Drawing.Color.FromArgb(((System.Byte)(232)), ((System.Byte)(237)), ((System.Byte)(223)));
			this.panel1.PanelAssRightTitleColor = System.Drawing.Color.FromArgb(((System.Byte)(147)), ((System.Byte)(167)), ((System.Byte)(159)));
			this.panel1.PanelBottomAreaColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(230)), ((System.Byte)(210)));
			this.panel1.PanelClientAreaColor = System.Drawing.Color.FromArgb(((System.Byte)(232)), ((System.Byte)(237)), ((System.Byte)(223)));
			this.panel1.PanelLeftOptionsColor = System.Drawing.Color.FromArgb(((System.Byte)(147)), ((System.Byte)(167)), ((System.Byte)(159)));
			this.panel1.PanelTopOptionsColor = System.Drawing.Color.FromArgb(((System.Byte)(119)), ((System.Byte)(145)), ((System.Byte)(135)));
			this.panel1.PanelType = PallaControls.Windows.Forms.PanelTypes.ClientArea;
			this.panel1.Size = new System.Drawing.Size(506, 373);
			this.panel1.Style = this.styleGuide1;
			this.panel1.TabIndex = 0;
			// 
			// menuListBox1
			// 
			this.menuListBox1.BorderColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(217)), ((System.Byte)(207)));
			this.menuListBox1.BorderHotColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(217)), ((System.Byte)(207)));
			this.menuListBox1.DockPadding.All = 1;
			this.menuListBox1.EditColor = System.Drawing.Color.FromArgb(((System.Byte)(232)), ((System.Byte)(237)), ((System.Byte)(223)));
			this.menuListBox1.EditDisabledColor = System.Drawing.Color.FromArgb(((System.Byte)(238)), ((System.Byte)(238)), ((System.Byte)(225)));
			this.menuListBox1.EditFocusedColor = System.Drawing.Color.FromArgb(((System.Byte)(240)), ((System.Byte)(240)), ((System.Byte)(240)));
			this.menuListBox1.EditReadOnlyColor = System.Drawing.Color.FromArgb(((System.Byte)(238)), ((System.Byte)(238)), ((System.Byte)(225)));
			this.menuListBox1.FlashColor = System.Drawing.Color.FromArgb(((System.Byte)(147)), ((System.Byte)(167)), ((System.Byte)(159)));
			this.menuListBox1.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.menuListBox1.ItemImage = ((System.Drawing.Bitmap)(resources.GetObject("menuListBox1.ItemImage")));
			this.menuListBox1.Location = new System.Drawing.Point(144, 40);
			this.menuListBox1.Name = "menuListBox1";
			this.menuListBox1.SelectedIndex = -1;
			this.menuListBox1.SelectionColor = System.Drawing.Color.FromArgb(((System.Byte)(224)), ((System.Byte)(231)), ((System.Byte)(214)));
			this.menuListBox1.Size = new System.Drawing.Size(362, 333);
			this.menuListBox1.Style = this.styleGuide1;
			this.menuListBox1.TabIndex = 2;
			this.menuListBox1.TextColor = System.Drawing.Color.Black;
			this.menuListBox1.TitleFont = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold);
			// 
			// styleGuide1
			// 
			this.styleGuide1.BorderColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(217)), ((System.Byte)(207)));
			this.styleGuide1.BorderHotColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(217)), ((System.Byte)(207)));
			this.styleGuide1.ButtonBorderColor = System.Drawing.Color.FromArgb(((System.Byte)(123)), ((System.Byte)(156)), ((System.Byte)(159)));
			this.styleGuide1.ButtonBorderHotColor = System.Drawing.Color.FromArgb(((System.Byte)(123)), ((System.Byte)(156)), ((System.Byte)(159)));
			this.styleGuide1.ButtonColor = System.Drawing.Color.FromArgb(((System.Byte)(123)), ((System.Byte)(156)), ((System.Byte)(159)));
			this.styleGuide1.ButtonFlashColor = System.Drawing.Color.FromArgb(((System.Byte)(109)), ((System.Byte)(135)), ((System.Byte)(125)));
			this.styleGuide1.ButtonHotColor = System.Drawing.Color.FromArgb(((System.Byte)(131)), ((System.Byte)(171)), ((System.Byte)(170)));
			this.styleGuide1.ButtonPressedColor = System.Drawing.Color.FromArgb(((System.Byte)(99)), ((System.Byte)(133)), ((System.Byte)(137)));
			this.styleGuide1.ButtonTextColor = System.Drawing.Color.FromArgb(((System.Byte)(224)), ((System.Byte)(231)), ((System.Byte)(213)));
			this.styleGuide1.CalendarBackColor = System.Drawing.Color.FromArgb(((System.Byte)(232)), ((System.Byte)(237)), ((System.Byte)(223)));
			this.styleGuide1.CalendarForeColor = System.Drawing.Color.Black;
			this.styleGuide1.CalendarTitleBackColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(217)), ((System.Byte)(207)));
			this.styleGuide1.CalendarTitleForeColor = System.Drawing.Color.White;
			this.styleGuide1.CalendarTrailingForeColor = System.Drawing.Color.FromArgb(((System.Byte)(147)), ((System.Byte)(167)), ((System.Byte)(159)));
			this.styleGuide1.CheckBoxColor = System.Drawing.Color.FromArgb(((System.Byte)(232)), ((System.Byte)(237)), ((System.Byte)(223)));
			this.styleGuide1.CheckColor = System.Drawing.Color.FromArgb(((System.Byte)(147)), ((System.Byte)(167)), ((System.Byte)(159)));
			this.styleGuide1.CollapsiblePanelBackColor = System.Drawing.Color.FromArgb(((System.Byte)(183)), ((System.Byte)(196)), ((System.Byte)(190)));
			this.styleGuide1.CollapsiblePanelBarBackColor = System.Drawing.Color.FromArgb(((System.Byte)(147)), ((System.Byte)(167)), ((System.Byte)(159)));
			this.styleGuide1.CollapsiblePanelEndColor = System.Drawing.Color.White;
			this.styleGuide1.CollapsiblePanelLineEndColor = System.Drawing.Color.White;
			this.styleGuide1.CollapsiblePanelLineStartColor = System.Drawing.Color.White;
			this.styleGuide1.CollapsiblePanelLinkColor = System.Drawing.Color.White;
			this.styleGuide1.CollapsiblePanelStartColor = System.Drawing.Color.FromArgb(((System.Byte)(114)), ((System.Byte)(139)), ((System.Byte)(129)));
			this.styleGuide1.CollapsiblePanelTitleFontColor = System.Drawing.Color.White;
			this.styleGuide1.DataGridAlternatingBackColor = System.Drawing.Color.FromArgb(((System.Byte)(224)), ((System.Byte)(231)), ((System.Byte)(214)));
			this.styleGuide1.DataGridBackColor = System.Drawing.Color.FromArgb(((System.Byte)(240)), ((System.Byte)(240)), ((System.Byte)(240)));
			this.styleGuide1.DataGridBackgroundColor = System.Drawing.Color.FromArgb(((System.Byte)(232)), ((System.Byte)(237)), ((System.Byte)(223)));
			this.styleGuide1.DataGridCaptionBackColor = System.Drawing.Color.FromArgb(((System.Byte)(109)), ((System.Byte)(135)), ((System.Byte)(125)));
			this.styleGuide1.DataGridCaptionForeColor = System.Drawing.Color.White;
			this.styleGuide1.DataGridForeColor = System.Drawing.Color.Black;
			this.styleGuide1.DataGridHeaderBackColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(217)), ((System.Byte)(207)));
			this.styleGuide1.DataGridHeaderForeColor = System.Drawing.Color.Black;
			this.styleGuide1.DataGridLineColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(217)), ((System.Byte)(207)));
			this.styleGuide1.DataGridLinkColor = System.Drawing.Color.LightSteelBlue;
			this.styleGuide1.DataGridParentRowsBackColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(217)), ((System.Byte)(207)));
			this.styleGuide1.DataGridParentRowsForeColor = System.Drawing.Color.Black;
			this.styleGuide1.DataGridSelectionBackColor = System.Drawing.Color.Navy;
			this.styleGuide1.DataGridSelectionForeColor = System.Drawing.Color.White;
			this.styleGuide1.DockingActiveColor = System.Drawing.Color.FromArgb(((System.Byte)(224)), ((System.Byte)(231)), ((System.Byte)(214)));
			this.styleGuide1.DockingActiveTextColor = System.Drawing.Color.White;
			this.styleGuide1.DockingBackColor = System.Drawing.Color.FromArgb(((System.Byte)(232)), ((System.Byte)(237)), ((System.Byte)(223)));
			this.styleGuide1.DockingInactiveTextColor = System.Drawing.Color.Black;
			this.styleGuide1.DockingResizeBarColor = System.Drawing.Color.FromArgb(((System.Byte)(231)), ((System.Byte)(231)), ((System.Byte)(214)));
			this.styleGuide1.EditButtonColor = System.Drawing.Color.FromArgb(((System.Byte)(224)), ((System.Byte)(231)), ((System.Byte)(214)));
			this.styleGuide1.EditButtonHotColor = System.Drawing.Color.FromArgb(((System.Byte)(231)), ((System.Byte)(231)), ((System.Byte)(214)));
			this.styleGuide1.EditButtonPressedColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(217)), ((System.Byte)(207)));
			this.styleGuide1.EditColor = System.Drawing.Color.FromArgb(((System.Byte)(232)), ((System.Byte)(237)), ((System.Byte)(223)));
			this.styleGuide1.EditDisabledColor = System.Drawing.Color.FromArgb(((System.Byte)(238)), ((System.Byte)(238)), ((System.Byte)(225)));
			this.styleGuide1.EditFocusedColor = System.Drawing.Color.FromArgb(((System.Byte)(240)), ((System.Byte)(240)), ((System.Byte)(240)));
			this.styleGuide1.EditReadOnlyColor = System.Drawing.Color.FromArgb(((System.Byte)(238)), ((System.Byte)(238)), ((System.Byte)(225)));
			this.styleGuide1.FlashColor = System.Drawing.Color.FromArgb(((System.Byte)(147)), ((System.Byte)(167)), ((System.Byte)(159)));
			this.styleGuide1.InfiniteProgressEndColor = System.Drawing.Color.FromArgb(((System.Byte)(240)), ((System.Byte)(240)), ((System.Byte)(240)));
			this.styleGuide1.InfiniteProgressStartColor = System.Drawing.Color.FromArgb(((System.Byte)(147)), ((System.Byte)(167)), ((System.Byte)(159)));
			this.styleGuide1.LabelColor = System.Drawing.Color.FromArgb(((System.Byte)(224)), ((System.Byte)(231)), ((System.Byte)(214)));
			this.styleGuide1.NegativeNumberColor = System.Drawing.Color.Black;
			this.styleGuide1.PanelAssBottomAreaColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(230)), ((System.Byte)(210)));
			this.styleGuide1.PanelAssClientAreaColor = System.Drawing.Color.FromArgb(((System.Byte)(232)), ((System.Byte)(237)), ((System.Byte)(223)));
			this.styleGuide1.PanelAssLeftOptionsColor = System.Drawing.Color.FromArgb(((System.Byte)(147)), ((System.Byte)(167)), ((System.Byte)(159)));
			this.styleGuide1.PanelAssLeftTitleColor = System.Drawing.Color.FromArgb(((System.Byte)(232)), ((System.Byte)(237)), ((System.Byte)(223)));
			this.styleGuide1.PanelAssRightTitleColor = System.Drawing.Color.FromArgb(((System.Byte)(147)), ((System.Byte)(167)), ((System.Byte)(159)));
			this.styleGuide1.PanelBottomAreaColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(230)), ((System.Byte)(210)));
			this.styleGuide1.PanelClientAreaColor = System.Drawing.Color.FromArgb(((System.Byte)(232)), ((System.Byte)(237)), ((System.Byte)(223)));
			this.styleGuide1.PanelItemAssBackColor = System.Drawing.Color.FromArgb(((System.Byte)(147)), ((System.Byte)(167)), ((System.Byte)(159)));
			this.styleGuide1.PanelItemBackColor = System.Drawing.Color.FromArgb(((System.Byte)(183)), ((System.Byte)(196)), ((System.Byte)(190)));
			this.styleGuide1.PanelItemFlashColor = System.Drawing.Color.FromArgb(((System.Byte)(108)), ((System.Byte)(108)), ((System.Byte)(108)));
			this.styleGuide1.PanelItemForeColor = System.Drawing.Color.FromArgb(((System.Byte)(228)), ((System.Byte)(234)), ((System.Byte)(218)));
			this.styleGuide1.PanelLeftOptionsColor = System.Drawing.Color.FromArgb(((System.Byte)(147)), ((System.Byte)(167)), ((System.Byte)(159)));
			this.styleGuide1.PanelTopOptionsColor = System.Drawing.Color.FromArgb(((System.Byte)(119)), ((System.Byte)(145)), ((System.Byte)(135)));
			this.styleGuide1.PictureBoxColor = System.Drawing.Color.FromArgb(((System.Byte)(232)), ((System.Byte)(237)), ((System.Byte)(223)));
			this.styleGuide1.PlansOfColors = PallaControls.Windows.Forms.PlansColors.AssGreen;
			this.styleGuide1.RadioButtonColor = System.Drawing.Color.FromArgb(((System.Byte)(232)), ((System.Byte)(237)), ((System.Byte)(223)));
			this.styleGuide1.SelectionColor = System.Drawing.Color.FromArgb(((System.Byte)(224)), ((System.Byte)(231)), ((System.Byte)(214)));
			this.styleGuide1.TabControlBackColor = System.Drawing.Color.FromArgb(((System.Byte)(232)), ((System.Byte)(237)), ((System.Byte)(223)));
			this.styleGuide1.TaskPanelBackColor = System.Drawing.Color.FromArgb(((System.Byte)(232)), ((System.Byte)(237)), ((System.Byte)(223)));
			this.styleGuide1.TaskPanelBarBackColor = System.Drawing.Color.FromArgb(((System.Byte)(232)), ((System.Byte)(237)), ((System.Byte)(223)));
			this.styleGuide1.TaskPanelTitleBackColor = System.Drawing.Color.FromArgb(((System.Byte)(147)), ((System.Byte)(167)), ((System.Byte)(159)));
			this.styleGuide1.TaskPanelTitleForeColor = System.Drawing.Color.White;
			this.styleGuide1.TextColor = System.Drawing.Color.Black;
			// 
			// panel2
			// 
			this.panel2.BackColor = System.Drawing.Color.Empty;
			this.panel2.Controls.AddRange(new System.Windows.Forms.Control[] {
																				 this.label1});
			this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel2.Name = "panel2";
			this.panel2.PanelAssBottomAreaColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(230)), ((System.Byte)(210)));
			this.panel2.PanelAssClientAreaColor = System.Drawing.Color.FromArgb(((System.Byte)(232)), ((System.Byte)(237)), ((System.Byte)(223)));
			this.panel2.PanelAssLeftOptionsColor = System.Drawing.Color.FromArgb(((System.Byte)(147)), ((System.Byte)(167)), ((System.Byte)(159)));
			this.panel2.PanelAssLeftTitleColor = System.Drawing.Color.FromArgb(((System.Byte)(232)), ((System.Byte)(237)), ((System.Byte)(223)));
			this.panel2.PanelAssRightTitleColor = System.Drawing.Color.FromArgb(((System.Byte)(147)), ((System.Byte)(167)), ((System.Byte)(159)));
			this.panel2.PanelBottomAreaColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(230)), ((System.Byte)(210)));
			this.panel2.PanelClientAreaColor = System.Drawing.Color.FromArgb(((System.Byte)(232)), ((System.Byte)(237)), ((System.Byte)(223)));
			this.panel2.PanelLeftOptionsColor = System.Drawing.Color.FromArgb(((System.Byte)(147)), ((System.Byte)(167)), ((System.Byte)(159)));
			this.panel2.PanelTopOptionsColor = System.Drawing.Color.FromArgb(((System.Byte)(119)), ((System.Byte)(145)), ((System.Byte)(135)));
			this.panel2.PanelType = PallaControls.Windows.Forms.PanelTypes.AssRightTitle;
			this.panel2.Size = new System.Drawing.Size(506, 40);
			this.panel2.Style = this.styleGuide1;
			this.panel2.TabIndex = 0;
			// 
			// label1
			// 
			this.label1.BackColor = System.Drawing.Color.Transparent;
			this.label1.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label1.Location = new System.Drawing.Point(152, 8);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(96, 24);
			this.label1.TabIndex = 0;
			this.label1.Text = " Spoons";
			this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// optionPanel1
			// 
			this.optionPanel1.BackColor = System.Drawing.Color.Empty;
			this.optionPanel1.Controls.AddRange(new System.Windows.Forms.Control[] {
																					   this.panel3,
																					   this.panelItem1,
																					   this.panelItem2,
																					   this.panelItem3,
																					   this.panelItem4,
																					   this.panelItem5});
			this.optionPanel1.Dock = System.Windows.Forms.DockStyle.Left;
			this.optionPanel1.InitialSpaceForItens = 42;
			this.optionPanel1.Name = "optionPanel1";
			this.optionPanel1.PanelAssBottomAreaColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(230)), ((System.Byte)(210)));
			this.optionPanel1.PanelAssClientAreaColor = System.Drawing.Color.FromArgb(((System.Byte)(232)), ((System.Byte)(237)), ((System.Byte)(223)));
			this.optionPanel1.PanelAssLeftOptionsColor = System.Drawing.Color.FromArgb(((System.Byte)(147)), ((System.Byte)(167)), ((System.Byte)(159)));
			this.optionPanel1.PanelAssLeftTitleColor = System.Drawing.Color.FromArgb(((System.Byte)(232)), ((System.Byte)(237)), ((System.Byte)(223)));
			this.optionPanel1.PanelAssRightTitleColor = System.Drawing.Color.FromArgb(((System.Byte)(147)), ((System.Byte)(167)), ((System.Byte)(159)));
			this.optionPanel1.PanelBottomAreaColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(230)), ((System.Byte)(210)));
			this.optionPanel1.PanelClientAreaColor = System.Drawing.Color.FromArgb(((System.Byte)(232)), ((System.Byte)(237)), ((System.Byte)(223)));
			this.optionPanel1.PanelItens.AddRange(new PallaControls.Windows.Forms.PanelItem[] {
																								  this.panelItem1,
																								  this.panelItem2,
																								  this.panelItem3,
																								  this.panelItem4,
																								  this.panelItem5});
			this.optionPanel1.PanelLeftOptionsColor = System.Drawing.Color.FromArgb(((System.Byte)(147)), ((System.Byte)(167)), ((System.Byte)(159)));
			this.optionPanel1.PanelTopOptionsColor = System.Drawing.Color.FromArgb(((System.Byte)(119)), ((System.Byte)(145)), ((System.Byte)(135)));
			this.optionPanel1.PanelType = PallaControls.Windows.Forms.PanelTypes.AssLeftOptions;
			this.optionPanel1.Size = new System.Drawing.Size(144, 373);
			this.optionPanel1.Style = this.styleGuide1;
			this.optionPanel1.TabIndex = 1;
			// 
			// panel3
			// 
			this.panel3.BackColor = System.Drawing.Color.Empty;
			this.panel3.Controls.AddRange(new System.Windows.Forms.Control[] {
																				 this.label2});
			this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel3.Name = "panel3";
			this.panel3.PanelAssBottomAreaColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(230)), ((System.Byte)(210)));
			this.panel3.PanelAssClientAreaColor = System.Drawing.Color.FromArgb(((System.Byte)(232)), ((System.Byte)(237)), ((System.Byte)(223)));
			this.panel3.PanelAssLeftOptionsColor = System.Drawing.Color.FromArgb(((System.Byte)(147)), ((System.Byte)(167)), ((System.Byte)(159)));
			this.panel3.PanelAssLeftTitleColor = System.Drawing.Color.FromArgb(((System.Byte)(232)), ((System.Byte)(237)), ((System.Byte)(223)));
			this.panel3.PanelAssRightTitleColor = System.Drawing.Color.FromArgb(((System.Byte)(147)), ((System.Byte)(167)), ((System.Byte)(159)));
			this.panel3.PanelBottomAreaColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(230)), ((System.Byte)(210)));
			this.panel3.PanelClientAreaColor = System.Drawing.Color.FromArgb(((System.Byte)(232)), ((System.Byte)(237)), ((System.Byte)(223)));
			this.panel3.PanelLeftOptionsColor = System.Drawing.Color.FromArgb(((System.Byte)(147)), ((System.Byte)(167)), ((System.Byte)(159)));
			this.panel3.PanelTopOptionsColor = System.Drawing.Color.FromArgb(((System.Byte)(119)), ((System.Byte)(145)), ((System.Byte)(135)));
			this.panel3.PanelType = PallaControls.Windows.Forms.PanelTypes.AssLeftTitle;
			this.panel3.Size = new System.Drawing.Size(144, 40);
			this.panel3.Style = this.styleGuide1;
			this.panel3.TabIndex = 1;
			// 
			// label2
			// 
			this.label2.BackColor = System.Drawing.Color.Transparent;
			this.label2.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label2.Location = new System.Drawing.Point(6, 8);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(96, 24);
			this.label2.TabIndex = 1;
			this.label2.Text = " No";
			this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// panelItem1
			// 
			this.panelItem1.BorderColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(217)), ((System.Byte)(207)));
			this.panelItem1.BorderHotColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(217)), ((System.Byte)(207)));
			this.panelItem1.Checked = false;
			this.panelItem1.Cursor = System.Windows.Forms.Cursors.Hand;
			this.panelItem1.GroupIndex = -1;
			this.panelItem1.ImageIndexDisabled = 0;
			this.panelItem1.ImageIndexEnabled = 0;
			this.panelItem1.ItemStyle = PallaControls.Windows.Forms.PanelItemStyle.Option;
			this.panelItem1.Location = new System.Drawing.Point(3, 49);
			this.panelItem1.Name = "panelItem1";
			this.panelItem1.PanelItemBackColor = System.Drawing.Color.FromArgb(((System.Byte)(147)), ((System.Byte)(167)), ((System.Byte)(159)));
			this.panelItem1.PanelItemFlashColor = System.Drawing.Color.FromArgb(((System.Byte)(108)), ((System.Byte)(108)), ((System.Byte)(108)));
			this.panelItem1.PanelItemForeColor = System.Drawing.Color.FromArgb(((System.Byte)(228)), ((System.Byte)(234)), ((System.Byte)(218)));
			this.panelItem1.Size = new System.Drawing.Size(199, 19);
			this.panelItem1.Style = this.styleGuide1;
			this.panelItem1.TabIndex = 2;
			this.panelItem1.Text = "Option 1";
			this.panelItem1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
			this.panelItem1.ButtonPressed += new PallaControls.Windows.Forms.ButtonPressedEventHandler(this.panelItem1_ButtonPressed);
			// 
			// panelItem2
			// 
			this.panelItem2.BorderColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(217)), ((System.Byte)(207)));
			this.panelItem2.BorderHotColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(217)), ((System.Byte)(207)));
			this.panelItem2.Checked = false;
			this.panelItem2.Cursor = System.Windows.Forms.Cursors.Hand;
			this.panelItem2.GroupIndex = -1;
			this.panelItem2.ImageIndexDisabled = 0;
			this.panelItem2.ImageIndexEnabled = 0;
			this.panelItem2.ItemStyle = PallaControls.Windows.Forms.PanelItemStyle.Option;
			this.panelItem2.Location = new System.Drawing.Point(3, 70);
			this.panelItem2.Name = "panelItem2";
			this.panelItem2.PanelItemBackColor = System.Drawing.Color.FromArgb(((System.Byte)(147)), ((System.Byte)(167)), ((System.Byte)(159)));
			this.panelItem2.PanelItemFlashColor = System.Drawing.Color.FromArgb(((System.Byte)(108)), ((System.Byte)(108)), ((System.Byte)(108)));
			this.panelItem2.PanelItemForeColor = System.Drawing.Color.FromArgb(((System.Byte)(228)), ((System.Byte)(234)), ((System.Byte)(218)));
			this.panelItem2.Size = new System.Drawing.Size(199, 19);
			this.panelItem2.Style = this.styleGuide1;
			this.panelItem2.TabIndex = 3;
			this.panelItem2.Text = "Option 2";
			this.panelItem2.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
			this.panelItem2.ButtonPressed += new PallaControls.Windows.Forms.ButtonPressedEventHandler(this.panelItem2_ButtonPressed);
			// 
			// panelItem3
			// 
			this.panelItem3.BorderColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(217)), ((System.Byte)(207)));
			this.panelItem3.BorderHotColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(217)), ((System.Byte)(207)));
			this.panelItem3.Checked = false;
			this.panelItem3.Cursor = System.Windows.Forms.Cursors.Hand;
			this.panelItem3.GroupIndex = -1;
			this.panelItem3.ImageIndexDisabled = 0;
			this.panelItem3.ImageIndexEnabled = 0;
			this.panelItem3.ItemStyle = PallaControls.Windows.Forms.PanelItemStyle.Option;
			this.panelItem3.Location = new System.Drawing.Point(3, 91);
			this.panelItem3.Name = "panelItem3";
			this.panelItem3.PanelItemBackColor = System.Drawing.Color.FromArgb(((System.Byte)(147)), ((System.Byte)(167)), ((System.Byte)(159)));
			this.panelItem3.PanelItemFlashColor = System.Drawing.Color.FromArgb(((System.Byte)(108)), ((System.Byte)(108)), ((System.Byte)(108)));
			this.panelItem3.PanelItemForeColor = System.Drawing.Color.FromArgb(((System.Byte)(228)), ((System.Byte)(234)), ((System.Byte)(218)));
			this.panelItem3.Size = new System.Drawing.Size(199, 19);
			this.panelItem3.Style = this.styleGuide1;
			this.panelItem3.TabIndex = 4;
			this.panelItem3.Text = "Option 3";
			this.panelItem3.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
			this.panelItem3.ButtonPressed += new PallaControls.Windows.Forms.ButtonPressedEventHandler(this.panelItem3_ButtonPressed);
			// 
			// panelItem4
			// 
			this.panelItem4.BorderColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(217)), ((System.Byte)(207)));
			this.panelItem4.BorderHotColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(217)), ((System.Byte)(207)));
			this.panelItem4.Checked = false;
			this.panelItem4.Cursor = System.Windows.Forms.Cursors.Default;
			this.panelItem4.GroupIndex = -1;
			this.panelItem4.ImageIndexDisabled = 0;
			this.panelItem4.ImageIndexEnabled = 0;
			this.panelItem4.ItemStyle = PallaControls.Windows.Forms.PanelItemStyle.Separator;
			this.panelItem4.Location = new System.Drawing.Point(3, 112);
			this.panelItem4.Name = "panelItem4";
			this.panelItem4.PanelItemBackColor = System.Drawing.Color.FromArgb(((System.Byte)(147)), ((System.Byte)(167)), ((System.Byte)(159)));
			this.panelItem4.PanelItemFlashColor = System.Drawing.Color.FromArgb(((System.Byte)(108)), ((System.Byte)(108)), ((System.Byte)(108)));
			this.panelItem4.PanelItemForeColor = System.Drawing.Color.FromArgb(((System.Byte)(228)), ((System.Byte)(234)), ((System.Byte)(218)));
			this.panelItem4.Size = new System.Drawing.Size(134, 19);
			this.panelItem4.Style = this.styleGuide1;
			this.panelItem4.TabIndex = 5;
			this.panelItem4.Text = "panelItem4";
			this.panelItem4.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
			// 
			// panelItem5
			// 
			this.panelItem5.BorderColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(217)), ((System.Byte)(207)));
			this.panelItem5.BorderHotColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(217)), ((System.Byte)(207)));
			this.panelItem5.Checked = false;
			this.panelItem5.Cursor = System.Windows.Forms.Cursors.Hand;
			this.panelItem5.GroupIndex = -1;
			this.panelItem5.ImageIndexDisabled = 0;
			this.panelItem5.ImageIndexEnabled = 0;
			this.panelItem5.ItemStyle = PallaControls.Windows.Forms.PanelItemStyle.Item;
			this.panelItem5.Location = new System.Drawing.Point(3, 133);
			this.panelItem5.Name = "panelItem5";
			this.panelItem5.PanelItemBackColor = System.Drawing.Color.FromArgb(((System.Byte)(147)), ((System.Byte)(167)), ((System.Byte)(159)));
			this.panelItem5.PanelItemFlashColor = System.Drawing.Color.FromArgb(((System.Byte)(108)), ((System.Byte)(108)), ((System.Byte)(108)));
			this.panelItem5.PanelItemForeColor = System.Drawing.Color.FromArgb(((System.Byte)(228)), ((System.Byte)(234)), ((System.Byte)(218)));
			this.panelItem5.Size = new System.Drawing.Size(199, 19);
			this.panelItem5.Style = this.styleGuide1;
			this.panelItem5.TabIndex = 6;
			this.panelItem5.Text = "Item 1";
			this.panelItem5.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
			this.panelItem5.ButtonPressed += new PallaControls.Windows.Forms.ButtonPressedEventHandler(this.panelItem5_ButtonPressed);
			// 
			// frmMenuListBoxSample
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(506, 373);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.optionPanel1,
																		  this.panel1});
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.MaximizeBox = false;
			this.Name = "frmMenuListBoxSample";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Menulistbox";
			this.panel1.ResumeLayout(false);
			this.panel2.ResumeLayout(false);
			this.optionPanel1.ResumeLayout(false);
			this.panel3.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		private void panelItem1_ButtonPressed(object sender, System.EventArgs e)
		{
			menuListBox1.Items.Clear();
			menuListBox1.Items.Add("&Option 1.1", "Description of option 1.1");
			menuListBox1.Items.Add("O&ption 1.2", "Description of option 1.2");
			menuListBox1.Items.Add("Op&tion 1.3", "Description of option 1.3");
		}

		private void panelItem2_ButtonPressed(object sender, System.EventArgs e)
		{
			menuListBox1.Items.Clear();
			menuListBox1.Items.Add("&Option 2.1", "Description of option 2.1");
			menuListBox1.Items.Add("O&ption 2.2", "Description of option 2.2");
			menuListBox1.Items.Add("Op&tion 2.3", "Description of option 2.3");
		}

		private void panelItem3_ButtonPressed(object sender, System.EventArgs e)
		{
			menuListBox1.Items.Clear();
			menuListBox1.Items.Add("&Option 3.1", "Description of option 3.1");
			menuListBox1.Items.Add("O&ption 3.2", "Description of option 3.2");
			menuListBox1.Items.Add("Op&tion 3.3", "Description of option 3.3");
			menuListBox1.Items.Add("Opt&ion 3.4", "Description of option 3.4");
			menuListBox1.Items.Add("Optio&n 3.5", "Description of option 3.5");
		}

		private void panelItem5_ButtonPressed(object sender, System.EventArgs e)
		{
			menuListBox1.Items.Clear();
		}
	}
}
