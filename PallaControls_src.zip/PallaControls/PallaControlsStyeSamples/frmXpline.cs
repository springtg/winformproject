using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace PallaControlsStyeSamples
{
	/// <summary>
	/// Summary description for frmXpline.
	/// </summary>
	public class frmXpline : System.Windows.Forms.Form
	{
		private PallaControls.Windows.Forms.Panel panel2;
		private PallaControls.Windows.Forms.Panel panel3;
		private PallaControls.Windows.Forms.Panel panel1;
		private PallaControls.Windows.Forms.Panel panel4;
		private PallaControls.Windows.Forms.TextBox textBox1;
		private PallaControls.Windows.Forms.Label label1;
		private PallaControls.Windows.Forms.TextBox textBox2;
		private PallaControls.Windows.Forms.Label label2;
		private PallaControls.Windows.Forms.XpLine xpLine1;
		private System.Windows.Forms.Label label3;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public frmXpline(PallaControls.Windows.Forms.StyleGuide style)
		{
			InitializeComponent();

			this.panel1.Style = style;
			this.panel2.Style = style;
			this.panel3.Style = style;
			this.panel4.Style = style;

			this.label1.Style = style;
			this.label2.Style = style;

			this.textBox1.Style = style;
			this.textBox2.Style = style;

		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.panel2 = new PallaControls.Windows.Forms.Panel();
			this.label3 = new System.Windows.Forms.Label();
			this.xpLine1 = new PallaControls.Windows.Forms.XpLine();
			this.textBox2 = new PallaControls.Windows.Forms.TextBox();
			this.label2 = new PallaControls.Windows.Forms.Label();
			this.textBox1 = new PallaControls.Windows.Forms.TextBox();
			this.label1 = new PallaControls.Windows.Forms.Label();
			this.panel4 = new PallaControls.Windows.Forms.Panel();
			this.panel3 = new PallaControls.Windows.Forms.Panel();
			this.panel1 = new PallaControls.Windows.Forms.Panel();
			this.panel2.SuspendLayout();
			this.SuspendLayout();
			// 
			// panel2
			// 
			this.panel2.BackColor = System.Drawing.Color.Empty;
			this.panel2.Controls.AddRange(new System.Windows.Forms.Control[] {
																				 this.label3,
																				 this.xpLine1,
																				 this.textBox2,
																				 this.label2,
																				 this.textBox1,
																				 this.label1,
																				 this.panel4,
																				 this.panel3});
			this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
			this.panel2.Location = new System.Drawing.Point(81, 0);
			this.panel2.Name = "panel2";
			this.panel2.PanelAssBottomAreaColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(217)), ((System.Byte)(207)));
			this.panel2.PanelAssClientAreaColor = System.Drawing.Color.FromArgb(((System.Byte)(242)), ((System.Byte)(242)), ((System.Byte)(228)));
			this.panel2.PanelAssLeftOptionsColor = System.Drawing.Color.FromArgb(((System.Byte)(231)), ((System.Byte)(231)), ((System.Byte)(214)));
			this.panel2.PanelAssLeftTitleColor = System.Drawing.Color.FromArgb(((System.Byte)(242)), ((System.Byte)(242)), ((System.Byte)(228)));
			this.panel2.PanelAssRightTitleColor = System.Drawing.Color.FromArgb(((System.Byte)(231)), ((System.Byte)(231)), ((System.Byte)(214)));
			this.panel2.PanelBottomAreaColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(217)), ((System.Byte)(207)));
			this.panel2.PanelClientAreaColor = System.Drawing.Color.FromArgb(((System.Byte)(242)), ((System.Byte)(242)), ((System.Byte)(228)));
			this.panel2.PanelLeftOptionsColor = System.Drawing.Color.FromArgb(((System.Byte)(231)), ((System.Byte)(231)), ((System.Byte)(214)));
			this.panel2.PanelTopOptionsColor = System.Drawing.Color.FromArgb(((System.Byte)(170)), ((System.Byte)(170)), ((System.Byte)(221)));
			this.panel2.PanelType = PallaControls.Windows.Forms.PanelTypes.ClientArea;
			this.panel2.Size = new System.Drawing.Size(431, 181);
			this.panel2.Style = null;
			this.panel2.TabIndex = 3;
			// 
			// label3
			// 
			this.label3.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label3.Location = new System.Drawing.Point(10, 24);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(56, 23);
			this.label3.TabIndex = 20;
			this.label3.Text = "login";
			// 
			// xpLine1
			// 
			this.xpLine1.EndColor = System.Drawing.Color.FromArgb(((System.Byte)(231)), ((System.Byte)(231)), ((System.Byte)(214)));
			this.xpLine1.LineDirection = PallaControls.Windows.Forms.LineDirection.Vertical;
			this.xpLine1.LineWidth = 1;
			this.xpLine1.Location = new System.Drawing.Point(64, 24);
			this.xpLine1.Name = "xpLine1";
			this.xpLine1.Size = new System.Drawing.Size(8, 128);
			this.xpLine1.StartColor = System.Drawing.Color.FromArgb(((System.Byte)(255)), ((System.Byte)(192)), ((System.Byte)(128)));
			this.xpLine1.TabIndex = 19;
			this.xpLine1.UseGradientInterpolation = true;
			// 
			// textBox2
			// 
			this.textBox2.AcceptsReturn = true;
			this.textBox2.AcceptsTab = false;
			this.textBox2.BorderColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(217)), ((System.Byte)(207)));
			this.textBox2.BorderHotColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(217)), ((System.Byte)(207)));
			this.textBox2.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
			this.textBox2.DecimalPlaces = 2;
			this.textBox2.DecMaxValue = 999999999;
			this.textBox2.DecMinValue = -999999999;
			this.textBox2.EditColor = System.Drawing.Color.FromArgb(((System.Byte)(242)), ((System.Byte)(242)), ((System.Byte)(228)));
			this.textBox2.EditDisabledColor = System.Drawing.Color.FromArgb(((System.Byte)(238)), ((System.Byte)(238)), ((System.Byte)(225)));
			this.textBox2.EditFocusedColor = System.Drawing.Color.White;
			this.textBox2.EditReadOnlyColor = System.Drawing.Color.FromArgb(((System.Byte)(238)), ((System.Byte)(238)), ((System.Byte)(225)));
			this.textBox2.FlashColor = System.Drawing.Color.FromArgb(((System.Byte)(170)), ((System.Byte)(170)), ((System.Byte)(221)));
			this.textBox2.HideSelection = true;
			this.textBox2.Lines = new string[0];
			this.textBox2.Location = new System.Drawing.Point(232, 60);
			this.textBox2.Mask = PallaControls.Windows.Forms.EditMask.Text;
			this.textBox2.MaxLength = 32767;
			this.textBox2.Multiline = false;
			this.textBox2.Name = "textBox2";
			this.textBox2.NegativeNumberColor = System.Drawing.Color.Black;
			this.textBox2.NotAcceptsChars = "";
			this.textBox2.PasswordChar = '*';
			this.textBox2.ReadOnly = false;
			this.textBox2.Required = true;
			this.textBox2.ScrollBars = System.Windows.Forms.ScrollBars.None;
			this.textBox2.ShowErrorProvider = true;
			this.textBox2.Size = new System.Drawing.Size(161, 19);
			this.textBox2.Style = null;
			this.textBox2.TabIndex = 18;
			this.textBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
			this.textBox2.TextColor = System.Drawing.Color.Black;
			this.textBox2.WordWrap = true;
			// 
			// label2
			// 
			this.label2.BorderColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(217)), ((System.Byte)(207)));
			this.label2.BorderHotColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(217)), ((System.Byte)(207)));
			this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label2.LabelColor = System.Drawing.Color.FromArgb(((System.Byte)(231)), ((System.Byte)(231)), ((System.Byte)(214)));
			this.label2.Location = new System.Drawing.Point(80, 60);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(150, 19);
			this.label2.Style = null;
			this.label2.TabIndex = 17;
			this.label2.Text = "Password";
			this.label2.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
			this.label2.TextColor = System.Drawing.Color.Black;
			// 
			// textBox1
			// 
			this.textBox1.AcceptsReturn = true;
			this.textBox1.AcceptsTab = false;
			this.textBox1.BorderColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(217)), ((System.Byte)(207)));
			this.textBox1.BorderHotColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(217)), ((System.Byte)(207)));
			this.textBox1.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
			this.textBox1.DecimalPlaces = 2;
			this.textBox1.DecMaxValue = 999999999;
			this.textBox1.DecMinValue = -999999999;
			this.textBox1.EditColor = System.Drawing.Color.FromArgb(((System.Byte)(242)), ((System.Byte)(242)), ((System.Byte)(228)));
			this.textBox1.EditDisabledColor = System.Drawing.Color.FromArgb(((System.Byte)(238)), ((System.Byte)(238)), ((System.Byte)(225)));
			this.textBox1.EditFocusedColor = System.Drawing.Color.White;
			this.textBox1.EditReadOnlyColor = System.Drawing.Color.FromArgb(((System.Byte)(238)), ((System.Byte)(238)), ((System.Byte)(225)));
			this.textBox1.FlashColor = System.Drawing.Color.FromArgb(((System.Byte)(170)), ((System.Byte)(170)), ((System.Byte)(221)));
			this.textBox1.HideSelection = true;
			this.textBox1.Lines = new string[0];
			this.textBox1.Location = new System.Drawing.Point(232, 40);
			this.textBox1.Mask = PallaControls.Windows.Forms.EditMask.Text;
			this.textBox1.MaxLength = 32767;
			this.textBox1.Multiline = false;
			this.textBox1.Name = "textBox1";
			this.textBox1.NegativeNumberColor = System.Drawing.Color.Black;
			this.textBox1.NotAcceptsChars = "";
			this.textBox1.PasswordChar = '\0';
			this.textBox1.ReadOnly = false;
			this.textBox1.Required = true;
			this.textBox1.ScrollBars = System.Windows.Forms.ScrollBars.None;
			this.textBox1.ShowErrorProvider = true;
			this.textBox1.Size = new System.Drawing.Size(161, 19);
			this.textBox1.Style = null;
			this.textBox1.TabIndex = 16;
			this.textBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
			this.textBox1.TextColor = System.Drawing.Color.Black;
			this.textBox1.WordWrap = true;
			// 
			// label1
			// 
			this.label1.BorderColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(217)), ((System.Byte)(207)));
			this.label1.BorderHotColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(217)), ((System.Byte)(207)));
			this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label1.LabelColor = System.Drawing.Color.FromArgb(((System.Byte)(231)), ((System.Byte)(231)), ((System.Byte)(214)));
			this.label1.Location = new System.Drawing.Point(80, 40);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(150, 19);
			this.label1.Style = null;
			this.label1.TabIndex = 15;
			this.label1.Text = "User id";
			this.label1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
			this.label1.TextColor = System.Drawing.Color.Black;
			// 
			// panel4
			// 
			this.panel4.BackColor = System.Drawing.Color.Empty;
			this.panel4.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel4.Name = "panel4";
			this.panel4.PanelAssBottomAreaColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(217)), ((System.Byte)(207)));
			this.panel4.PanelAssClientAreaColor = System.Drawing.Color.FromArgb(((System.Byte)(242)), ((System.Byte)(242)), ((System.Byte)(228)));
			this.panel4.PanelAssLeftOptionsColor = System.Drawing.Color.FromArgb(((System.Byte)(231)), ((System.Byte)(231)), ((System.Byte)(214)));
			this.panel4.PanelAssLeftTitleColor = System.Drawing.Color.FromArgb(((System.Byte)(242)), ((System.Byte)(242)), ((System.Byte)(228)));
			this.panel4.PanelAssRightTitleColor = System.Drawing.Color.FromArgb(((System.Byte)(231)), ((System.Byte)(231)), ((System.Byte)(214)));
			this.panel4.PanelBottomAreaColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(217)), ((System.Byte)(207)));
			this.panel4.PanelClientAreaColor = System.Drawing.Color.FromArgb(((System.Byte)(242)), ((System.Byte)(242)), ((System.Byte)(228)));
			this.panel4.PanelLeftOptionsColor = System.Drawing.Color.FromArgb(((System.Byte)(231)), ((System.Byte)(231)), ((System.Byte)(214)));
			this.panel4.PanelTopOptionsColor = System.Drawing.Color.FromArgb(((System.Byte)(170)), ((System.Byte)(170)), ((System.Byte)(221)));
			this.panel4.PanelType = PallaControls.Windows.Forms.PanelTypes.TopOptions;
			this.panel4.Size = new System.Drawing.Size(431, 18);
			this.panel4.Style = null;
			this.panel4.TabIndex = 14;
			// 
			// panel3
			// 
			this.panel3.BackColor = System.Drawing.Color.Empty;
			this.panel3.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.panel3.Location = new System.Drawing.Point(0, 156);
			this.panel3.Name = "panel3";
			this.panel3.PanelAssBottomAreaColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(217)), ((System.Byte)(207)));
			this.panel3.PanelAssClientAreaColor = System.Drawing.Color.FromArgb(((System.Byte)(242)), ((System.Byte)(242)), ((System.Byte)(228)));
			this.panel3.PanelAssLeftOptionsColor = System.Drawing.Color.FromArgb(((System.Byte)(231)), ((System.Byte)(231)), ((System.Byte)(214)));
			this.panel3.PanelAssLeftTitleColor = System.Drawing.Color.FromArgb(((System.Byte)(242)), ((System.Byte)(242)), ((System.Byte)(228)));
			this.panel3.PanelAssRightTitleColor = System.Drawing.Color.FromArgb(((System.Byte)(231)), ((System.Byte)(231)), ((System.Byte)(214)));
			this.panel3.PanelBottomAreaColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(217)), ((System.Byte)(207)));
			this.panel3.PanelClientAreaColor = System.Drawing.Color.FromArgb(((System.Byte)(242)), ((System.Byte)(242)), ((System.Byte)(228)));
			this.panel3.PanelLeftOptionsColor = System.Drawing.Color.FromArgb(((System.Byte)(231)), ((System.Byte)(231)), ((System.Byte)(214)));
			this.panel3.PanelTopOptionsColor = System.Drawing.Color.FromArgb(((System.Byte)(170)), ((System.Byte)(170)), ((System.Byte)(221)));
			this.panel3.PanelType = PallaControls.Windows.Forms.PanelTypes.BottomArea;
			this.panel3.Size = new System.Drawing.Size(431, 25);
			this.panel3.Style = null;
			this.panel3.TabIndex = 13;
			// 
			// panel1
			// 
			this.panel1.BackColor = System.Drawing.Color.Empty;
			this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
			this.panel1.Name = "panel1";
			this.panel1.PanelAssBottomAreaColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(217)), ((System.Byte)(207)));
			this.panel1.PanelAssClientAreaColor = System.Drawing.Color.FromArgb(((System.Byte)(242)), ((System.Byte)(242)), ((System.Byte)(228)));
			this.panel1.PanelAssLeftOptionsColor = System.Drawing.Color.FromArgb(((System.Byte)(231)), ((System.Byte)(231)), ((System.Byte)(214)));
			this.panel1.PanelAssLeftTitleColor = System.Drawing.Color.FromArgb(((System.Byte)(242)), ((System.Byte)(242)), ((System.Byte)(228)));
			this.panel1.PanelAssRightTitleColor = System.Drawing.Color.FromArgb(((System.Byte)(231)), ((System.Byte)(231)), ((System.Byte)(214)));
			this.panel1.PanelBottomAreaColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(217)), ((System.Byte)(207)));
			this.panel1.PanelClientAreaColor = System.Drawing.Color.FromArgb(((System.Byte)(242)), ((System.Byte)(242)), ((System.Byte)(228)));
			this.panel1.PanelLeftOptionsColor = System.Drawing.Color.FromArgb(((System.Byte)(231)), ((System.Byte)(231)), ((System.Byte)(214)));
			this.panel1.PanelTopOptionsColor = System.Drawing.Color.FromArgb(((System.Byte)(170)), ((System.Byte)(170)), ((System.Byte)(221)));
			this.panel1.PanelType = PallaControls.Windows.Forms.PanelTypes.LeftOptions;
			this.panel1.Size = new System.Drawing.Size(81, 181);
			this.panel1.Style = null;
			this.panel1.TabIndex = 2;
			// 
			// frmXpline
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(512, 181);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.panel2,
																		  this.panel1});
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.MaximizeBox = false;
			this.Name = "frmXpline";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "frmXpline";
			this.panel2.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion
	}
}
