using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace PallaControlsStyeSamples
{
	/// <summary>
	/// Summary description for InputControls.
	/// </summary>
	public class frmInputControls : System.Windows.Forms.Form
	{
		private PallaControls.Windows.Forms.Panel panel2;
		private PallaControls.Windows.Forms.Panel panel3;
		private PallaControls.Windows.Forms.Panel panel1;
		private PallaControls.Windows.Forms.Label label1;
		private PallaControls.Windows.Forms.Label label2;
		private PallaControls.Windows.Forms.Label label3;
		private PallaControls.Windows.Forms.Label label4;
		private PallaControls.Windows.Forms.SpinEdit spinEdit1;
		private PallaControls.Windows.Forms.ButtonEdit buttonEdit1;
		private PallaControls.Windows.Forms.DatePicker datePicker1;
		private PallaControls.Windows.Forms.TextBox textBox1;
		private PallaControls.Windows.Forms.ListBox listBox1;
		private PallaControls.Windows.Forms.CheckBox checkBox1;
		private PallaControls.Windows.Forms.CheckBox checkBox2;
		private PallaControls.Windows.Forms.RadioButton radioButton1;
		private PallaControls.Windows.Forms.RadioButton radioButton2;
		private System.ComponentModel.IContainer components;

		public frmInputControls(PallaControls.Windows.Forms.StyleGuide style)
		{
			InitializeComponent();

			//With IHasStyleControl; look property "ParentStyle" in the child 
			//controls...
			
			panel1.Style = style;
			panel2.Style = style;

			//Before of IHasStyleControl
			
			/*this.panel1.Style = style;
			this.panel2.Style = style;
			this.panel3.Style = style;

			this.label1.Style = style;
			this.label2.Style = style;
			this.label3.Style = style;
			this.label4.Style = style;

			this.textBox1.Style = style;
			this.spinEdit1.Style = style;
			this.listBox1.Style = style;
			this.buttonEdit1.Style = style;
			this.datePicker1.Style = style;

			this.checkBox1.Style = style;
			this.checkBox2.Style = style;

			this.radioButton1.Style = style;
			this.radioButton2.Style = style;*/
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.panel2 = new PallaControls.Windows.Forms.Panel();
			this.radioButton2 = new PallaControls.Windows.Forms.RadioButton();
			this.radioButton1 = new PallaControls.Windows.Forms.RadioButton();
			this.checkBox2 = new PallaControls.Windows.Forms.CheckBox();
			this.checkBox1 = new PallaControls.Windows.Forms.CheckBox();
			this.listBox1 = new PallaControls.Windows.Forms.ListBox();
			this.textBox1 = new PallaControls.Windows.Forms.TextBox();
			this.datePicker1 = new PallaControls.Windows.Forms.DatePicker();
			this.buttonEdit1 = new PallaControls.Windows.Forms.ButtonEdit();
			this.spinEdit1 = new PallaControls.Windows.Forms.SpinEdit();
			this.label4 = new PallaControls.Windows.Forms.Label();
			this.label3 = new PallaControls.Windows.Forms.Label();
			this.label2 = new PallaControls.Windows.Forms.Label();
			this.label1 = new PallaControls.Windows.Forms.Label();
			this.panel3 = new PallaControls.Windows.Forms.Panel();
			this.panel1 = new PallaControls.Windows.Forms.Panel();
			this.panel2.SuspendLayout();
			this.SuspendLayout();
			// 
			// panel2
			// 
			this.panel2.BackColor = System.Drawing.Color.Empty;
			this.panel2.Controls.AddRange(new System.Windows.Forms.Control[] {
																				 this.radioButton2,
																				 this.radioButton1,
																				 this.checkBox2,
																				 this.checkBox1,
																				 this.listBox1,
																				 this.textBox1,
																				 this.datePicker1,
																				 this.buttonEdit1,
																				 this.spinEdit1,
																				 this.label4,
																				 this.label3,
																				 this.label2,
																				 this.label1,
																				 this.panel3});
			this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
			this.panel2.Location = new System.Drawing.Point(81, 0);
			this.panel2.Name = "panel2";
			this.panel2.PanelAssBottomAreaColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(217)), ((System.Byte)(207)));
			this.panel2.PanelAssClientAreaColor = System.Drawing.Color.FromArgb(((System.Byte)(242)), ((System.Byte)(242)), ((System.Byte)(228)));
			this.panel2.PanelAssLeftOptionsColor = System.Drawing.Color.FromArgb(((System.Byte)(231)), ((System.Byte)(231)), ((System.Byte)(214)));
			this.panel2.PanelAssLeftTitleColor = System.Drawing.Color.FromArgb(((System.Byte)(242)), ((System.Byte)(242)), ((System.Byte)(228)));
			this.panel2.PanelAssRightTitleColor = System.Drawing.Color.FromArgb(((System.Byte)(231)), ((System.Byte)(231)), ((System.Byte)(214)));
			this.panel2.PanelBottomAreaColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(217)), ((System.Byte)(207)));
			this.panel2.PanelClientAreaColor = System.Drawing.Color.FromArgb(((System.Byte)(242)), ((System.Byte)(242)), ((System.Byte)(228)));
			this.panel2.PanelLeftOptionsColor = System.Drawing.Color.FromArgb(((System.Byte)(231)), ((System.Byte)(231)), ((System.Byte)(214)));
			this.panel2.PanelTopOptionsColor = System.Drawing.Color.FromArgb(((System.Byte)(170)), ((System.Byte)(170)), ((System.Byte)(221)));
			this.panel2.PanelType = PallaControls.Windows.Forms.PanelTypes.ClientArea;
			this.panel2.ParentStyle = true;
			this.panel2.Size = new System.Drawing.Size(361, 383);
			this.panel2.Style = null;
			this.panel2.TabIndex = 1;
			// 
			// radioButton2
			// 
			this.radioButton2.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(242)), ((System.Byte)(242)), ((System.Byte)(228)));
			this.radioButton2.BorderColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(217)), ((System.Byte)(207)));
			this.radioButton2.BorderHotColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(217)), ((System.Byte)(207)));
			this.radioButton2.ButtonColor = System.Drawing.Color.FromArgb(((System.Byte)(242)), ((System.Byte)(242)), ((System.Byte)(228)));
			this.radioButton2.CheckColor = System.Drawing.Color.FromArgb(((System.Byte)(170)), ((System.Byte)(170)), ((System.Byte)(221)));
			this.radioButton2.Checked = false;
			this.radioButton2.EditColor = System.Drawing.Color.FromArgb(((System.Byte)(242)), ((System.Byte)(242)), ((System.Byte)(228)));
			this.radioButton2.EditDisabledColor = System.Drawing.Color.FromArgb(((System.Byte)(238)), ((System.Byte)(238)), ((System.Byte)(225)));
			this.radioButton2.EditFocusedColor = System.Drawing.Color.White;
			this.radioButton2.EditReadOnlyColor = System.Drawing.Color.FromArgb(((System.Byte)(238)), ((System.Byte)(238)), ((System.Byte)(225)));
			this.radioButton2.FlashColor = System.Drawing.Color.FromArgb(((System.Byte)(170)), ((System.Byte)(170)), ((System.Byte)(221)));
			this.radioButton2.GroupIndex = -1;
			this.radioButton2.Location = new System.Drawing.Point(8, 156);
			this.radioButton2.Name = "radioButton2";
			this.radioButton2.ParentStyle = true;
			this.radioButton2.ReadOnly = false;
			this.radioButton2.Size = new System.Drawing.Size(144, 19);
			this.radioButton2.Style = null;
			this.radioButton2.TabIndex = 11;
			this.radioButton2.Text = "radio2";
			this.radioButton2.TextColor = System.Drawing.Color.Black;
			// 
			// radioButton1
			// 
			this.radioButton1.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(242)), ((System.Byte)(242)), ((System.Byte)(228)));
			this.radioButton1.BorderColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(217)), ((System.Byte)(207)));
			this.radioButton1.BorderHotColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(217)), ((System.Byte)(207)));
			this.radioButton1.ButtonColor = System.Drawing.Color.FromArgb(((System.Byte)(242)), ((System.Byte)(242)), ((System.Byte)(228)));
			this.radioButton1.CheckColor = System.Drawing.Color.FromArgb(((System.Byte)(170)), ((System.Byte)(170)), ((System.Byte)(221)));
			this.radioButton1.Checked = false;
			this.radioButton1.EditColor = System.Drawing.Color.FromArgb(((System.Byte)(242)), ((System.Byte)(242)), ((System.Byte)(228)));
			this.radioButton1.EditDisabledColor = System.Drawing.Color.FromArgb(((System.Byte)(238)), ((System.Byte)(238)), ((System.Byte)(225)));
			this.radioButton1.EditFocusedColor = System.Drawing.Color.White;
			this.radioButton1.EditReadOnlyColor = System.Drawing.Color.FromArgb(((System.Byte)(238)), ((System.Byte)(238)), ((System.Byte)(225)));
			this.radioButton1.FlashColor = System.Drawing.Color.FromArgb(((System.Byte)(170)), ((System.Byte)(170)), ((System.Byte)(221)));
			this.radioButton1.GroupIndex = -1;
			this.radioButton1.Location = new System.Drawing.Point(8, 140);
			this.radioButton1.Name = "radioButton1";
			this.radioButton1.ParentStyle = true;
			this.radioButton1.ReadOnly = false;
			this.radioButton1.Size = new System.Drawing.Size(144, 19);
			this.radioButton1.Style = null;
			this.radioButton1.TabIndex = 10;
			this.radioButton1.Text = "radio1";
			this.radioButton1.TextColor = System.Drawing.Color.Black;
			// 
			// checkBox2
			// 
			this.checkBox2.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(242)), ((System.Byte)(242)), ((System.Byte)(228)));
			this.checkBox2.BorderColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(217)), ((System.Byte)(207)));
			this.checkBox2.BorderHotColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(217)), ((System.Byte)(207)));
			this.checkBox2.ButtonColor = System.Drawing.Color.FromArgb(((System.Byte)(242)), ((System.Byte)(242)), ((System.Byte)(228)));
			this.checkBox2.CheckColor = System.Drawing.Color.FromArgb(((System.Byte)(170)), ((System.Byte)(170)), ((System.Byte)(221)));
			this.checkBox2.Checked = false;
			this.checkBox2.EditColor = System.Drawing.Color.FromArgb(((System.Byte)(242)), ((System.Byte)(242)), ((System.Byte)(228)));
			this.checkBox2.EditDisabledColor = System.Drawing.Color.FromArgb(((System.Byte)(238)), ((System.Byte)(238)), ((System.Byte)(225)));
			this.checkBox2.EditFocusedColor = System.Drawing.Color.White;
			this.checkBox2.EditReadOnlyColor = System.Drawing.Color.FromArgb(((System.Byte)(238)), ((System.Byte)(238)), ((System.Byte)(225)));
			this.checkBox2.FlashColor = System.Drawing.Color.FromArgb(((System.Byte)(170)), ((System.Byte)(170)), ((System.Byte)(221)));
			this.checkBox2.Location = new System.Drawing.Point(8, 112);
			this.checkBox2.Name = "checkBox2";
			this.checkBox2.ParentStyle = true;
			this.checkBox2.ReadOnly = false;
			this.checkBox2.Size = new System.Drawing.Size(136, 19);
			this.checkBox2.Style = null;
			this.checkBox2.TabIndex = 9;
			this.checkBox2.Text = "check2";
			this.checkBox2.TextColor = System.Drawing.Color.Black;
			// 
			// checkBox1
			// 
			this.checkBox1.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(242)), ((System.Byte)(242)), ((System.Byte)(228)));
			this.checkBox1.BorderColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(217)), ((System.Byte)(207)));
			this.checkBox1.BorderHotColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(217)), ((System.Byte)(207)));
			this.checkBox1.ButtonColor = System.Drawing.Color.FromArgb(((System.Byte)(242)), ((System.Byte)(242)), ((System.Byte)(228)));
			this.checkBox1.CheckColor = System.Drawing.Color.FromArgb(((System.Byte)(170)), ((System.Byte)(170)), ((System.Byte)(221)));
			this.checkBox1.Checked = false;
			this.checkBox1.EditColor = System.Drawing.Color.FromArgb(((System.Byte)(242)), ((System.Byte)(242)), ((System.Byte)(228)));
			this.checkBox1.EditDisabledColor = System.Drawing.Color.FromArgb(((System.Byte)(238)), ((System.Byte)(238)), ((System.Byte)(225)));
			this.checkBox1.EditFocusedColor = System.Drawing.Color.White;
			this.checkBox1.EditReadOnlyColor = System.Drawing.Color.FromArgb(((System.Byte)(238)), ((System.Byte)(238)), ((System.Byte)(225)));
			this.checkBox1.FlashColor = System.Drawing.Color.FromArgb(((System.Byte)(170)), ((System.Byte)(170)), ((System.Byte)(221)));
			this.checkBox1.Location = new System.Drawing.Point(8, 96);
			this.checkBox1.Name = "checkBox1";
			this.checkBox1.ParentStyle = true;
			this.checkBox1.ReadOnly = false;
			this.checkBox1.Size = new System.Drawing.Size(136, 19);
			this.checkBox1.Style = null;
			this.checkBox1.TabIndex = 8;
			this.checkBox1.Text = "check1";
			this.checkBox1.TextColor = System.Drawing.Color.Black;
			// 
			// listBox1
			// 
			this.listBox1.BorderColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(217)), ((System.Byte)(207)));
			this.listBox1.BorderHotColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(217)), ((System.Byte)(207)));
			this.listBox1.ColumnWidth = 0;
			this.listBox1.DockPadding.All = 1;
			this.listBox1.EditColor = System.Drawing.Color.FromArgb(((System.Byte)(242)), ((System.Byte)(242)), ((System.Byte)(228)));
			this.listBox1.EditDisabledColor = System.Drawing.Color.FromArgb(((System.Byte)(238)), ((System.Byte)(238)), ((System.Byte)(225)));
			this.listBox1.EditFocusedColor = System.Drawing.Color.White;
			this.listBox1.EditReadOnlyColor = System.Drawing.Color.FromArgb(((System.Byte)(238)), ((System.Byte)(238)), ((System.Byte)(225)));
			this.listBox1.FlashColor = System.Drawing.Color.FromArgb(((System.Byte)(170)), ((System.Byte)(170)), ((System.Byte)(221)));
			this.listBox1.Items.AddRange(new object[] {
														  "Option 1",
														  "Option 2",
														  "Option 3"});
			this.listBox1.Location = new System.Drawing.Point(159, 88);
			this.listBox1.MultiColumn = false;
			this.listBox1.Name = "listBox1";
			this.listBox1.ParentStyle = true;
			this.listBox1.SelectedIndex = -1;
			this.listBox1.SelectedItem = null;
			this.listBox1.SelectedValue = null;
			this.listBox1.SelectionMode = System.Windows.Forms.SelectionMode.One;
			this.listBox1.Size = new System.Drawing.Size(161, 264);
			this.listBox1.Sorted = false;
			this.listBox1.Style = null;
			this.listBox1.TabIndex = 12;
			this.listBox1.TextColor = System.Drawing.Color.Black;
			this.listBox1.TopIndex = 0;
			this.listBox1.ValueMember = "";
			// 
			// textBox1
			// 
			this.textBox1.AcceptsReturn = true;
			this.textBox1.AcceptsTab = false;
			this.textBox1.BorderColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(217)), ((System.Byte)(207)));
			this.textBox1.BorderHotColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(217)), ((System.Byte)(207)));
			this.textBox1.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
			this.textBox1.DecimalPlaces = 2;
			this.textBox1.DecMaxValue = 999999999;
			this.textBox1.DecMinValue = -999999999;
			this.textBox1.EditColor = System.Drawing.Color.FromArgb(((System.Byte)(242)), ((System.Byte)(242)), ((System.Byte)(228)));
			this.textBox1.EditDisabledColor = System.Drawing.Color.FromArgb(((System.Byte)(238)), ((System.Byte)(238)), ((System.Byte)(225)));
			this.textBox1.EditFocusedColor = System.Drawing.Color.White;
			this.textBox1.EditReadOnlyColor = System.Drawing.Color.FromArgb(((System.Byte)(238)), ((System.Byte)(238)), ((System.Byte)(225)));
			this.textBox1.FlashColor = System.Drawing.Color.FromArgb(((System.Byte)(170)), ((System.Byte)(170)), ((System.Byte)(221)));
			this.textBox1.HideSelection = true;
			this.textBox1.Lines = new string[0];
			this.textBox1.Location = new System.Drawing.Point(159, 8);
			this.textBox1.Mask = PallaControls.Windows.Forms.EditMask.Email;
			this.textBox1.MaxLength = 32767;
			this.textBox1.Multiline = false;
			this.textBox1.Name = "textBox1";
			this.textBox1.NegativeNumberColor = System.Drawing.Color.Black;
			this.textBox1.NotAcceptsChars = "";
			this.textBox1.ParentStyle = true;
			this.textBox1.PasswordChar = '\0';
			this.textBox1.ReadOnly = false;
			this.textBox1.RegularExpression = "";
			this.textBox1.Required = true;
			this.textBox1.ScrollBars = System.Windows.Forms.ScrollBars.None;
			this.textBox1.ShowErrorProvider = true;
			this.textBox1.Size = new System.Drawing.Size(161, 19);
			this.textBox1.Style = null;
			this.textBox1.TabIndex = 1;
			this.textBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
			this.textBox1.TextColor = System.Drawing.Color.Black;
			this.textBox1.WordWrap = true;
			// 
			// datePicker1
			// 
			this.datePicker1.AcceptsPlussKey = true;
			this.datePicker1.BorderColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(217)), ((System.Byte)(207)));
			this.datePicker1.BorderHotColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(217)), ((System.Byte)(207)));
			this.datePicker1.ButtonBorderColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(217)), ((System.Byte)(207)));
			this.datePicker1.ButtonBorderHotColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(217)), ((System.Byte)(207)));
			this.datePicker1.ButtonColor = System.Drawing.Color.FromArgb(((System.Byte)(242)), ((System.Byte)(242)), ((System.Byte)(228)));
			this.datePicker1.ButtonHotColor = System.Drawing.Color.FromArgb(((System.Byte)(231)), ((System.Byte)(231)), ((System.Byte)(214)));
			this.datePicker1.ButtonPressedColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(217)), ((System.Byte)(207)));
			this.datePicker1.CalendarBackColor = System.Drawing.Color.White;
			this.datePicker1.CalendarForeColor = System.Drawing.Color.Black;
			this.datePicker1.CalendarTitleBackColor = System.Drawing.Color.FromArgb(((System.Byte)(170)), ((System.Byte)(170)), ((System.Byte)(221)));
			this.datePicker1.CalendarTitleForeColor = System.Drawing.Color.White;
			this.datePicker1.CalendarTrailingForeColor = System.Drawing.Color.Silver;
			this.datePicker1.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
			this.datePicker1.EditColor = System.Drawing.Color.FromArgb(((System.Byte)(242)), ((System.Byte)(242)), ((System.Byte)(228)));
			this.datePicker1.EditDisabledColor = System.Drawing.Color.FromArgb(((System.Byte)(238)), ((System.Byte)(238)), ((System.Byte)(225)));
			this.datePicker1.EditFocusedColor = System.Drawing.Color.White;
			this.datePicker1.EditReadOnlyColor = System.Drawing.Color.FromArgb(((System.Byte)(238)), ((System.Byte)(238)), ((System.Byte)(225)));
			this.datePicker1.FlashColor = System.Drawing.Color.FromArgb(((System.Byte)(170)), ((System.Byte)(170)), ((System.Byte)(221)));
			this.datePicker1.HideSelection = true;
			this.datePicker1.Location = new System.Drawing.Point(159, 28);
			this.datePicker1.Mask = PallaControls.Windows.Forms.EditMask.Date;
			this.datePicker1.MaxLength = 32767;
			this.datePicker1.Name = "datePicker1";
			this.datePicker1.NegativeNumberColor = System.Drawing.Color.Black;
			this.datePicker1.ParentStyle = true;
			this.datePicker1.PasswordChar = '\0';
			this.datePicker1.ReadOnly = false;
			this.datePicker1.RegularExpression = "";
			this.datePicker1.Required = true;
			this.datePicker1.ShowErrorProvider = true;
			this.datePicker1.Size = new System.Drawing.Size(161, 19);
			this.datePicker1.Style = null;
			this.datePicker1.TabIndex = 3;
			this.datePicker1.Text = "25/06/2003";
			this.datePicker1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
			this.datePicker1.TextColor = System.Drawing.Color.Black;
			this.datePicker1.Value = new System.DateTime(2003, 6, 25, 0, 0, 0, 0);
			// 
			// buttonEdit1
			// 
			this.buttonEdit1.AcceptsPlussKey = true;
			this.buttonEdit1.BorderColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(217)), ((System.Byte)(207)));
			this.buttonEdit1.BorderHotColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(217)), ((System.Byte)(207)));
			this.buttonEdit1.ButtonBorderColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(217)), ((System.Byte)(207)));
			this.buttonEdit1.ButtonBorderHotColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(217)), ((System.Byte)(207)));
			this.buttonEdit1.ButtonColor = System.Drawing.Color.FromArgb(((System.Byte)(242)), ((System.Byte)(242)), ((System.Byte)(228)));
			this.buttonEdit1.ButtonHotColor = System.Drawing.Color.FromArgb(((System.Byte)(231)), ((System.Byte)(231)), ((System.Byte)(214)));
			this.buttonEdit1.ButtonPressedColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(217)), ((System.Byte)(207)));
			this.buttonEdit1.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
			this.buttonEdit1.EditColor = System.Drawing.Color.FromArgb(((System.Byte)(242)), ((System.Byte)(242)), ((System.Byte)(228)));
			this.buttonEdit1.EditDisabledColor = System.Drawing.Color.FromArgb(((System.Byte)(238)), ((System.Byte)(238)), ((System.Byte)(225)));
			this.buttonEdit1.EditFocusedColor = System.Drawing.Color.White;
			this.buttonEdit1.EditReadOnlyColor = System.Drawing.Color.FromArgb(((System.Byte)(238)), ((System.Byte)(238)), ((System.Byte)(225)));
			this.buttonEdit1.FlashColor = System.Drawing.Color.FromArgb(((System.Byte)(170)), ((System.Byte)(170)), ((System.Byte)(221)));
			this.buttonEdit1.HideSelection = true;
			this.buttonEdit1.Location = new System.Drawing.Point(159, 68);
			this.buttonEdit1.Mask = PallaControls.Windows.Forms.EditMask.FileName;
			this.buttonEdit1.MaxLength = 32767;
			this.buttonEdit1.Name = "buttonEdit1";
			this.buttonEdit1.NegativeNumberColor = System.Drawing.Color.Black;
			this.buttonEdit1.ParentStyle = true;
			this.buttonEdit1.PasswordChar = '\0';
			this.buttonEdit1.ReadOnly = false;
			this.buttonEdit1.RegularExpression = "";
			this.buttonEdit1.Required = false;
			this.buttonEdit1.ShowErrorProvider = true;
			this.buttonEdit1.Size = new System.Drawing.Size(161, 19);
			this.buttonEdit1.Style = null;
			this.buttonEdit1.TabIndex = 7;
			this.buttonEdit1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
			this.buttonEdit1.TextColor = System.Drawing.Color.Black;
			// 
			// spinEdit1
			// 
			this.spinEdit1.BorderColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(217)), ((System.Byte)(207)));
			this.spinEdit1.BorderHotColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(217)), ((System.Byte)(207)));
			this.spinEdit1.ButtonBorderColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(217)), ((System.Byte)(207)));
			this.spinEdit1.ButtonBorderHotColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(217)), ((System.Byte)(207)));
			this.spinEdit1.ButtonColor = System.Drawing.Color.FromArgb(((System.Byte)(242)), ((System.Byte)(242)), ((System.Byte)(228)));
			this.spinEdit1.ButtonHotColor = System.Drawing.Color.FromArgb(((System.Byte)(231)), ((System.Byte)(231)), ((System.Byte)(214)));
			this.spinEdit1.ButtonPressedColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(217)), ((System.Byte)(207)));
			this.spinEdit1.ButtonsAlign = PallaControls.Windows.Forms.LeftRight.Right;
			this.spinEdit1.DecMaxValue = 100;
			this.spinEdit1.DecMinValue = 2;
			this.spinEdit1.DecValue = 0;
			this.spinEdit1.EditColor = System.Drawing.Color.FromArgb(((System.Byte)(242)), ((System.Byte)(242)), ((System.Byte)(228)));
			this.spinEdit1.EditDisabledColor = System.Drawing.Color.FromArgb(((System.Byte)(238)), ((System.Byte)(238)), ((System.Byte)(225)));
			this.spinEdit1.EditFocusedColor = System.Drawing.Color.White;
			this.spinEdit1.EditReadOnlyColor = System.Drawing.Color.FromArgb(((System.Byte)(238)), ((System.Byte)(238)), ((System.Byte)(225)));
			this.spinEdit1.FlashColor = System.Drawing.Color.FromArgb(((System.Byte)(170)), ((System.Byte)(170)), ((System.Byte)(221)));
			this.spinEdit1.Location = new System.Drawing.Point(159, 48);
			this.spinEdit1.MaxLength = 32767;
			this.spinEdit1.Name = "spinEdit1";
			this.spinEdit1.NegativeNumberColor = System.Drawing.Color.Black;
			this.spinEdit1.ParentStyle = true;
			this.spinEdit1.ReadOnly = false;
			this.spinEdit1.Required = false;
			this.spinEdit1.ShowErrorProvider = true;
			this.spinEdit1.Size = new System.Drawing.Size(161, 19);
			this.spinEdit1.Style = null;
			this.spinEdit1.TabIndex = 5;
			this.spinEdit1.Text = "0";
			this.spinEdit1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
			this.spinEdit1.TextColor = System.Drawing.Color.Black;
			// 
			// label4
			// 
			this.label4.BorderColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(217)), ((System.Byte)(207)));
			this.label4.BorderHotColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(217)), ((System.Byte)(207)));
			this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label4.LabelColor = System.Drawing.Color.FromArgb(((System.Byte)(231)), ((System.Byte)(231)), ((System.Byte)(214)));
			this.label4.Location = new System.Drawing.Point(8, 68);
			this.label4.Name = "label4";
			this.label4.ParentStyle = true;
			this.label4.Size = new System.Drawing.Size(150, 19);
			this.label4.Style = null;
			this.label4.TabIndex = 6;
			this.label4.Text = "File name";
			this.label4.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
			this.label4.TextColor = System.Drawing.Color.Black;
			// 
			// label3
			// 
			this.label3.BorderColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(217)), ((System.Byte)(207)));
			this.label3.BorderHotColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(217)), ((System.Byte)(207)));
			this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label3.LabelColor = System.Drawing.Color.FromArgb(((System.Byte)(231)), ((System.Byte)(231)), ((System.Byte)(214)));
			this.label3.Location = new System.Drawing.Point(8, 48);
			this.label3.Name = "label3";
			this.label3.ParentStyle = true;
			this.label3.Size = new System.Drawing.Size(150, 19);
			this.label3.Style = null;
			this.label3.TabIndex = 4;
			this.label3.Text = "Number";
			this.label3.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
			this.label3.TextColor = System.Drawing.Color.Black;
			// 
			// label2
			// 
			this.label2.BorderColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(217)), ((System.Byte)(207)));
			this.label2.BorderHotColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(217)), ((System.Byte)(207)));
			this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label2.LabelColor = System.Drawing.Color.FromArgb(((System.Byte)(231)), ((System.Byte)(231)), ((System.Byte)(214)));
			this.label2.Location = new System.Drawing.Point(8, 28);
			this.label2.Name = "label2";
			this.label2.ParentStyle = true;
			this.label2.Size = new System.Drawing.Size(150, 19);
			this.label2.Style = null;
			this.label2.TabIndex = 2;
			this.label2.Text = "Date";
			this.label2.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
			this.label2.TextColor = System.Drawing.Color.Black;
			// 
			// label1
			// 
			this.label1.BorderColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(217)), ((System.Byte)(207)));
			this.label1.BorderHotColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(217)), ((System.Byte)(207)));
			this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label1.LabelColor = System.Drawing.Color.FromArgb(((System.Byte)(231)), ((System.Byte)(231)), ((System.Byte)(214)));
			this.label1.Location = new System.Drawing.Point(8, 8);
			this.label1.Name = "label1";
			this.label1.ParentStyle = true;
			this.label1.Size = new System.Drawing.Size(150, 19);
			this.label1.Style = null;
			this.label1.TabIndex = 0;
			this.label1.Text = "e-mail";
			this.label1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
			this.label1.TextColor = System.Drawing.Color.Black;
			// 
			// panel3
			// 
			this.panel3.BackColor = System.Drawing.Color.Empty;
			this.panel3.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.panel3.Location = new System.Drawing.Point(0, 358);
			this.panel3.Name = "panel3";
			this.panel3.PanelAssBottomAreaColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(217)), ((System.Byte)(207)));
			this.panel3.PanelAssClientAreaColor = System.Drawing.Color.FromArgb(((System.Byte)(242)), ((System.Byte)(242)), ((System.Byte)(228)));
			this.panel3.PanelAssLeftOptionsColor = System.Drawing.Color.FromArgb(((System.Byte)(231)), ((System.Byte)(231)), ((System.Byte)(214)));
			this.panel3.PanelAssLeftTitleColor = System.Drawing.Color.FromArgb(((System.Byte)(242)), ((System.Byte)(242)), ((System.Byte)(228)));
			this.panel3.PanelAssRightTitleColor = System.Drawing.Color.FromArgb(((System.Byte)(231)), ((System.Byte)(231)), ((System.Byte)(214)));
			this.panel3.PanelBottomAreaColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(217)), ((System.Byte)(207)));
			this.panel3.PanelClientAreaColor = System.Drawing.Color.FromArgb(((System.Byte)(242)), ((System.Byte)(242)), ((System.Byte)(228)));
			this.panel3.PanelLeftOptionsColor = System.Drawing.Color.FromArgb(((System.Byte)(231)), ((System.Byte)(231)), ((System.Byte)(214)));
			this.panel3.PanelTopOptionsColor = System.Drawing.Color.FromArgb(((System.Byte)(170)), ((System.Byte)(170)), ((System.Byte)(221)));
			this.panel3.PanelType = PallaControls.Windows.Forms.PanelTypes.BottomArea;
			this.panel3.ParentStyle = true;
			this.panel3.Size = new System.Drawing.Size(361, 25);
			this.panel3.Style = null;
			this.panel3.TabIndex = 13;
			// 
			// panel1
			// 
			this.panel1.BackColor = System.Drawing.Color.Empty;
			this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
			this.panel1.Name = "panel1";
			this.panel1.PanelAssBottomAreaColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(217)), ((System.Byte)(207)));
			this.panel1.PanelAssClientAreaColor = System.Drawing.Color.FromArgb(((System.Byte)(242)), ((System.Byte)(242)), ((System.Byte)(228)));
			this.panel1.PanelAssLeftOptionsColor = System.Drawing.Color.FromArgb(((System.Byte)(231)), ((System.Byte)(231)), ((System.Byte)(214)));
			this.panel1.PanelAssLeftTitleColor = System.Drawing.Color.FromArgb(((System.Byte)(242)), ((System.Byte)(242)), ((System.Byte)(228)));
			this.panel1.PanelAssRightTitleColor = System.Drawing.Color.FromArgb(((System.Byte)(231)), ((System.Byte)(231)), ((System.Byte)(214)));
			this.panel1.PanelBottomAreaColor = System.Drawing.Color.FromArgb(((System.Byte)(222)), ((System.Byte)(217)), ((System.Byte)(207)));
			this.panel1.PanelClientAreaColor = System.Drawing.Color.FromArgb(((System.Byte)(242)), ((System.Byte)(242)), ((System.Byte)(228)));
			this.panel1.PanelLeftOptionsColor = System.Drawing.Color.FromArgb(((System.Byte)(231)), ((System.Byte)(231)), ((System.Byte)(214)));
			this.panel1.PanelTopOptionsColor = System.Drawing.Color.FromArgb(((System.Byte)(170)), ((System.Byte)(170)), ((System.Byte)(221)));
			this.panel1.PanelType = PallaControls.Windows.Forms.PanelTypes.LeftOptions;
			this.panel1.ParentStyle = true;
			this.panel1.Size = new System.Drawing.Size(81, 383);
			this.panel1.Style = null;
			this.panel1.TabIndex = 0;
			// 
			// frmInputControls
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(442, 383);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.panel2,
																		  this.panel1});
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.MaximizeBox = false;
			this.Name = "frmInputControls";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Input controls";
			this.panel2.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion
	}
}
