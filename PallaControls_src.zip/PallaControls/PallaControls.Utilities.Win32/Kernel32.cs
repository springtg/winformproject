using System;
using System.Text;
using System.Runtime.InteropServices;

namespace PallaControls.Utilities.Win32
{
	public class Kernel32
	{
		private Kernel32()
		{
		}

		[DllImport("kernel32.dll", ExactSpelling=true, CharSet=CharSet.Auto)]
		public static extern int GetCurrentThreadId();

		[DllImport( "kernel32.dll", CharSet=CharSet.Auto )]
		public extern static int GetShortPathName(string lpszLongPath, 
			StringBuilder lpszShortPath, int cchBuffer);
	}
}
