#region Using directives

using System;
using System.Drawing;

#endregion

namespace Stepi.UI
{
    /// <summary>
    /// 
    /// </summary>
    class FadeTextAnimation:TextAnimation
    {
        #region Members
       

        /// <summary>
        /// 
        /// </summary>
        private int fadingStep = 1;

        
        /// <summary>
        /// 
        /// </summary>
        public new event AnimationFinished AnimationFinished = null;
        #endregion

        #region Override
        public override void DrawText()
        {
            if (null != text)
            {
                StringFormat stringFormat = new StringFormat(StringFormatFlags.LineLimit | StringFormatFlags.MeasureTrailingSpaces);
                SizeF size = graphics.MeasureString(text, font, area.Size, stringFormat);
                float widthAdjustment = (area.Width - size.Width) / 2;
                float heightAdjustment = (area.Height - size.Height) / 2;

                RectangleF tempArea = new RectangleF(new PointF(area.X + widthAdjustment, area.Y + heightAdjustment), size);

                if (fadingStep >= 255)
                {
                    using (Brush brush = new SolidBrush(textColor))
                    {
                        graphics.DrawString(text, font, brush, tempArea);
                        if (!eventSignaled && AnimationFinished != null)
                        {
                            AnimationFinished(this, new EventArgs());
                        }
                    }
                }
                else
                {

                    using (Brush brush = new SolidBrush(Color.FromArgb(fadingStep, textColor)))
                    {
                        graphics.DrawString(text, font, brush, tempArea);
                    }
                    fadingStep += fadingStep;
                }
            }
        }


        public override void Reset()
        {
            fadingStep = 1;
            eventSignaled = false;
        }
        #endregion
       
    }
}
