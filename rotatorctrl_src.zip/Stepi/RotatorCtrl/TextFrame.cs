#region Using Directives
using System;
using System.Drawing;
using System.ComponentModel;
using System.Drawing.Drawing2D;
#endregion

namespace Stepi.UI
{
    class TextFrame : Frame
    {
        #region Members
        
        /// <summary>
        /// 
        /// </summary>
        private uint alignTextStartPosition = 0;

        /// <summary>
        /// 
        /// </summary>
        private uint alignTextEndPosition = 100;

        /// <summary>
        /// 
        /// </summary>
        private string text = null;

        /// <summary>
        /// 
        /// </summary>
        private Color textColor = Color.Black;

        /// <summary>
        /// 
        /// </summary>
        private TextAnimationMode textAnimationMode = TextAnimationMode.None;

        /// <summary>
        /// 
        /// </summary>
        private ITextAnimation textAnimation = null;
        #endregion

        #region ctor

        public TextFrame()
        {
            InitializeTextAnimation();
        }

        public TextFrame(string text)
        {
            this.text = text;
            //set up animation
            InitializeTextAnimation();
        }

        public TextFrame(string text,Color textColor):this(text)
        {
            this.textColor = textColor;
            this.textAnimation.TextColor = textColor;

            //set up animation
            InitializeTextAnimation();
        }

        public TextFrame(string text, Color textColor, TextAnimationMode animationMode)
        {
            this.text = text;
            this.textColor = textColor;
            this.textAnimationMode = animationMode;
            //set up animation
            InitializeTextAnimation();
        }
        #endregion

        #region Private

        private void InitializeTextAnimation()
        {            
            this.textAnimation = TextAnimationFactory.GetAnimation(this.textAnimationMode);
            this.textAnimation.TextColor = textColor;
            this.textAnimation.Text = text;

            this.textAnimation.AnimationFinished += new AnimationFinished(OnAnimationFinished);
        }

        private void InitializeAnimationArea()
        {
            this.textAnimation.Area = new RectangleF(0 + ClientRectangle.Width * alignTextStartPosition * 0.01f, cornerSquare, ClientRectangle.Width * alignTextStartPosition * 0.01f, ClientRectangle.Height - cornerSquare);
        }
        #endregion

        #region Properties


        public new string Text
        {
            get
            {
                return text;
            }
            set
            {
                text = value;
                if (null != text && text.Length > 0)
                {
                    textAnimation.Text = text;
                    Refresh();
                }
            }
        }

        public Color TextColor
        {
            get
            {
                return textColor;
            }
            set
            {
                if (value != textColor)
                {
                    textColor = value;
                    textAnimation.TextColor = textColor;
                    Refresh();
                }
            }
        }

        public TextAnimationMode TextAnimationMode
        {
            get
            {
                return textAnimationMode;
            }
            set
            {
                if (value != textAnimationMode)
                {
                    textAnimationMode = value;
                    InitializeTextAnimation();
                }
            }
        }

        [DefaultValue(0)]
        public uint AlignTextStartPosition
        {
            get
            {
                return this.alignTextStartPosition;     
            }
            set
            {
                if (value > 100)
                {
                    value = 100;
                }
                if (value > this.alignTextStartPosition)
                {
                    value = this.alignTextEndPosition;
                }
                if (value != this.alignTextStartPosition)
                {
                    this.alignTextStartPosition = value;
                }
                InitializeAnimationArea();
            }
        }

        [DefaultValue(100)]
        public uint AlignTextEndPosition
        {
            get
            {
                return this.alignTextStartPosition;
            }
            set
            {
                if (value > 100)
                {
                    value = 100;
                }
                if (value < this.alignTextStartPosition)
                {
                    value = this.alignTextStartPosition;
                }
                if (value != this.alignTextEndPosition)
                {
                    this.alignTextEndPosition = value;
                }
                InitializeAnimationArea();
            }
        }
        #endregion

        #region Override

        protected override void OnResize(EventArgs eventargs)
        {
            base.OnResize(eventargs);
            InitializeAnimationArea();
        }

        protected override void OnPaint(System.Windows.Forms.PaintEventArgs e)
        {
            base.OnPaint(e);

            this.textAnimation.Graphics = e.Graphics;
            this.textAnimation.DrawText();
        }
        #endregion

        #region Events
        void OnAnimationFinished(object sender, EventArgs e)
        {
            
        }
        #endregion
    }
}
