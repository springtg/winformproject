#region Using directives
using System;

using Stepi.UI;
using System.Drawing;
using System.ComponentModel;
using System.Drawing.Drawing2D;

#endregion

namespace Stepi.UI
{
    public class Frame :CornerCtrl
    {
        #region Members

        /// <summary>
        /// 
        /// </summary>
        protected double constPercentage = 0.05f;
        
        /// <summary>
        /// 
        /// </summary>
        protected BrushType brushType = BrushType.Gradient;


        /// <summary>
        /// 
        /// </summary>
        protected Color colorOne = Color.White;

      
        /// <summary>
        /// 
        /// </summary>
        protected Color colorTwo = Color.FromArgb(155, Color.Orange);

        
        /// <summary>
        /// 
        /// </summary>
        protected Brush brush = null;

        #endregion

        #region ctor
        public Frame()
        {
            //set up the graphic
            InitializeGraphicPath();

            //create the brush used for filling the background
            InitializeBrush();
        }
        #endregion

        #region Properties

        [Browsable(true)]
        [Description("Set/Get the type of the brush used for painting the background")]
        [Category("Behavior")]
        public BrushType BrushType
        {
            get
            {
                return brushType;
            }
            set
            {
                if (value != brushType)
                {
                    brushType = value;
                    InitializeBrush();
                    //have to repaint
                    Refresh();
                }
            }
        }

        [Browsable(true)]
        [Description("Set/Get the starting color if the brush is set to gradient, or the only color used if the brush is set to solid")]
        [Category("Behavior")]
        public Color ColorOne
        {
            get 
            { 
                return colorOne; 
            }
            set 
            {
                if (value != colorOne)
                {
                    colorOne = value;
                    InitializeBrush();
                    //repaint control
                    Refresh();
                }
            }
        }

        [Browsable(true)]
        [Description("Set/Get the ending color if the brush is set to gradient")]
        [Category("Behavior")]
        public Color ColorTwo
        {
            get 
            { 
                return colorTwo; 
            }
            set 
            {
                if (value != colorTwo)
                {
                    colorTwo = value;
                    //see if need for repainting
                    //if (brushType == BrushType.Gradient)
                    {
                        InitializeBrush();
                        Refresh();
                    }
                }
            }
        }

    
        #endregion

        #region Private
        /// <summary>
        /// Set up the brush used in filling this control
        /// </summary>
        private void InitializeBrush()
        {
            if (null != brush)
            {
                brush.Dispose();
            }
            if (brushType == BrushType.Solid)
            {
                brush = new SolidBrush(colorOne);
            }
            else
            {
                int width = this.Width;
                if (width == 0)
                {
                    width = 1;
                }
                int height = this.Height;
                if (height == 0)
                {
                    height = 1;
                }
                brush = new LinearGradientBrush(new Rectangle(0, 0, width, height), colorOne, colorTwo, LinearGradientMode.Horizontal);
            }
        }
        #endregion

        #region Override

        #region GraphicPath
        /// <summary>
        /// Set up the graphic path used for drawing the borders
        /// </summary>
        protected override void InitializeGraphicPath()
        {
            cornerSquare = (int)(Height > Width ? Height * constPercentage : Width * constPercentage);
            base.InitializeGraphicPath();
            if (this.cornerStyle == CornerStyle.Rounded)
            {
                this.Region = new Region(regionPath);
            }
        }
        #endregion

        #region Window events
        /// <summary>
        /// 
        /// </summary>
        /// <param name="eventargs"></param>
        protected override void OnResize(EventArgs eventargs)
        {
            base.OnResize(eventargs);
            InitializeGraphicPath();
            //might need to recreate the brush
            if (this.brushType == BrushType.Gradient)
            {
                InitializeBrush();
            }
        }

        protected override void OnPaint(System.Windows.Forms.PaintEventArgs e)
        {
            base.OnPaint(e);
            //set up some flags
            e.Graphics.CompositingQuality = System.Drawing.Drawing2D.CompositingQuality.HighQuality;
            e.Graphics.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.High;
            e.Graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.HighQuality;
            e.Graphics.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAlias;

            //check to see if the path has been initialized
            if (graphicPath == null)
            {
                InitializeGraphicPath();
            }
            //draw the border
            e.Graphics.DrawPath(new Pen(borderColor), graphicPath);
            //paint the background
            e.Graphics.FillPath(brush, graphicPath);
        }
        #endregion

        #endregion
    }
}
