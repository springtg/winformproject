#region Using directives
using System;
using System.Drawing;
#endregion

namespace Stepi.UI
{
    /// <summary>
    /// Define the delegate for the event of finishing the animation
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    public delegate void AnimationFinished(object sender, EventArgs e);

    interface ITextAnimation
    {
        
        event AnimationFinished AnimationFinished;
        
        /*int TextAnimationDelay
        {
            get;
            set;
        }*/

        /// <summary>
        /// The text to be animated
        /// </summary>
        string Text
        {
            get;
            set;
        }

        /// <summary>
        /// Set the graphic object that will take care of rendering the text
        /// </summary>
        Graphics Graphics
        {
            set;
        }

        /// <summary>
        /// The area available for the text 
        /// </summary>
        RectangleF Area
        {
            set;
        }

        /// <summary>
        /// The color the text is rendered
        /// </summary>
        Color TextColor
        {
            set;
        }

        /// <summary>
        /// The font used to draw the text
        /// </summary>
        Font Font
        {
            set;
        }

        /// <summary>
        /// Reset the animation
        /// </summary>
        void Reset();
        
        /// <summary>
        /// Render the text
        /// </summary>
        void DrawText();
    }
}
