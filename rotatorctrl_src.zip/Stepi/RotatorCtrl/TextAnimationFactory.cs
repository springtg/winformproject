#region Using Directives

using System;

#endregion

namespace Stepi.UI
{
    sealed class TextAnimationFactory
    {
        public static ITextAnimation GetAnimation(TextAnimationMode mode)
        {
            ITextAnimation animation = null;
            switch (mode)
            {
                case TextAnimationMode.None :
                    animation = new NoTextAnimation();
                    break;

                case TextAnimationMode.Fading:
                    animation = new FadeTextAnimation();
                    break;
                    
                case TextAnimationMode.Typing:
                    animation = new TypingTextAnimation();
                    break;
            }
            return animation;
        }
    }
}
