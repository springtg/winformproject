#region Using directives

using System;
using System.Drawing;
using System.Drawing.Design;
using System.ComponentModel;
using System.ComponentModel.Design;

using Stepi.UI;

#endregion

namespace Stepi.UI.Rotator
{
    /// <summary>
    /// UDT for the rotator frame;
    /// </summary>
    public class RotatorCtrl : Frame
    {
        #region Members

        /// <summary>
        /// flag if the title text needs to be centered
        /// </summary>
        private bool calculateTitleArea = true;

        /// <summary>
        /// reference to the text displayed as title
        /// </summary>
        private string titleText = "Title goes here.";

        /// <summary>
        /// the collection of rotatoritemdata objects
        /// </summary>
        private RotatorItemDataCollection items = null;

        /// <summary>
        /// The template for the rotator frames
        /// </summary>
        private RotatorFrameTemplate template = null;

        /// <summary>
        /// the container for the rotator frames
        /// </summary>
        private RotatorFrameContainer frameContainer = null;

        /// <summary>
        /// Text color for the text displayed 
        /// </summary>
        private Color titleTextColor = Color.Black;


        /// <summary>
        /// instance of the text area 
        /// </summary>
        private RectangleF titleArea = RectangleF.Empty;

        /// <summary>
        /// The brush
        /// </summary>
        private Brush titleBrush = new SolidBrush(Color.Black);
        #endregion

        #region ctor

        /// <summary>
        /// implicit constructor
        /// </summary>
        public RotatorCtrl()
        {
            //initialize the objects
            this.items = new RotatorItemDataCollection();
            this.template = new RotatorFrameTemplate();
            this.template.HeaderFont = this.Font;
            this.template.InformationFont = this.Font;
            
            //initialize the components of this control
            InitializeComponents();            
        }

        #endregion

        #region Properties

        [Browsable(true)]
        [Category("Data")]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
        [Description("Get the collection of RotatorItemData")]
        [Editor(typeof(CollectionEditor), typeof(UITypeEditor))]
        public RotatorItemDataCollection Items
        {
            get
            {
                return this.items;
            }
        }

        [Browsable(true)]
        [Category("Behavior")]
        [Description("Get/Set the color of the text displayed as title for this window")]
        public Color TitleTextColor
        {
            get
            {
                return titleTextColor;
            }
            set
            {
                titleTextColor = value;
                titleBrush = new SolidBrush(titleTextColor);
                Refresh();
            }
        }
        
        [Category("Behavior")]
        [DefaultValue("Here goes the title")]
        [Description("Set/Get the text displayed as title for this rotator window")]
        public string TitleText
        {
            get
            {
                return titleText;
            }
            set
            {
                titleText = value;
                calculateTitleArea = true;
                Refresh();
            }
        }

        [Category("Behavior")]
        [DefaultValue(1)]
        [Description("Set/Get the time to wait while the frames are moved")]
        public int FrameAnimationDelay
        {
            get
            {
                return frameContainer.AnimationDelay;
            }
            set
            {
                frameContainer.AnimationDelay = value;
            }
        }

        [Category("Behavior")]
        [DefaultValue(1)]
        [Description("Set/Get the step used for moving the frames")]
        public int FrameAnimationStep
        {
            get
            {
                return frameContainer.AnimationStep;
            }
            set
            {
                frameContainer.AnimationStep = value;
            }
        }

        [Category("Behavior")]
        [DefaultValue(1)]
        [Description("Set/Get the way frme animation is made on either X or Y axis")]
        public RotatorControlAnimationMode FrameAnimationMode
        {
            get
            {
                return frameContainer.AnimationMode;
            }
            set
            {
                frameContainer.AnimationMode = value;
            }
        }

        public override Font Font
        {
            get
            {
                return base.Font;
            }
            set
            {
                base.Font = value;
                calculateTitleArea = true;
            }
        }

        [Browsable(true)]
        [Category("Frame")]
        [DefaultValue(BrushType.Gradient)]
        [Description("Get/Set the brush type for the header part of a rotating frame")]
        public BrushType HeaderBrushType
        {
            get
            {
                return template.HeaderBrushType;
            }
            set
            {
                template.HeaderBrushType = value;
            }
        }

        [Browsable(true)]
        [Category("Frame")]
        [Description("Get/Set the first color for the header part of a rotating frame")]
        public Color HeaderColorOne
        {
            get
            {
                return template.HeaderColorOne;
            }
            set
            {
                template.HeaderColorOne = value;
            }
        }

        [Browsable(true)]
        [Category("Frame")]
        [Description("Get/Set the second color(used when the brush type is set to gradient) for the header part of a rotating frame")]
        public Color HeaderColorTwo
        {
            get
            {
                return template.HeaderColorTwo;
            }
            set
            {
                template.HeaderColorTwo = value;
            }
        }

        [Browsable(true)]
        [Category("Frame")]
        [Description("Get/Set the color of the text displayed in the header part of a rotating frame")]
        public Color HeaderTextColor
        {
            get
            {
                return template.HeaderTextColor;
            }
            set
            {
                template.HeaderTextColor = value;
            }
        }

        [Browsable(true)]
        [Category("Frame")]
        [Description("Get/Set the font of the text displayed in the header part of a rotating frame")]
        public Font HeaderFont
        {
            get
            {
                return template.HeaderFont;
            }
            set
            {
                template.HeaderFont = value;
            }
        }

        [Browsable(true)]
        [Category("Frame")]
        [DefaultValue(40)]
        [Description("Get/Set the size for the header part of a rotating frame")]
        public uint HeaderSize
        {
            get
            {
                return template.HeaderSize;
            }
            set
            {
                template.HeaderSize = value;
            }
        }

        [Browsable(true)]
        [Category("Frame")]
        [DefaultValue(BrushType.Gradient)]
        [Description("Get/Set the brush type used for the background of the information part of a rotating frame")]
        public BrushType InformationBrushType
        {
            get
            {
                return template.InformationBrushType;
            }
            set
            {
                template.InformationBrushType = value;
            }
        }

        [Browsable(true)]
        [Category("Frame")]
        [Description("Get/Set the first color for the brush used for the information part of a rotating frame")]
        public Color InformationColorOne
        {
            get
            {
                return template.InformationColorOne;
            }
            set
            {
                template.InformationColorOne = value;
            }
        }

        [Browsable(true)]
        [Category("Frame")]
        [Description("Get/Set the second color for the brush used for the information part of a rotating frame.It is only used if the brush type is set to gradient.")]
        public Color InformationColorTwo
        {
            get
            {
                return template.InformationColorTwo;
            }
            set
            {
                template.InformationColorTwo = value;
            }
        }

        [Browsable(true)]
        [Category("Frame")]
        [Description("Get/Set the color for the brush used for the information part of a rotating frame")]
        public Color InformationTextColor
        {
            get
            {
                return template.InformationTextColor;
            }
            set
            {
                template.InformationTextColor = value;
            }
        }

        [Browsable(true)]
        [Category("Frame")]
        [Description("Get/Set the font used for the text in information part of a rotating frame")]
        public Font InformationFont
        {
            get
            {
                return template.InformationFont;
            }
            set
            {
                template.InformationFont = value;
            }
        }

        [Browsable(true)]
        [Category("Frame")]
        [Description("Get/Set the delay in milliseconds for animating the text")]
        public int TextAnimationDelay
        {
            get
            {
                return template.TextAnimationDelay;
            }
            set
            {
                template.TextAnimationDelay = value;
            }
        }

        #endregion

        #region Private

        /// <summary>
        /// Creates the frame container and adds it to this control
        /// </summary>
        private void InitializeComponents()
        {
            this.frameContainer = new RotatorFrameContainer(items, template);
            this.SuspendLayout();
            
            this.frameContainer.TabIndex = 0;
            this.frameContainer.Name = "frameContainer";
            this.Location = new Point(0, 0);
            this.Controls.Add(this.frameContainer);

            this.ResumeLayout(false);
        }

        #endregion

        #region Override 

        /// <summary>
        /// Override the handler for the resize event;the frame container needs to be repositioned, title area needs to be reset
        /// </summary>
        /// <param name="eventargs"></param>
        protected override void OnResize(EventArgs eventargs)
        {
            int quarterHeight = (this.Height) / 4;
            this.frameContainer.Location = new Point(cornerSquare, quarterHeight);
            this.frameContainer.Size = new Size(this.Width - 2 * cornerSquare, Height - quarterHeight - (Height - 4 * quarterHeight)-cornerSquare);
            this.titleArea = new RectangleF(cornerSquare, 0, Width - 2 * cornerSquare, quarterHeight);
            this.calculateTitleArea = true;
            
            base.OnResize(eventargs);
            //repaint control to reflect changes
            Refresh();
        }

        /// <summary>
        /// Handler to the paint event
        /// </summary>
        /// <param name="e"></param>
        protected override void OnPaint(System.Windows.Forms.PaintEventArgs e)
        {
            base.OnPaint(e);

            if (calculateTitleArea)
            {
                StringFormat stringFormat = new StringFormat(StringFormatFlags.LineLimit | StringFormatFlags.MeasureTrailingSpaces);
                SizeF size = e.Graphics.MeasureString(titleText, Font, titleArea.Size, stringFormat);
                float widthAdjustment = (titleArea.Width - size.Width) / 2;
                float heightAdjustment = (titleArea.Height - size.Height) / 2;

                titleArea = new RectangleF(new PointF(titleArea.X, titleArea.Y + heightAdjustment), size);
                calculateTitleArea = false;
            }
            e.Graphics.DrawString(titleText, this.Font, titleBrush, titleArea);
            
        }

        protected override void Dispose(bool disposing)
        {
            if (null != items)
            {
                items.Clear();
            }
            if (null != titleBrush)
            {
                titleBrush.Dispose();
                titleBrush = null;
            }
            frameContainer.Dispose();
            base.Dispose(disposing);
        }
        #endregion
    }
}
