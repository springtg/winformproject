#region Using Directives

using System;
using System.Drawing;
using System.Globalization;
using System.ComponentModel;
using System.ComponentModel.Design.Serialization;
using System.Reflection;


#endregion
namespace Stepi.UI.Rotator
{
    /// <summary>
    /// Defines the object holding the data for a frame : header text, information being displayed and the image for the header
    /// </summary>
    [DesignTimeVisible(true)]
    [TypeConverter("Stepi.UI.Rotator.RotatorItemDataConverter")]
    public class RotatorItemData
    {
        #region Members

        /// <summary>
        /// Instance of the text displayed in the header
        /// </summary>
        private string headerText;

        /// <summary>
        /// Reference to the text being displayed as information for a roatatorframe 
        /// </summary>
        private string infoText;

        /// <summary>
        /// Reference to the image being displayed on the header
        /// </summary>
        private Image image = null;

        #endregion

        #region ctor

        public RotatorItemData()
        { }

        /// <summary>
        /// Explicit constructor
        /// </summary>
        /// <param name="headerText">holds the text to be set as header text</param>
        /// <param name="informationText">the text to be set as information text</param>
        /// <param name="image">the image to be displayed in the header</param>
        public RotatorItemData(string headerText, string informationText, Image image)
        {
            this.headerText = headerText;
            this.InformationText = informationText;
            this.image = image;
        }
        #endregion

        #region Properties

        [DesignerSerializationVisibility( DesignerSerializationVisibility.Visible )]
		[Browsable(true)]
        [Description("The text to be displayed in the rotator frame as header text")]
        public string HeaderText
        {
            get { return headerText; }
            set { headerText = value; }
        }

        [DesignerSerializationVisibility(DesignerSerializationVisibility.Visible)]
        [Browsable(true)]
        [Description("The text to be displayed in the rotator frame as main text")]
        public string InformationText
        {
            get { return infoText; }
            set { infoText = value; }
        }

        [DesignerSerializationVisibility(DesignerSerializationVisibility.Visible)]
        [Browsable(true)]
        [Description("The image to be displayed in the rotator frame in the header")]
        public Image Image
        {
            get { return image; }
            set { image = value; }
        }
        #endregion
    }

    /// <summary>
    /// Defines conversion from string to RotatorItemData and vice versa
    /// </summary>
    public class RotatorItemDataConverter : TypeConverter
    {
        /// <summary>
        /// Conversion from Item to string
        /// </summary>
        /// <param name="context"></param>
        /// <param name="destinationType"></param>
        /// <returns></returns>
        public override bool CanConvertTo(ITypeDescriptorContext context, Type destinationType)
        {
            if (destinationType == typeof(InstanceDescriptor))
            {
                return true;
            }
            return base.CanConvertTo(context, destinationType);
        }

        /// <summary>
        /// Conversion to string
        /// </summary>
        /// <param name="context"></param>
        /// <param name="culture"></param>
        /// <param name="value"></param>
        /// <param name="destinationType"></param>
        /// <returns></returns>
        public override object  ConvertTo(ITypeDescriptorContext context, CultureInfo culture, object value, Type destinationType)
        {
            if (destinationType == typeof(InstanceDescriptor) && (value is RotatorItemData))
            {
                RotatorItemData item = (RotatorItemData)value;

                return item;
            }
 	        return base.ConvertTo(context, culture, value, destinationType);
        }
    }

}
