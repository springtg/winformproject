#region Using Directives

using System;
using System.Drawing;
using System.Drawing.Drawing2D;
#endregion

namespace Stepi.UI.Rotator
{
    #region delegates
    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="args"></param>
    internal delegate void HeaderSizeEvent(object sender, EventArgs args);

    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="args"></param>
    internal delegate void InformationTextColorEvent(object sender,EventArgs args);
    
    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="args"></param>
    internal delegate void TextAnimationDelayEvent(object sender,EventArgs args);

    #endregion
    internal class RotatorFrameTemplate
    {

        #region Members

            #region Events
        /// <summary>
        /// The event raised whenever the size of the rotator frame header has changed
        /// </summary>
        internal event HeaderSizeEvent HeaderSizeChanged = null;

        /// <summary>
        /// Event raised whenever the text color for the main text in the rotator frame has changed
        /// </summary>
        internal event InformationTextColorEvent InformationTextColorChanged = null;

        /// <summary>
        /// Event raised when the text animation delay has been changed
        /// </summary>
        internal event TextAnimationDelayEvent TextAnimationDelayChanged = null;
            #endregion

        /// <summary>
        /// In milliseconds time between the text animation
        /// </summary>
        private int textAnimationDelay = 100;

        /// <summary>
        /// Size in pixels for the roatator frame header
        /// </summary>
        private uint headerSize = 40;

        /// <summary>
        /// used in creating the gradient brush
        /// </summary>
        private int width = 1;

        /// <summary>
        /// used in creating the gradient brush
        /// </summary>
        private int height = 1;

        /// <summary>
        /// Brush type used to fill the background of the rotator frame header background
        /// </summary>
        private BrushType headerBrushType = BrushType.Gradient;

        /// <summary>
        /// Brush type used to fill the background of the rotator frame main text area background
        /// </summary>
        private BrushType infoBrushType = BrushType.Gradient;

        /// <summary>
        /// Font used for the header text
        /// </summary>
        private Font headerFont = null;

        /// <summary>
        /// Font used for the main text in the rotator frame
        /// </summary>
        private Font infoFont = null;

        /// <summary>
        /// First color for the rotator header background. If brush is set to gradient this will be the starting color
        /// </summary>
        private Color headerColorOne = Color.White;

        /// <summary>
        /// First color for the rotator frame main text area background. If brush is set to gradient this will be the starting color
        /// </summary>
        private Color infoColorOne = Color.White;

        /// <summary>
        ///  If brush is set to gradient this will be the ending color for filling the rotator frame header background
        /// </summary>
        private Color headerColorTwo = Color.FromArgb(155, Color.Blue);


        /// <summary>
        ///  If brush is set to gradient this will be the ending color for filling the rotator frame main text area background
        /// </summary>
        private Color infoColorTwo = Color.FromArgb(155, Color.Gray);

        /// <summary>
        /// Color used for the header text 
        /// </summary>
        private Color headerTextColor = Color.Black;

        /// <summary>
        /// Color used for the main text 
        /// </summary>
        private Color infoTextColor = Color.Black;

        /// <summary>
        /// The brush used for the header background
        /// </summary>
        private Brush headerBrush = null;

        /// <summary>
        /// The brush used for the main text area background
        /// </summary>
        private Brush infoBrush = null;

        #endregion

        #region ctor

        /// <summary>
        /// implicit constructor
        /// </summary>
        internal RotatorFrameTemplate()
        {
            //create the brush used for filling the backgrounds
            InitializeBrush();
        }

        #endregion

        #region Private
        /// <summary>
        /// Initializes the brushes based on the current settings
        /// </summary>
        private void InitializeBrush()
        {
            //create the brush for the header
            if (null != headerBrush)
            {
                headerBrush.Dispose();
            }
            if (headerBrushType == BrushType.Solid)
            {
                headerBrush = new SolidBrush(headerColorOne);
            }
            else
            {
                headerBrush = new LinearGradientBrush(new Rectangle(0, 0, this.width, this.height), headerColorOne, headerColorTwo, LinearGradientMode.Horizontal);
            }

            //create the brush for the main text area
            if (null != infoBrush)
            {
                infoBrush.Dispose();
            }
            if (infoBrushType == BrushType.Solid)
            {
                infoBrush = new SolidBrush(infoColorOne);
            }
            else
            {
                infoBrush = new LinearGradientBrush(new Rectangle(0, 0, this.width, this.height), infoColorOne, infoColorTwo, LinearGradientMode.Horizontal);
            }
        }
        #endregion

        #region Properties

        /// <summary>
        /// Holds the time to delay the text animation in the main text area of a rotator frame 
        /// </summary>
        internal int TextAnimationDelay
        {
            get 
            { 
                return textAnimationDelay; 
            }
            set 
            {
                if (value != textAnimationDelay)
                {
                    textAnimationDelay = value;
                    if (null != TextAnimationDelayChanged)
                    {
                        TextAnimationDelayChanged(this, new EventArgs());
                    }
                }
            }
        }

        /// <summary>
        /// Get the brush used for the header part of a rotator frame
        /// </summary>
        internal Brush HeaderBrush
        {
            get
            {
                return headerBrush;
            }
        }

        /// <summary>
        /// Get the brush used for the main text area of a rotator frame
        /// </summary>
        internal Brush InformationBrush
        {
            get
            {
                return infoBrush;
            }
        }

        /// <summary>
        /// Get/Set the font for the header text
        /// </summary>
        internal Font HeaderFont
        {
            get 
            { 
                return headerFont; 
            }
            set 
            { 
                headerFont = value; 
            }
        }

        /// <summary>
        /// Get/Set the font for the main text
        /// </summary>
        internal Font InformationFont
        {
            get
            {
                return infoFont;
            }
            set
            {
                infoFont = value;
            }
        }

        /// <summary>
        /// Get/Set the text color for the header text
        /// </summary>
        internal Color HeaderTextColor
        {
            get 
            { 
                return headerTextColor; 
            }
            set 
            {
                if (value != headerTextColor)
                {
                    headerTextColor = value;
                }
            }
        }

        /// <summary>
        /// Get/Set the brush type for the header background
        /// </summary>
        internal BrushType HeaderBrushType
        {
            get 
            { 
                return headerBrushType; 
            }
            set 
            {
                if (value != headerBrushType)
                {
                    headerBrushType = value;
                    InitializeBrush();
                }
            }
        }

        /// <summary>
        /// Get/Set the brush type for the main text part background
        /// </summary>
        internal BrushType InformationBrushType
        {
            get 
            { 
                return infoBrushType; 
            }
            set 
            {
                if (value != infoBrushType)
                {
                    infoBrushType = value;
                    InitializeBrush();
                }
            }
        }

        /// <summary>
        /// Get/Set the color/starting color for the background of the header area 
        /// </summary>
        internal Color HeaderColorOne
        {
            get 
            { 
                return headerColorOne; 
            }
            set 
            {
                if (value != HeaderColorOne)
                {
                    headerColorOne = value;
                    InitializeBrush();
                }
            }
        }

        /// <summary>
        /// Get/Set the color/starting color for the background of the main text area
        /// </summary>
        internal Color InformationColorOne
        {
            get 
            { 
                return infoColorOne; 
            }
            set 
            {
                if (value != infoColorOne)
                {
                    infoColorOne = value;
                    InitializeBrush();
                }
            }
        }

        /// <summary>
        /// Get/Set the ending color for the background of the header area 
        /// </summary>
        internal Color HeaderColorTwo
        {
            get 
            { 
                return headerColorTwo; 
            }
            set 
            {
                if (value != headerColorTwo)
                {
                    headerColorTwo = value;
                    if (headerBrushType == BrushType.Gradient)
                    {
                        InitializeBrush();
                    }
                }
            }
        }

        /// <summary>
        /// Get/Set the ending color for the background of the main text area
        /// </summary>
        internal Color InformationColorTwo
        {
            get 
            {
                return infoColorTwo; 
            }
            set 
            {
                if (value != infoColorTwo)
                {
                    infoColorTwo = value; 
                    if (infoBrushType == BrushType.Gradient)
                    {
                        InitializeBrush();
                    }
                }
            }
        }

        /// <summary>
        /// Get/Set the text color for the main text displayed in a rotator frame
        /// </summary>
        internal Color InformationTextColor
        {
            get 
            { 
                return infoTextColor; 
            }
            set 
            {
                if (null != value)
                {
                    infoTextColor = value;
                    if (null != InformationTextColorChanged)
                    {
                        InformationTextColorChanged(this, new EventArgs());
                    }
                }
            }
        }

        /// <summary>
        /// Get/Set the size in pixels for the rotator frame header 
        /// </summary>
        internal uint HeaderSize
        {
            get 
            { 
                return headerSize; 
            }
            set 
            {
                if (value != headerSize)
                {
                    headerSize = value;
                    if (null != HeaderSizeChanged)
                    {
                        HeaderSizeChanged(this, new EventArgs());
                    }
                }
            }
        }
        #endregion

        #region Public
        /// <summary>
        /// Recreates the brushes.Called whenever a rotator frame size is changed and the brush type is set to be gradient
        /// </summary>
        /// <param name="width">width of the rotator frame control</param>
        /// <param name="height">rotator frame control height</param>
        public void RefreshBrushes(int width,int height)
        {
            //check for valid data; this values must not be zero otherwise the code creating the gradient 
            //brush fails with InvalidParameter exception
            this.width = width;
            if (this.width == 0)
            {
                this.width = 1;
            }

            this.height = height;
            if (this.height == 0)
            {
                this.height = 1;
            }
            InitializeBrush();
        }
        #endregion


    }
}
