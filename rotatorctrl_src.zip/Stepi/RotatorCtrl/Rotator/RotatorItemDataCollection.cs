#region Using Directives

using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;

#endregion

namespace Stepi.UI.Rotator
{
    /// <summary>
    /// Defines to delegate used to notify the collection has changed adding,removing or updating item.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="args"></param>
    internal delegate void RotatorItemCollectionChanged(object sender,CollectionChangeArgs args);

    /// <summary>
    /// Collection change enumeration
    /// </summary>
    internal enum ChangeType { Empty = 0, ItemAdded = 1, ItemRemoved = 2, ItemsRemoved = 3, ItemUpdate =4 };


    /// <summary>
    /// Defines the object that holds the information regarding a collection change
    /// </summary>
    internal class CollectionChangeArgs : EventArgs
    {       
        #region ctor
       
        private int index = -1;
        private int count = 0;

        private ChangeType changeType = ChangeType.Empty;
        #endregion

        #region ctor
        internal CollectionChangeArgs(int index, int count,ChangeType changeType)
        {
            this.index = index;
            this.count = count;
            this.changeType = changeType;
        }
        #endregion

        #region Properties
        /// <summary>
        /// 
        /// </summary>
        internal int Index
        {
            get
            {
                return index;
            }
            set
            {
                index = value;
            }
        }
        /// <summary>
        /// 
        /// </summary>
        internal int Count
        {
            get
            {
                return count;
            }
            set
            {
                count = value;
            }
        }
        /// <summary>
        /// 
        /// </summary>
        internal ChangeType ChangeType
        {
            get
            {
                return changeType;
            }
            set
            {
                changeType = value;
            }
        }
        #endregion
    }

    /// <summary>
    /// Defines the collection of RotatorItemDatas
    /// </summary>
    public class RotatorItemDataCollection :  List<RotatorItemData>
    {
        #region Members

        /// <summary>
        /// dummy object used for synchronizing the
        /// </summary>
        private object syncRoot = new object();

        /// <summary>
        /// the delegate to be called whenever the collection has changed
        /// </summary>
        internal event RotatorItemCollectionChanged CollectionChanged = null;

        #endregion

        #region New SyncImplementation

        public new int Count
        {
            get
            {
                lock (this.syncRoot)
                {
                    return base.Count;
                }
            }
        }

        public new void Add(RotatorItemData data)
        {
            lock (this.syncRoot)
            {
                base.Add(data);
                if (null != CollectionChanged)
                {
                    CollectionChanged(this, new CollectionChangeArgs(base.Count - 1, base.Count, ChangeType.ItemAdded));
                }
            }
        }

        public new RotatorItemData this[int index]
        {
            get
            {
                lock (syncRoot)
                {
                    return base[index];
                }
            }
            set
            {
                lock (syncRoot)
                {
                    base[index] = value;
                }
                if (null != CollectionChanged)
                {
                    CollectionChanged(this, new CollectionChangeArgs(base.Count - 1, base.Count, ChangeType.ItemUpdate));
                }
            }
        }

        public new void AddRange(IEnumerable<RotatorItemData> collection)
        {
            lock (this.syncRoot)
            {
                int prevCount = base.Count;
                base.AddRange(collection);
                if (null != CollectionChanged)
                {
                    CollectionChanged(this, new CollectionChangeArgs(base.Count-1, base.Count, ChangeType.ItemAdded));
                }
            }
        }

        public new ReadOnlyCollection<RotatorItemData> AsReadOnly()
        {
            ReadOnlyCollection<RotatorItemData> collection = null;
            lock (this.syncRoot)
            {
                collection = base.AsReadOnly();
            }
            return collection;
        }

        public new void Clear()
        {
            lock (this.syncRoot)
            {
                base.Clear();
                if (null != CollectionChanged)
                {
                    CollectionChanged(this, new CollectionChangeArgs(- 1, 0, ChangeType.ItemsRemoved));
                }
            }
        }

        public new bool Contains(RotatorItemData item)
        {
            lock (this.syncRoot)
            {
                return base.Contains(item);
            }
        }

        public new bool Exists(Predicate<RotatorItemData> match)
        {
            lock (this.syncRoot)
            {
                return base.Exists(match);
            }
        }


        public new RotatorItemData Find(Predicate<RotatorItemData> match)
        {
            lock (this.syncRoot)
            {
                return base.Find(match);
            }
        }


        public new void Insert(int index,RotatorItemData data)
        {
            lock (this.syncRoot)
            {
                base.Insert(index, data);
                if (null != CollectionChanged)
                {
                    CollectionChanged(this, new CollectionChangeArgs(index, base.Count, ChangeType.ItemAdded));
                }
            }
        }

        private new  void Remove(RotatorItemData data)
        {
            lock (this.syncRoot)
            {
               // int index = base.FindIndex(0,new Predicate<RotatorItemData>(data));
                base.Remove(data);
                
            }
        }

        private new int RemoveAll(Predicate<RotatorItemData> match)
        {
            int removed = 0;
            lock (this.syncRoot)
            {
                removed = base.RemoveAll(match);
                /*if (null != CollectionChanged)
                {
                    CollectionChanged(this, new CollectionChangeArgs(-1, base.Count, ChangeType.ItemAdded));
                }*/
            }
            return removed;
        }

        public new void RemoveAt(int index)
        {
            lock (this.syncRoot)
            {
                base.RemoveAt(index);
                if (null != CollectionChanged)
                {
                    CollectionChanged(this, new CollectionChangeArgs(index, base.Count, ChangeType.ItemRemoved));
                }
            }
        }
        #endregion

    }
}
