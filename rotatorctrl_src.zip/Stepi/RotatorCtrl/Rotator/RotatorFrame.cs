#region Using directives

using System;
using System.Drawing;
using System.Threading;
using System.ComponentModel;
using System.Drawing.Drawing2D;

using Stepi.UI;

#endregion

namespace Stepi.UI.Rotator
{
    /// <summary>
    /// Defines the delegate for the event of finishing animating the header text
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="args"></param>
    internal delegate void RotatorFrameTextAnimationFinished(object sender, EventArgs args);

    /// <summary>
    /// Definition of the event raised whenever a repaint of this control is needed(used for the animation part)
    /// </summary>
    internal delegate void NotifyRepaintEvent();

    /// <summary>
    /// UDT for a frame window to display the data
    /// </summary>
    internal class RotatorFrame : CornerCtrl
    {
        #region Members

        /// <summary>
        /// Used to syncronize the access to the control
        /// </summary>
        //private object sync = new object();

        /// <summary>
        /// flag telling whether the image needs resizing or the text size needs to be recalculated; flagged on the resize event and whenever the Data property is modified
        /// </summary>
        private bool bufferAdjusment = true;

        /// <summary>
        /// Once disposed method is called this is set to true
        /// </summary>
        ///private bool disposed = false;
        
        /// <summary>
        /// Enables text animation
        /// </summary>
        private bool enableTextAnimation = false;

        /// <summary>
        /// the string format object used for measuring the size of the main text.
        /// </summary>
        private StringFormat stringFormat = new StringFormat(StringFormatFlags.LineLimit | StringFormatFlags.MeasureTrailingSpaces);

        /// <summary>
        /// The size of the main text 
        /// </summary>
        private SizeF bufferedTextSize = SizeF.Empty;

        /// <summary>
        /// Cached rectangle where to draw the header text
        /// </summary>
        private RectangleF outputHeaderText = RectangleF.Empty;

        /// <summary>
        /// instance of the header graphic path
        /// </summary>
        private GraphicsPath headerPath = null;

        /// <summary>
        /// instance of the main text area graphic path
        /// </summary>
        private GraphicsPath infoPath = null;

        /// <summary>
        /// instance of the image to be displayed in the header
        /// </summary>
        private Image localImage = null;

        /// <summary>
        /// instance of the object handling the text animation
        /// </summary>
        private ITextAnimation textAnimation = null;

        /// <summary>
        /// reference to the template holding all the values for rendering this control : text color, background color,font an so on
        /// </summary>
        private RotatorFrameTemplate frameTemplate = null;

        /// <summary>
        /// reference to the data this object is linked to
        /// </summary>
        private RotatorItemData data = null;

        /// <summary>
        /// A notifier object that will raise the reapaint event
        /// </summary>
        private EventNotifier repaintNotifier = null;

        /// <summary>
        /// Callback for forcing the repaint (thread safe , the notifier spawns a thread so access to the frame object should be thread safe)
        /// </summary>
        private NotifyRepaintEvent RepaintNotifyHandler = null;

        /// <summary>
        /// The event raised whenever the text animation has finished
        /// </summary>
        internal event RotatorFrameTextAnimationFinished AnimationFinished;

        #endregion
        
        #region ctor

        /// <summary>
        /// Explicit ctor
        /// </summary>
        /// <param name="template">reference to the frame template</param>
        public RotatorFrame(RotatorFrameTemplate template)
        {
            this.frameTemplate = template;
            //set the header size change event handler
            this.frameTemplate.HeaderSizeChanged += new HeaderSizeEvent(OnHeaderSizeChanged);
            //set the main text color changed event handler
            this.frameTemplate.InformationTextColorChanged += new InformationTextColorEvent(OnInformationTextColorChanged);
            //set the event handler for the event raised whenever the animation delay has been modified
            this.frameTemplate.TextAnimationDelayChanged += new TextAnimationDelayEvent(OnTextAnimationDelayChanged);
            //set up the graphic
            InitializeGraphicPath();
            //create the notifier
            this.repaintNotifier = new EventNotifier(template.TextAnimationDelay, new NotifierEvent(OnNotifierEvent));
            //set the callback for the repaint
            this.RepaintNotifyHandler = new NotifyRepaintEvent(Repaint);
            
            
        }

        /// <summary>
        /// Explicit constructor
        /// </summary>
        /// <param name="template">reference to the frame template</param>
        /// <param name="data">reference to the data object this frame is bound to</param>
        public RotatorFrame(RotatorFrameTemplate template,RotatorItemData data) : this(template)
        {
            this.data = data;
        }

     
        #endregion

        #region Properties

        /// <summary>
        /// Flags whether or not the text animation should take place
        /// </summary>
        internal bool EnableTextAnimation
        {
            get
            {
                return enableTextAnimation;
            }
            set
            {
                enableTextAnimation = value;
                if (enableTextAnimation)
                {
                    repaintNotifier.Pause = false;
                    repaintNotifier.Start();
                }
                else 
                {
                    repaintNotifier.Stop();//true);
                }
            }
        }
        /// <summary>
        /// Get/Set the template for this frame
        /// </summary>
        internal RotatorFrameTemplate FrameTemplate
        {
            get 
            { 
                return frameTemplate; 
            }
            set 
            {
                frameTemplate = value; 
            }
        }

        /// <summary>
        /// Get/Set the data linked to this object
        /// </summary>
        public RotatorItemData Data
        {
            get 
            {
                return data; 
            }
            set 
            { 
                data = value;
                if (null != data)
                {
                    bufferAdjusment = true;
                    InitializeHeaderPath();

                    if (this.textAnimation != null)
                    {
                        this.textAnimation.Text = data.InformationText;
                        this.textAnimation.Reset();
                    }
                }
            }
        }
        #endregion

        #region Private

        private void StopEventNotifier()
        {
            //syncNotifier.Reset();
            //repaintNotifier.Stopping();
            //syncNotifier.WaitOne();
            repaintNotifier.Stop();
        }

        /// <summary>
        /// initialize the header graphic path
        /// </summary>
        private void InitializeHeaderPath()
        {
            if (null != headerPath)
            {
                headerPath.Dispose();
                headerPath = null;
            }

            int width = (this.Width * (int)frameTemplate.HeaderSize) / 100;
            int startingPoint = 0;
            if (null != localImage)
            {
                localImage.Dispose();
                localImage = null;
            }

            if (data != null && data.Image != null)
            {  
                localImage = (Image)data.Image.Clone();
               
                int half = (int)Math.Truncate(width / 2.0);
                localImage = ImageResize.Resize(localImage, half, Height);
                startingPoint = half-1;
            }

            headerPath = new GraphicsPath();
            
            if (cornerSquare == 0)
            {
                cornerSquare = 1;
            }
            headerPath.StartFigure();
            //check to see the corner mode, based on this create the graphic path
            switch (cornerStyle)
            {
                case CornerStyle.Rounded:

                    if (null == localImage)
                    {
                        headerPath.AddArc(-1, -1, cornerSquare, cornerSquare, 180, 90);
                        headerPath.AddLine(cornerSquare - cornerSquare / 2, 0, width - cornerSquare + cornerSquare / 2, 0);
                        headerPath.AddArc(width - cornerSquare, -1, cornerSquare, cornerSquare, -90, 90);

                        headerPath.AddLine(width, cornerSquare - cornerSquare / 2, width, Height - cornerSquare + cornerSquare / 2);
                        headerPath.AddArc(width - cornerSquare, Height - cornerSquare, cornerSquare, cornerSquare, 0, 90);
                        headerPath.AddLine(cornerSquare - cornerSquare / 2, Height, width - cornerSquare + cornerSquare / 2, Height);

                        headerPath.AddArc(-1, Height - cornerSquare, cornerSquare, cornerSquare, 90, 90);
                        headerPath.AddLine(-1, cornerSquare - cornerSquare / 2, -1, Height - cornerSquare + cornerSquare / 2);
                    }
                    else
                    {
                        headerPath.AddLine(startingPoint - cornerSquare, -1, width - cornerSquare + cornerSquare / 2, -1);
                        headerPath.AddArc(width - cornerSquare, -1, cornerSquare, cornerSquare, -90, 90);

                        headerPath.AddLine(width, cornerSquare - cornerSquare / 2, width, Height - cornerSquare + cornerSquare / 2);
                        headerPath.AddArc(width - cornerSquare, Height - cornerSquare, cornerSquare, cornerSquare, 0, 90);
                        headerPath.AddLine(width - cornerSquare + cornerSquare / 2, Height, startingPoint - cornerSquare , Height);
                        
                        headerPath.AddArc(startingPoint - cornerSquare, Height - cornerSquare, cornerSquare, cornerSquare, 90, -90);
                        headerPath.AddLine(startingPoint, Height - cornerSquare, startingPoint, cornerSquare);
                        headerPath.AddArc(startingPoint - cornerSquare, -1, cornerSquare, cornerSquare, 0, -90);
                     
                    }
                    break;

                case CornerStyle.Normal:

                    headerPath.AddLine(0, 0, width, 0);
                    headerPath.AddLine(Width, 0, width, Height);
                    headerPath.AddLine(Width, width, 0, Height);
                    headerPath.AddLine(0, Height, 0, 0);
                    break;

                default:
                    throw new ApplicationException("Unrecognized style for rendering the corners");
                    break;
            }
            headerPath.CloseFigure();
        }

        /// <summary>
        /// initialize the main text area graphic path
        /// </summary>
        private void InitializeInfoPath()
        {
            if (null != infoPath)
            {
                infoPath.Dispose();
                infoPath = null;
            }

            infoPath = new GraphicsPath();

            int width = (this.Width * (int)frameTemplate.HeaderSize)/ 100;
            //check to see the corner mode, based on this create the graphic path
            infoPath.StartFigure();
            switch (cornerStyle)
            {
                case CornerStyle.Rounded:

                    /*infoPath.AddArc(width - cornerSquare, -1, cornerSquare, cornerSquare, -90, 90);
                    infoPath.AddLine(width, cornerSquare - cornerSquare / 2, width, Height - cornerSquare + cornerSquare / 2);
                    infoPath.AddArc(width - cornerSquare, Height - cornerSquare, cornerSquare, cornerSquare, 0, 90);
                    infoPath.AddLine(width - cornerSquare, Height, Width - cornerSquare / 2, Height);
                    infoPath.AddArc(Width - cornerSquare, Height - cornerSquare, cornerSquare, cornerSquare, 0, 90);

                    infoPath.AddLine(Width, Height - cornerSquare / 2, Width, cornerSquare / 2);
                    infoPath.AddArc(Width - cornerSquare, -1, cornerSquare, cornerSquare, -90, 90);
                    infoPath.AddLine(Width - cornerSquare / 2, -1, width - cornerSquare / 2, -1);
                    */

                    int startingPoint = width;
                    infoPath.AddLine(startingPoint - cornerSquare, -1, Width - cornerSquare + cornerSquare / 2, -1);
                    infoPath.AddArc(Width - cornerSquare, -1, cornerSquare, cornerSquare, -90, 90);

                    infoPath.AddLine(Width, cornerSquare - cornerSquare / 2, Width, Height - cornerSquare + cornerSquare / 2);
                    infoPath.AddArc(Width - cornerSquare, Height - cornerSquare, cornerSquare, cornerSquare, 0, 90);
                    infoPath.AddLine(Width - cornerSquare + cornerSquare / 2, Height, startingPoint - cornerSquare, Height);

                    infoPath.AddArc(startingPoint - cornerSquare, Height - cornerSquare, cornerSquare, cornerSquare, 90, -90);
                    infoPath.AddLine(startingPoint , Height - cornerSquare, startingPoint , cornerSquare);
                    infoPath.AddArc(startingPoint - cornerSquare, -1, cornerSquare, cornerSquare, 0, -90);
                    break;

                case CornerStyle.Normal:

                    infoPath.AddLine(width, 0, Width, 0);
                    infoPath.AddLine(Width, 0, Width, Height);
                    infoPath.AddLine(Width, width, 0, Height);
                    infoPath.AddLine(width, Height, width, 0);
                    break;

                default:
                    throw new ApplicationException("Unrecognized style for rendering the corners");
                    break;
            }
            infoPath.CloseFigure();
        }

        /// <summary>
        /// Initializes the text animation in this case a typingtextanimation
        /// </summary>
        private void InitializeTextAnimation()
        {

            textAnimation = new TypingTextAnimation();
            //set the animation area
            RectangleF area = infoPath.GetBounds();
            textAnimation.Area = new RectangleF(new PointF(area.X + cornerSquare, area.Y), new SizeF(area.Width - cornerSquare, area.Height));
            //set data needed for the animation
            textAnimation.Text = data.InformationText;
            textAnimation.TextColor = frameTemplate.InformationTextColor;
            textAnimation.Font = frameTemplate.InformationFont;
            //set the handler for the animation finished event
            (textAnimation as TypingTextAnimation).AnimationFinished += new AnimationFinished(OnTextAnimationFinished);
        }
        
        #endregion

        #region Public
        /// <summary>
        /// 
        /// </summary>
        public void ResetAnimation()
        {
            if (null != textAnimation)
            {
                textAnimation.Reset();
            }
        }

        #endregion

        #region Override

        #region GraphicPath
        /// <summary>
        /// Set up the graphic path used for drawing the borders
        /// </summary>
        protected override void InitializeGraphicPath()
        {
            cornerSquare = (int)(Height > Width ? Height * 0.04f : Width * 0.04f);

            InitializeHeaderPath();
            base.InitializeGraphicPath();
            if (this.cornerStyle == CornerStyle.Rounded)
            {
                this.Region = new Region(regionPath);
            }
        }
        #endregion

        #region Window events

        /// <summary>
        /// Handle the resize event. need to recreat the graphics paths and eventually the brushes
        /// </summary>
        /// <param name="eventargs"></param>
        protected override void OnResize(EventArgs eventargs)
        {
            base.OnResize(eventargs);
            //check if the header size has been set to 0; default to 40%of the control
            if (frameTemplate.HeaderSize == 0)
            {
                frameTemplate.HeaderSize = (uint)(this.Width * 0.4);
            }
            InitializeGraphicPath();
            InitializeInfoPath();
            //might need to recreate the brush
            if (frameTemplate.HeaderBrushType == BrushType.Gradient || frameTemplate.InformationBrushType == BrushType.Gradient)
            {
                frameTemplate.RefreshBrushes(this.Width, this.Height);
            }
            
            if (null != textAnimation)
            {
                ///recreate the area for the animation
                RectangleF area = infoPath.GetBounds();
                textAnimation.Area = new RectangleF(new PointF(area.X + cornerSquare, area.Y), new SizeF(area.Width - cornerSquare, area.Height));
                (textAnimation as TypingTextAnimation).MeasureTextArea = true;
            }
            //text size needs to be recalculated
            bufferAdjusment = true;
        }

        protected override void OnSizeChanged(EventArgs e)
        {
            base.OnSizeChanged(e);
            bufferAdjusment = true;
        }
      
        /// <summary>
        /// Override the paint event raised for a WM_PAINT message
        /// </summary>
        /// <param name="e"></param>
        protected override void OnPaint(System.Windows.Forms.PaintEventArgs e)
        {
            base.OnPaint(e);
            //set up some flags
            e.Graphics.CompositingQuality = System.Drawing.Drawing2D.CompositingQuality.HighQuality;
            e.Graphics.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;
            e.Graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
            e.Graphics.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAlias;

            //check to see if the path has been initialized
            if (graphicPath == null)
            {
                InitializeGraphicPath();
            }
            //draw header moved down
            //e.Graphics.FillPath(frameTemplate.HeaderBrush, headerPath);

            //draw the background for the main text area
            e.Graphics.FillPath(frameTemplate.InformationBrush, infoPath);
            //is there data linked to this object
            if (null != data)
            {
                
                if (null != localImage)
                {
                   e.Graphics.DrawImage(localImage, new Point(0, 0));
                }
                //draw header
                e.Graphics.FillPath(frameTemplate.HeaderBrush, headerPath);

                //recalculate the text size if necessary
                if (bufferAdjusment)
                {
                    outputHeaderText = headerPath.GetBounds();
                    outputHeaderText = new RectangleF(outputHeaderText.X + cornerSquare, 0, outputHeaderText.Width - cornerSquare, Height);
                    bufferedTextSize = e.Graphics.MeasureString(data.HeaderText, frameTemplate.HeaderFont, outputHeaderText.Size, stringFormat);
                    bufferAdjusment = false;
                    //set the header area 
                    outputHeaderText = new RectangleF(new PointF(outputHeaderText.X + (outputHeaderText.Width - bufferedTextSize.Width) * 0.5f, outputHeaderText.Y + (outputHeaderText.Height - bufferedTextSize.Height) * 0.5f), bufferedTextSize);
                }
                
                //render the header text
                e.Graphics.DrawString(data.HeaderText, frameTemplate.HeaderFont, new SolidBrush(frameTemplate.HeaderTextColor), outputHeaderText, stringFormat);
            }
            else
            {
                //draw header
                e.Graphics.FillPath(frameTemplate.HeaderBrush, headerPath);
            }
           
            //is animation enabled
            if (enableTextAnimation)
            {
                //initialize animation if necessary
                if (null == textAnimation)
                {
                    InitializeTextAnimation();
                }
                //set the graphics object
                textAnimation.Graphics = e.Graphics;
                //render the main text
                textAnimation.DrawText();
                textAnimation.Graphics = null;
                this.repaintNotifier.Pause = false;
            }
            else
            {
                //pause the repaint event notifier
                this.repaintNotifier.Pause = true;
            }
        }

        #endregion

        #endregion

        #region Events

        /// <summary>
        /// Handler for the animation delay changed event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="args"></param>
        private void OnTextAnimationDelayChanged(object sender, EventArgs args)
        {
            repaintNotifier.NotifyPeriod = frameTemplate.TextAnimationDelay;
        }

        /// <summary>
        /// The callback method for the repaint notify event(control has to be thread safe)
        /// </summary>
        private void Repaint()
        {
           this.Invalidate(new Region(infoPath));
           this.Update();
        }

        /// <summary>
        /// Handler for the repaint event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="args"></param>
        private void OnNotifierEvent(object sender, EventArgs args)
        {

            this.repaintNotifier.Pause = true;

            //invoke the delegate; thread safe access
            this.Invoke(RepaintNotifyHandler);
        }


        /// <summary>
        /// Handler of the text animation finished event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void OnTextAnimationFinished(object sender, EventArgs e)
        {
            //stop the repaint notfier
            StopEventNotifier();
            if (null != AnimationFinished)
            {
                //raise the event further if the case
                AnimationFinished(this, new EventArgs());
            }
        }

        /// <summary>
        /// Handler for the header size changed event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="args"></param>
        private void OnHeaderSizeChanged(object sender, EventArgs args)
        {
            //need to recreate the graphic paths
            InitializeHeaderPath();
            InitializeInfoPath();
        }

        /// <summary>
        /// Hanlder for the main text color changed event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="args"></param>
        private void OnInformationTextColorChanged(object sender, EventArgs args)
        {
            if (null != textAnimation)
            {
                textAnimation.TextColor = this.frameTemplate.InformationTextColor;
            }
        }

        #endregion

        #region IDisposable Members

        /// <summary>
        /// Clear the memory; stop the notifier
        /// </summary>
        protected override void Dispose(bool disposing)
        {
            if (null != repaintNotifier)
            {
                StopEventNotifier();
            }
            if (null != graphicPath)
            {
                graphicPath.Dispose();
            }
            if (null != infoPath)
            {
                infoPath.Dispose();
            }
            if (null != headerPath)
            {
                headerPath.Dispose();
            }

            base.Dispose(disposing);
        }
         
        
        #endregion
    }
}
