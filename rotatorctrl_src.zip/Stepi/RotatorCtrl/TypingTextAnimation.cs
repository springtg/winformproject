#region Using Directives
using System;
using System.Drawing;
#endregion

namespace Stepi.UI
{
    /// <summary>
    /// Defines the text typing animation for a given text
    /// </summary>
    sealed class TypingTextAnimation:TextAnimation, IDisposable
    {
        #region Members

        /// <summary>
        /// flag for caching the text size
        /// </summary>
        private bool measureText = true;

        /// <summary>
        /// index of the current character within the given text
        /// </summary>
        private int index = 0;

        /// <summary>
        /// The brush used in drawing the text
        /// </summary>
        private Brush brush = null;

        /// <summary>
        /// The string formatting flags
        /// </summary>
        private StringFormat stringFormat = null;
        
        /// <summary>
        /// Redefines the animationfinished event; to be raised when the animation has completed
        /// </summary>
        public new event AnimationFinished AnimationFinished = null;

        #endregion

        #region ctor
        /// <summary>
        /// Implicit constructor
        /// </summary>
        internal TypingTextAnimation()
        {
            //set the string format flags
            stringFormat = new StringFormat(StringFormatFlags.LineLimit | StringFormatFlags.MeasureTrailingSpaces);
            stringFormat.Trimming = StringTrimming.EllipsisWord;
        }
        #endregion

        #region Properties

        /// <summary>
        /// Set the color of the text being animated
        /// </summary>
        public new Color TextColor
        {
            set
            {
                if (value != textColor)
                {
                    textColor = value;
                    this.brush = new SolidBrush(textColor);
                }
            }
        }

        /// <summary>
        /// Set the text to be animated
        /// </summary>
        public new string Text
        {
            set
            {
                text = value;
                //reset index
                index = 0;
                //flag for raising the animaiton finished event
                eventSignaled = false;
            }
        }

        /// <summary>
        /// Set/Get wheter the text size has to be recalculated
        /// </summary>
        public bool MeasureTextArea
        {
            get
            {
                return measureText;
            }
            set
            {
                measureText = value;
            }
        }

        #endregion

        #region Override

        /// <summary>
        /// Reset the animation
        /// </summary>
        public override void Reset()
        {
            index = 0;
            eventSignaled = false;
        }

        /// <summary>
        /// The method responsible for drawing the text
        /// </summary>
        public override void DrawText()
        {
            if (text != null)
            {
                if (null == brush)
                {
                    brush = new SolidBrush(textColor);
                }
                //calculate the text size if needed
                if (measureText)
                {
                    measureText = false;
                    
                    //stringFormat.LineAlignment = StringAlignment.Center;
                    
                    SizeF size = graphics.MeasureString(text, font, area.Size, stringFormat);
                    //center the text within the given rectangle
                    float widthAdjustment = (area.Width - size.Width) / 2;
                    float heightAdjustment = (area.Height - size.Height) / 2;
                    //set the new area
                    area = new RectangleF(new PointF(area.X + widthAdjustment, area.Y + heightAdjustment), size);
                }
               

                if (index >= text.Length)
                {
                    graphics.DrawString(text, font, brush, area);
                    //raise the event if necessary
                    if (null != AnimationFinished && !eventSignaled)
                    {
                        AnimationFinished(this, new EventArgs());
                        eventSignaled = true;
                    }
                }
                else
                {
                    //draw part of the text
                    graphics.DrawString(text.Substring(0, index), font, brush, area);
                    //set the new step of the animation
                    index++ ;
                    if (index > text.Length)
                    {
                        index = text.Length;
                    }
                    SizeF sizeExceed = graphics.MeasureString(text.Substring(0, index), font, (int)area.Width, stringFormat);
                    //if text exceeds the available area don't draw it
                    if (sizeExceed.Height > area.Height)
                    {
                        //get last empty character of the text being rendered and add the "..."
                        int lastSpace = text.LastIndexOf(' ');
                        if (lastSpace == text.Length - 1)
                        {
                            lastSpace = text.LastIndexOf(' ', lastSpace);
                        }
                        if (lastSpace < 0)
                        {
                            lastSpace = 0;
                        }
                        text = text.Substring(0, lastSpace) + "...";
                        index = text.Length;
                    }
                }
            }
        }
        #endregion

        #region IDisposable Members

        public void Dispose()
        {
            if (null != brush)
            {
                brush.Dispose();
                brush = null;
            }
        }

        #endregion
    }
}
