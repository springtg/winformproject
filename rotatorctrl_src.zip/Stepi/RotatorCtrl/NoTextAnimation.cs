#region Using Directives

using System;
using System.Drawing;

#endregion

namespace Stepi.UI
{
    class NoTextAnimation :TextAnimation, IDisposable
    {
        #region Members

        /// <summary>
        /// 
        /// </summary>
        private Brush brush = null;

        /// <summary>
        /// 
        /// </summary>
        public new event AnimationFinished AnimationFinished = null;

        #endregion

        #region Override

        public override void Reset()
        {
            
        }

        public override void DrawText()
        {
            if(null == brush)
            {
                brush = new SolidBrush(textColor);
            }
            graphics.DrawString(text, font, brush, area);
            if (!eventSignaled && AnimationFinished != null)
            {
                AnimationFinished(this, new EventArgs());
            }
        }
        #endregion

        #region IDisposable Members

        public void Dispose()
        {
            if (null != brush)
            {
                brush.Dispose();
                brush = null;
            }
        }

        #endregion
    }
}
