#region Using directives

using System;
using System.Drawing;

#endregion

namespace Stepi.UI
{   
    /// <summary>
    /// Abstract class defining the text animation object
    /// </summary>
    abstract class TextAnimation : ITextAnimation
    {
        #region Members

        /// <summary>
        /// Flag for raising the finish animation only once
        /// </summary>
        protected bool eventSignaled = false;

        /// <summary>
        /// text to be animated
        /// </summary>
        protected string text = null;

        /// <summary>
        /// Reference to the graphics object doing the text rendering
        /// </summary>
        protected Graphics graphics = null;

        /// <summary>
        /// The color of the text
        /// </summary>
        protected Color textColor = Color.Empty;

        /// <summary>
        /// Reference to the font used in rendering the text
        /// </summary>
        protected Font font = new Font("Arial" ,10);

        /// <summary>
        /// The available rectangle to animate the text
        /// </summary>
        protected RectangleF area = RectangleF.Empty;

        /// <summary>
        /// The event to be raised when the animation has finished
        /// </summary>
        public new event AnimationFinished AnimationFinished = null;
        #endregion
       
        #region Properties

        /// <summary>
        /// Get/Set the text to be animated
        /// </summary>
        public string Text
        {
            get
            {
                return text;
            }
            set
            {
                text = value;
            }
        }

        /// <summary>
        /// Set the graphic object
        /// </summary>
        public Graphics Graphics
        {
            set
            {
                this.graphics = value;
            }
        }

        /// <summary>
        /// Set the rectangle in which the text is going to be rendered
        /// </summary>
        public RectangleF Area
        {
            set 
            {
                this.area = value;
            }
        }

        /// <summary>
        /// Set the text color
        /// </summary>
        public Color TextColor
        {
            set
            {
                this.textColor = value;
            }
        }

        /// <summary>
        /// Set the font used in drawing the text
        /// </summary>
        public Font Font
        {
            set
            {
                this.font = value;
            }
        }
        #endregion

        #region Abstract

        /// <summary>
        /// Method to reset the animation
        /// </summary>
        public abstract void Reset();

        /// <summary>
        /// The method responsible for drawing the text
        /// </summary>
        public abstract void DrawText();
            
        #endregion
    }
}
