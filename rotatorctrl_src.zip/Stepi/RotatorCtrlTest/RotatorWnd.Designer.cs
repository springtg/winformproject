using System.Drawing;
namespace RotatorCtrlTest
{
    partial class RotatorWnd
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Stepi.UI.Rotator.RotatorItemData rotatorItemData1 = new Stepi.UI.Rotator.RotatorItemData();
            Stepi.UI.Rotator.RotatorItemData rotatorItemData2 = new Stepi.UI.Rotator.RotatorItemData();
            this.rotatorCtrl1 = new Stepi.UI.Rotator.RotatorCtrl();
            this.SuspendLayout();
            // 
            // rotatorCtrl1
            // 
            this.rotatorCtrl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.rotatorCtrl1.BorderColor = System.Drawing.Color.Gray;
            this.rotatorCtrl1.BrushType = Stepi.UI.BrushType.Solid;
            this.rotatorCtrl1.ColorOne = System.Drawing.Color.WhiteSmoke;
            this.rotatorCtrl1.ColorTwo = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.rotatorCtrl1.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rotatorCtrl1.FrameAnimationDelay = 100;
            this.rotatorCtrl1.FrameAnimationMode = Stepi.UI.Rotator.RotatorControlAnimationMode.YAxis;
            this.rotatorCtrl1.FrameAnimationStep = 20;
            this.rotatorCtrl1.HeaderColorOne = System.Drawing.Color.WhiteSmoke;
            this.rotatorCtrl1.HeaderColorTwo = System.Drawing.Color.Gray;
            this.rotatorCtrl1.HeaderFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rotatorCtrl1.HeaderSize = ((uint)(40u));
            this.rotatorCtrl1.HeaderTextColor = System.Drawing.Color.Black;
            this.rotatorCtrl1.InformationBrushType = Stepi.UI.BrushType.Solid;
            this.rotatorCtrl1.InformationColorOne = System.Drawing.Color.LightGray;
            this.rotatorCtrl1.InformationColorTwo = System.Drawing.Color.DimGray;
            this.rotatorCtrl1.InformationFont = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rotatorCtrl1.InformationTextColor = System.Drawing.Color.Black;
            rotatorItemData1.HeaderText = "Max. 26�C\r\nMin.  22�C";
            rotatorItemData1.Image = global::RotatorCtrlTest.Properties.Resources.cloudy;
            rotatorItemData1.InformationText = "Cloudy with periods of light rain. High 64F. Winds NNW at 5 to 10 mph. Chance of " +
                "rain 70%.";
            rotatorItemData2.HeaderText = "Max. 29�C\r\nMin.  25�C";
            rotatorItemData2.Image = global::RotatorCtrlTest.Properties.Resources.sunny;
            rotatorItemData2.InformationText = "A mainly sunny sky. High 76F. Winds NE at 5 to 10 mph. ";
            this.rotatorCtrl1.Items.Add(rotatorItemData1);
            this.rotatorCtrl1.Items.Add(rotatorItemData2);
            this.rotatorCtrl1.Location = new System.Drawing.Point(2, 1);
            this.rotatorCtrl1.Name = "rotatorCtrl1";
            this.rotatorCtrl1.Size = new System.Drawing.Size(480, 164);
            this.rotatorCtrl1.TabIndex = 0;
            this.rotatorCtrl1.TextAnimationDelay = 150;
            this.rotatorCtrl1.TitleText = "Weather Forecast";
            this.rotatorCtrl1.TitleTextColor = System.Drawing.Color.DarkGray;
            // 
            // RotatorWnd
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(483, 169);
            this.Controls.Add(this.rotatorCtrl1);
            this.Name = "RotatorWnd";
            this.Text = "Test";
            this.ResumeLayout(false);

        }

        #endregion

        private Stepi.UI.Rotator.RotatorCtrl rotatorCtrl1;

    }
}