namespace ExampleApplication
{
	partial class Form2
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if(disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
			this.label1 = new System.Windows.Forms.Label();
			this.radioButtonPanel1 = new UIToolbox.RadioButtonPanel();
			this.radioGroupBox3 = new UIToolbox.RadioGroupBox();
			this.panel1 = new System.Windows.Forms.Panel();
			this.radioButton6 = new System.Windows.Forms.RadioButton();
			this.radioButton5 = new System.Windows.Forms.RadioButton();
			this.radioGroupBox2 = new UIToolbox.RadioGroupBox();
			this.button1 = new System.Windows.Forms.Button();
			this.radioGroupBox1 = new UIToolbox.RadioGroupBox();
			this.checkBox2 = new System.Windows.Forms.CheckBox();
			this.checkBox1 = new System.Windows.Forms.CheckBox();
			this.radioButton4 = new System.Windows.Forms.RadioButton();
			this.radioButton3 = new System.Windows.Forms.RadioButton();
			this.radioButton2 = new System.Windows.Forms.RadioButton();
			this.radioButton1 = new System.Windows.Forms.RadioButton();
			this.radioButtonPanel1.SuspendLayout();
			this.radioGroupBox3.SuspendLayout();
			this.panel1.SuspendLayout();
			this.radioGroupBox2.SuspendLayout();
			this.radioGroupBox1.SuspendLayout();
			this.SuspendLayout();
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(27, 315);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(303, 58);
			this.label1.TabIndex = 1;
			this.label1.Text = resources.GetString("label1.Text");
			// 
			// radioButtonPanel1
			// 
			this.radioButtonPanel1.Controls.Add(this.radioGroupBox3);
			this.radioButtonPanel1.Controls.Add(this.radioGroupBox2);
			this.radioButtonPanel1.Controls.Add(this.radioGroupBox1);
			this.radioButtonPanel1.Controls.Add(this.radioButton4);
			this.radioButtonPanel1.Controls.Add(this.radioButton3);
			this.radioButtonPanel1.Controls.Add(this.radioButton2);
			this.radioButtonPanel1.Controls.Add(this.radioButton1);
			this.radioButtonPanel1.Location = new System.Drawing.Point(73, 12);
			this.radioButtonPanel1.Name = "radioButtonPanel1";
			this.radioButtonPanel1.Size = new System.Drawing.Size(211, 297);
			this.radioButtonPanel1.TabIndex = 0;
			// 
			// radioGroupBox3
			// 
			this.radioGroupBox3.Controls.Add(this.panel1);
			this.radioGroupBox3.Location = new System.Drawing.Point(4, 231);
			this.radioGroupBox3.Name = "radioGroupBox3";
			this.radioGroupBox3.Size = new System.Drawing.Size(200, 61);
			this.radioGroupBox3.TabIndex = 6;
			this.radioGroupBox3.TabStop = false;
			this.radioGroupBox3.Text = "radioGroupBox3";
			// 
			// panel1
			// 
			this.panel1.Controls.Add(this.radioButton6);
			this.panel1.Controls.Add(this.radioButton5);
			this.panel1.Location = new System.Drawing.Point(10, 19);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(184, 36);
			this.panel1.TabIndex = 1;
			// 
			// radioButton6
			// 
			this.radioButton6.AutoSize = true;
			this.radioButton6.Location = new System.Drawing.Point(16, 18);
			this.radioButton6.Name = "radioButton6";
			this.radioButton6.Size = new System.Drawing.Size(85, 17);
			this.radioButton6.TabIndex = 1;
			this.radioButton6.Text = "radioButton6";
			this.radioButton6.UseVisualStyleBackColor = true;
			// 
			// radioButton5
			// 
			this.radioButton5.AutoSize = true;
			this.radioButton5.Checked = true;
			this.radioButton5.Location = new System.Drawing.Point(16, 1);
			this.radioButton5.Name = "radioButton5";
			this.radioButton5.Size = new System.Drawing.Size(85, 17);
			this.radioButton5.TabIndex = 0;
			this.radioButton5.TabStop = true;
			this.radioButton5.Text = "radioButton5";
			this.radioButton5.UseVisualStyleBackColor = true;
			// 
			// radioGroupBox2
			// 
			this.radioGroupBox2.Controls.Add(this.button1);
			this.radioGroupBox2.Location = new System.Drawing.Point(4, 164);
			this.radioGroupBox2.Name = "radioGroupBox2";
			this.radioGroupBox2.Size = new System.Drawing.Size(200, 61);
			this.radioGroupBox2.TabIndex = 5;
			this.radioGroupBox2.TabStop = false;
			this.radioGroupBox2.Text = "radioGroupBox2";
			// 
			// button1
			// 
			this.button1.Location = new System.Drawing.Point(26, 20);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(75, 23);
			this.button1.TabIndex = 1;
			this.button1.Text = "button1";
			this.button1.UseVisualStyleBackColor = true;
			// 
			// radioGroupBox1
			// 
			this.radioGroupBox1.Controls.Add(this.checkBox2);
			this.radioGroupBox1.Controls.Add(this.checkBox1);
			this.radioGroupBox1.Location = new System.Drawing.Point(4, 97);
			this.radioGroupBox1.Name = "radioGroupBox1";
			this.radioGroupBox1.Size = new System.Drawing.Size(200, 61);
			this.radioGroupBox1.TabIndex = 4;
			this.radioGroupBox1.TabStop = false;
			this.radioGroupBox1.Text = "radioGroupBox1";
			// 
			// checkBox2
			// 
			this.checkBox2.AutoSize = true;
			this.checkBox2.Location = new System.Drawing.Point(26, 38);
			this.checkBox2.Name = "checkBox2";
			this.checkBox2.Size = new System.Drawing.Size(80, 17);
			this.checkBox2.TabIndex = 2;
			this.checkBox2.Text = "checkBox2";
			this.checkBox2.UseVisualStyleBackColor = true;
			// 
			// checkBox1
			// 
			this.checkBox1.AutoSize = true;
			this.checkBox1.Location = new System.Drawing.Point(26, 20);
			this.checkBox1.Name = "checkBox1";
			this.checkBox1.Size = new System.Drawing.Size(80, 17);
			this.checkBox1.TabIndex = 1;
			this.checkBox1.Text = "checkBox1";
			this.checkBox1.UseVisualStyleBackColor = true;
			// 
			// radioButton4
			// 
			this.radioButton4.AutoSize = true;
			this.radioButton4.Location = new System.Drawing.Point(14, 74);
			this.radioButton4.Name = "radioButton4";
			this.radioButton4.Size = new System.Drawing.Size(85, 17);
			this.radioButton4.TabIndex = 3;
			this.radioButton4.Text = "radioButton4";
			this.radioButton4.UseVisualStyleBackColor = true;
			// 
			// radioButton3
			// 
			this.radioButton3.AutoSize = true;
			this.radioButton3.Location = new System.Drawing.Point(14, 50);
			this.radioButton3.Name = "radioButton3";
			this.radioButton3.Size = new System.Drawing.Size(85, 17);
			this.radioButton3.TabIndex = 2;
			this.radioButton3.Text = "radioButton3";
			this.radioButton3.UseVisualStyleBackColor = true;
			// 
			// radioButton2
			// 
			this.radioButton2.AutoSize = true;
			this.radioButton2.Location = new System.Drawing.Point(14, 27);
			this.radioButton2.Name = "radioButton2";
			this.radioButton2.Size = new System.Drawing.Size(85, 17);
			this.radioButton2.TabIndex = 1;
			this.radioButton2.Text = "radioButton2";
			this.radioButton2.UseVisualStyleBackColor = true;
			// 
			// radioButton1
			// 
			this.radioButton1.AutoSize = true;
			this.radioButton1.Checked = true;
			this.radioButton1.Location = new System.Drawing.Point(14, 4);
			this.radioButton1.Name = "radioButton1";
			this.radioButton1.Size = new System.Drawing.Size(85, 17);
			this.radioButton1.TabIndex = 0;
			this.radioButton1.TabStop = true;
			this.radioButton1.Text = "radioButton1";
			this.radioButton1.UseVisualStyleBackColor = true;
			// 
			// Form2
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(351, 373);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.radioButtonPanel1);
			this.Name = "Form2";
			this.Text = "Form2";
			this.Load += new System.EventHandler(this.Form2_Load);
			this.radioButtonPanel1.ResumeLayout(false);
			this.radioButtonPanel1.PerformLayout();
			this.radioGroupBox3.ResumeLayout(false);
			this.radioGroupBox3.PerformLayout();
			this.panel1.ResumeLayout(false);
			this.panel1.PerformLayout();
			this.radioGroupBox2.ResumeLayout(false);
			this.radioGroupBox2.PerformLayout();
			this.radioGroupBox1.ResumeLayout(false);
			this.radioGroupBox1.PerformLayout();
			this.ResumeLayout(false);

		}

		#endregion

		private UIToolbox.RadioButtonPanel radioButtonPanel1;
		private System.Windows.Forms.RadioButton radioButton3;
		private System.Windows.Forms.RadioButton radioButton2;
		private System.Windows.Forms.RadioButton radioButton1;
		private System.Windows.Forms.RadioButton radioButton4;
		private UIToolbox.RadioGroupBox radioGroupBox2;
		private UIToolbox.RadioGroupBox radioGroupBox1;
		private UIToolbox.RadioGroupBox radioGroupBox3;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.CheckBox checkBox2;
		private System.Windows.Forms.CheckBox checkBox1;
		private System.Windows.Forms.Panel panel1;
		private System.Windows.Forms.RadioButton radioButton6;
		private System.Windows.Forms.RadioButton radioButton5;
	}
}