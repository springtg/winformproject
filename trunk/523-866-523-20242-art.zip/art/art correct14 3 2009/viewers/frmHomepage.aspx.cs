using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class viewers_frmHomepage : System.Web.UI.Page
{
    Class1 cs = new Class1();
    protected void Page_Load(object sender, EventArgs e)
    {
        string A = "select username,logindate from login";
            DataSet ds = cs.exeadptor(A);
            int i = Convert.ToInt32(ds.Tables[0].Rows.Count);
            for (int s = 1; s <= i; s++)
            {
                DateTime cu = DateTime.Today;
                DateTime z = Convert.ToDateTime(ds.Tables[0].Rows[s-1][1]);
                TimeSpan sd = cu - z;
                int q = Convert.ToInt32(sd.TotalDays);
                if (q > 90)
                {
                    string d = "select imageid from images where  username='" + ds.Tables[0].Rows[s - 1][0] + "'";
                    DataSet r = cs.exeadptor(d);
                    if (r.Tables[0].Rows.Count > 0)
                    {
                        for (int ew = 0; ew < r.Tables[0].Rows.Count; ew++)
                        {
                            int ea = Convert.ToInt32(r.Tables[0].Rows[ew][0]);
                            string ab = "delete from register where username='" + ds.Tables[0].Rows[s - 1][0] + "'";
                            cs.exequery(ab);
                            string abc = "delete from images where imageid='" + ea + "'";
                            cs.exequery(abc);
                            string abcd = "delete from comment where imageid='" + ea + "'";
                            cs.exequery(abcd);
                            string abcde = "delete from sharing where imageid='" + ea + "'";
                            cs.exequery(abcde);
                            string abcdef = "delete from login where username='" + ds.Tables[0].Rows[s - 1][0] + "'";
                            cs.exequery(abcdef);
                            string abcdefg = "delete from addressbook where owner='" + ds.Tables[0].Rows[s - 1][0] + "'";
                            cs.exequery(abcdefg);
                            string abcdefgh = "delete from feed where username='" + ds.Tables[0].Rows[s - 1][0] + "'";
                            cs.exequery(abcdefgh);
                        }


                    }
                    else
                    {
                        int Z = 0;
                    }
                }
                else
                {
                    int fg = 0;
                }
        }
    }
}

