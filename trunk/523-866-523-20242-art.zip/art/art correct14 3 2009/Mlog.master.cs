using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class Mlog : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }



    protected void lnkregister_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/User/frmRegister.aspx");
    }
    protected void lnklogin_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/User/frmLogin.aspx");
    }
    protected void lnkView_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/viewers/frmViewgallery.aspx");
    }
    protected void lnkAboutus_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/viewers/frmAbout.aspx");
    }
    protected void LinkLogout_Click(object sender, EventArgs e)
    {
        Session["username"] = " ";
        Response.Redirect("~/viewers/frmHomepage.aspx");
    }
    protected void LinkHelp_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/viewers/frmHelp.aspx");
    }
}
