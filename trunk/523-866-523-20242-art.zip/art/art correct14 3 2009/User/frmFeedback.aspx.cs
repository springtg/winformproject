using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class User_frmFeedback : System.Web.UI.Page
{
    Class1 cs = new Class1();
    protected void Page_Load(object sender, EventArgs e)
    {
        txtneed.Focus();
    }
    
    protected void cmdsend_Click(object sender, EventArgs e)
    {
        string d = "select * from feed where username='" + Session["username"] + "' and status=0";
        DataSet m = cs.exeadptor(d);
        if (m.Tables[0].Rows.Count > 2)
        {
            Response.Write("<script> window.alert('you already have 3 unprocessed requests');</script>");
        }
        else
        {
            string s = "insert into feed values('" + Session["username"] + "','" + txtneed.Text + "','" + System.DateTime.Now.ToShortDateString() + "',0)";
            int i = cs.exequery(s);
            Response.Write("<script> window.alert('Feedback added')</script>");
        }

    }



    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/User/home.aspx");
    }
}
