using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class User_frmViewmycomment : System.Web.UI.Page
{
    Class1 cs = new Class1();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            Session["a"] = Convert.ToInt32(Request.Params["imgid"]);
            string s = "select comment.comment,register.email from comment,register where comment.fromname=register.username and comment.imageid='" + Session["a"] + "' and comment.status=1";
            DataSet ds = cs.exeadptor(s);
            if (ds.Tables[0].Rows.Count > 0)
            {
                GridView1.DataSource = ds;
                GridView1.DataBind();
            }
            else
            {
                Response.Write("<script> window.alert('There is no comments');  location.href='frmMyfiles.aspx'</script>");
            }
        }
    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        Response.Redirect("frmMyfiles.aspx");

    }
}
