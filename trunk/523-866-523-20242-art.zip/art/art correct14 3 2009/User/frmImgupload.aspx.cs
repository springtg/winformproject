using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.IO;

public partial class User_frmImgupload1 : System.Web.UI.Page
{
    Class1 connect = new Class1();
    string filename = "";
    protected void Page_Load(object sender, EventArgs e)
    {


        if (!IsPostBack == true)
        {
            string s = "select categoryname from category ";
            DataSet dss = connect.exeadptor(s);
            combocategory.DataSource = dss;
            combocategory.DataBind();



        }
    }
    protected void cmdsubmitt_Click(object sender, EventArgs e)
    {
        DirectoryInfo dinfo = new DirectoryInfo(Server.MapPath("~/image/"));
        FileInfo[] f = dinfo.GetFiles();
        string filename = "", ext = "", _path = "";
        if (FileUpload1.HasFile)
        {

            ext = Path.GetExtension(FileUpload1.PostedFile.FileName).ToLower();
            filename = FileUpload1.FileName;
            _path = Server.MapPath("~/image/") + filename;
            if (ext.ToLower() == ".jpeg" || ext.ToLower() == ".jpg" || ext.ToLower() == ".gif" || ext.ToLower() == ".bmp")
            {
                int fileapd = 0;
                while (File.Exists(_path))
                {
                    fileapd++;
                    filename = Path.GetFileNameWithoutExtension(FileUpload1.FileName) + fileapd.ToString() + ".jpg";
                    _path = Server.MapPath("~/image/") + filename;
                }
                FileUpload1.SaveAs(_path);
                Image1.ImageUrl = "~/image/" + filename;
                string a = "~/image/" + filename;
                string s1 = "select categoryid from category where categoryname='" + combocategory.SelectedItem.Value + "'";
                DataSet dss = connect.exeadptor(s1);
                string h = dss.Tables[0].Rows[0][0].ToString();
                int i = Convert.ToInt32(h);
                string s = "insert into images values('" + Session["username"] + "','" + i + "','" + txttitle.Text + "','" + txtdescription.Text + "','" + a + "','" + System.DateTime.Now.ToShortDateString() + "',0,0,0,0)";
                int j = connect.exequery(s);
                Response.Write("<script> window.alert('Image uploaded')</script>");




            }
        }
    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        Response.Redirect("frmMyfiles.aspx");
    }
}