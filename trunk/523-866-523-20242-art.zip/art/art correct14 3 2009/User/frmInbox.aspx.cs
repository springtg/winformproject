using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class User_frminbox : System.Web.UI.Page
{
    Class1 cs = new Class1();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            string s = "select * from images,sharing where images.imageid=sharing.imageid and sharing.toname='"+Session["username"]+"'";
            DataSet ds = cs.exeadptor(s);
            if (ds.Tables[0].Rows.Count > 0)
            {
                GridView1.DataSource = ds;
                GridView1.DataBind();
            }
            else
            {
                Response.Write("<script> window.alert('There is no recieved images');location.href='home.aspx'</script>");
            }
 
            
        }

    }

    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "OK")
        {
            string s = "select image from images where imageid='" + (e.CommandArgument) + "'";
            DataSet ds1 = cs.exeadptor(s);
            Session["sd"] = Convert.ToInt32(e.CommandArgument);
            Image1.ImageUrl = ds1.Tables[0].Rows[0][0].ToString();

        }
    }
    protected void cmddelete_Click(object sender, EventArgs e)
    {

        string df = "select * from sharing where imageid='" + Session["sd"] + "'and toname='" + Session["username"] + "'";
        DataSet asd = cs.exeadptor(df);
        if (Convert.ToInt32(asd.Tables[0].Rows[0][3]) == 0)
        {
            string rt = "delete from sharing where imageid='" + Session["sd"] + "'and toname='" + Session["username"] + "'";
            cs.exequery(rt);
        }
        else
        {
            string we = "select * from sharing where imageid='" + Session["sd"] + "'";
            DataSet fg = cs.exeadptor(we);
            if (fg.Tables[0].Rows.Count > 1)
            {
                string rt = "delete from sharing where imageid='" + Session["sd"] + "' and toname='" + Session["username"] + "'";
                cs.exequery(rt);
                string ee = "select * from sharing where imageid='" + Session["sd"] + "'";
                DataSet fdf = cs.exeadptor(ee);
                string podi = "update images set username='" + fdf.Tables[0].Rows[0][2] + "' where username='" + Session["username"] + "'";
                cs.exequery(podi);
                string zx = "update sharing set compare='1'where toname='" + fdf.Tables[0].Rows[0][2] + "'";
                cs.exequery(zx);
            }
            else
            {
                string rt = "delete from sharing where imageid='" + Session["sd"] + "' and toname='" + Session["username"] + "'";
                cs.exequery(rt);
                string oi = "delete from images where imageid='" + Session["sd"] + "'";
                cs.exequery(oi);
                string sdf = "delete from comment where imageid='" + Session["sd"] + "'";
                cs.exequery(sdf);
            }
        }

        Response.Redirect("frmInbox.aspx");



    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/User/home.aspx");

    }
}
