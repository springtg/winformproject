using System;
using System.IO;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class User_frmallfiles : System.Web.UI.Page
{
    Class1 cs = new Class1();

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {

            cmddownload.Visible = false;
            string s = "select * from images where inbox=0 and status=1 order by(hit) desc ";
            DataSet ds = cs.exeadptor(s);
            int m = Convert.ToInt32(ds.Tables[0].Rows.Count);
            for (int d = 1; d <= m; d++)
            {
                string sq = "update images set rank='" + d + "' where imageid='" + ds.Tables[0].Rows[d - 1][0] + "' and inbox=0 and status=1";
                int q = cs.exequery(sq);
            }
            string a = "select * from images where inbox=0 and status=1 order by(rank)  ";
            ds = cs.exeadptor(a);
            GridView1.DataSource = cs.ds;
            GridView1.DataBind();
        }
    }
    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "OK")
        {
            string s = "select image from images where imageid='" + (e.CommandArgument) + "'";
            DataSet ds1 = cs.exeadptor(s);
            Session["imagename"] = ds1.Tables[0].Rows[0][0].ToString();
            Image1.ImageUrl = ds1.Tables[0].Rows[0][0].ToString();
            string s1 = "update images set hit=hit+1 where imageid='" + e.CommandArgument + "' and status=1";
            int i = cs.exequery(s1);
            string s2 = "select * from images where status=1 order by(hit) desc";
            DataSet ds = cs.exeadptor(s2);
            int m = Convert.ToInt32(ds.Tables[0].Rows.Count);
            for (int d = 1; d <= m; d++)
            {
                string sq = "update images set rank='" + d + "' where imageid='" + ds.Tables[0].Rows[d - 1][0] + "' and status=1";
                int q = cs.exequery(sq);
            }

            cmddownload.Visible = true;


        }
    }

    protected void cmddownload_Click(object sender, EventArgs e)
    {
       
        string a = Session["imagename"].ToString();
        string aa = Server.MapPath(a);
       FileInfo fi = new FileInfo(a);
        Response.Write(fi.Name);
        Response.ClearHeaders();
            Response.ClearContent();
            Response.AddHeader("Content-Disposition", "attachment; filename=" + Path.GetFileName(fi.Name));
           Response.ContentType = "image/jpeg";
            Response.TransmitFile(aa);
            Response.End();
            
        
         
       }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/User/home.aspx");
    }
}


    