using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;


public partial class frmRegister : System.Web.UI.Page
{
    Class1 connect = new Class1();
    
    protected void Page_Load(object sender, EventArgs e)
    {
        Label13.Visible = false;
        int i;

        for (i = 1930; i < 2000; i++)
        {
            string ss = i.ToString();
            comboyear.Items.Add(ss);
        }
        for (i = 1; i < 32; i++)
        {
            string ss = i.ToString();
            combodate.Items.Add(ss);
        }
        comboyear.SelectedIndex = 0;
        combodate.SelectedIndex = 0;
    }


    protected void cmdsubmit_Click(object sender, EventArgs e)
    {
        string d = "select * from register where username='" + txtuname.Text  + "'";
        DataSet dss = connect.exeadptor(d);
        if (dss.Tables[0].Rows.Count > 0)
        {
            Label13.Visible = true;
            txtuname.Text = "";
            txtuname.Focus();
        }
        else
        {
                     
           Label13.Visible = false;
                string s = "insert into register values('" + txtuname.Text + "','" + txtfname.Text + "','" + txtlname.Text + "','" + gender.SelectedValue + "','" + txtemail.Text + "','" + combodate.SelectedItem.Value + "/" + combomonth.SelectedItem.Value + "/" + comboyear.SelectedItem.Value + "','" + txtcountry.Text + "','" + txtzcode.Text + "','2','" + System.DateTime.Now.ToShortDateString() + "','" + txtaddress.Text + "')";
                string s1= "insert into login values('" + txtuname.Text + "','" + txtpword.Text + "','2','" + System.DateTime.Now.ToShortDateString() + "')";
        
                if (txtpword.Text == txtrpword.Text)
            {
                int rtn = connect.exequery(s);
                connect.close();

                int c = connect.exequery(s1);
                connect.close();
                Response.Write("<script> window.alert('Saved');location.href='frmLogin.aspx'</script>");

                lblmess.Visible = false;
            }
            else
            {
                lblmess.Visible = true;
                lblmess.Text = "Wrong password";
            }


        }
    }
    protected void cmdreset_Click(object sender, EventArgs e)
    {
        Response.Redirect("frmRegister.aspx");
    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/User/home.aspx");

    }
}
