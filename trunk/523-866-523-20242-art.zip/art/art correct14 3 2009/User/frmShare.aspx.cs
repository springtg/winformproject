using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class User_frmShare : System.Web.UI.Page
{
    Class1 cs = new Class1();
    DataSet ds = new DataSet();
    protected void cmdadd_Click1(object sender, EventArgs e)
    {
        Session["a"] = Convert.ToInt32(Request.Params["imgid"]);
        foreach (GridViewRow gr in GridView1.Rows)
        {
            CheckBox ck = (CheckBox)gr.FindControl("chkSelect");
            if (ck.Checked)
            {
                string s = "insert into sharing values('" + Session["c"] + "','" + GridView1.DataKeys[gr.RowIndex].Value.ToString() + "',0,'" + System.DateTime.Now.ToShortDateString() + "')";
                int r=cs.exequery(s);
                Response.Write("<script> window.alert('Shared')</script>");
            }
        }




    }
    protected void Page_Load(object sender, EventArgs e)
    {
       
        if (!IsPostBack)
        {
            string s = "SELECT register.firstname,register.username,register.email,addressbook.address FROM register INNER JOIN addressbook ON addressbook.owner = '" + Session["username"] + "' AND register.username = addressbook.address";
            ds = cs.exeadptor(s);
            if (ds.Tables[0].Rows.Count > 0)
            {
                GridView1.DataSource = ds;
                GridView1.DataBind();
            }
            else
            {
            Response.Redirect("frmAddaddressbook.aspx");

            }

        }
    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        Response.Redirect("frmMyfiles.aspx");

    }
}
