using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class User_frmAddcomment : System.Web.UI.Page
{
    Class1 cs = new Class1();
    protected void Page_Load(object sender, EventArgs e)
    {
        txtcomment.Focus();

    }

    protected void cmdok_Click1(object sender, EventArgs e)
    {
        DataSet ds = new DataSet();
        int r;
        int b = Convert.ToInt32(Session["a"]);
        string s = "insert into comment values('" + b + "','" + txtcomment.Text + "','" + Session["username"] + "',0)"; ;

        string sa;
        string sd = "select * from comment where imageid='" + b + "'";
        ds = cs.exeadptor(sd);
        if ((ds.Tables[0].Rows.Count) > 9)
        {
            sa = "delete from comment where commentid='" + ds.Tables[0].Rows[0][0] + "'";
             int j = cs.exequery(sa);

            int i = cs.exequery(s);
            Response.Write("<script> window.alert('Added')</script>");
         
        }
        else
        {
            r = cs.exequery(s);
            Response.Write("<script> window.alert('Added')</script>");
        }
        txtcomment.Text = "";
        Response.Redirect("frmAllfiles.aspx");
    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        Response.Redirect("frmAllfiles.aspx");
    }
}
    
