using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class User_frmChangepassword : System.Web.UI.Page
{
    Class1 cs = new Class1();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            txtop.Focus();
            Label7.Visible = false;
            Label5.Visible = false;
        }
    }
    protected void cmdsubmit_Click(object sender, EventArgs e)
    {
        Label4.Visible = false;
        string ff="select * from login where username='"+Session["username"]+"'";
        DataSet dss = cs.exeadptor(ff);
        if (dss.Tables[0].Rows[0][1].ToString() !=txtop.Text)
        {
            Label7.Visible = true;
            txtop.Focus();
        }
        else
        {
            Label5.Visible = false;
            Label7.Visible = false;
            if (txtcpword.Text == txtpword.Text)
            {
                string s = "update login set upassword='" + txtcpword.Text + "' where username='" + Session["username"] + "'";
                int i = cs.exequery(s);
                if (i > 0)
                {
                    Label4.Text = "Password changed successfully";
                    Label4.Visible = true;
                    Session["ua"] = txtcpword.Text;
                    txtpword.Text = "";
                    txtcpword.Text = "";
                    

                }
            }
            else
            {
                Label5.Visible = true;
                txtcpword.Text = "";
                txtcpword.Focus();


            }

        }
    }
    protected void cmdreset_Click(object sender, EventArgs e)
    {
        Label5.Visible = false ;
        Label4.Visible = false;
        txtpword.Text = "";
        txtcpword.Text = "";
        txtop.Text = "";
        Label7.Visible = false;
        txtpword.Focus();

    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/User/home.aspx");
    }
}
