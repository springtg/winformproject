using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class login : System.Web.UI.Page
{
    Class1 connect = new Class1();
    protected void Page_Load(object sender, EventArgs e)
    {
        Label4.Text = "Invalid username and password";
        textuser.Focus();
        Label4.Visible = false;
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Label4.Visible = false;
        string s = "SELECT * FROM login WHERE (username = '"+textuser.Text+"') AND (upassword = '"+textpass.Text+"')";
        DataSet dss = new DataSet();
        dss = connect.exeadptor(s);
        if (dss.Tables[0].Rows.Count > 0)
        {
            if (dss.Tables[0].Rows[0][2].Equals(2))
            {

                Session["username"] = textuser.Text;
                string sd = "update login set logindate='" + System.DateTime.Now.ToShortDateString() + "' where username='" + Session["username"] + "'";
                connect.exequery(sd);
                Response.Redirect("~/User/home.aspx");

            }
            else

                Response.Redirect("~/admin/homeadm.aspx");
        }
        else
            Label4.Visible = true; 
        textuser.Text = "";
        textpass.Text = "";
        textuser.Focus();
          
      }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/User/home.aspx");

    }
}
