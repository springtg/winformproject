using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class User_frmAddaddbook : System.Web.UI.Page
{
    Class1 cs = new Class1();
    DataSet ds = new DataSet();
    protected void Page_Load(object sender, EventArgs e)

    {
 if (!IsPostBack)
        {
            fill();

        }
   
    }
    void fill()
    {
        string s = "SELECT register.firstname,register.lastname,register.email,addressbook.address FROM register INNER JOIN addressbook ON addressbook.owner = '" + Session["username"] + "' AND register.username = addressbook.address";
        ds = cs.exeadptor(s);
        if (ds.Tables[0].Rows.Count > 0)
        {
            GridView1.DataSource = ds;
            GridView1.DataBind();
        }
        else
        {
            Response.Write("<script> window.alert('There is no friends,please add your friends');location.href='frmAddaddressbook.aspx'</script>");

        }
    }
   

    protected void cmdadd_Click(object sender, EventArgs e)
    {
        Response.Redirect("frmAddaddressbook.aspx");
    }

    
    protected void cmddelete_Click(object sender, EventArgs e)
    {

        string s;
        foreach (GridViewRow gr in GridView1.Rows)
        {
            CheckBox ck = (CheckBox)gr.FindControl("chkSelect");
            if (ck.Checked)
            {
                s = "delete from addressbook where owner='" + Session["username"] + "' and address='" + GridView1.DataKeys[gr.RowIndex].Value + "'";
                cs.exequery(s);
            }
        }
        fill();
    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/User/home.aspx");

    }
}


  
   
