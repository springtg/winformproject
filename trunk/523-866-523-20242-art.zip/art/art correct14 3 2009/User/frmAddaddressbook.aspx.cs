using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class addaddressbook : System.Web.UI.Page
{
    Class1 cs = new Class1();
    DataSet ds = new DataSet();

    protected void Page_Load(object sender, EventArgs e)
    {

        if (!IsPostBack)
        {
            string s = "select * from register where username not in(select address from addressbook where owner='" + Session["username"] + "')and username!='" + Session["username"] + "'";
            ds = cs.exeadptor(s);
            GridView1.DataSource = ds;
            GridView1.DataBind();

        }
    }



    protected void cmdok_Click1(object sender, EventArgs e)
    {

        foreach (GridViewRow gr in GridView1.Rows)
        {
            CheckBox ck = (CheckBox)gr.FindControl("chkSelect");
            if (ck.Checked)
            {
                string s = "insert into addressbook values('" + Session["username"] + "','" + GridView1.DataKeys[gr.RowIndex].Value.ToString() + "')";
                cs.exequery(s);
                Response.Write("<script> window.alert('Added');location.href='frmAddaddressbook.aspx'</script>");
            }
        }
}

    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        Response.Redirect("frmViewaddbook.aspx");
    }
}
