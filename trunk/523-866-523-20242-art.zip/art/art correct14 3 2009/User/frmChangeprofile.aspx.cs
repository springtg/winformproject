using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class Change : System.Web.UI.Page
{
    Class1 connect = new Class1();
    protected void Page_Load(object sender, EventArgs e)
    {
        Label3.Visible = false;
     

        if (!IsPostBack)
        {
            string s = "select * from register where username='" + Session["username"] + "'";
            connect.exereader(s);
            if (connect.dr.Read())
            {
                txtuname.Text = connect.dr.GetString(0);
                txtfname.Text = connect.dr.GetString(1);
                txtlname.Text = connect.dr.GetString(2);
                gender.SelectedValue = connect.dr.GetString(3);
                txtemail.Text = connect.dr.GetString(4);
                txtcountry.Text = connect.dr.GetString(6);
                txtzcode.Text = connect.dr.GetInt32(7).ToString();
                txtaddress.Text = connect.dr.GetString(10);

            }


        }
    }


    protected void cmdsubmit_Click1(object sender, EventArgs e)
    {
        string d = "select * from register where username='" + txtuname.Text + "' and username!='"+Session["username"]+"'";
       DataSet dss = connect.exeadptor(d);
       if (dss.Tables[0].Rows.Count > 0)
       {
           Label3.Visible = true;
           txtuname.Text = "";
           txtuname.Focus();
       }
       else
       {
           Label3.Visible = false;
           string s1,s2;
           s1 = "update register set username='" + txtuname.Text + "',firstname='" + txtfname.Text + "',lastname='" + txtlname.Text + "',gender= '" + gender.SelectedValue + "',email='" + txtemail.Text + "',country='" + txtcountry.Text + "',zipcode='" + txtzcode.Text + "',address='" + txtaddress.Text + "' where username='" + Session["username"] + "'";
           s2 = "update login set username='" + txtuname.Text + "' where username='" + Session["username"] + "'";
           connect.exequery(s1);
           connect.exequery(s2);
           Response.Write("<script> window.alert('Changed')</script>");
           Session["username"] = txtuname.Text;

       }
    }


    protected void cmdchange_Click(object sender, EventArgs e)
    {
        Response.Redirect("frmChangepassword.aspx");
    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/User/home.aspx");
    }
}
