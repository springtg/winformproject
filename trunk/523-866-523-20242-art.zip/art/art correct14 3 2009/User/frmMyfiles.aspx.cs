using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.IO;


public partial class User_frmMyfiles : System.Web.UI.Page
{
    Class1 cs = new Class1();
    DataSet ds = new DataSet();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {

            string s = "select categoryname from category";
            ds = cs.exeadptor(s);
            combocategory.DataSource = ds;
            combocategory.DataBind();
            string s1 = "select * from images where username='" + Session["username"] + "' and categoryid=(select categoryid from category where categoryname='"+combocategory.SelectedValue.ToString()+"') and status=1 ";
            DataSet dss = cs.exeadptor(s1);
            GridView1.DataSource = dss;
            GridView1.DataBind();

        }
    }


    protected void combocategory_SelectedIndexChanged(object sender, EventArgs e)
    {
        Image1.Visible = false;
        int i;
        string s2 = "select categoryid from category where categoryname='" + combocategory.SelectedValue.ToString() + "'";
        DataSet ds1 = cs.exeadptor(s2);
        i = Convert.ToInt32(ds1.Tables[0].Rows[0][0]);
        string s1 = "select * from images where username='" + Session["username"] + "'and categoryid='" + i + "'and inbox=0 and status=1 order by(rank)";
        DataSet dss = cs.exeadptor(s1);
        GridView1.DataSource = dss;
        GridView1.DataBind();
    }
    protected void cmdadd_Click(object sender, EventArgs e)
    {
        Response.Redirect("frmImgupload.aspx");
    }
    protected void cmdshare_Click(object sender, EventArgs e)
    {
        Response.Redirect("frmShare.aspx");

    }

    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "OK")
        {
            Image1.Visible = true;
            Session["c"] = Convert.ToInt32(e.CommandArgument);
            string s = "select image from images where imageid='" + (e.CommandArgument) + "'";
            DataSet ds1 = cs.exeadptor(s);
            Image1.ImageUrl = ds1.Tables[0].Rows[0][0].ToString();
            
           
        }
    }

    protected void cmddelete_Click(object sender, EventArgs e)
    {
        string h = "select * from sharing where imageid='" + Session["c"] + "'";
        DataSet f = cs.exeadptor(h);
        if (f.Tables[0].Rows.Count > 0)
        {
            string d = "update images set username='" + f.Tables[0].Rows[0][2] + "',inbox=1 where imageid='" + Session["c"] + "'";
            cs.exequery(d);
            string w = "update sharing set compare='1' where toname='" + f.Tables[0].Rows[0][2] + "'";
            cs.exequery(w);
            string sdf = "delete from comment where imageid='" + Session["c"] + "'";
            cs.exequery(sdf);
        }
        else
        {
            string s2 = "select image from images where imageid='" + Session["c"] + "'";
            DataSet dss = cs.exeadptor(s2);
            string s3 = dss.Tables[0].Rows[0][0].ToString();
            string c = "delete from images where imageid='" + Session["c"] + "'";
            cs.exequery(c);
            string sdf = "delete from comment where imageid='" + Session["c"] + "'";
            cs.exequery(sdf);
            s3 = s3.Replace("~/image/", "");
            s3.Replace("'", "");

            DirectoryInfo dr = new System.IO.DirectoryInfo(Server.MapPath("~/image"));

            FileInfo[] finfo = dr.GetFiles();

            foreach (FileInfo fi in finfo)
            {

                if (fi.Name.Equals(s3))
                    fi.Delete();


            }

        }
        string s = "select * from images where inbox=0 and status=1 order by(hit) desc ";
        DataSet ds = cs.exeadptor(s);
        int m = Convert.ToInt32(ds.Tables[0].Rows.Count);
        for (int d = 1; d <= m; d++)
        {
            string sq = "update images set rank='" + d + "' where imageid='" + ds.Tables[0].Rows[d - 1][0] + "' and status=1 ";
            int q = cs.exequery(sq);
        }
        Response.Redirect("frmMyfiles.aspx");  
       

    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/User/home.aspx");

    }
}