using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class MspAlogin : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        

    }
   
    protected void lnkprofile_Click1(object sender, EventArgs e)
    {
        Response.Redirect("~/User/frmMyfiles.aspx");
    }
    protected void lnkInbox_Click1(object sender, EventArgs e)
    {
        Response.Redirect("~/User/frmInbox.aspx");
    }
    

    protected void lnkAddressbok_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/User/frmViewaddbook.aspx");
    }
    protected void lnkAllfiles_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/User/frmAllfiles.aspx");
    }
    
    protected void lnkSuggestions_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/User/frmFeedback.aspx");
    }
    protected void lnklogout_Click(object sender, EventArgs e)
    {
        Session["username"]=" ";
        Response.Redirect("~/viewers/frmHomepage.aspx");
    }
    protected void lnkchangeprofile_Click1(object sender, EventArgs e)
    {
        Response.Redirect("~/User/frmChangeprofile.aspx");
    }
    protected void lnkhome_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/viewers/frmHomepage.aspx");
    }
}
