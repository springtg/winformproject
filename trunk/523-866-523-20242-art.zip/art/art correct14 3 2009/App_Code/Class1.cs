using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Collections;
 
/// <summary>
/// Summary description for Class1
/// </summary>
public class Class1
{
    public SqlConnection con;
    public SqlCommand cmd;
    public SqlDataReader dr;
    public SqlDataAdapter adp;
    public DataSet ds;

    public Class1()
    {
      //  con = new SqlConnection("Data Source=CLIENT2;Initial Catalog=artgallery;User ID=sa;Password=info");
        con = new SqlConnection(@"Data Source=CLIENT5\SQLEXPRESS;Initial Catalog=artgallery;User ID=sa;Password=info");
       
    }
    //public void Connect()
    //{
    //   con = new SqlConnection("Data Source=CLIENT2\\SQLEXPRESS;Initial Catalog=artgallery;User ID=sa;Password=info");
    //   con.Open();
       
    //}
    public int exequery(string query)
    {
     
        cmd = new SqlCommand(query, con);
        con.Open();
       int i  = cmd.ExecuteNonQuery();
        con.Close();
        return (i);
        
    }
    public DataSet exeadptor(string query)
    {
        ds = new DataSet();
        con.Open();
        adp = new SqlDataAdapter(query, con);
        adp.Fill(ds);
        con.Close();
        return (ds);
      

    }
    public SqlDataReader exereader(string query)
    {
        cmd = new SqlCommand(query, con);
        con.Open();
        dr = cmd.ExecuteReader();
     
        return (dr);
    }
    public void close()
{
    con.Close();
}
    
}