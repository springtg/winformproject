using System;
using System.IO;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class admin_frmCheck : System.Web.UI.Page
{
    Class1 cs = new Class1();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {

            string d = "select * from images where status=0";
            DataSet x = cs.exeadptor(d);
            if (x.Tables[0].Rows.Count > 0)
            {
                GridView1.DataSource = x;
                GridView1.DataBind();
            }
            else
            {
                cmdaccept.Visible = false;
                cmddelete.Visible = false;
                Image1.Visible = false;
            }
        }
    }
    protected void cmdaccept_Click(object sender, EventArgs e)
    {
        foreach (GridViewRow gr in GridView1.Rows)
        {
            CheckBox ck = (CheckBox)gr.FindControl("chk");
            if (ck.Checked)
            {
                string s = "update images set status=1 where imageid='"+GridView1.DataKeys[gr.RowIndex].Value.ToString()+"'";
                cs.exequery(s);
                Response.Redirect("frmCheck.aspx");
                
            }
        }
    }
    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "OK")
        {
            string s = "select image from images where imageid='" + (e.CommandArgument) + "'";
            DataSet ds1 = cs.exeadptor(s);
            Image1.ImageUrl = ds1.Tables[0].Rows[0][0].ToString();
            Session["xyz"] = Convert.ToInt32(e.CommandArgument);

            
        }
    }
   
    protected void cmddelete_Click1(object sender, EventArgs e)
    {
        string s2 = "select image from images where imageid='" + Session["xyz"] + "'";
        DataSet dss = cs.exeadptor(s2);
        string s3 = dss.Tables[0].Rows[0][0].ToString();
        string s = "delete from  images where imageid='" + Session["xyz"] + "'";
        cs.exequery(s);
        s3 = s3.Replace("~/image/", "");
        s3.Replace("'", "");

        DirectoryInfo dr = new System.IO.DirectoryInfo(Server.MapPath("~/image"));

        FileInfo[] finfo = dr.GetFiles();

        foreach (FileInfo fi in finfo)
        {

            if (fi.Name.Equals(s3))
                fi.Delete();


        }
        Response.Redirect("frmCheck.aspx");
      
    }
    protected void cmdchk_Click(object sender, EventArgs e)
    {
        Response.Redirect("frmCheckcomment.aspx");
    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/admin/homeadm.aspx");
    }
}