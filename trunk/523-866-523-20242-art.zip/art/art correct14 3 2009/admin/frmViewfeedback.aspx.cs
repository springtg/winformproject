using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.IO;

public partial class admin_frmViewfeedback : System.Web.UI.Page
{
    Class1 cs = new Class1();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            string s = "select * from feed where status=0";
            DataSet m = cs.exeadptor(s);
            if (m.Tables[0].Rows.Count > 0)
            {
                GridView1.DataSource = m;
                GridView1.DataBind();
            }
            else 
            {
                cmdok.Visible = false;
            }
        }

    }


    protected void cmdok_Click(object sender, EventArgs e)
    {

        foreach (GridViewRow gr in GridView1.Rows)
        {
            CheckBox ck = (CheckBox)gr.FindControl("chk");
            if (ck.Checked)
            {
                string s = "update feed set status=1 where slno='" + GridView1.DataKeys[gr.RowIndex].Value + "'";
                cs.exequery(s);
                Response.Redirect("frmViewfeedback.aspx");
               
            }
        }
    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/admin/homeadm.aspx");
    }
}