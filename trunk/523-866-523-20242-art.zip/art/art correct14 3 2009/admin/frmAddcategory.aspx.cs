using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class admin_frmAddcategory : System.Web.UI.Page
{
    Class1 cs = new Class1();
    protected void Page_Load(object sender, EventArgs e)
    {
        txtcategory.Focus();
    }
    protected void cmdok_Click(object sender, EventArgs e)
    {
        string s = "insert into category values('" + txtcategory.Text + "')";
        int a = cs.exequery(s);
        txtcategory.Text="";

        Response.Write("<script> window.alert('Added')</script>");
    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        Response.Redirect("frmDeletecategory.aspx");
    }
}
