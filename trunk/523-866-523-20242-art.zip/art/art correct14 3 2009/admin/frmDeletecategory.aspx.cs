using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class admin_frmAddcategory : System.Web.UI.Page
{
    Class1 cs=new Class1 ();
    DataSet ds = new DataSet();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack == true)
        {
            string s = "select categoryname from category where categoryid!=17 ";
            ds = cs.exeadptor(s);
            if (ds.Tables[0].Rows.Count > 0)
            {
                combocategory.DataSource = ds;
                combocategory.DataBind();
            }
            else
            {
                Response.Write("<script> window.alert('There is no categories');location.href='frmAddcategory.aspx'</script>");
            }
        }
    }
    protected void cmddelete_Click(object sender, EventArgs e)
    {
        string m = "select categoryid from category where categoryname='" + combocategory.SelectedItem.Value + "'";
        DataSet sd = cs.exeadptor(m);
       int n = Convert.ToInt32(sd.Tables[0].Rows[0][0]);
        string d = "update images set categoryid='17' where categoryid='" +n+ "'";
        int r = cs.exequery(d);
      
        string s = "delete from category where categoryname='" + combocategory.SelectedItem.Value  + "'";
       int a= cs.exequery(s);
       Response.Write("<script> window.alert('Deleted')</script>");
       if (a > 0)
       {
           Response.Redirect("frmDeletecategory.aspx");

       }

    }
    protected void cmdadd_Click(object sender, EventArgs e)
    {
        Response.Redirect("frmAddcategory.aspx");
    }
    protected void combocategory_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/admin/homeadm.aspx");
    }
}
