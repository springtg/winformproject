using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.IO;


public partial class admin_frmDeleteimage : System.Web.UI.Page
{
    Class1 cs = new Class1();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            Session["b"] = Convert.ToInt32(Request.Params["imgid"]);
            fill();

           
        }
    }
    void fill()
    {
        string s = "select comment.comment,register.email from comment,register where comment.fromname=register.username and comment.imageid='" + Session["b"] + "'and comment.status=1";
        DataSet ds = cs.exeadptor(s);
        if (ds.Tables[0].Rows.Count > 0)
        {
            GridView1.DataSource = ds;
            GridView1.DataBind();
        }
        else
        {
            Response.Write("<script> window.alert('There is no comments');location.href='frmAdminallimage.aspx'</script>");

        }
    }
    protected void cmddelete_Click(object sender, EventArgs e)
    {

        string s2 = "select image from images where imageid='" + Session["b"] + "'";
        DataSet dss = cs.exeadptor(s2);
        string s3 = dss.Tables[0].Rows[0][0].ToString();
        string c = "delete from images where imageid='" + Session["b"] + "'";
        int i = cs.exequery(c);
        string sdf = "delete from comment where imageid='" + Session["b"] + "'";
        cs.exequery(sdf);
        string sd = "delete from sharing where imageid='" + Session["b"] + "'";
        cs.exequery(sd);
        fill();
        s3 = s3.Replace("~/image/", "");
        s3.Replace("'", "");

        DirectoryInfo dr = new System.IO.DirectoryInfo(Server.MapPath("~/image"));

        FileInfo[] finfo = dr.GetFiles();

        foreach (FileInfo fi in finfo)
        {

            if (fi.Name.Equals(s3))
                fi.Delete();


        }
        Response.Write("<script> window.alert('Deleted')</script>");
        Response.Redirect("frmAdminallimage.aspx");

       

    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        Response.Redirect("frmAdminallimage.aspx");
    }
}
