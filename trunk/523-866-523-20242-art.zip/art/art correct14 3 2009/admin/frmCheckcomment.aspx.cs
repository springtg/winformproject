using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class admin_frmCheckcomment : System.Web.UI.Page
{
    Class1 cs = new Class1();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            string s = "select * from comment where status=0";
            DataSet m = cs.exeadptor(s);
            if (m.Tables[0].Rows.Count > 0)
            {
                GridView1.DataSource = m;
                GridView1.DataBind();
            }
            else
            {

                cmdaccept.Visible = false;
                cmddelete.Visible = false;
                Response.Write("<script> window.alert('There is no comments');location.href='frmCheck.aspx'</script>");

            }
        }
    }
    protected void cmdaccept_Click(object sender, EventArgs e)
    {
        foreach (GridViewRow gr in GridView1.Rows)
        {
            CheckBox ck = (CheckBox)gr.FindControl("chk");
            if (ck.Checked)
            {
                string s = "update comment set status=1 where commentid='" + GridView1.DataKeys[gr.RowIndex].Value + "'";
                cs.exequery(s);
                Response.Redirect("frmCheckcomment.aspx");

            }
        }
    }
    

    
    protected void cmddelete_Click1(object sender, EventArgs e)
    {
        foreach (GridViewRow gr in GridView1.Rows)
        {
            CheckBox ck = (CheckBox)gr.FindControl("chk");
            if (ck.Checked)
            {
                string s1 = "delete from comment where commentid='" + GridView1.DataKeys[gr.RowIndex].Value + "'";
                cs.exequery(s1);
                Response.Write("KK");
                Response.Redirect("frmCheckcomment.aspx");

            }
        }

    }
    protected void Back_Click(object sender, EventArgs e)
    {
        Response.Redirect("frmCheck.aspx");
    }
}
