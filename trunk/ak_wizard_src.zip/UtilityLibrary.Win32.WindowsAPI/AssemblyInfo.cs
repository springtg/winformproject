using System.Reflection;
using System.Runtime.CompilerServices;


[assembly: AssemblyTitle(           "Utility Library Controls Win32 API Core" )]
[assembly: AssemblyDescription(     "Library with Office XP style controls" )]
[assembly: AssemblyConfiguration(   "" )]
[assembly: AssemblyCompany(         "ELEKS Software Ltd." )]
[assembly: AssemblyProduct(         "Team Professional" )]
[assembly: AssemblyCopyright(       "2002-2003 (c) ELEKS Software Ltd." )]
[assembly: AssemblyTrademark(       "Team Professional" )]
[assembly: AssemblyCulture(         "" )]   
[assembly: AssemblyVersion(         "1.0.4.0" )]

[assembly: AssemblyDelaySign( false )]
[assembly: AssemblyKeyFile( "..\\..\\Strong Keys\\utilitylibstrongkey.snk" )]
[assembly: AssemblyKeyName( "" )]

