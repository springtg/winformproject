using System;
using System.Drawing.Design;
using System.Windows.Forms.Design;

namespace UtilityLibrary.Designers
{
  public class ToolBarExDesigner : ParentControlDesigner
  {
  }
}
