﻿namespace CornerBowl.Forms
{
    partial class CBPopupHelpCtrl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.SuspendLayout();
            // 
            // CBPopupHelpCtrl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::CornerBowl.Forms.Properties.Resources.help;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.MaximumSize = new System.Drawing.Size(16, 16);
            this.MinimumSize = new System.Drawing.Size(16, 16);
            this.Name = "CBPopupHelpCtrl";
            this.Size = new System.Drawing.Size(16, 16);
            this.MouseLeave += new System.EventHandler(this.PopupHelpCtrl_MouseLeave);
            this.EnabledChanged += new System.EventHandler(this.CBPopupHelpCtrl_EnabledChanged);
            this.MouseEnter += new System.EventHandler(this.PopupHelpCtrl_MouseEnter);
            this.ResumeLayout(false);

        }

        #endregion
    }
}
