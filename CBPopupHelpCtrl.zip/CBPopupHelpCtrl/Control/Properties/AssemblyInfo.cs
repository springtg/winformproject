﻿using System.Reflection;

[assembly: AssemblyTitle("Popup Help Control")]
[assembly: AssemblyDescription("Open source popup help control")]
[assembly: AssemblyCompany("Corner Bowl Software Corporation")]
[assembly: AssemblyProduct("Corner Bowl Popup Help Control")]
[assembly: AssemblyCopyright("Copyright (c) 2010 Corner Bowl Software Corporation\r\nAll Rights Reserved")]
[assembly: AssemblyVersion("1.0.0.0")]