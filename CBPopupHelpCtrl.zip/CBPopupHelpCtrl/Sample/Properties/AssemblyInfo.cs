﻿using System.Reflection;

[assembly: AssemblyTitle("Popup Help Control Test Application")]
[assembly: AssemblyDescription("Open source popup help control test application")]
[assembly: AssemblyCompany("Corner Bowl Software Corporation Test Application")]
[assembly: AssemblyProduct("Corner Bowl Popup Help Control")]
[assembly: AssemblyCopyright("Copyright (c) 2010 Corner Bowl Software Corporation\r\nAll Rights Reserved")]
[assembly: AssemblyVersion("1.0.0.0")]