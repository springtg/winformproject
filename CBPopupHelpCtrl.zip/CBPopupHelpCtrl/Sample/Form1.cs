﻿using System;
using System.Windows.Forms;

namespace CBHelpPopupCtrlTest
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();            

            txtTitle.Text = ctrl.TitleText;
            txtMessage.Text = ctrl.MessageText;
            propertyGrid.SelectedObject = ctrl;
        }

        private void Form1_HelpRequested(object sender, HelpEventArgs hlpevent)
        {
            MessageBox.Show(this, "Help Requested", Application.ProductName);
        }

        private void txtTitle_TextChanged(object sender, EventArgs e)
        {
            ctrl.TitleText = txtTitle.Text;
        }

        private void txtMessage_TextChanged(object sender, EventArgs e)
        {
            ctrl.MessageText = txtMessage.Text;
        }
    }
}
